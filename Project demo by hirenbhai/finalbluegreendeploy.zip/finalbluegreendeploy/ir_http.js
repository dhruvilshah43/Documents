//load configuration data
config = module.exports = require("./config.json");
fs  = module.exports = require('graceful-fs');
md5 = module.exports = require('MD5'); 
FB  = module.exports = require('fb');
express = module.exports = require('express');
crypto = module.exports = require('crypto');
https = module.exports = require("https");
rq = module.exports = require('request');
request = module.exports = rq;
schedule = module.exports = require('node-schedule');

var http = require('http')
    , path = require('path')
    , redis = require('redis')
    , amqp = require('amqp')
    , mongod = require('mongodb');

        //some global array & logger defination start 
        //dataCodesArr = module.exports = new Array();

        dataCodesArr =  new Array();
        SERVICE_HOST =  '192.168.0.194'; //game host url
        SERVER_PROTO =  'https';
        SERVER_ID    =  'httpServer';
        SERVER_PORT  =   3000;

        //SERVER_PORT  = module.exports = typeof process.argv[3]!='undefined'?process.argv[3] : 3000;
        //SERVER_ID    = module.exports = 'httpServer';
        //REDIS_DB       = module.exports = config.REDIS_DB;
        //SERVER_PROTO = module.exports = typeof process.argv[2]!='undefined'?process.argv[2] : 'https';
        REDIS_DB         =  config.REDIS_DB;
        REDIS_CONFIG =  { host :config.RDS_HOST , password : config.RDS_AUTH, port : 6379 };
        RBMQ_CONFIG  =  { host : config.RMQ_HOST, login : config.RMQ_LOGIN, password : config.RMQ_PASSWORD, vhost : config.RMQ_VHOST};
       

        //REDIS_DB         = module.exports = config.REDIS_DB;

        //RBMQ_CONFIG  = module.exports = { host : '54.164.101.117', login : 'indianrummy', password : 'indianrummy', vhost : 'idianrummy'};
        //RBMQ_CONFIG  = module.exports = { host : config.RMQ_HOST, login : config.RMQ_LOGIN, password : config.RMQ_PASSWORD, vhost : config.RMQ_VHOST};

        //REDIS_CONFIG = module.exports = { host : "54.164.101.117", password : 'gG4{m>&sQMm9Rbh', port : 6379 };
        //REDIS_CONFIG = module.exports = { host :config.RDS_HOST , password : config.RDS_AUTH, port : 6379 };

        c = module.exports = function(arr){ 
                if(config.DEBUG){
                        for(var i = 0; i < arguments.length; i++)
                                console.log(arguments[i]);
                } 
        };


        /*=========================================================
                                        Start HTTPS Server
        ===========================================================*/
        var httpsOptions = {  key: fs.readFileSync('certificate/artoon.key'), cert: fs.readFileSync('certificate/artoon.crt') };
        app = module.exports = express();
        var secureServer = https.createServer(httpsOptions, app);
        if(SERVER_PROTO == 'http')
        {

                var server = http.createServer(app);
                server.listen(SERVER_PORT);

        }
        else {
                secureServer.listen(SERVER_PORT);
        }


        console.log(SERVER_PROTO +' server start on '+SERVER_PORT);

        /*=========================================================
                                HTTPS Server setup code finish
        ===========================================================*/

        /*=========================================================
                                        Include all required modules.
        ===========================================================*/
        urlHanlder       = module.exports = require('./classes/urlHandler.class.js');
        urlHanlder.BindWithCluster();

        commonClass      = module.exports = require("./classes/common.class.js"); //common functions
        cdClass                  = module.exports = require("./classes/commonData.class.js"); //common Data functions
        FBClass                  = module.exports = require("./classes/FB.class.js");
        FBStoryClass     = module.exports = require("./classes/FBStory.class.js");
        notificationClass= module.exports = require("./classes/notification.class.js");
        trackClass               = module.exports = require("./classes/track.class.js");
        paymentClass     = module.exports = require("./classes/payment.class.js");
        amqpClass                = module.exports = require("./classes/amqp.class.js");
        trackClass               = module.exports = require("./classes/track.class.js");
        chatClass                = module.exports = require("./classes/chat.class.js");
        bonusClass               = module.exports = require("./classes/bonus.class.js");
        /*=========================================================
                                        Module inclusion finish here.
        ===========================================================*/




        /*=========================================================
                                Redis server configuration start here..
        ===========================================================*/
        rClient = module.exports = redis.createClient(REDIS_CONFIG.port, REDIS_CONFIG.host);
        rClient.auth(REDIS_CONFIG.password, function(){ }); //redis authentication
        rClient.select(REDIS_DB);
        rClient.on("error", function (rerr) {
                console.log('\n rClient ---------------------------> Redis exception : ',rerr);
        })
        /*=========================================================
                                Redis server configuration start here..
        ===========================================================*/




        /*=========================================================
                                        RabbitMq server setup start
        ===========================================================*/
        rabbitConn = module.exports = amqp.createConnection(RBMQ_CONFIG);
        rabbitConn.on('ready', function () {
                console.log('rabit connected !!!');
                playExchange = module.exports = rabbitConn.exchange('pe', {'type': 'topic'});
                userExchange = module.exports = rabbitConn.exchange('ue', {'type': 'direct', autoDelete : false, durable: true});
                jobExchange  = module.exports = rabbitConn.exchange('jb', {'type': 'topic'});

        });
        rabbitConn.on('error', function (e){
                console.log("rabbit connection error >> ", e);
        });
        /*=========================================================
                                RabbitMq server setup finish here
        ===========================================================*/


        /*=========================================================
                                Mongo Db connection start here.
        ===========================================================*/
        var MongoClient = mongod.MongoClient;
        MongoID = module.exports = mongod.ObjectID; //reporting conversion class instavle to global for convert string to object
        console.log('mongodb url:','mongodb://'+config.DB_USERNAME+':'+config.DB_PASSWORD+'@'+config.DB_HOST+':'+config.DB_PORT+'/'+config.DB_NAME);
        MongoClient.connect('mongodb://'+config.DB_USERNAME+':'+config.DB_PASSWORD+'@'+config.DB_HOST+':'+config.DB_PORT+'/'+config.DB_NAME,function(err, dClient){  
          if(err){
                console.log('mongodb error: ', err);
          } 
          else{
                db = module.exports = dClient.db(config.DB_NAME);
                console.log('http +-> database connected successfully!!!');
                //cClass = module.exports = require("./classes/cardLogic.class.js");
                //c(cClass.CheckForSingleSpread(["F-12","F-13","F-1"], "F-2"));

                if(SERVER_ID == 'httpServer'){
                        setInterval(function(){ cdClass.AutoRepairTable() },7200000 );
                        setInterval(function(){ cdClass.RepairOnlineUser() }, 36000000);
                        setInterval(function(){ trackClass.monitorUsers() }, 5000);
                        cdClass.RepairOnlineUser();
                }
          }
        });
        /*=========================================================
                                Mongod Db connection Ends.
        ===========================================================*/


process.on('unhandledRejection', (reason, p) => {
    console.log(reason, ' >>>>>>>>>>>>>>>> 11 Unhandled Rejection at Promise >>>>>>>>>>>>>>>>>>>> ', p);
});
process.on('uncaughtException', err => {
        console.log(err, ' >>>>>>>>>>>>>>>>>>>>>> 11 Uncaught Exception thrown >>>>>>>>>>>>>');
});