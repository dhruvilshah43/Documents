//load configuration
config =  require("./config.json");
commaNumber =  require('comma-number');
fs  =  require('graceful-fs');
md5 =  require('MD5'); 
FB  =  require('fb');
express = require('express');
crypto =  require('crypto');  //deprecated inbulid in node 
cryptoJs =  require('crypto-js');
https =  require("https");
request =  require('request'); 
rq =  request;
iplocation = require('iplocation');
base64 = require('base-64');
_ =  require('underscore');
countrynames =  require('countrynames');
schedule = require('node-schedule');


var http = require('http');
var redis = require('redis');
var amqp = require('amqp');
var mongod = require('mongodb');

//some global array & logger defination start 
dataCodesArr =  new Array();
SERVICE_HOST =  '15.206.124.182'; //game host url
SERVER_PROTO =  'https';
SERVER_ID    =  'httpServer';
SERVER_PORT  =   3000;

REDIS_DB         =  config.REDIS_DB;

RBMQ_CONFIG  =  { host : config.RMQ_HOST, login : config.RMQ_LOGIN, password : config.RMQ_PASSWORD, vhost : config.RMQ_VHOST};
REDIS_CONFIG =  { host :config.RDS_HOST , password : config.RDS_AUTH, port : 6379 };

c = module.exports = function(arr){ 
	if(config.DEBUG){
		for(var i = 0; i < arguments.length; i++)
			console.log(arguments[i]);
	} 
};

/*=========================================================
					Start HTTPS Server
===========================================================*/

var httpsOptions = {  key: fs.readFileSync('certificate/artoon.key'), cert: fs.readFileSync('certificate/artoon.crt') };
app = express();

var secureServer = https.createServer(httpsOptions, app);

if(SERVER_PROTO == 'http')
{
	
	var server = http.createServer(app);		
	server.listen(SERVER_PORT);
	
}
else {
	secureServer.listen(SERVER_PORT);
}

c(SERVER_PROTO +' server start on '+SERVER_PORT);

/*=========================================================
				HTTPS Server setup code finish
===========================================================*/




/*=========================================================
					Include all required modules.
===========================================================*/

urlHandler = require('./classes/urlHandler.class.js');
amqpClass =  require("./classes/amqp.class.js");
commonClass =  require("./classes/common.class.js"); //common functions
cdClass  =  require("./classes/commonData.class.js"); //common Data functions
trackClass =  require("./classes/track.class.js");
signupClass =  require("./classes/signup.class.js");
dashboardClass =  require("./classes/dashboard.class.js");
playClass =  require("./classes/play.class.js");
notiClass =  require("./classes/notification.class.js");
fbClass =  require("./classes/feedback.class.js");
FBClass =  require("./classes/FB.class.js");
/*paymentClass =  require("./classes/payment.class.js");
strClass =  require("./classes/store.class.js");
ppClass = require("./classes/phonePe.class.js");
langClass = require("./classes/language.class.js");*/

/*=========================================================
					Module inclusion finish here.
===========================================================*/



/*=========================================================
				Redis server configuration starts here..
===========================================================*/

rClient =  redis.createClient(REDIS_CONFIG.port, REDIS_CONFIG.host);
rClient.auth(REDIS_CONFIG.password, function(){ }); //redis authentication
rClient.select(REDIS_DB);
rClient.on('error',function(err){
	console.log('redis :::::::::::: Error: ',err);
});

/*=========================================================
				Redis server configuration ends here..
===========================================================*/


/*=========================================================
					RabbitMq server setup start
===========================================================*/

rabbitConn = amqp.createConnection(RBMQ_CONFIG);
rabbitConn.on('ready', function () {
	//create exchange here
	playExchange  = rabbitConn.exchange('pe', {'type': 'topic'});
	jobExchange   = rabbitConn.exchange('jb', {'type': 'topic'});
	offerExchange  = rabbitConn.exchange('of', {'type': 'topic'});
});

rabbitConn.on('error', function (e){
 	console.log('rabit ::::::: Error: ',e);
});

/*=========================================================
				RabbitMq server setup finish here
===========================================================*/



/*=========================================================
				Mongo Db connection start here.
===========================================================*/
var MongoClient = mongod.MongoClient;
MongoID = mongod.ObjectID; //reporting conversion global class instance  for converting string to object
var databaseConnectionString = 'mongodb://' + config.DB_USERNAME + ':' + config.DB_PASSWORD + '@' + config.DB_HOST + ':' + config.DB_PORT + '/' + config.DB_NAME;
MongoClient.connect(databaseConnectionString,{useUnifiedTopology: true,useNewUrlParser: true}, function (err, dClient) {
	if(err){
		console.log('mongodb :::::::::::::Error: ',err);
	}
	else{
		db = dClient.db(config.DB_NAME);
		console.log('Database connected  successfully------->>>>>');
		urlHandler.BindWithCluster();

		setInterval(function(){ trackClass.monitorUsers() }, 5000);
		/*setInterval(function(){ trackClass.trackUserCount() }, 300000);*/
	} 	
});
/*=========================================================
				Mongod Db connection Ends.
===========================================================*/



