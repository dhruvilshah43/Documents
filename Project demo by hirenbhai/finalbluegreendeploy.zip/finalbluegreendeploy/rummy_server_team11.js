//load configuration data
config = require("./config.json"); 
fs = require('graceful-fs');
commaNumber = require('comma-number');
FB = require('fb');
express = require('express');
crypto = require('crypto');  //deprecated inbulid in node 
cryptoJs = require('crypto-js');
rq = require('request');
request = rq;
schedule = require('node-schedule');
_ = require('underscore');
ses = require('nodemailer-ses-transport');
nodemailer = require('nodemailer');	
https = require("https");
iplocation = require('iplocation');
base64 = require('base-64');
app = module.exports = express();
 
var http = require('http');
var redis = require('redis');
var amqp = require('amqp');
var mongod = require('mongodb'); 


//some global array defination start 
dataCodesArr = new Array();
//SERVICE_HOST = process.argv[4];	//game host url
//SERVER_PROTO = 'https';
//SERVER_ID    = process.argv[2];    //S<prefix number>_<server number>
//SERVER_PORT  = process.argv[3];	//server port
//MATRIX_PORT = process.argv[4];
	
SERVICE_HOST = 'socketalb-1132371271.ap-south-1.elb.amazonaws.com'; //process.argv[4];   //game host url
SERVER_PROTO = 'https';
SERVER_ID    = 's1_1'; //process.argv[2];    //S<prefix number>_<server number>
SERVER_PORT  = '3001'; //process.argv[3];       //server port
MATRIX_PORT = process.argv[4];
REDIS_DB = config.REDIS_DB;	

RBMQ_CONFIG  = { host : config.RMQ_HOST, login : config.RMQ_LOGIN, password : config.RMQ_PASSWORD, vhost : config.RMQ_VHOST};
REDIS_CONFIG = { host :config.RDS_HOST , password : config.RDS_AUTH, port : 6379 };

c = module.exports = function(arr){  if(config.DEBUG) { for(var i = 0; i < arguments.length; i++) console.log(arguments[i]); }};
process.setMaxListeners(0);

/*=========================================================
				Start HTTPS Server
===========================================================*/

var httpsOptions = {  key: fs.readFileSync('certificate/artoon.key'), cert: fs.readFileSync('certificate/artoon.crt') };
app = module.exports = express();
var secureServer = https.createServer(httpsOptions, app);

io = module.exports = require('socket.io').listen(secureServer,{pingTimeout: 7000, pingInterval: 10000});
secureServer.listen(SERVER_PORT);
console.log("Server listening on port : "+ SERVER_PORT  + " - " + new Date());

/*app.get('/crossdomain.xml', function(req,res){    //used for flash game
	res.sendFile('crossdomain.xml');
});*/
app.get("/test", (req, res) => {
        res.send("OK");
});

/*=========================================================
				End HTTPS Server starting
===========================================================*/

/*=========================================================
					Include all required modules.
===========================================================*/

amqpClass = require("./classes/amqp.class.js");
commonClass  = require("./classes/common.class.js"); //common functions
cdClass = require("./classes/commonData.class.js"); //common Data functions
ecClass = require("./classes/eventCases.class.js");
trackClass = require("./classes/track.class.js");
signupClass = require("./classes/signup.class.js");
dashboardClass = require("./classes/dashboard.class.js");
langClass = require("./classes/language.class.js");
playingTableClass= require("./classes/playingTable.class.js");
robotsClass = require("./classes/robots.class.js");
playClass = require("./classes/play.class.js");
jtClass = require("./classes/jobTimers.class.js");
cardsClass = require("./classes/cards.class.js");
cheatClass = require("./classes/cheat.class.js");
profileClass = require("./classes/profile.class.js");
notiClass = require("./classes/notification.class.js");
buddiesClass = require("./classes/buddies.class.js");
bonusClass = require("./classes/bonus.class.js");
leaderBoardClass = require("./classes/leaderBoard.class.js");
gbClass = require("./classes/godBot.class.js");
fbClass = require("./classes/feedback.class.js");
FBClass = require("./classes/FB.class.js");
/*sendGiftClass = require("./classes/sendGift.class.js");
strClass = require("./classes/store.class.js");
gameSettingsClass = require("./classes/gameSettings.class.js");
chatClass = require("./classes/chat.class.js");
paymentClass = require("./classes/payment.class.js");
miniGameClass = require("./classes/miniGame.class.js");
artClass = require("./classes/artifact.class.js");
dealerClass = require("./classes/changeDealer.class.js");
tbRprClass = require("./classes/tableRepair.class.js");
cbClass = require("./classes/callbreak.class.js");
ppClass = require("./classes/phonePe.class.js");*/

/*=========================================================
					Module inclusion finish here.
===========================================================*/


/*=========================================================
				Redis server configuration start here..
===========================================================*/

rClient = redis.createClient(REDIS_CONFIG.port, REDIS_CONFIG.host);
rClient.auth(REDIS_CONFIG.password, function () { }); //redis authentication
rClient.select(REDIS_DB);
	
rClient.on("connect", function () {
        c("Redis running....");
        rClient.GET("lastPrefix", function (err, s_id) {
                c("Redis running..1 ..", s_id);

                if (s_id) {
	                        SERVER_ID = s_id[0] + s_id[1] + s_id[2] + (Number(s_id[3]) + 1);
	
        	                rClient.SET("lastPrefix", SERVER_ID);
	
	                }
	                else {
	                        rClient.SET("lastPrefix", SERVER_ID);
	                }
	        });
	});
	
rClient.on('error', function (err) {
	console.log('redis::::::::::::Error: ', err)
});

/*=========================================================
			Redis server configuration start here..
===========================================================*/	


/*=========================================================
					RabbitMq server setup start
===========================================================*/

rabbitConn = amqp.createConnection(RBMQ_CONFIG);
rabbitConn.on('ready', function () {
   	
	//create exchange here
	playExchange = rabbitConn.exchange('pe', {'type': 'topic'});
	jobExchange  = rabbitConn.exchange('jb', {'type': 'topic'});
	offerExchange = rabbitConn.exchange('of', {'type': 'topic'});
	amqpClass.CreateQueues();
	
});
rabbitConn.on('error', function (e) {
	console.log('rabbit:::::::::::::::Error: ',e);
});

/*=========================================================
				RabbitMq server setup finish here
===========================================================*/


/*=========================================================
				Mongo Db connection start here.
===========================================================*/	
var MongoClient = mongod.MongoClient;
MongoID = mongod.ObjectID; //reporting conversion global class instance  for converting string to object
var databaseConnectionString = 'mongodb://' + config.DB_USERNAME + ':' + config.DB_PASSWORD + '@' + config.DB_HOST + ':' + config.DB_PORT + '/' + config.DB_NAME;
MongoClient.connect(databaseConnectionString,{useUnifiedTopology: true,useNewUrlParser: true}, function (err, dClient) {
	if(err){
		console.log('mongodb::::::::::::Error: ',err);
	} 
	else{

		db = dClient.db(config.DB_NAME);
		console.log('Database connected  successfully------->>>>>:');



		var re = new RegExp(SERVER_ID,'i');
		db.collection('admin').update({},{$pull:{scks:re}},function(){}); //query to remove connected admins
		// db.collection('playing_table').remove({jid:re},function(){}); //query to remove table
		// db.collection('game_users').update({'flags._ir':1,s:'busy',sck:re},{$set:{s:'free',sck:'','counters.opc':0,tbid:''}},{multi:true},function(){});
		// db.collection('game_users').update({'flags._ir':0,sck:re},{$set:{sck:'','flags._io':0}},{multi:true},function(){

			ecClass.init(); //init server setup
		// });

		// if(typeof MATRIX_PORT != 'undefined' && MATRIX_PORT != null )
		// 	dash.monitor({port:MATRIX_PORT});   /// for checking server load
		// }
		// catch(e){
		// 	c('metrics off ');
		// }

		////////////////////////////robot testing code//////////////////////////////
		// robotinterval = module.exports =  setInterval(function(){
		// 	robotsClass.autoRobot();
		// },5000);
		/////////////////////////////end robot testing code////////////////////////

		if(config.MAIL){
			var html = "<html><body><h2>Restart Server </h2><table><tr><td>SERVER_ID</td><td>"+SERVER_ID+"</td></tr><tr><td>SERVER_PORT</td><td>"+SERVER_PORT+"</td></tr><tr><td>SERVICE_HOST</td><td>"+SERVICE_HOST+"</td></tr><tr><td>Date Time</td><td>"+new Date()+"</td></tr></table></body></html>";
			var obj={
				to:"deep.desai@artoon.in",
				subject:'MyTeam11 rummy Server Restart Pleace have look at that',
				html:html
			};

			if(SERVER_ID.split("_")[0] == config.SERVER.split("_")[0]){
				commonClass.sendMail(obj);
			}
			obj={};
		}
	} 
});
	
/*=========================================================
				Mongod Db connection Ends.
===========================================================*/
