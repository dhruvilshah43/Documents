
var socket = '';
var getServer_data;
var tempObj;

//data encoding decoding function
var encKey = "DFK8s58uWFCF4Vs8NCrgTxfMLwjL9WUy";

 function Encryption(data) {
  try {
    /* +-------------------------------------------------------------------+
    desc: this function encrypt the data.
    i/p: plain data
    o/p: encrypted data
    +-------------------------------------------------------------------+ */
    // Encrypt
    var ciphertext = CryptoJS.Rabbit.encrypt(JSON.stringify(data), encKey).toString();
    // console.log(ciphertext);
    return ciphertext;
  } catch (e) {}
};
function Decryption(data) {
  try {
    /* +-------------------------------------------------------------------+
        desc: this function decrypt the data.
        i/p: encrypted data
        o/p: decrypted data
    +-------------------------------------------------------------------+ */
    // Decrypt
    var bytes = CryptoJS.Rabbit.decrypt(data, encKey);
    var decryptedData = JSON.parse(bytes.toString(CryptoJS.enc.Utf8));
    // console.log(decryptedData);
    return decryptedData;
  } catch (e) {}
};



// local server
jQuery.ajax({
    url: 'https://new-dev.artoon.in:6034/chooseServer?det=html', // dev server
    success: function (result) {
        getServer_data = Decryption(result);
        // console.log(getServer_data)
    },
    async: false
});

// client server
// jQuery.ajax({
//     url: 'https://game2.artoon.in:3007/chooseServer?det=html',
//     success: function (result) {
//         getServer_data = Decryption(result);
//     },
//     async: false
// });

if (localStorage.getItem('DeviceId') == undefined || localStorage.getItem('DeviceId') == null) {
    var rnd = Math.floor(Math.random() * (parseInt(99999) - parseInt(100) + 1)) + parseInt(100);
    var x = Number(rnd);
    localStorage.setItem('DeviceId', x);
    tempObj = {DeviceId: x.toString(), ult:'guest'};
}else{
    tempObj = {DeviceId:localStorage.getItem('DeviceId'), ult:'guest'};
}


var app = angular.module("MT11RUMMY", ["ngRoute", "ngTouch", "ui.sortable", "rzModule", "ngScrollbars", "img-preloader"]);
// scrollbar config
app.config(function(ScrollBarsProvider) {
    // scrollbar defaults
    ScrollBarsProvider.defaults = {
        autoHideScrollbar: false,
        scrollInertia: 0,
        autoResize: true,
        axis: 'xy',
        advanced: {
            updateOnContentResize: true
        },
        scrollButtons: {
            scrollAmount: 'auto', // scroll amount when button pressed
            enable: true // enable scrolling buttons by default  
        }
    };
});

// socket connection
app.factory('socket', ['$rootScope', function($rootScope) {
//      socket = io.connect(getServer_data.proto + '://' + getServer_data.host + ':' + getServer_data.port);
	socket = io.connect('https://rummy11socket.artoon.in:3001');
    
    $rootScope.sockets = socket;
    return {
        on: function(eventName, callback) {
            // get data from socket
            function wrapper() {
                var args = arguments;
                $rootScope.$apply(function() {
                    callback.apply(socket, args);
                });
            }
            socket.on(eventName, wrapper);
            return function() {
                socket.removeListener(eventName, wrapper);
            };
        },emit: function(eventName, data, callback) {
            // data send to socket 
            socket.emit(eventName, data, function() {
                var args = arguments;
                $rootScope.$apply(function() {
                    if (callback) {
                        callback.apply(socket, args);
                    }
                });
            });
        }
    };
}]);

app.directive("ngTouchstart", function() {
    return {
        // mobile device ui sortable,drag start event 
        controller: ["$scope", "$element", function($scope, $element) {
            $element.bind("touchstart", onTouchStart);
            function onTouchStart(event) {
                var method = $element.attr("ng-touchstart");
                $scope.$event = event;
                $scope.$apply(method);
            }
        }]
    }
}).directive("ngTouchend", function() {
    return {
        controller: ["$scope", "$element", function($scope, $element) {
            // mobile device ui sortable, drag end event 
            $element.bind("touchend", onTouchEnd);
            function onTouchEnd(event) {
                var method = $element.attr("ng-touchend");
                $scope.$event = event;
                $scope.$apply(method);
            }
        }]
    }
}).directive('imageonload', function() {
    return {
        // preload image function
        restrict: 'A',
        link: function(scope, element, attrs) {
            element.bind('load', function() {
                alert('image is loaded');
            });
            element.bind('error', function() {
                alert('image could not be loaded');
            });
        }
    };
}); 
// routing config
app.config(function($routeProvider) {
    $routeProvider
    .when("/", {
        templateUrl: "../HTML5/dashbord.html",
        controller: "html"
    })
});

app.controller("html", function($scope, $http, $location, $interval, $timeout, $rootScope, $route, $window, socket, preloader) {
    $scope.getAndroidVersion = function(ua) {
        ua = (ua || navigator.userAgent).toLowerCase(); 
        var match = ua.match(/android\s([0-9\.]*)/);
        $scope.getAndroidVersion_data = match[1];
        // return match ? match[1] : undefined;
        $scope.device_type = 'ANDROID';
    };


window.fbAsyncInit = function() {
    FB._https = true;
      // init the FB JS SDK 
    FB.init({
        appId      : '528966561160683',
        status     : true,
        cookie     : true,                                
        xfbml      : true ,
        frictionlessRequests : true,
        version : 'v3.0'
    });
    FB.Event.subscribe('edge.create', function(href, widget) {

    });
};

(function(d, s, id){
   var js, fjs = d.getElementsByTagName(s)[0];
   if (d.getElementById(id)) {return;}
   js = d.createElement(s); js.id = id;
   js.src = "//connect.facebook.net/en_US/all.js";
   fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));
 
var script = document.createElement("script");
script.type = "text/javascript";
script.src = "//s-assets.tp-cdn.com/static3/js/api/payment_overlay.js";
document.getElementsByTagName("body")[0].appendChild(script);

$scope.myFunction2 = function() {
    FB.getLoginStatus(function(response) {
        console.log('>>>>>>>>>>>>>>>222',response)
        // statusChangeCallback(response);
    });
    FB.login(function(response){
      // handle the response 
      console.log('>>>>>>>>>>>>>>>111',response)
    });
}


function onSignIn(googleUser) {
  var profile = googleUser.getBasicProfile();
  console.log('ID: ' + profile.getId()); // Do not send to your backend! Use an ID token instead.
  console.log('Name: ' + profile.getName());
  console.log('Image URL: ' + profile.getImageUrl());
  console.log('Email: ' + profile.getEmail()); // This is null if the 'email' scope is not present.
}


    $scope.getiosVersion = function() {
        if (/iP(hone|od|ad)/.test(navigator.platform)) {
            // supports iOS 2.0 and later: <http://bit.ly/TJjs1V>
            var v = (navigator.appVersion).match(/OS (\d+)_(\d+)_?(\d+)?/);
            $scope.getiosVersion_data = [parseInt(v[1], 10), parseInt(v[2], 10), parseInt(v[3] || 0, 10)];
            $scope.device_type = 'IOS';
        }
    };

    // variable defined
    
    // scroll config XX
    $scope.scrollbarConfig2 = {
        autoHideScrollbar: false,
        theme: 'dark',
        axis: 'x',
        advanced: {
            updateOnContentResize: true
        },
        // setHeight: 200,
        scrollInertia: 600
    }

    // feedback popup scrollbar config
    $scope.scrollbarConfig3 = {
        autoHideScrollbar: false,
        theme: '',
        axis: 'y',
        autoDraggerLength: true,
        advanced: {
            updateOnContentResize: true
        },
    }

    $scope.screen = [0, 0, 0, 1, 0]; //screen hide show   logo,loader,login ,dashboard,playing
    $scope.popup = [0, 0]; // table info popup and menu popup hide  show 
    $scope.user_detail; // current user detail save
    $scope.table_user = [0, 0, 0, 0, 0, 0]; // table all user detail store
    $scope.wildCard; // wildcard store 
    $scope.tCard = [0, 0]; // trump card store
    $scope.smccard = { tCard: '', wildCard: '' }; // save cards details
    $scope.round_timer = 0; // set round time seconds
    $scope.user_setting_ar = [
        [2, 3, 4, 5, 0, 1],
        [1, 2, 3, 4, 5, 0],
        [0, 1, 2, 3, 4, 5],
        [5, 0, 1, 2, 3, 4],
        [4, 5, 0, 1, 2, 3],
        [3, 4, 5, 0, 1, 2]
    ]; // set user position in table
    $scope.hakamchk; //  hakam cards set
    $scope.tb_id; // table id set
    $scope.timer_round; // round time interval 
    $scope.closedeck = 'close_card1-0'; //close deck card set
    $scope.through_card = 'close_card1-0'; // other user through card  set
    $scope.userturn_click = false; // user turn flag set
    $scope.pickcrds = false; //pick cards from deck flag
    $scope.purechecked = false; // pure sequance flag
    $scope.pure_impure = []; // pure sequance array 
    $scope.setting_menu_btn = false; // setting menu flag set
    $scope.dropbtn = false; // drop button hide show flage set
    $scope.declarebtn = false; // declare button flage set
    $scope.disabled_drop = false; // user drop flag set
    $scope.drop_standup = false;
    $scope.config; // GGC event data set
    $scope.bv; // boot value set
    $scope.deadwood_points_c = 0; // user points set ( score ) 
    $scope.declaret = [0, 0, 0, 0, 0, 0]; // set user tag like(win ,drop ,finish etc.......)
    $scope.turn_timer; // user turn start  interval 
    $scope.finish_popup_show = false; // conform  declare popup show flag
    $scope.dropd_chips = 0; // drop chips value 
    $scope.dropd_chips_first = 0; // rejoin time droped chips set
    $scope.dropd_chips_d = false; // drop chips flag set
    $scope.winner_chips_d = false; // winner screen flag set
    $scope.winner_chips = 0; // winner chips set 
    $scope.joker = ['j-1', 'j-2', 'j-3', 'j-4']; // joker set
    $scope.winner_scored = false; // scoreboard flag set
    $scope.winner_scored_data; // winner screen data set
    $scope.no_internet = true; // internet connection  flag set
    $scope.joinhere = false; // join here  flag set
    $scope.joinback_switch = 0; // rejoin flag set like (0,1,2,3)
    $scope.out_chips = false; // out of chips data set
    $scope.discarded_popup = false; //  Discarded card  popup flag
    $scope.classes_width = 0; // totat card length set 
    $scope.collect_chips = [0, 0, 0, 0, 0, 0]; // collect chips array set 
    $scope.dealcollect = 0; // deal rummy  total collected chips set
    $scope.modelset; // current playing mode set
    $scope.msmode = true; //  Whether to show an empty seat or not
    $scope.currentround = 0; // deal mode current round set  like (1,2)
    $scope.points = [0, 0, 0, 0, 0, 0]; // points array set 
    $scope.ms_count = 0; // minimum set fill to  round start
    $scope.ofcoin = [0, 0]; // animation left and top  postion set. run time
    $scope.time_clearwinner = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]; // winner screen clear interval 
    $scope.bet_help = 0; // help popup flag set
    $scope.bet_value = 0; // bet value set
    $scope.last_bv_bet = 0; // last  bet value set
    $scope.count_win_seq = []; //  user sequance length count
    $scope.selected_current_seq = 4; // selected card sequance or not validation flag set
    $scope.wi = false; // group arranging time show updated sequance and  set flag
    $scope.outtime_data = ''; // time out data set
    $scope.view_profile_detail = []; // view profile data set
    $scope.chat_play = false;
    $scope.loading_progress = 0; // loading screen progress % set
    $scope.ngclick_enabled = true; // dashbord button  click enabled ,disable flag set
    $scope.gameround = 0; // current game round  data set
    $scope.currentuserwatch = false; // current user watching mode flag set
    $scope.switch_table_p = false; // switch table popup flag set
    $scope.parcentage_loding = 0; // loading screen percent set
    $scope.coupons = 0; // coupons data set
    $scope.collect_mitter = 0; //collect coupon mitter popup data set
    $scope.collect_mitter_pointer = -104; // rotate mitter calculation 
    $scope.multiuser_connect = false; // multi user connect same login data set
    $scope.stopper; // maintaince mode time interval 
    $scope.sp_id; // set  user id
    $scope.settings_popup = false; // setting popup 
    $scope.selected_dis_msg = false;
    $scope.selected_dic_msg = false;
    $scope.finish_time='';
    $scope.finish_time_min='';
    $scope.only_jocar_card = true;
    $scope.store_chips_coin = ''; //store chips and coin arre
    $scope.store_chips_open = true; //store chips part
    $scope.store_coin_open = false; //store coin part
    $scope.out_chips;
    $scope.store_popup = false;
    $scope.store_version_error = false;
    $scope.store_not_avelebal = false;
    $scope.store_btn_show = true;
    $scope.all_platform = navigator.platform;
    $scope.sound_onPause = false;
    $('.timer_counter').removeClass('active')
    $scope.click_deactive = false;
    $scope.gti_data;
    $scope.settin_menu_slid = 0; // language popup  data set
    $scope.notifications = false;
    $scope.sdc_cards = false; // start dealing flag set
    $scope.hakamfinish = false;
    $scope.pop_msg = ''; //common popup message set
    $scope.last_play = ''; // last play lost chips popup data  set
    // deal rummy
    $scope.dealjointable_data = []; //deal rummy select table and join popup data set 
    $scope.jointable_data = []; //Pool rummy select table and join popup data set
    $scope.indexofsliderpool = 0; // pool rummy select pack to join the table
    $scope.set_index = 0; // current user seat index store
    $scope.lists = []; // cards lists  store
    $scope.select_lists = [{ cards: [], seq: 4 }]; // selected card data set
    $scope.loginDetails;
    $scope.getAndroidVersion_data;
    $scope.getiosVersion_data;
    $scope.device_type;
    $scope.D_card;
    $scope.spam = false;
    $scope.card_glow_img_show = false;
    $scope.common_popup_show = false;
    $scope.jointable_data = 0;
    $scope.pool_101 = true;
    $scope.pool_201 = false;
    $scope.theme_color = 'red';
    $('.menu_side_1').addClass('menu_right_to_center');
    $('.menu_side_2').addClass('deactive_right');
    $('.menu_side_3').addClass('deactive_right');
    $('.menu_side_tab_1').addClass('deactive_right')
    $('.menu_side_tab_2').addClass('deactive_right');
    $scope.menu_side_tab_2_show = false;
    $scope.cash_game_lagel = false;
    $scope.tounament_game_lagel = false;
    $scope.practice_game_lagel = false;
    $scope.pwf_game_lagel = false;
    $scope.menu_side_tab_2_show = false;
    $scope.pass_time = 0;
    $scope.remaing_time = 0;
    $scope.open_dack_joker = false;
    $scope.finish_slot_card = 0;
    $scope.add_cash_popup_show = false;
    $scope.LB_data = [];
    $scope.GSD_data = [];
    $scope.HTOGMB = false;
    $scope.GPTI_data = [];
    $scope.RPD_data = [];
    $scope.user_turn_g = false;
    $scope.switch_table_msg = false;
    $scope.wallet_popup = false;
    $scope.refer_earn_popup = false;
    $scope.rules_popup = false;
    $scope.CFDB_data = [];
    $scope.SDS_data = [];
    $scope.INDECL_data = [];
    $scope.dccards = [];
    $scope.card_flip_animation = false;
    $scope.howtoplay = false;
    $scope.cash_game_info_data = [];
    $scope.typePassword=false;
    $scope.lastdeal = false;
    $scope.feedback_popup = false;
    $scope.get_network = '';
    $scope.HB_id = 1;
    $scope.network_tower_show = 'Medium';
    $scope.p_true_show = false;
    $scope.p_true_show2 = false;
    $scope.referral_code_box = false;
    $scope.sign_up = true;
    $scope.sign_in = false;



    // socket responce // event resive from server
    socket.on("resw", function(resw) {
        $scope.res = Decryption(resw.data); //decode socket responce
        // console.log(">>>> RECIVE",$scope.res);
        console.log($scope.res);
        // get game config
        if ($scope.res.en == "GGC") {
            $scope.config = $scope.res.data;
            $scope.d_bonus = $scope.res.data.DAILYBONUS;
            $scope.d_bonus_p = $window.getShortCurrency($scope.d_bonus);
        }
        //over get game config

        if ($scope.res.en == "HB") {
            $scope.HB_data = $scope.res.data;
            $scope.HB_end_time = new Date();
            $scope.HB_respons_time = new Date($scope.HB_end_time) - new Date($scope.HB_start_time);
            // $scope.HB_respons_time = $scope.HB_respons_time_temp * 1000;
            console.log($scope.HB_respons_time)
            if ($scope.HB_data.id == $scope.HB_id) {
                $scope.HB_id = 1;
                if ($scope.HB_respons_time <= $scope.config.PONG_TIMER[0]) {
                    $scope.network_tower_show = 'Strong';
                } else if ($scope.HB_respons_time >= $scope.config.PONG_TIMER[0] && $scope.HB_respons_time <= $scope.config.PONG_TIMER[1]) {
                    $scope.network_tower_show = 'Medium';
                } else if ($scope.HB_respons_time >= $scope.config.PONG_TIMER[3]) {
                    $scope.network_tower_show = 'Weak';
                } else {

                }
            } else if (($scope.HB_data.id + 1) == $scope.HB_id) {
                $scope.network_tower_show = 'Medium';
            } else {
                // $scope.HB_id = 1;
                $scope.network_tower_show = 'Weak';
            }
        }
        
        // socket connect Successfully
        if ($scope.res.en == "DONE") {

            // If all the documents are loaded and if the  gets done  an event send the sp event  
            // reconnect reconnect time send sp event

            if ($scope.parcentage_loding == 200) {
                $scope.clear_play_table(); //clear all variable or data
                $interval.cancel($scope.socket_c); // clear body click event interval
                $scope.data = {
                    ult: $scope.loginDetails.ult,
                    det: 'html',
                    nwt: 'wifi',
                    DeviceId: $scope.loginDetails.DeviceId
                } // send signup  event
                $scope.sendData('SP', $scope.data);
                $scope.Notification_sound();
                if ($scope.screen[1] == 1) {
                    $('.menu_side_1').removeClass('deactive_left deactive_right menu_right_to_center menu_center_to_left menu_left_to_center menu_center_to_right').addClass('menu_left_to_center');
                    $('.menu_side_2').removeClass('deactive_left deactive_right menu_right_to_center menu_center_to_left menu_left_to_center menu_center_to_right').addClass('menu_center_to_right');
                    $('.menu_side_3').removeClass('deactive_left deactive_right menu_right_to_center menu_center_to_left menu_left_to_center menu_center_to_right').addClass('deactive_right');
                    $('.menu_side_tab_1').removeClass('deactive_left deactive_right menu_right_to_center menu_center_to_left menu_left_to_center menu_center_to_right menu_side_tab_bg menu_side_tab_fix').addClass('menu_center_to_right');
                    $('.menu_side_tab_2').removeClass('deactive_left deactive_right menu_right_to_center menu_center_to_left menu_left_to_center menu_center_to_right').addClass('deactive_right');
                    $timeout(function() {
                        $scope.menu_side_tab_2_show = false;
                        $scope.cash_game_lagel = false;
                        $scope.tounament_game_lagel = false;
                        $scope.practice_game_lagel = false;
                        $scope.pwf_game_lagel = false;
                    }, 500);
                    $('.menu_side_1').addClass('menu_right_to_center');
                    $('.menu_side_2').addClass('deactive_right');
                    $('.menu_side_3').addClass('deactive_right');
                    $('.menu_side_tab_1').addClass('deactive_right')
                    $('.menu_side_tab_2').addClass('deactive_right');
                }
            }
        }

        //signup  
        if ($scope.res.en == "SP") {
            $scope.screen[1] = 1;
            $scope.screen[2] = 0;
            $scope.user_detail = $scope.res.data;
            $scope.sound_on_off = $scope.res.data.flags._snd;
            $scope.user_chips = $scope.res.data.Chips;
            $scope.user_cash = $scope.res.data.totalcash;
            $scope.freeBonus = $scope.res.data.freeBonus;


            //over set game button  
            $scope.sp_id = $scope.res.data._id;
            $scope.dataLoaded = true; //dashboard button  slider load flag set
            
            if ($scope.user_detail.MM == false && $scope.user_detail.StartAfter != 0 && $scope.user_detail.RemoveAfter != 0) {
                $scope.m_c_flag;
                $scope.m_counter($scope.user_detail.StartAfter, 'start')
            } else if ($scope.user_detail.MM == true) {
                $scope.m_counter($scope.user_detail.RemoveAfter, 'end');
            }

            if ($scope.user_detail.rejoin == 1) {
                $scope.sendData('RJT', {});
            } else if ($scope.user_detail.rejoin == 2) {
                $scope.joinback_switch = 2;
            } else if ($scope.user_detail.rejoin == 3) {
                $scope.joinback_switch = 3;
            }
        }
        //over signup

        if ($scope.res.en == "CGS") {
            $scope.sound_on_off = $scope.res.data.sts;
        }

        if ($scope.res.en == "UC") {
            $scope.user_chips = $scope.res.data.Chips;
            $scope.user_cash = $scope.res.data.totalCash;
        }

        // SPINNER DAILY BONUS
        if ($scope.res.en == "GSD") {
            $scope.GSD_data = $scope.res.data;
            $scope.spinnerData = $scope.GSD_data.spinnerData.reverse();
            $scope.free_spin_btn_deactive = false;
        }

        $scope.spin = function(index){
            $scope.deg = 0;
            $scope.free_spin_btn_deactive = true;
            $timeout(function() {
                $interval.cancel($scope.spinInt);
                $scope.sendData('GSR', {result:index});
                $timeout(function() {
                    $scope.GSD_data = [];
                }, 1000);
            }, 10000);
            $scope.spinInt = $interval(function() {
                $('.spinner_chpis_text').css({'transform':'rotate(' + $scope.deg + 'deg)'});
                $scope.deg += 32.70;
                if($scope.deg >= (index + 1)*32.70+1080){
                    $interval.cancel($scope.spinInt);
                    $timeout(function() {
                        $scope.sendData('GSR', {result:index});
                        $scope.GSD_data = [];
                    }, 7000);
                }
            }, 1);
        }
        // OVER SPINNER DAILY BONUS

        // DAILY BONUS CLIAM
        if ($scope.res.en == "CFDB") {
            $scope.CFDB_data = $scope.res.data;
        }
        if ($scope.res.en == "CDB") {
            $scope.CFDB_data = [];
            // $scope.freeBonus = false;
        }
        // OVER DAILY BONUS CLIAM

        // join table 
        if ($scope.res.en == "JT") {
            $scope.declaret[$scope.res.data.si] = 0;
            $scope.SDC_data = [];
            $scope.user_dealer = -1;
            
            // add the information of the join user in the user list
            $scope.table_user[$scope.res.data.si] = $scope.res.data;
            if ($scope.table_user.filter(function(element) { return element.uid === $scope.sp_id })[0] != undefined) {
                $scope.set_index = $scope.table_user.filter(function(element) { return element.uid === $scope.sp_id })[0].si;

            } else {
                // if user not find table to set index = 5
                $scope.set_index = 0;
            }
        }
        //over join table

        if ($scope.res.en == "CS") {
            $scope.store_data = $scope.res.data;
        }

        //  Maintaince mode
        if ($scope.res.en == "MMN") {
            clearTimeout($scope.stopper);
            $scope.user_detail.MM = false;
            $scope.user_detail.RemoveAfter = $scope.res.data.RemoveAfter;
            $scope.user_detail.StartAfter = $scope.res.data.StartAfter;
            if ($scope.user_detail.MM == false && $scope.user_detail.StartAfter != 0 && $scope.user_detail.RemoveAfter != 0) {
                $scope.m_c_flag;
                $scope.m_counter($scope.user_detail.StartAfter, 'start')
            } else if ($scope.user_detail.MM == true) {
                $scope.m_counter($scope.user_detail.RemoveAfter, 'end');
            }
        }
        // Over Maintaince mode

        // Check For Daily Bonus 
        if ($scope.res.en == "CFDB") {
            // SHOW DAILY REWARD POPUP
            $scope.daily_bonus = $scope.res.data;
        }
        // Over Check For Daily Bonus 

        // See My Cards
        if ($scope.res.en == "SMC") {
            // get players cards
            $scope.smccard = $scope.res.data;
        }
        // Over See My Cards

        // Start Dealer Selection
        if ($scope.res.en == "SDS") {
            $scope.SDS_data = $scope.res.data;
            $scope.card_flip_animation = true;
            // $('.current_user').removeClass('active').css({ "z-index": "3" });
            // if ($scope.modelset != 'Deal') {
            //     $('.user_cards_user_' + $scope.res.data.dealer + '').addClass('active');
            // }
            // $('.dealrummy_round_top').show();
            // // deal rummy round text animation
            // $('.dealrummy_round_sub').playKeyframe({
            //     name: 'delstartcount',
            //     duration: '1.5s',
            //     timingFunction: 'linear',
            //     delay: '0s',
            //     iterationCount: '1',
            //     direction: 'normal',
            //     fillMode: 'forwards',
            //     complete: function() {
            //         $('.dealrummy_round_sub').resetKeyframe();
            //         $('.dealrummy_round').find('p').css({ 'opacity': '1' });
            //         $('.dealrummy_round_top').hide();
            //         // dealer icon animaton set
            //         $('.user_cards_user_' + $scope.res.data.dealer + '').addClass('active');
            //     }
            // });
            // $scope.currentround = $scope.res.data.round;
        }
        //Over Start Dealer Selection

        // Start Dealing Cards
        if ($scope.res.en == "SDC") {
            $scope.SDS_data = [];
            $scope.SDC_data = $scope.res.data;
            $scope.user_dealer = $scope.res.data.dealer;
            $scope.sdc_cards = true;
            $scope.smccard.tCard = $scope.res.data.tCard;
            $scope.smccard.wildCard = $scope.res.data.wildCard;
            $('.playing_buttom_cards').css({ 'z-index': '3' });
            var ind = 0;
            if ($scope.short_btn_flag == false) {
                $scope.short_btn_flag = true;
            }

            // cards dealing animaton 
            var distribution_sound = $interval(function() {
                $scope.Card_Distribution_sound();
            }, 300);
            $timeout(function() {
                $('.dealing_cards_top').css('opacity', '1');
                angular.forEach($scope.res.data.si, function(value, key) {
                    $('.deling_cards_' + $scope.user_setting_ar[$scope.set_index][value] + '').addClass('active_sdc');
                    // if ($scope.set_index == value) {
                    //     $scope.join.pi[$scope.set_index].s = 'playing';
                    // }
                });
                var dealr = $interval(function() {
                    $('.active_sdc').find('img:nth-child(' + ind + ')').addClass('active_card_animation');
                    if (ind == 13) {
                        $interval.cancel(distribution_sound);
                        $interval.cancel(dealr);
                    }
                    ind = ind + 1;
                }, 200);
            }, 100);
            $timeout(function() {
                $('.active_sdc').find('img').removeClass('active_card_animation');
                $scope.cardgroupset($scope.smccard);
            }, 300 * 13);
        }
        // Over Start Dealing Cards

        // Round Time Started 
        if ($scope.res.en == "RTS") {
            $scope.currentwatch = true;
            $scope.RTS_data = $scope.res.data;
            // angular.forEach($scope.res.data.pi, function(value, key) {
            //     if ( value.si == $scope.set_index) {
            //         if (value.uid == $scope.sp_id) {
            //             $scope.player_stutes = value.s;
            //         } else if (value.uid != $scope.sp_id) {
            //             $scope.player_stutes = 'watch';
            //         } else {

            //         }
            //     }
            // })
            // start round timer
            $scope.round_time_start($scope.res.data.timer);
        }
        //Over Round Time Started

        // Get Table Information
        if ($scope.res.en == "GTI") {
            $scope.dropbtn = false;
            $scope.sortableOptions.items = '.sort_custom';
            $('.ring_circle2').attr("stroke-dasharray", "0,100%");
            $('.ring_circle2').attr("stroke", "rgba(255,29,21,0)");
            $('.timer_counter').removeClass('active');
            $interval.cancel($scope.turn_timer);
            $interval.cancel($scope.turn_timer_counter);
            $scope.dealjointable_data = [];
            $scope.jointable_data = [];
            $scope.playwithfriends_data = [];
            $scope.SDC_data = [];
            $scope.user_dealer = $scope.res.data.dealer;
            $scope.bet_help = 0;
            $scope.help_popup_open = false;
            $scope.bv = $scope.res.data.bv;
            $scope.gti_data = $scope.res.data;

            // $scope.HB_timer = $interval(function() {
            //     $scope.sendData('HB', {id:$scope.HB_id});                
            //     $scope.HB_start_time = new Date();
            //     $scope.HB_id = $scope.HB_id + 1;
            // }, $scope.config.PING_INTERVAL*1000);


            // $timeout(function() {
            //     $scope.setting_menu_btn = false;
            // },3000);
            
            $scope.modelset = $scope.res.data.gt;
            $scope.table_id = $scope.res.data._id;
            $scope.game_id = $scope.res.data.round;
            $scope.collect_chips_single = $scope.res.data.bv;

            angular.forEach($scope.gti_data.pi, function(value, key) {
                if (value.uid == $scope.sp_id) {
                    $scope.theme_color = value.theme;
                    $scope.short_btn_flag = value.sort;
                }

                if ($scope.STNDUP_data != undefined) {
                    if ($scope.STNDUP_data.uid == value.uid) {
                        // $('body').css({ 'pointer-events': 'none' });
                        $scope.joinback_switch = 1;
                        $scope.disabled_drop = false;
                        $scope.joinhere = false;
                        $scope.STNDUP_data = [];
                    }
                }
            })

            if ($scope.res.data.gt == 'Deal') {
                $scope.config.MIN_SEAT_TO_FILL = 2;
            }
            if ($scope.res.data.gt == 'Pool') {
                $scope.config.MIN_SEAT_TO_FILL = 4;
            }
            if ($scope.res.data.gt == 'Bet') {
                if ($scope.res.data._isHelp == 1) {
                    $scope.bet_help = 0;
                }
                $scope.last_bv_bet = $scope.res.data.bv;
            }
            $scope.ngclick_enabled = true;

            // rejoin data set
            $scope.rejoin($scope.res.data);
            $scope.ms_count = $scope.res.data.ms;
            
            // set seat arrangement data
            // pool rummy and deal rummy seating arrangement
            if ($scope.res.data.ms == 2) {
                $scope.msmode = false;
                $scope.user_setting_ar = [
                    [2, 5],
                    [5, 2],
                    [2, 5],
                    [5, 2],
                    [2, 5],
                    [5, 2]
                ];
            } else if ($scope.res.data.ms == 4) {
                $scope.msmode = false;
                $scope.user_setting_ar = [
                    [2, 3, 5, 1],
                    [1, 2, 3, 5],
                    [5, 1, 2, 3],
                    [3, 5, 1, 2],
                    [2, 3, 5, 1],
                    [1, 2, 3, 5]
                ];
            } else {
                $scope.user_setting_ar = [
                    [2, 3, 4, 5, 0, 1],
                    [1, 2, 3, 4, 5, 0],
                    [0, 1, 2, 3, 4, 5],
                    [5, 0, 1, 2, 3, 4],
                    [4, 5, 0, 1, 2, 3],
                    [3, 4, 5, 0, 1, 2]
                ];
                $scope.msmode = true;
            }
            //over set seat arrangement data

            // help flag set
            $scope.Notification_sound();
        }
        // Over Get Table Information

        // popup   
        if ($scope.res.en == "PUP") {
            $('body').css({ 'pointer-events': 'auto' });
            $scope.PopupOpen_sound();
            $scope.PUP_data = $scope.res.data;
            if ($scope.res.data.flag == 'noChips') {
                // SHOW  OUT OF CHIPS POPUP
                $scope.out_chips = $scope.res;
            } else if ($scope.res.data.flag == 'lastPlay') {
                // SHOW LAST PLAY POPUP
                $scope.last_play = $scope.res.msg;
            } else {
                // SHOW COMMON POPUP
                $scope.pop_msg = $scope.res;
            }
        }
        //Over popup   

        // New User Connected
        if ($scope.res.en === "NCC") {
            // SHOW MULTI USER CONNECT POPUP
            // socket_reconnect = false;
            $scope.PopupOpen_sound();
            $scope.multiuser_connect = true;
            $scope.connected = false;
        }
        // Over New User Connected

        // Leave Table
        if ($scope.res.en == "LT") {
            $scope.pop_msg = '';
            
            if ($scope.res.data.leave != 0) {
                $scope.declaret[$scope.res.data.si] = 1;
                if ($scope.res.data.uid == $scope.sp_id) {
                // current Player leave table
                    $scope.LT_data = $scope.res.data;
                    $interval.cancel($scope.HB_timer);
                    $scope.joinhere = false;
                    $scope.STNDUP_data = [];
                    $scope.SDC_data = [];
                    $scope.user_dealer = -1;
                    $scope.settin_menu_slid = 0;
                    if ($scope.res.data.flag == 'noChips') {
                        $scope.switch_table_p = false;
                    }
                    $scope.leave_table_reset($scope.res.data);
                    $scope.gameround = 0;
                    $scope.winner_clear();
                    $('.drop_button').removeClass('active');
                    $interval.cancel($scope.turn_timer);
                    $interval.cancel($scope.turn_timer_counter);
                    $scope.pass_time = 0;
                    $scope.remaing_time = 0;
                    $scope.notturn = false;
                    $scope.userturn_click = false;
                    $scope.user_turn_g = false;
                    $scope.joinhere = false;
                    $scope.dropbtn = false;
                    $('.ring_circle2').attr("stroke-dasharray", "0,100%");
                    $('.ring_circle2').attr("stroke", "rgba(255,29,21,0)");
                    $('.timer_counter').removeClass('active');
                } else {
                    // Other Player leave table
                    // leave player remove data
                    $scope.table_user[$scope.table_user.map(function(d) { return d['uid']; }).indexOf($scope.res.data.uid)] = 0;
                    if ($scope.table_user.filter(function(element) { return element.uid === $scope.sp_id }).length != 0) {
                        // seat index change
                        $scope.set_index = $scope.table_user.filter(function(element) { return element.uid === $scope.sp_id })[0].si;
                    }

                    if ($scope.res.data.wc != undefined) {
                        // drop animate function call
                        $scope.dropchips_p($scope.res.data.si, Math.abs($scope.res.data.wc),"LT");
                    }
                }
            }
        }
        // Over Leave Table

        // User Turn Start
        if ($scope.res.en == "UTS") {
            $scope.hakamfinish = false;
            $('.dealing_cards_top').css('opacity', '0');
            $scope.bet_value = $scope.res.data.bbv;
            $scope.max_bet_value = $scope.res.data.maxBet;
            $scope.scale_value = $scope.res.data.scale;
            $scope.min_value = $scope.res.data.bbv;
            $scope.round_id = $scope.res.data.rSeq;
            $scope.UTS_data = $scope.res.data;

            $timeout(function() {
                
                // player time data clear 
                $('.timer_counter').removeClass('active')
                $('.ring_circle2').attr("stroke-dasharray", "0,100%");
                $('.ring_circle2').attr("stroke", "rgba(255,29,21,0)");
                if ($scope.UTS_data.uid == $scope.sp_id) {
                    $scope.notturn = false;
                    $scope.pickcrds = false;
                    $scope.user_turn_g = true;
                    $scope.userturn_click = true;
                    $scope.dropbtn = true;
                    
                    if ($scope.join.pi[$scope.set_index].pickCount == 1 && $scope.bet_help != 3 && $scope.join._isHelp != 0) {
                        $scope.bet_help = 3;
                    }
                    $scope.Users_Turn_sound();
                } else {
                    $scope.AnotherUserTurn_sound();
                    $scope.userturn_click = false;
                    $scope.dropbtn = false;
                    $scope.user_turn_g = false;
                }
                // player timer animation
                if ($scope.wildCard != '' && $scope.wildCard.length != 0) {
                    $scope.anim_userturn_f($scope.config.STT, $scope.UTS_data.si, 1);
                    $scope.remaing_time = $scope.UTS_data.time;
                }
            }, 50);
            // $timeout(function() {
            //     // timeout text remove
            //     $('.timeout_img').removeClass('active');
            // }, 1500);
        }
        //Over User Turn Start

        if ($scope.res.en == "STS") {
            $scope.remaing_time = $scope.res.data.time;
            $scope.secTime_pass = $scope.res.data.t;
            $scope.anim_userturn_f($scope.secTime_pass, $scope.res.data.si, 0);
        }

        if ($scope.res.en == "LB") {
            $scope.LB_data = $scope.res.data;
        }

        //Turn Time Out
        if ($scope.res.en == "TUT") {
            $scope.setting_menu_btn = false;
            $scope.userturn_click = true;
            $scope.finish_slot_card = 0;
            $scope.outtime_data = $scope.res.data;
            $scope.user_turn_g = false;
            $scope.pickcrds = false;
            $scope.dropbtn = false;
            $scope.finish_popup_show = false;
            $('.ring_circle2').attr("stroke-dasharray", "0,100%");
            $('.ring_circle2').attr("stroke", "rgba(255,29,21,0)");

            // time out text show
            // $('.timeout_img').addClass('active');
            $timeout(function() {
                // turn interval clear
                $interval.cancel($scope.turn_timer);
                $interval.cancel($scope.turn_timer_counter);
                if ($scope.outtime_data.ctth != '' && $scope.outtime_data.si == $scope.set_index) {
                    $timeout(function() {
                        $('.sort_custom').mouseup();
                    }, 0);
                    if ($scope.sortableOptions.disabled == true) {
                        //animtion runnig. at that time current player time out and picked card from deck 
                        $timeout(function() {
                            $('.sort_custom').css({ 'top': '0vh' }).removeClass('active_green active highlight_cards');
                            if ($scope.outtime_data.length != 0) {
                                $.grep($scope.lists, function(data, ind) {
                                    var indexd = $.map(data.cards, function(element, index) {
                                        // get card index
                                        if (element.card_detail === $scope.outtime_data.ctth.slice(0, -2) && element.deck === $scope.outtime_data.ctth.substr($scope.outtime_data.ctth.length - 1)) {
                                            return index;
                                        }
                                    });
                                    if (indexd[0] != -1) {
                                        $('.sort_custom').removeClass('highlight_cards active active_green');
                                        $('.sort_custom-container').eq(ind).find('.sort_custom').eq(indexd[0]).addClass('highlight_cards');
                                        //throw card animate 
                                        $scope.discard({ si: $scope.outtime_data.si, card: $scope.outtime_data.ctth }, ind, indexd[0]);
                                    }
                                });
                            }
                        }, 1000);
                    } else {
                        //not any animtion runnig.at that time  current player time out and picked card from deck 
                        $scope.sortableOptions.disabled = true;
                        $timeout(function() {
                            $('.sort_custom').css({ 'top': '0vh' }).removeClass('active_green active highlight_cards');
                            if ($scope.outtime_data.length != 0) {
                                $.grep($scope.lists, function(data, ind) {
                                    var indexd = $.map(data.cards, function(element, index) {
                                        // get card index
                                        if (element.card_detail === $scope.outtime_data.ctth.slice(0, -2) && element.deck === $scope.outtime_data.ctth.substr($scope.outtime_data.ctth.length - 1)) {
                                            return index;
                                        }
                                    });
                                    if (indexd[0] != -1) {
                                        $('.sort_custom').removeClass('highlight_cards active active_green');
                                        $('.sort_custom-container').eq(ind).find('.sort_custom').eq(indexd[0]).addClass('highlight_cards');
                                        //throw card animate 
                                        $scope.discard({ si: $scope.outtime_data.si, card: $scope.outtime_data.ctth }, ind, indexd[0]);
                                    }
                                });
                            }
                        }, 100);
                    }
                } else if ($scope.outtime_data.ctth !== '') {
                    // other player timeout to throw card
                    $scope.discard({ si: $scope.outtime_data.si, card: $scope.outtime_data.ctth });
                }
            }, 50);
        }
        //Over Turn Time Out

        // pick card from open deck
        if ($scope.res.en == "PFOD") {
            // pick card function call
            $scope.pick_deck('open_deck', $scope.res.data);
            $scope.Card_Pick_sound();
            if ($scope.res.data.si == $scope.set_index) {
                $scope.pick_card_msg = false;
            }
        }
        //over pick card from open deck

        //  pick card from close deck
        if ($scope.res.en == "PFCD") {
            // pick card function call
            $scope.pick_deck('close_deck', $scope.res.data);
            $scope.Card_Pick_sound();
            if ($scope.res.data.si == $scope.set_index) {
                $scope.pick_card_msg = false;
            }
        }
        //over pick card from close  deck

        // Discard Card
        if ($scope.res.en == "DSCRD") {
            // call descard function
            $scope.Card_Discard_sound();
            $scope.discard($scope.res.data);
        }
        // over Discard Card

        // Drop Cards
        if ($scope.res.en == "DRC") {
            $scope.Drop_sound();
            $scope.setting_menu_btn = false;
            $scope.dropbtn = false;
            if ($scope.res.data.si == $scope.set_index && $scope.res.data.uid == $scope.sp_id) {
                // current player drop game 
                $scope.disabled_drop = true;
                $scope.drop_standup = true;
                $scope.short_btn_flag = false;
                $scope.declarebtn = false;
                // if ($scope.res.data.dps == undefined) {
                //     // call chips cut animation function
                //     $scope.table_user[$scope.set_index].Chips = $scope.table_user[$scope.set_index].Chips - Math.abs($scope.res.data.wc);
                // }
                $('.sort_custom').removeClass('highlight_cards active active_green');
            }
            var s_id = $scope.res.data.si;
            var c_n = $scope.res.data.dps - $scope.points[s_id];
            // point  increment animation
            $(this).prop('Counter', $scope.points[s_id]).animate({
                Counter: ($scope.points[s_id] + c_n)
            }, {
                duration: 1500,
                easing: 'swing',
                step: function(now) {
                    $timeout(function() {
                        $scope.points[s_id] = Math.ceil(now);
                    }, 0);
                }
            });
            // deal point update arrow animation
            $('.deal_point_img' + s_id + ' img').playKeyframe({
                name: 'delarpointupdate',
                duration: '1600ms',
                timingFunction: 'linear',
                delay: '0s',
                iterationCount: '1',
                direction: 'normal',
                fillMode: 'forwards',
                complete: function() {
                    $('.deal_point_img img').resetKeyframe();
                }
            });
            // set drop label user profile 
            $scope.declaret[$scope.res.data.si] = 2;
            if ($scope.modelset != 'Pool' && $scope.modelset != 'Deal') {
                // drop chips label animation function
                $scope.dropchips_p($scope.res.data.si, Math.abs($scope.res.data.wc),"DRC");
            }
        }
        // over Drop Cards

        if ($scope.res.en == "UTC") {
            $scope.UTC_data = $scope.res.data;
        }

        // Winner Declare
        if ($scope.res.en == "WD") {
            $scope.dropbtn = false;
            $scope.setting_menu_btn = true;
            $scope.settin_menu_slid = 0;
            $scope.short_btn_flag = false;
            $scope.switch_table_msg = false;
            $scope.SDC_data = [];
            $scope.user_dealer = -1;
            $interval.cancel($scope.turn_timer_fns);
            $('.ring_circle2').attr("stroke-dasharray", "0,100%");
            $('.ring_circle2').attr("stroke", "rgba(255,29,21,0)");
            $scope.notturn = false;
            $scope.WD_data = $scope.res.data;
            $scope.finish_popup_show = false;
            $scope.select_lists[0].cards = [];
            $scope.select_gi = [];
            $scope.select_ci = [];
            $scope.winner_chips_d = true;
            // clear player turn animation
            $interval.cancel($scope.timer_round);
            $interval.cancel($scope.turn_timer);
            $interval.cancel($scope.turn_timer_counter);
            $interval.cancel($scope.turn_timer_fns);
            $scope.pass_time = 0;
            $scope.remaing_time = 0;
            angular.forEach($scope.WD_data.pi, function(value, key) {
                // close menu and table info popup and disable click event
                if (value.uid == $scope.sp_id) {
                    $scope.declaret[$scope.WD_data.si] = 0;
                }
            });
            var wind_data = angular.copy($scope.res.data); // copy winner declare data

            // deal and pool mode winner screen
            if ($scope.modelset == 'Deal' || $scope.modelset == 'Pool') {
                $timeout(function() {
                    $scope.deal_winner(wind_data);
                    // $timeout(function() {
                    //     $scope.DealPoolRummyWinner_sound();
                    // },1600);
                }, 1000);
            } else {
                // classic and bet mode  winner screen
                // if ($scope.res.data.wAnimation == false) {
                $timeout(function() {
                    if ($scope.screen[2] == 1) {
                        $scope.count_win_seq = [];
                        $scope.winner_scored_data = $scope.WD_data.pi;
                        $scope.winner_scored = true;
                        angular.forEach(wind_data.pi, function(value2, key2) {
                            $scope.count_win_seq.push((value2.dCards.pure.length + value2.dCards.seq.length));
                        });
                        $scope.clear_play_table();
                        $scope.winner_chips_d = false;
                        $scope.winner_chips_d = false;
                        $interval.cancel($scope.timer_round);
                        $('.winner_animate,.drop_chips_animation').removeClass('active');
                        $('.winner_animate').removeClass('active');
                        $('.winnner_screen_chip p').resetKeyframe();
                        $('.winnner_screen_chip').hide();
                        $('.winnner_screen_chip,.drop_chips_animation').removeClass('active');
                        $('.winnner_screen_chip p').css({ "left": "0", "top": "0", "transition": "0s" });
                        $('.ring_circle2').attr("stroke-dasharray", "0,100%");
                        $('.ring_circle2').attr("stroke", "rgba(255,29,21,0)");
                        $('.timer_counter').removeClass('active');
                        $('.drag_chipsanim').removeClass('active3');
                    }
                },1000);
            // } else {
                //     // close menu and table info popup and disable click event
                //     $scope.classic_winner(wind_data);
                //     $scope.Winner_sound();
                // }
            }
            $('.timer_counter').removeClass('active')
        }
        //Over Winner Declare

        // Last Deal Winner
        if ($scope.res.en == "LASTDEAL") {
            $scope.WD_data = $scope.res.data;
            $scope.winner_scored_data = $scope.WD_data.pi;
            $scope.lastdeal = true;
            $scope.winner_scored = true;
        }
        //Over Last Deal Winner

        // Discarded card
        if ($scope.res.en == "DC") {
            //show  discard slider 
            $scope.dccards = $scope.res.data.dscd;
        }
        //Over Discarded card

        // switch info
        if ($scope.res.en == "SWINF") {
            $scope.SWINF_data = $scope.res.data;
            $scope.switch_table_msg = true;
        }
        // Over switch info

        // Stand UP
        if ($scope.res.en == "STNDUP") {
            $scope.declaret[$scope.res.data.si] = 0;
            $scope.currentwatch = false;
            $scope.STNDUP_data = $scope.res.data;
            $scope.stndupuser_si = $scope.res.data.si;
            $('.user_cards_user_' + $scope.res.data.si + '').removeClass('active');
            if (($scope.waiting_status.length - 1) < $scope.config.MIN_SEAT_TO_FILL) {
                $interval.cancel($scope.timer_round);
            }
            if ($scope.res.data.si == $scope.set_index && $scope.STNDUP_data.uid == $scope.sp_id) {
                // current player standup
                $scope.lists = [];
                $scope.drop_standup = false;
                $scope.select_lists[0].cards = [];
                $scope.dropbtn = false;
                $scope.declarebtn = false;
                $scope.deadwood_points_c = 0;
                $scope.g_data = [];
                $scope.short_btn_flag = false;
            }
            // standup time chips animation
            if ($scope.res.data.wc != undefined) {
                $scope.dropchips_p($scope.res.data.si, Math.abs($scope.res.data.wc), "STNDUP");
            } else {
                $scope.dropchips_p($scope.res.data.si, 0, "STNDUP");
            }
        }
        // Over Stand UP

        // Game Information
        if ($scope.res.en == "GPTI") {
            $scope.GPTI_data = $scope.res.data;
        }
        // Over Game Information

        // Game Information
        if ($scope.res.en == "RPD") {
            $scope.RPD_data = $scope.res.data;
            $(".wrapper-dropdown-5>p").text('Select Issue')
        }
        // Over Game Information

        // Refresh Game Table
        if ($scope.res.en == "REFRESH") {
            $scope.REFRESH_data = $scope.res.data;
            
            if ($scope.lists[0].cards.length != 0) {
                if ($scope.short_btn_flag == false) {
                    $scope.refresh_card_save = $scope.lists;
                    $scope.lists = [{ cards: [], seq: 4 }, { cards: [], seq: 4 }, { cards: [], seq: 4 }, { cards: [], seq: 4 }, { cards: [], seq: 4 }];

                    angular.forEach($scope.refresh_card_save, function(value_data1) {
                        angular.forEach(value_data1, function(value_data2) {
                            angular.forEach(value_data2, function(value_data) {
                                $scope.lists[0].cards.push({ card_detail: value_data.card_detail, deck: value_data.deck });
                            });
                        });
                    });

                    $scope.cards_length = $scope.lists[0].cards.length;
                    $scope.classes_width = ($scope.lists.length);
                    $scope.lists.nullval_remove();
                    $scope.get_margin($scope.cards_length, $scope.classes_width, 2);
                    $scope.onecard_combine();
                    $scope.deadwood_points_c = 80;
                    $scope.deadwood_points($scope.refresh_card_save);
                    $scope.short_btn_flag = $scope.REFRESH_data.sort;
                }
            }
        }
        // Over Refresh Game Table

        // Declare 
        if ($scope.res.en == "DECL") {
            $scope.notturn = false;

            // finsih timer popup set
            if ($scope.res.data.uid == $scope.sp_id) {
                $scope.declarebtn = false;
                $('.not_click').addClass('active');
                $scope.short_btn_flag = false;
                // "waiting for all the players to Finish"
                // $scope.fin_msg = 'Waiting for all the players to finish';
                $interval.cancel($scope.autofinish);
                $interval.cancel($scope.autofinishrejoin);
            }
            // profile label set
            $scope.declaret[$scope.res.data.si] = 3;
        }
        // over Declare 

        // Invalide Declare
        if ($scope.res.en == "INDECL") {
            // profile label set
            $scope.INDECL_data = $scope.res.data;
            $('.not_click').removeClass('active');
            $scope.declaret[$scope.res.data.si] = 2;
            $scope.declarebtn = false;
            $scope.hakamfinish = false;
            $scope.finish_slot_card = 0;
            if ($scope.res.data.si == $scope.set_index) {
                $scope.short_btn_flag = false;
            }
            
            angular.forEach($scope.res.data.sort, function(value, key) {
                if (value.uid == $scope.sp_id && $scope.res.data.si != $scope.set_index) {
                    $scope.declaret[$scope.res.data.si] = 0;
                    $scope.short_btn_flag = value.sort;
                }
            })
            angular.forEach($scope.res.data.asi, function(value, key) {
                $scope.declaret[value] = 0;
            })

            $scope.tCard[1] = $scope.res.data.ocard;
            $('.drop_card_list').removeClass('open_deck_not_click');
        }
        // over Invalide Declare

        // Finish 
        if ($scope.res.en == "FNS") {
            $('.ring_circle2').attr("stroke-dasharray", "0,100%");
            $('.ring_circle2').attr("stroke", "rgba(255,29,21,0)");
            $scope.discarded_popup = false;
            $scope.FNS_data = $scope.res.data;
            $scope.fns_user_si = $scope.res.data.si;
            $scope.popup = [0, 0];
            $scope.setting_menu_btn = true;
            $scope.settin_menu_slid = 0;
            $scope.notturn = false;
            $scope.disabled_drop = false;
            $scope.finish_time = $scope.res.data.t * 1000;
            $scope.finish_time_min = $scope.finish_time;
            $scope.declarebtn = false;
            $scope.switch_table_msg = false;
            $scope.Declare_sound();
            $scope.hakamfinish = true;
            // turn timer animate stop
            $scope.anim_userturn_f(0, $scope.res.data.si, 1);



            // finish timer message set
            // if ($scope.res.data.si == $scope.set_index) {
            //     // "you have declare the game"
            //     $scope.fin_msg = 'You have declared the game';
            //     // "please arrange your cards in sets and sequences and tap"
            //     $scope.fin_msg2 = 'Please arrange your cards in sets and sequences and tap Finish';
            // } else if ($scope.res.data.asi.indexOf($scope.set_index) == -1) {
            //     $scope.fin_msg = $scope.table_user[$scope.res.data.si].un + ' is declaring';
            //     // "waiting for all the players to finish"
            //     $scope.fin_msg2 = 'Waiting for all the players to finish';
            // } else {
            //     $scope.fin_msg = $scope.table_user[$scope.res.data.si].un + ' is declaring';
            //     $scope.fin_msg2 = 'Please arrange your cards in sets and sequences and tap Finish';
            // }
            angular.forEach($scope.res.data.asi, function(value, key) {
                // hide table info popup and menu popup
                $timeout(function() {
                    if (value == $scope.set_index) {
                        var interval_fns = 30;
                        var totla_px_fns = 88;
                        var timer_fns = 88;
                        var circle_fns = document.getElementsByClassName('turn_timer_' + value)[0];
                        var circle_top_fns = document.getElementsByClassName('patern_2')[0];
                        var angle_increment_fns = (totla_px_fns / ((parseInt(1000 / interval_fns) * interval_fns) * $scope.FNS_data.t)) * interval_fns;
                        var angle_fns = timer_fns;

                        $scope.turn_timer_fns = $interval(function() {
                            circle_fns.setAttribute("stroke-dasharray", (totla_px_fns * (angle_fns / totla_px_fns * 100) / 100) + ",100%");
                            circle_fns.setAttribute("stroke", $scope.getColorForPercentage(parseInt(angle_fns / totla_px_fns * 100) / 100));
                            if (parseInt(angle_fns / totla_px_fns * 100) <= 0) {
                                $interval.cancel($scope.turn_timer_fns);
                                $('.ring_circle2').attr("stroke-dasharray", "0,100%");
                                $('.ring_circle2').attr("stroke", "rgba(255,29,21,0)");
                                circle_fns.setAttribute("stroke-dasharray", "0,100%");
                                $scope.declare_btn();
                            }
                            angle_fns = angle_fns - angle_increment_fns;
                        }, interval_fns);
                        $scope.setting_menu_btn = true;
                        $scope.settin_menu_slid = 0;
                        $scope.declarebtn = true;
                    }
                }, 1000);
            });
        }
        // Over Finish 

        // Get PLAY WITH FRIENDS Table Category List
        if ($scope.res.en == "GPT") {
            // SHOW PLAY WITH FRIENDS RUMMY JOIN TABLE POPUP
            $scope.playwithfriends_jointable = 'Classic';
            $scope.playwithfriends_data = $scope.res.data;
            $scope.classicjointable = true;
            $scope.playwithfriends_jointable_data_length = 0;
            $scope.point_minus_btn = false;
            $scope.point_plus_btn = true;
            $scope.player_minus_btn = false;
            $scope.player_plus_btn = true;
            $scope.playwithfriends_jointable_player = 2;
            $scope.playwithfriends_jointable_data = $scope.playwithfriends_data.classicData[$scope.playwithfriends_jointable_data_length].cpp;
        }
        //over Get PLAY WITH FRIENDS Table Category List

        // Get Deal Table Category List
        if ($scope.res.en == "GDTCL") {
            // SHOW DEAL RUMMY SELECT JOIN TABLE POPUP 
            $scope.dealjointable_data = $scope.res.data;
        }
        // over Get Deal Table Category List

        // Get Point Table Category List
        if ($scope.res.en == "GPTC") {
            // SHOW POOL RUMMY JOIN TABLE POPUP
            $scope.table_mode = 'point';
            $scope.jointable_data = $scope.res.data;
            setTimeout(function() {
                $scope.slider = {
                    value: 0,
                    options: {
                        showTicksValues: true,
                        stepsArray: [
                            {value: $scope.jointable_data[0].cpp},
                            {value: $scope.jointable_data[1].cpp},
                            {value: $scope.jointable_data[2].cpp},
                            {value: $scope.jointable_data[3].cpp},
                            {value: $scope.jointable_data[4].cpp},
                            {value: $scope.jointable_data[5].cpp}
                        ],
                        getSelectionBarColor: function(value) {
                            angular.forEach($scope.jointable_data, function(val, key) {
                                if (val.cpp == value) {
                                    $scope.indexofsliderpoint = key;
                                    $scope.value_tabel = val.cpp;
                                }
                            })
                        }
                    }
                };
                $('.uislider').trigger('click');
            }, 500);
        }
        //over Get Point Table Category List


        // Get Pool Table Category List
        if ($scope.res.en == "GPTCL") {
            // SHOW POOL RUMMY JOIN TABLE POPUP
            $scope.table_mode = 'pool';
            $scope.jointable_data = $scope.res.data;
            $scope.pool_101 = true;
            $scope.pool_201 = false;
            setTimeout(function() {
                $scope.slider = {
                    value: 0,
                    options: {
                        showTicksValues: true,
                        stepsArray: [
                            {value: $scope.jointable_data[0].fee},
                            {value: $scope.jointable_data[1].fee},
                            {value: $scope.jointable_data[2].fee},
                            {value: $scope.jointable_data[3].fee},
                            {value: $scope.jointable_data[4].fee}
                        ],
                        getSelectionBarColor: function(value) {
                            angular.forEach($scope.jointable_data, function(val, key) {
                                if (val.fee == value) {
                                    $scope.indexofsliderpool = key;
                                    $scope.value_tabel = val.fee;
                                }
                            })
                        }
                    }
                };
                $('.uislider').trigger('click');
            }, 500);
        }
        //over Get Pool Table Category List

        // Collect Boot Value
        if ($scope.res.en == "CBV") {
            // set collect boot chips
            $scope.collect_chips = [$scope.collect_chips_single, $scope.collect_chips_single, $scope.collect_chips_single, $scope.collect_chips_single, $scope.collect_chips_single];
            // call collect boot function 
            $scope.deal_collect_chips($scope.res.data);
        }
        // Collect Boot Value

        // Is Bet help
        if ($scope.res.en == "ISBH") {
            // SHOW BET HELP POPUP
            $scope.bet_help = $scope.res.data.show;
        }
        // over Is Bet help

        // my profile
        if ($scope.res.en == "MP") {
            // SHOW PROFILE POPUP
            $scope.view_profile_detail = $scope.res.data;
            $scope.PopupOpen_sound();
            $scope.edit_profile_value = false;
        }
        //over my profile

        // get all chat message
        if ($scope.res.en == "GACM") {
            $scope.PopupOpen_sound();
            $scope.chat_play = true;
            $scope.chat_play_data = $scope.res.data;
            if ($scope.chat_play_data == true) {
                $scope.chat_play_data = []
                $scope.chat_play_data.ms.push();
            } else {
                $scope.chat_play_data.ms.push() ;
            }
        }

        // chat on table
        if ($scope.res.en == "COT") {
            $('.chat_play_massage').addClass('chat_play_massage_show');
            $scope.chat_play_data_msg = $scope.res.data;
            $scope.chat_play_msg_set = $scope.res.data.si;
            $timeout(function() {
                $('.chat_play_massage').removeClass('chat_play_massage_show');
            },2000);
        }
    });


    $scope.menu_side = function(value,mode) {
        $scope.dealjointable_data = [];
        $scope.jointable_data = [];
        $scope.playwithfriends_data = [];
        if (value == 2) {
            $scope.cash_game_lagel = false;
            $scope.tounament_game_lagel = false;
            $scope.practice_game_lagel = false;
            $scope.pwf_game_lagel = false;
            if (mode == 'cash') {
                $scope.cash_game_lagel = true;
            } else if (mode == 'tounament') {
                $scope.tounament_game_lagel = true;
            } else if (mode == 'practice') {
                $scope.practice_game_lagel = true;
            } else if (mode == 'pwf') {
                $scope.pwf_game_lagel = true;
            }else{

            }
            $('.menu_side_1').removeClass('deactive_left deactive_right menu_right_to_center menu_center_to_left menu_left_to_center menu_center_to_right').addClass('menu_center_to_left');
            $('.menu_side_2').removeClass('deactive_left deactive_right menu_right_to_center menu_center_to_left menu_left_to_center menu_center_to_right').addClass('menu_right_to_center');
            $('.menu_side_3').removeClass('deactive_left deactive_right menu_right_to_center menu_center_to_left menu_left_to_center menu_center_to_right').addClass('deactive_right');
            $('.menu_side_tab_1').removeClass('deactive_left deactive_right menu_right_to_center menu_center_to_left menu_left_to_center menu_center_to_right menu_side_tab_bg menu_side_tab_fix').addClass('menu_right_to_center');
            $('.menu_side_tab_2').removeClass('deactive_left deactive_right menu_right_to_center menu_center_to_left menu_left_to_center menu_center_to_right').addClass('deactive_right');
            $scope.menu_side_tab_2_show = true;
        } else if (value == 3) {
            $scope.theme_color = 'red';
            $scope.point_rummy_lagel = false;
            $scope.deal_rummy_lagel = false;
            $scope.pool_rummy_lagel = false;
            $scope.raise_rummy_lagel = false;
            if (mode == 'point') {
                $scope.point_rummy_lagel = true;
                if ($scope.cash_game_lagel == true) {
                    $scope.sendData('GPTC', {mode:"cash", pCount: 2});
                } else {
                    $scope.sendData('GPTC', {mode:"practice", pCount: 2});
                }
            } else if (mode == 'deal') {
                $scope.deal_rummy_lagel = true;
            } else if (mode == 'pool') {
                $scope.pool_rummy_lagel = true;
                $scope.pool_type = 101;
                if ($scope.cash_game_lagel == true) {
                    $scope.sendData('GPTCL', {mode:"cash", pCount: 2});
                } else {
                    $scope.sendData('GPTCL', {mode:"practice", pCount: 2});
                }
            } else if (mode == 'raise') {
                $scope.raise_rummy_lagel = true;
            }else{

            }

            $('.menu_side_tab_1').removeClass('deactive_left deactive_right menu_right_to_center menu_center_to_left menu_left_to_center menu_center_to_right menu_side_tab_bg');
            $('.menu_side_tab_1').addClass('menu_side_tab_fix')
            setTimeout(function() {
                $('.menu_side_tab_1').addClass('menu_side_tab_bg')
            }, 500);

            $('.menu_side_1').removeClass('deactive_left deactive_right menu_right_to_center menu_center_to_left menu_left_to_center menu_center_to_right').addClass('deactive_left');
            $('.menu_side_2').removeClass('deactive_left deactive_right menu_right_to_center menu_center_to_left menu_left_to_center menu_center_to_right').addClass('menu_center_to_left');
            $('.menu_side_3').removeClass('deactive_left deactive_right menu_right_to_center menu_center_to_left menu_left_to_center menu_center_to_right').addClass('menu_right_to_center');
            $('.menu_side_tab_2').removeClass('deactive_left deactive_right menu_right_to_center menu_center_to_left menu_left_to_center menu_center_to_right').addClass('menu_right_to_center');
            $scope.menu_side_tab_2_show = true;
        } else if (value == -1) {
            $('.menu_side_1').removeClass('deactive_left deactive_right menu_right_to_center menu_center_to_left menu_left_to_center menu_center_to_right').addClass('menu_left_to_center');
            $('.menu_side_2').removeClass('deactive_left deactive_right menu_right_to_center menu_center_to_left menu_left_to_center menu_center_to_right').addClass('menu_center_to_right');
            $('.menu_side_3').removeClass('deactive_left deactive_right menu_right_to_center menu_center_to_left menu_left_to_center menu_center_to_right').addClass('deactive_right');
            $('.menu_side_tab_1').removeClass('deactive_left deactive_right menu_right_to_center menu_center_to_left menu_left_to_center menu_center_to_right menu_side_tab_bg menu_side_tab_fix').addClass('menu_center_to_right');
            $('.menu_side_tab_2').removeClass('deactive_left deactive_right menu_right_to_center menu_center_to_left menu_left_to_center menu_center_to_right').addClass('deactive_right');
            $timeout(function() {
                $scope.menu_side_tab_2_show = false;
                $scope.cash_game_lagel = false;
                $scope.tounament_game_lagel = false;
                $scope.practice_game_lagel = false;
                $scope.pwf_game_lagel = false;
            }, 500);
        } else if (value == -2) {
            $('.menu_side_tab_1').removeClass('deactive_left deactive_right menu_right_to_center menu_center_to_left menu_left_to_center menu_center_to_right menu_side_tab_bg menu_side_tab_fix');
            $('.menu_side_1').removeClass('deactive_left deactive_right menu_right_to_center menu_center_to_left menu_left_to_center menu_center_to_right').addClass('deactive_right');
            $('.menu_side_2').removeClass('deactive_left deactive_right menu_right_to_center menu_center_to_left menu_left_to_center menu_center_to_right').addClass('menu_left_to_center');
            $('.menu_side_3').removeClass('deactive_left deactive_right menu_right_to_center menu_center_to_left menu_left_to_center menu_center_to_right').addClass('menu_center_to_right');
            $('.menu_side_tab_2').removeClass('deactive_left deactive_right menu_right_to_center menu_center_to_left menu_left_to_center menu_center_to_right').addClass('menu_center_to_right');
            $scope.menu_side_tab_2_show = true;
        }
    }

    // get language list
    $scope.settin_menu = function(flag) {
        $scope.ButtonClick_sound();
        if (flag == 'notifications') {
            if ($scope.settin_menu_slid == 0) {
                $scope.settin_menu_slid = 1;
                $scope.notifications = true;
            } else {
                $scope.settin_menu_slid = 0;
                $scope.notifications = false;
            }
        }else{
            $scope.notifications = false;
            if ($scope.settin_menu_slid == 0) {
                $scope.settin_menu_slid = 1;
            } else {
                $scope.settin_menu_slid = 0;
            }
        }
    };

    $scope.pool_type_abc = function(data) {
        if (data == 'pool_101') {
            $scope.pool_101 = true;
            $scope.pool_201 = false;
            $scope.pool_type = 101;
        }else{
            $scope.pool_201 = true;
            $scope.pool_101 = false;
            $scope.pool_type = 201;
        }
    };

    $scope.table_value = function(data, table_mode) {
        if ($scope.jointable_data.length - 1 > $scope.indexofsliderpool && data == 'max' && table_mode == 'pool') {
            $scope.indexofsliderpool = $scope.indexofsliderpool + 1;

        } else if (0 < $scope.indexofsliderpool && data == 'min' && table_mode == 'pool') {
            $scope.indexofsliderpool = $scope.indexofsliderpool - 1;

        } else if ($scope.jointable_data.length - 1 > $scope.indexofsliderpoint && data == 'max' && table_mode == 'point') {
            $scope.indexofsliderpoint = $scope.indexofsliderpoint + 1;
            
        } else if (0 < $scope.indexofsliderpoint && data == 'min' && table_mode == 'point') {
            $scope.indexofsliderpoint = $scope.indexofsliderpoint - 1;

        }else{

        }
        if (table_mode == 'pool') {
            $scope.slider = {
                value: $scope.jointable_data[$scope.indexofsliderpool].fee,
                options: {
                    showTicksValues: true,
                    stepsArray: [
                        {value: $scope.jointable_data[0].fee},
                        {value: $scope.jointable_data[1].fee},
                        {value: $scope.jointable_data[2].fee},
                        {value: $scope.jointable_data[3].fee},
                        {value: $scope.jointable_data[4].fee}
                    ],
                    getSelectionBarColor: function(value) {
                        angular.forEach($scope.jointable_data, function(val, key) {
                            if (val.fee == value) {
                                $scope.indexofsliderpool = key;
                                $scope.value_tabel = val.fee;
                            }
                        })
                    }
                }
            };
        }
        if (table_mode == 'point') {
            $scope.slider = {
                value: $scope.jointable_data[$scope.indexofsliderpoint].cpp,
                options: {
                    showTicksValues: true,
                    stepsArray: [
                        {value: $scope.jointable_data[0].cpp},
                        {value: $scope.jointable_data[1].cpp},
                        {value: $scope.jointable_data[2].cpp},
                        {value: $scope.jointable_data[3].cpp},
                        {value: $scope.jointable_data[4].cpp},
                        {value: $scope.jointable_data[5].cpp}
                    ],
                    getSelectionBarColor: function(value) {
                        angular.forEach($scope.jointable_data, function(val, key) {
                            if (val.cpp == value) {
                                $scope.indexofsliderpoint = key;
                                $scope.value_tabel = val.cpp;
                            }
                        })
                    }
                }
            };
        }
    };

    $scope.chat_popup = function() {
        $scope.ButtonClick_sound();
        $scope.chat_play =true;
        $scope.sendData('GACM', {});
    };

    $(document).on('click', '.dropdown li a', function(){
        $(".wrapper-dropdown-5>p").text($(this).html())
    });

    $(".wrapper-dropdown-5").click(function(){
        $(this).toggleClass('active');
    });

    $scope.report_submit = function() {
        $scope.ButtonClick_sound();
        $scope.report_category = $(".wrapper-dropdown-5>p").html()
        $scope.report_comments = $(".txt_category").html()
        $scope.sendData('RAP', {category: $scope.report_category, text: $scope.report_comments, tbid: $scope.table_id})
        if ($scope.report_category != 'Select Issue') {
            $scope.RPD_data = [];
        }
    }

    $scope.chat_play_msg_send = function() {
        if ($scope.chat_play_msg != '' && $scope.chat_play_msg != undefined) {
            $scope.sendData('COT', {text: $scope.chat_play_msg });
            $scope.ButtonClick_sound();
            $scope.chat_play_msg = '';
            $scope.chat_play = false;
            $scope.chat_msg_show=true;
        }
        else{
            console.log('No Massage');
        }
        document.getElementById('msg_type').blur();
    };

    $scope.chat_play_msg_defult = function(index) {
        if ($scope.chat_play_msg == '' || $scope.chat_play_msg == undefined) {
            $scope.ButtonClick_sound();
            $scope.a = $scope.chat_play_data.ms[index];
            $scope.sendData('COT', {text: $scope.a});
            $scope.chat_play = false;
            $scope.chat_msg_show=true;
        }
        else{
            console.log('No Massage');
        }
    };

    // array generate function
    $scope.range = function(n) {
        return new Array(n);
    };
    // over array generate function

    // user profile click event
    $scope.view_profile = function(uid) {
        $scope.sendData('MP', { uid: uid });
    };
    //over user profile click event

    // socket connection check
    $scope.socket_c;
    $scope.connected = true;
    $scope.$watch('connected', function() {
        if ($scope.connected == false) {
            $scope.socket_c = $interval(function() {
                $("body").trigger("click");
            }, 10000);
        } else {

        }
    });
    // over socket connection check

    // check internet connection
    $scope.$watch(
        function doesConnectionExist() {
            if ($rootScope.sockets.io.reconnecting == undefined || $rootScope.sockets.connected == true) {
                $scope.connected = true;
            } else if ($rootScope.sockets.io.reconnecting == true || $rootScope.sockets.connected == false) {
                $scope.connected = false;
            }
            $scope.waiting_status = $scope.table_user.filter(function(word) { return word != 0 })
        }
    );
    //over check internet connection
    
    // resize window
    angular.element($window).bind('resize', function() {
        $scope.width_table = ($scope.vhTOpx(100) * 0.3) + $scope.vhTOpx(100);
    });
    //over resize window

    // bet mode bet increase button event
    $scope.betincrease = function(id) {
        if (id == 'inc') {
            if (($scope.bet_value + $scope.scale_value) <= $scope.max_bet_value) {
                $scope.bet_value = $scope.bet_value + $scope.scale_value;
                $scope.join.pi[$scope.set_index].pickCount = $scope.join.pi[$scope.set_index].pickCount + 1;
            } else {
                $('.maxbootvalue').show();
                $timeout(function() {
                    $('.maxbootvalue').hide();
                }, 3000);
            }
        } else if (id == 'dec') {
            if (($scope.bet_value - $scope.scale_value) >= $scope.min_value) {
                $scope.bet_value = $scope.bet_value - $scope.scale_value;
            }
        }
    }
    //over bet mode bet increase  button event

    // deal rummy collect chips animation
    $scope.deal_collect_chips = function(data) {
        var current_by = data.pv;
        $.each(data.pChips, function(index, value) {
            // $('.drag_chips' + $scope.user_setting_ar[$scope.set_index][value.si] + '').addClass('active3');
            $scope.table_user[value.si].Chips = $scope.table_user[value.si].Chips - $scope.collect_chips[0];
            // if($scope.modelset === "Pool" || $scope.modelset === "Deal"){
            //     setTimeout(function() {
            //         $scope.CoinsCollectInDealORPool_sound();
            //     }, 1400);
            // }
            // if (index == 0) {
            //     // user chips cut animation
            //     $(this).prop('Counter', $scope.collect_chips[0]).animate({
            //         Counter: ($scope.collect_chips[0] - $scope.collect_chips[0])
            //     }, {
            //         duration: 1500,
            //         easing: 'swing',
            //         step: function(now) {
            //             $timeout(function() {
            //                 $scope.collect_chips[0] = Math.ceil(now);
            //                 $scope.collect_chips[1] = Math.ceil(now);
            //                 $scope.collect_chips[2] = Math.ceil(now);
            //                 $scope.collect_chips[3] = Math.ceil(now);
            //                 $scope.collect_chips[4] = Math.ceil(now);
            //             }, 0);
            //         },
            //         complete: function() {
            //             $('.drag_chipsanim').removeClass('active3');
            //             $timeout(function() {
            //                 $('.deal_rummy img').css('opacity', '1');
            //                 $scope.ofcoin[0] = ($('.deal_coin_pos').offset().left + $('.deal_coin_pos').width() / 2) - $('.deal_rummy img').offset().left;
            //                 $scope.ofcoin[1] = ($('.deal_coin_pos').offset().top + $('.deal_coin_pos').height() / 2) - $('.deal_rummy img').offset().top;
            //                 $.keyframe.define([{
            //                     name: 'dealchipsanim',
            //                     '0%': {
            //                         'left': '' + $scope.vhTOpx(0.5) + 'px',
            //                         'top': '' + $scope.vhTOpx(1) + 'px',
            //                     },
            //                     '100%': {
            //                         'left': '' + $scope.ofcoin[0] + 'px',
            //                         'top': '' + $scope.ofcoin[1] + 'px',
            //                     }
            //                 }, ]);

            //                 $('.deal_rummy  img').each(function(index) {
            //                     $(this).playKeyframe({
            //                         name: 'dealchipsanim',
            //                         duration: '' + ((index + 1) * 10) + 'ms',
            //                         timingFunction: 'linear',
            //                         delay: '0s',
            //                         iterationCount: 'infinite',
            //                         direction: 'normal',
            //                         fillMode: 'forwards',
            //                         complete: function() {}
            //                     });
            //                 });
            //             }, 500);
            //         }
            //     });
            // } else if (index == 1) {
            //     // table chips increment  animation
            //     $(this).prop('Counter', $scope.dealcollect).animate({
            //         Counter: ($scope.dealcollect + data.pv)
            //     }, {
            //         duration: 1500,
            //         easing: 'swing',
            //         step: function(now) {
            //             $timeout(function() {
            //                 $scope.dealcollect = Math.ceil(now);
            //             }, 0);
            //         },
            //         complete: function() {
            //             $timeout(function() {
            //                 $('.count').each(function(index) {
            //                     if (index == 0) {
            //                         // table chips decrement animation
            //                         $(this).prop('Counter', $scope.dealcollect).animate({
            //                             Counter: ($scope.dealcollect - $scope.dealcollect)
            //                         }, {
            //                             duration: 1500,
            //                             easing: 'swing',
            //                             step: function(now) {
            //                                 $timeout(function() {
            //                                     $scope.dealcollect = Math.ceil(now);
            //                                 }, 0);
            //                             }
            //                         });
            //                     } else {
            //                         // table info popup chips increment
            //                         $scope.bv = 0;
            //                         $(this).prop('Counter', $scope.bv).animate({
            //                             Counter: ($scope.bv + data.pv)
            //                         }, {
            //                             duration: 1500,
            //                             easing: 'swing',
            //                             step: function(now) {
            //                                 $timeout(function() {
            //                                     $scope.bv = Math.ceil(now);
            //                                 }, 0);
            //                             }
            //                         });
            //                     }
            //                 });
            //             }, 500);
            //         }
            //     });
            // }
            // // user label animate
            // $timeout(function() {
            //     var width = ($('.user_cards_user_' + value.si + ' .blankuser').outerWidth() / 2) - ($('.drag_chips' + $scope.user_setting_ar[$scope.set_index][value.si] + '').outerWidth() / 2);
            //     $scope.ofcoin[0] = ($('.user_cards_user_' + value.si + ' .blankuser').outerWidth() / 2) + ($('.deal_rummy').offset().left - $('.drag_chips' + $scope.user_setting_ar[$scope.set_index][value.si] + '').offset().left);
            //     $scope.ofcoin[1] = ($('.deal_rummy').offset().top) - ($('.user_cards_user_' + value.si + ' .blankuser').offset().top);
            //     $.keyframe.define([{
            //         name: 'collect_chips' + value.si + '',
            //         '0%': {
            //             'left': '' + (width) + 'px',
            //             'top': '' + $scope.vhTOpx(13) + 'px',
            //         },
            //         '100%': {
            //             'left': '' + $scope.ofcoin[0] + 'px',
            //             'top': '' + $scope.ofcoin[1] + 'px',
            //         }
            //     }, ]);
            //     $('.drag_chips' + $scope.user_setting_ar[$scope.set_index][value.si] + '').playKeyframe({
            //         name: 'collect_chips' + value.si + '',
            //         duration: '1.3s',
            //         timingFunction: 'linear',
            //         delay: '0s',
            //         iterationCount: '1',
            //         direction: 'normal',
            //         fillMode: 'forwards',
            //         complete: function() {
            //             $('.drag_chips' + $scope.user_setting_ar[$scope.set_index][value.si] + '').resetKeyframe();
            //         }
            //     });
            // }, 200);
        });
    }
    // deal rummy collect chips animation

    //chips fortmate generate
    $scope.chips_formate = function(num) {
        if (num >= 1000000000) {
            var val_Cr_up_round;
            var val_Cr_round;
            var val_L_round;
            var val_K_round;
            var val_Cr_up = (num / 100000000).toFixed(3).replace(/\B(?=(\d{3})+(?!\d))/g);
            var val_Cr_up_split = val_Cr_up.split('.');
            if (val_Cr_up_split[1] == "000") {
                val_Cr_up_round = val_Cr_up_split[0];
            }else{
                val_Cr_up_round = val_Cr_up_split[0] + '.' + val_Cr_up_split[1];
            }
            return val_Cr_up_round + ' Cr';
        }
        if (num >= 10000000 && num < 1000000000) {
            var val_Cr_round;
            var val_L_round;
            var val_K_round;
            var val_Cr = (num / 10000000).toFixed(2).replace(/\B(?=(\d{2})+(?!\d))/g);
            var val_Cr_split = val_Cr.split('.');
            if (val_Cr_split[1] == "00") {
                val_Cr_round = val_Cr_split[0];
            }else{
                val_Cr_round = val_Cr_split[0] + '.' + val_Cr_split[1];
            }
            return val_Cr_round + ' Cr';
        }
        if (num >= 100000 && num < 10000000) {
            var val_L = (num / 100000).toFixed(2).replace(/\B(?=(\d{2})+(?!\d))/g);
            var val_L_split = val_L.split('.');
            if (val_L_split[1] == "00") {
                val_L_round = val_L_split[0];
            }else{
                val_L_round = val_L_split[0] + '.' + val_L_split[1];
            }
            return val_L_round + ' L';
        }
        if (num >= 1000 && num < 100000) {
            var val_K = (num / 1000).toFixed(2).replace(/\B(?=(\d{2})+(?!\d))/g);
            var val_K_split = val_K.split('.');
            if (val_K_split[1] == "00") {
                val_K_round = val_K_split[0];
            }else{
                val_K_round = val_K_split[0] + '.' + val_K_split[1];
            }
            return val_K_round + ' K';
        }
        // if (num < 1000) {
        //     num = num.toString();
        //     var lastThree = num.substring(num.length - 3);
        //     var otherNumbers = num.substring(0, num.length - 3);
        //     if (otherNumbers != '')
        //         lastThree = ',' + lastThree;
        //     num = otherNumbers.replace(/\B(?=(\d{2})+(?!\d))/g) + lastThree;
        // }
        return num;
    }
    //over chips fortmate generate

    // drop chips animate and cut chips animation
    $scope.g_data = [];
    $scope.datavalue = 0;
    var counter;
    $scope.dropchips_p = function(data, chips, flag) {
        var stopTime;
        var totalcount = $scope.dropd_chips_first;
        $interval.cancel(stopTime);
        $scope.collect_chips[$scope.user_setting_ar[$scope.set_index][data]] = chips;
        if ($scope.gti_data.mode == 'practice') {
            $scope.table_user[data].Chips = $scope.table_user[data].Chips - chips;
        } else {
            $scope.table_user[data].totalCash = $scope.table_user[data].totalCash - chips;
        }
        $scope.g_data.push(chips);
        if (chips != 0) {
            $('.drop_chips_animation').removeClass('active');
            $('.drag_chipsanim' + data + '').addClass('active3');
            $scope.dropd_chips_d = true;
            $timeout(function() {
                // user label animation
                if ($('.drop_chips_left').length != 0 && $('.user_cards_user_' + data + ' .blankuser').length != 0) {
                    $scope.ofcoin[0] = ($('.drop_chips_left').offset().left + $('.drop_chips_left').width() / 2) - $('.user_cards_user_' + data + ' .blankuser').offset().left;
                    $scope.ofcoin[1] = ($('.drop_chips_left').offset().top) - ($('.user_cards_user_' + data + ' .blankuser').offset().top - $scope.vhTOpx(1));
                
                    $.keyframe.define([{
                        name: 'dropchips' + data + '',
                        '0%': {
                            'left': '' + $('.user_cards_user_' + data + ' .blankuser').outerWidth() / 2 + 'px',
                            'top': '' + $scope.vhTOpx(13) + 'px',
                        },
                        '100%': {
                            'left': '' + $scope.ofcoin[0] + 'px',
                            'top': '' + $scope.ofcoin[1] + 'px',
                        }
                    }, ]);
                    $('.drag_chipsanim' + data + '').playKeyframe({
                        name: 'dropchips' + data + '',
                        duration: '1.5s',
                        timingFunction: 'linear',
                        delay: '0s',
                        iterationCount: '1',
                        direction: 'normal',
                        fillMode: 'forwards',
                        complete: function() {
                            $('.drag_chipsanim' + data + '').resetKeyframe();
                            $('.drag_chipsanim' + data + '').removeClass('active active3');
                            $('.user_cards_user_' + data + '').css({ "z-index": "3" });
                            $('.drop_chips .drop_chips_animation').addClass('active');
                            $('.drag_chipsanim' + data + '').css({ "left": "50%", "top": "13vh" });
                            if (flag == "STNDUP") {
                                $scope.table_user[data] = 0;
                                if (data == $scope.set_index) {
                                    $scope.joinhere = true;
                                    $scope.set_index = data;
                                }
                            }
                            $scope.dropd_chips = $scope.dropd_chips + chips;
                        }
                    });
                    if (flag == "LT") {
                        $scope.dropd_chips = $scope.dropd_chips + chips;
                    }
                }
            }, 400);
        } else {
            if (flag == "STNDUP") {
                $scope.table_user[data] = 0;
                if (data == $scope.set_index) {
                    $scope.joinhere = true;
                    $scope.set_index = data;
                }
            }
        }
    }
    //over drop chips animate and cut chips animation

    // standup user join  event
    $scope.joinback = function(id) {
        $scope.sendData('JNBK', { si: id });
        // $scope.STNDUP_data = [];
    }
    //over standup user join  event

    // deal, pool and bet mode join table
    $scope.join_deal_pool = function(ctid, id) {
        $scope.ButtonClick_sound()
        $scope.clear_play_table();
        $scope.ngclick_enabled = false;
        if (id == 'point') {
            if ($scope.cash_game_lagel == true) {
                angular.forEach($scope.jointable_data, function(value, key) {
                    if (ctid == value._id) {
                        $scope.cash_game_info_data.push(value);
                        $scope.cash_game_info_data.push({gametype:id})
                        $scope.cash_game_auto_start_fun(10,id)
                    }
                })
            } else {
                $scope.sendData('FTAJ', { catid: ctid, theme: $scope.theme_color});
            }
        } else if (id == 'deal') {
            $scope.sendData('FTAJDM', { catid: ctid });
        } else if (id == 'pool') {
            if ($scope.cash_game_lagel == true) {
                angular.forEach($scope.jointable_data, function(value, key) {
                    if (ctid == value._id) {
                        $scope.cash_game_info_data.push(value);
                        $scope.cash_game_info_data.push({gametype:id})
                        $scope.cash_game_auto_start_fun(10,id)
                    }
                })
            } else {
                $scope.sendData('FTAJPM', { catid: ctid, pt: $scope.pool_type, theme: $scope.theme_color});
            }
        } else if (id == 'bet') {
            $scope.bet_help = 0;
            $scope.sendData('FTAJBM', {});
        } else if (id == 'playwithfriends') {
            $scope.sendData('CPT', {bv:$scope.playwithfriends_jointable_data, gt:$scope.playwithfriends_jointable, pCount:$scope.playwithfriends_jointable_player});
        }
    }
    // over deal, pool and bet mode join table

    // round time start  function
    $scope.cash_game_auto_start_fun = function(timer,flag) {
        if (timer == -1) {
            if (flag == 'point') {
                $scope.sendData('FTAJC', { catid: $scope.cash_game_info_data[0]._id, theme: $scope.theme_color});
            } else if (flag == 'pool') {
                $scope.sendData('FTAJPMC', { catid: $scope.cash_game_info_data[0]._id, pt: $scope.pool_type, theme: $scope.theme_color});
            } else {

            }
            $interval.cancel($scope.cash_game_auto_start);
            $scope.cash_game_info_data = []
        } else if (timer == false) {
            $interval.cancel($scope.cash_game_auto_start);
            $scope.cash_game_info_data = []
        } else {
            $scope.cash_game_start = timer;
            $interval.cancel($scope.cash_game_auto_start);
            $scope.setting_menu_btn = false;

            $scope.cash_game_auto_start = $interval(function() {
                $scope.cash_game_start = $scope.cash_game_start - 1;
                if ($scope.cash_game_start <= 0) {
                    $interval.cancel($scope.cash_game_auto_start);
                    if (flag == 'point') {
                        $scope.sendData('FTAJC', { catid: $scope.cash_game_info_data[0]._id, theme: $scope.theme_color});
                    } else if (flag == 'pool') {
                        $scope.sendData('FTAJPMC', { catid: $scope.cash_game_info_data[0]._id, pt: $scope.pool_type, theme: $scope.theme_color});
                    } else {
                        
                    }
                    $scope.cash_game_info_data = []
                }
            }, 1000);
        }
    }
    //over round time start  function

    //deal and pool mode winner screen 
    $scope.win_length = [0, 1];
    // deal mode ,pool mode winner animation
    $scope.deal_winner = function(data) {
        $scope.count_win_seq = [];
        $scope.winner_scored_data = data.pi;
        $interval.cancel($scope.timer_round);
        $scope.finish_timer = false;
        $scope.winner_chips_d = 'first';
        $scope.win_length = data.win;
        $('.winner_animate').removeClass('active');
        if (data.tst == "roundWinnerDeclared") {
            // round winner declare
            $scope.gameround = data.round;
            // red chips winner animation
            // $scope.time_clearwinner[6] = $timeout(function() {
            //     $('.winner_animate' + data.win[0] + '').addClass('active');
            // }, 2100);
            //red arrow animation
            // $scope.time_clearwinner[7] = $timeout(function() {
            //     $('.winner_animate').removeClass('active');
                angular.forEach(data.pi, function(value, key) {
                    if (value.dps != 0 && value.dps != $scope.points[value.si]) {
                        var c_n = value.dps - $scope.points[value.si]
                        $('.count').eq(value.si).prop('Counter', $scope.points[value.si]).animate({
                            Counter: ($scope.points[value.si] + c_n)
                        }, {
                            duration: 1500,
                            easing: 'swing',
                            step: function(now) {
                                $timeout(function() {
                                    $scope.points[value.si] = Math.ceil(now);
                                }, 0);
                            }
                        });
                        $('.deal_point_img' + value.si + ' img').playKeyframe({
                            name: 'delarpointupdate',
                            duration: '1600ms',
                            timingFunction: 'linear',
                            delay: '0s',
                            iterationCount: '1',
                            direction: 'normal',
                            fillMode: 'forwards',
                            complete: function() {
                                $('.deal_point_img img').resetKeyframe();
                            }
                        });
                    }
                    // $scope.time_clearwinner[8] = $timeout(function() {
                    //     $('.winner_animate').removeClass('active');
                        $scope.clear_play_table();
                        $scope.winner_scored = true;
                    // }, 1600);
                });
            // }, 4600);
        } else if (data.tst == "winnerDeclared") {
            // winnerDeclared
            $scope.gameround = 0;
            $scope.currentround = 2;
            // $('.dealwinneranimation_top').show();
            // $scope.time_clearwinner[9] = $timeout(function() {
            //     $('.dealwinneranimation').addClass('active');
            // }, 1000);
            // $scope.time_clearwinner[10] = $timeout(function() {
            //     //winner crown animation and deal winner/pool winner blink 
            //     $('.winner_crown,.winner_content_deal p:nth-child(1)').addClass('active');
            //     // winner user text transfer
            //     angular.forEach($scope.win_length, function(value3, key3) {
            //         $('.deal_point_img' + $scope.win_length[value3] + '').addClass('active');
            //     });
            // }, 2000);
            // $scope.time_clearwinner[11] = $timeout(function() {
            //     angular.forEach($scope.win_length, function(value4, key4) {
            //         var left_a = ($('.deal_point_img' + value4 + '').offset().left + $('.deal_point_img' + value4 + '').width() / 3) - ($('.winner_animate_dealmode').offset().left + $('.winner_animate_dealmode').width() / 2);
            //         var top_a = ($('.deal_point_img' + value4 + '').offset().top + $('.deal_point_img' + value4 + '').height() / 3) - ($('.winner_animate_dealmode').offset().top + $('.winner_animate_dealmode').height() / 2);
            //         $.keyframe.define([{
            //             name: 'winchips' + value4 + '',
            //             '0%': {
            //                 'left': '0px',
            //                 'top': '0px',
            //             },
            //             '100%': {
            //                 'left': '' + left_a + 'px',
            //                 'top': '' + top_a + 'px',
            //             }
            //         }, ]);
            //         $('.winner_animate_dealmode' + value4 + '').each(function(index) {
            //             $(this).playKeyframe({
            //                 name: 'winchips' + value4 + '',
            //                 duration: '' + ((index + 1) * 100) + 'ms',
            //                 timingFunction: 'linear',
            //                 delay: '0s',
            //                 iterationCount: 'infinite',
            //                 direction: 'normal',
            //                 fillMode: 'forwards',
            //                 complete: function() {
            //                     $('.winner_animate').removeClass('active');
            //                 }
            //             });
            //         });
            //     });
            //     $scope.time_clearwinner[12] = $timeout(function() {
            //         $('.winner_animate_dealmode').resetKeyframe();
            //         angular.forEach($scope.win_length, function(value4, key4) {
            //             $('.deal_point_img' + value4 + '').addClass('active2');
            //         });
            //         $scope.time_clearwinner[13] = $timeout(function() {
            //         }, 1500);
            //     }, 1500);
            // }, 3000);
            $scope.points = [0, 0, 0, 0, 0, 0];
            $scope.clear_play_table();
            $scope.winner_scored = true;

        }
        angular.forEach(data.pi, function(c_val, c_key) {
            $scope.count_win_seq.push((c_val.dCards.pure.length + c_val.dCards.seq.length));
            angular.forEach($scope.table_user, function(c_val1, c_key1) {
                if (c_val.si == c_val1.si) {
                    c_val1.Chips = c_val.Chips;
                }
            });
        });

        // set user drop,win,lost tag
        angular.forEach(data.pi, function(value2, key2) {
            angular.forEach(data.win, function(value3, key3) {
                if (value2.s == 'left') {
                    $scope.declaret[value2.si] = 6;
                }
                if (value2.s != 'drop' && value2.si != value3) {
                    $scope.declaret[value2.si] = 4;
                } else if (value2.si == value3) {
                    $scope.declaret[value2.si] = 5;
                    $scope.win_profile = value2.pp;
                }
                if (data.pi.length == data.win.length) {
                    $scope.declaret[value3] = 7;
                }
            });
        });
    }
    //over deal mode ,pool mode winner animation


    // classic mode winner
    $scope.classic_winner = function(data) {
        $scope.count_win_seq = [];
        $scope.winner_scored_data = data.pi;
        $interval.cancel($scope.timer_round);
        $scope.win_length = data.win;
        $scope.time_clearwinner[0] = $timeout(function() {
            $('.winner_animate,.drop_chips_animation').removeClass('active');
            $('.winner_animate' + data.win[0] + '').addClass('active');
        }, 100);
        $scope.time_clearwinner[1] = $timeout(function() {
            $('.winnner_screen_chip').show();
            $('.drop_big_coin').hide();
            angular.forEach(data.pi, function(value2, key2) {
                $scope.count_win_seq.push((value2.dCards.pure.length + value2.dCards.seq.length));
                angular.forEach(data.win, function(value3, key3) {
                    if (value2.s != 'standup' && value2.s != 'drop' && value2.s != 'left' && value2.si != value3) {
                        $('.drag_chips' + $scope.user_setting_ar[$scope.set_index][value2.si] + '').addClass('active3');
                        $scope.collect_chips[$scope.user_setting_ar[$scope.set_index][value2.si]] = Math.abs(value2.wc);
                    }
                });
            });
            $('.count').each(function(index) {
                $(this).prop('Counter', $scope.collect_chips[index]).animate({
                    Counter: ($scope.collect_chips[index] - $scope.collect_chips[index])
                }, {
                    duration: 1500,
                    easing: 'swing',
                    step: function(now) {
                        $timeout(function() {
                            $scope.collect_chips[index] = Math.ceil(now);
                        }, 0);
                    }
                });
            });
        }, 2650);
        $scope.time_clearwinner[2] = $timeout(function() {
            var chips = $scope.dropd_chips;
            $('.winner_animate').removeClass('active');
            if ($scope.dropd_chips != 0) {
                if ($('.winnner_screen_chip p').offset().left != undefined && $('.drop_chips').offset().left != undefined && $('.winnner_screen_chip p').offset().top != undefined && $('.drop_chips_left').offset().top != undefined) {
                    $scope.ofcoin[0] = ($('.winnner_screen_chip p').offset().left) - $('.drop_chips').offset().left;
                    $scope.ofcoin[1] = ($('.winnner_screen_chip p').offset().top) - ($('.drop_chips_left').offset().top - ($('.drop_chips_left').height() / 2));
                    $('.drop_chips_left').css({ "transform": "translate(" + $scope.ofcoin[0] + "px," + $scope.ofcoin[1] + "px)", "transition": "1.5s" });
                }
            }

            angular.forEach(data.pi, function(value2, key2) {
                angular.forEach(data.win, function(value3, key3) {
                    if (value2.s != 'standup' && value2.s != 'drop' && value2.s != 'left' && value2.si != value3) {
                        $scope.ofcoin[0] = ($('.winnner_screen_chip p').offset().left + $('.winnner_screen_chip p').width() / 1.85) - $('.user_cards_user_' + value2.si + ' .blankuser').offset().left;
                        $scope.ofcoin[1] = ($('.winnner_screen_chip p').offset().top) - ($('.user_cards_user_' + value2.si + ' .blankuser').offset().top);
                        $.keyframe.define([{
                            name: 'winner_collect' + value2.si + '',
                            '0%': {
                                'left': '' + $('.user_cards_user_' + value2.si + ' .blankuser').outerWidth() / 2 + 'px',
                                'top': '' + $scope.vhTOpx(13) + 'px',
                            },
                            '100%': {
                                'left': '' + $scope.ofcoin[0] + 'px',
                                'top': '' + $scope.ofcoin[1] + 'px',
                            }
                        }, ]);
                        $('.drag_chips' + $scope.user_setting_ar[$scope.set_index][value2.si] + '').playKeyframe({
                            name: 'winner_collect' + value2.si + '',
                            duration: '1.5s',
                            timingFunction: 'linear',
                            delay: '0s',
                            iterationCount: '1',
                            direction: 'normal',
                            fillMode: 'forwards',
                            complete: function() {
                                $('.drag_chipsanim').css({ "left": "50%", "top": "50%" }).removeClass('active3');
                                $('.drag_chips' + $scope.user_setting_ar[$scope.set_index][value2.si] + '').resetKeyframe();
                            }
                        });
                        chips = chips + Math.abs(value2.wc);
                        $scope.table_user[value2.si].Chips = ($scope.table_user[value2.si].Chips - Math.abs(value2.wc));
                        $scope.declaret[value2.si] = 0;
                    } else if (value2.si == value3) {
                        $scope.declaret[value2.si] = 0;
                    }
                });
            });
            $(this).prop('Counter', $scope.winner_chips).animate({
                Counter: ($scope.winner_chips + chips)
            }, {
                duration: 1500,
                easing: 'swing',
                step: function(now) {
                    $timeout(function() {
                        $scope.winner_chips = Math.ceil(now);
                    }, 0);
                }
            });
            $scope.time_clearwinner[3] = $timeout(function() {
                $scope.CoinDepositonWinning_sound();
                $('.drop_chips_left').css({ "transform": "0px,0px)", "transition": "1.5s" });
                $('.winnner_screen_chip .drop_chips_animation').addClass('active');
                $scope.dropd_chips_d = false;
                $scope.time_clearwinner[4] = $timeout(function() {
                    $('.winnner_screen_chip').addClass('active');
                    if ($('.user_cards_user_' + $scope.win_length[0] + ' .blankuser .user_name_chips_pts').length != 0 && $('.winnner_screen_chip p').length != 0) {
                        $scope.ofcoin[0] = ($('.user_cards_user_' + $scope.win_length[0] + ' .blankuser .user_name_chips_pts').offset().left) - ($('.winnner_screen_chip p').offset().left + ($('.winnner_screen_chip p').width() / 50));
                        $scope.ofcoin[1] = ($('.user_cards_user_' + $scope.win_length[0] + ' .blankuser .user_name_chips_pts').offset().top) - ($('.winnner_screen_chip p').offset().top);

                    
                        $.keyframe.define([{
                            name: 'dealchipsanim',
                            '0%': {
                                'left': '-' + $scope.vhTOpx(1) + 'px',
                                'top': '-' + $scope.vhTOpx(2) + 'px',
                            },
                            '100%': {
                                'left': '' + $scope.ofcoin[0] + 'px',
                                'top': '' + $scope.ofcoin[1] + 'px',
                            }
                        }, ]);
                        $('.winnner_screen_chip p').playKeyframe({
                            name: 'dealchipsanim',
                            duration: '1.5s',
                            timingFunction: 'linear',
                            delay: '0s',
                            iterationCount: '1',
                            direction: 'normal',
                            fillMode: 'forwards',
                            complete: function() {}
                        });
                        $(this).prop('Counter', $scope.table_user[data.win[0]].Chips).animate({
                            Counter: ($scope.table_user[data.win[0]].Chips + $scope.winner_chips)
                        }, {
                            duration: 1500,
                            easing: 'swing',
                            step: function(now) {
                                $timeout(function() {
                                    $scope.table_user[data.win[0]].Chips = Math.ceil(now);
                                }, 0);
                            }
                        });
                    }
                }, 500);

                $scope.time_clearwinner[5] = $timeout(function() {
                    $('.user_cards_user_' + $scope.win_length[0] + '').find('.drop_chips_animation').addClass('active');
                    $timeout(function() {
                        $scope.winner_scored = true;
                        $scope.clear_play_table();
                        $scope.winner_chips_d = false;
                        $('.winnner_screen_chip p').resetKeyframe();
                        $('.winnner_screen_chip').hide();
                        $('.drop_big_coin').show();
                        $('.winnner_screen_chip,.drop_chips_animation').removeClass('active');
                        $('.winnner_screen_chip p').css({ "left": "0", "top": "0", "transition": "0s" });
                    }, 500);
                }, 2000);
            }, 1600);
        }, 2700);
    }

    // clear playing table data
    $scope.clear_play_table = function() {
        $('.not_click').removeClass('active');
        $('.fin_card').css({'opacity':'1'})
        $scope.settin_menu_slid = 0;
        $scope.user_dealer = -1;
        $scope.switch_table_msg = false;
        $scope.GPTI_data = [];
        $scope.RPD_data = [];
        $scope.settings_popup = false;
        $scope.common_popup_show = false;
        $scope.INDECL_data = [];
        $scope.winner_chips = 0;
        $scope.smccard = { tCard: '', wildCard: '' };
        $scope.lists = [];
        $scope.view_profile_detail = [];
        $('.maxbootvalue').hide();
        $scope.setting_menu_btn = false;
        $scope.card_flip_animation = false;
        $scope.updatelisted = [];
        $scope.sdc_cards = false;
        $scope.wildCard = '';
        $scope.dataLoaded = false;
        $scope.tCard = [0, 0];
        $interval.cancel($scope.timer_round);
        $interval.cancel($scope.turn_timer);
        $interval.cancel($scope.turn_timer_counter);
        $scope.pass_time = 0;
        $scope.remaing_time = 0;
        $scope.round_timer = 0;
        $scope.lists = [];
        $scope.g_data = [];
        $scope.disabled_drop = false;
        $scope.drop_standup = false;
        $scope.dropbtn = false;
        $scope.winner_chips_d = false;
        $scope.hakamfinish = false;
        $scope.finish_popup_show = false;
        $scope.sdc_cards = false;
        $scope.dropd_chips_d = false;
        $scope.dropd_chips = 0;
        $scope.dropd_chips_first = 0;
        $scope.declaret = [0, 0, 0, 0, 0, 0];
        $scope.deadwood_points_c = 0;
        $scope.joinback_switch = 1;
        $scope.popup = [0, 0];
        $scope.select_lists[0].cards = [];
        $scope.select_gi = [];
        $scope.select_ci = [];
        $scope.dataLoaded = true;
        $scope.declarebtn = false;
        $scope.pickcrds = false;
        $scope.finish_slot_card = 0;
        $scope.switch_table_msg = false;
        $('.dealwinneranimation_top').hide();
        $('.dealwinneranimation,.deal_point_img,.winner_content_deal p').removeClass('active active2');
        $('.dealrummy_round').find('p').css({ 'opacity': '0' });
        // $('.timeout_img').removeClass('active');
        $('.deling_cards').removeClass('active_card_animation');
        $('.ring_circle2').attr("stroke-dasharray", "0,100%");
        $('.ring_circle2').attr("stroke", "rgba(255,29,21,0)");
        $('.timer_counter').removeClass('active')
        $('.deal_point_img img').resetKeyframe();
        $('.drag_chipsanim').css({ "left": "50%", "top": "50%" });
        $('.userlist,.current_user').removeClass('active');
    }
    //over clear playing table data

    // winner screen clear data
    $scope.winner_clear = function() {
        $scope.pickcrds = false;
        $scope.winner_chips_d = false;
        $scope.setting_menu_btn = false;
        $scope.points = [0, 0, 0, 0, 0, 0];
        $scope.card_flip_animation = false;
        angular.forEach($scope.time_clearwinner, function(value, key) {
            $timeout.cancel($scope.time_clearwinner[key]);
            if (key == 13) {
                $('.through_card').css({ 'transform': 'scale(0)' });
                $scope.winner_scored_data = '';
                $scope.lastdeal = false;
                $('.drop_chips_left').css({ "transform": "0px,0px)", "transition": "1.5s" });
                $('.winner_animate,.dealwinneranimation,.winner_crown,.winner_content_deal p:nth-child(1),.deal_point_img,.drag_chipsanim,.winnner_screen_chip,.drop_chips_animation').removeClass('active active2 active3');
                $('.userlist,.current_user').removeClass('active');
                $('.dealwinneranimation_top,.winnner_screen_chip,.drop_big_coin').hide();
                $('.winnner_screen_chip p').css({ "left": "0", "top": "0", "transition": "0s" });
                $scope.clear_play_table();
            }
        });
    }
    //over H winner screen clear data


    //playing table menu button event
    $scope.settings_menus = function(id, place) {
        $scope.ButtonClick_sound();
        if ($scope.setting_menu_btn == false) {
            if (place == 'playing') {
                $scope.settin_menu_slid = 0;
                if (id == 1) {
                    // Switch Table
                    $scope.sendData('SWINF', {tbid:$scope.table_id, si:$scope.set_index});
                }
                if (id == 2) {
                    $scope.sendData('STNDUP', {});
                }
                if (id == 3) {
                    // Game settings
                    $scope.PopupOpen_sound();
                    $scope.settings_popup = true;
                }
                if (id == 4) {
                    // Game Information
                    $scope.sendData('GPTI', {tbId:$scope.table_id});

                }
                if (id == 5) {
                    // Refresh Game Table
                    $scope.sendData('REFRESH', {tbid:$scope.table_id,si:$scope.set_index});
                }
                if (id == 6) {
                    // Report A Problem
                    $scope.sendData('RPD', {tbid:$scope.table_id});

                }
                if (id == 7) {
                    // Last Deal
                    $scope.sendData('LASTDEAL', {tbid:$scope.table_id});
                }
            } else {
                if (id == 1) {
                    $scope.settin_menu_slid = 0;
                    // My Account
                    $scope.view_profile($scope.sp_id)
                }
                if (id == 2) {
                    // Sound On / Off
                    $scope.ButtonClick_sound()
                    $scope.sendData('CGS', {flag:'sound'});
                }
                if (id == 3) {
                    // Vibrate On / Off
                    
                }
                if (id == 4) {
                    $scope.settin_menu_slid = 0;
                    // How to Play
                    $scope.howto_play_click(true);
                }
                if (id == 5) {
                    $scope.settin_menu_slid = 0;
                    // Help
                    $scope.rules_popup = true;
                }
                if (id == 6) {
                    $scope.settin_menu_slid = 0;
                    // Feedback
                    $scope.feedback_popup = true;
                }
                if (id == 7) {
                    $scope.settin_menu_slid = 0;
                    // Privacy Policies
                    window.open('https://www.myteam11.com/fantasy-sports/more/privacy-policy', '_blank');
                    
                }
                if (id == 8) {
                    $scope.settin_menu_slid = 0;
                    // Terms & Conditions
                    window.open('https://www.myteam11.com/fantasy-sports/more/terms-n-conditions', '_blank');
                    // https://www.myteam11.com/fantasy-sports/more/terms-n-conditions
                    
                }
                if (id == 9) {
                    // Logout
                    
                }
            }
            


        }
        // $scope.popup[1] = 0;
    }

    // LEAVE TABLE TO CLEAR DATA
    $scope.leave_table_reset = function(data) {
        $scope.table_user = [0, 0, 0, 0, 0, 0];
        $('.not_click').removeClass('active');
        if (data.flag != 'switch') {
            $scope.screen[1] = 1;
            $scope.screen[2] = 0;
            $scope.winner_clear();
            $scope.clear_play_table();
        } else {
            $scope.clear_play_table();
        }
    }
    //over playing table menu button event

    // conver into positive value
    $scope.positive_val = function(data) {
        return Math.abs(data);
    };
    //over conver into positive value

    // conver into positive value and integer
    $scope.positive_val_int = function(data) {
        return Math.round(data);
    };
    // over conver into positive value and integer

    // winner screen user sequance length count
    $scope.length_count = function(data, data1, data2) {
        return parseInt(data) + parseInt(data2);
    };
    //over winner screen user sequance length count

    // rejoin table
    $scope.rejoin = function(join) {
        $scope.lists = [];
        // $scope.declaret = [0, 0, 0, 0, 0, 0];
        $scope.sortableOptions.disabled = true;
        $scope.switch_table_p = false;
        $('.userlist').removeClass('active');
        // table info popup hide show
        $('.menu_side_1').removeClass('deactive_left deactive_right menu_right_to_center menu_center_to_left menu_left_to_center menu_center_to_right').addClass('menu_left_to_center');
        $('.menu_side_2').removeClass('deactive_left deactive_right menu_right_to_center menu_center_to_left menu_left_to_center menu_center_to_right').addClass('deactive_right');
        $('.menu_side_3').removeClass('deactive_left deactive_right menu_right_to_center menu_center_to_left menu_left_to_center menu_center_to_right').addClass('deactive_right');
        $('.menu_side_tab_1').removeClass('deactive_left deactive_right menu_right_to_center menu_center_to_left menu_left_to_center menu_center_to_right menu_side_tab_bg menu_side_tab_fix').addClass('deactive_right')
        $('.menu_side_tab_2').removeClass('deactive_left deactive_right menu_right_to_center menu_center_to_left menu_left_to_center menu_center_to_right').addClass('deactive_right');
        $scope.menu_side_tab_2_show = false;
        $scope.menu_side_tab_2_show = false;
        $scope.cash_game_lagel = false;
        $scope.tounament_game_lagel = false;
        $scope.practice_game_lagel = false;
        $scope.pwf_game_lagel = false;

        $scope.join = join;
        $scope.tb_id = join._id;
        $scope.screen[2] = 1;
        angular.forEach(join.pi, function(value, key) {
            $scope.points[value.si] = value.dps;
            if (value.uid != undefined) {
                $scope.table_user[key] = value;
            }
            if (value.s == 'drop') {
                $scope.declaret[value.si] = 2;
            }
        });
        $scope.bet_value = join.bbv;
        $scope.max_bet_value = join.maxBet;
        $scope.scale_value = join.scale;
        $scope.min_value = join.bbv;
        $scope.currentround = join.round;

        // get user seating index and watching mode 
        if ($scope.table_user.filter(function(element) { return element.uid === $scope.sp_id })[0] == undefined) {
            $scope.joinhere = true;
            $scope.set_index = 0;
        } else {

            $scope.set_index = $scope.table_user.filter(function(element) { return element.uid === $scope.sp_id })[0].si;
            $scope.joinhere = false;
            if (join.pi[$scope.set_index].cards.length != 0) {
                $scope.currentwatch = true;
            } else {
                $scope.currentwatch = false;
            }
            if (join.pi[$scope.set_index].s == 'watch') {
                $scope.currentuserwatch == true;
            } else {
                $scope.currentuserwatch == false;
            }
        }

        // check current player turn
        if (join.turn == $scope.set_index) {
            $scope.userturn_click = true;
            $scope.user_turn_g = true;
        } else {
            $scope.userturn_click = false;
        }

        // table round timer set
        if (join.tst == 'RoundTimerStarted') {
            $scope.round_time_start(join.Timer);
        }

        // card dealing 
        if (join.tst == 'RoundStarted' || join.tst == 'CardsDealt') {
            $scope.sdc_cards = true;
        }
        if (join.tst == 'RoundStarted') {
            $timeout(function() {
                $('.dealrummy_round').find('p').css({ 'opacity': '1' });
                // user timer function call
                if (join.secT == true) {
                    $scope.remaing_time = join.Timer;
                    $scope.anim_userturn_f(join.Timer, join.turn, 0);
                } else {
                    $scope.remaing_time = join.pi[join.turn].secTime;
                    $scope.anim_userturn_f(join.Timer, join.turn, 1);
                }
                // check user picked card or not 
                if (join.turn == $scope.set_index) {
                    if (join.pi[$scope.set_index].cards.length >= 14) {
                        $scope.userturn_click = true;
                        $scope.dropbtn = false;
                    } else {
                        $scope.dropbtn = true;
                        angular.forEach(join.pi, function(user_data, key) {
                            if (user_data.uid == $scope.sp_id) {
                                angular.forEach(user_data.gCards, function(value, key) {
                                    angular.forEach(user_data.gCards[key], function(value1, key1) {
                                        var c_card = 0;
                                        jQuery.grep(user_data.cards, function(a) {
                                            if (a != value1) { 
                                                c_card = c_card + 1; 
                                            }
                                        });
                                        if (c_card == 13) {
                                            $scope.lists[key].cards.splice(key1, 1);
                                        }
                                    });
                                });
                            }
                        });
                    }
                } else {
                    $scope.userturn_click = false;
                    $scope.dropbtn = false;
                    angular.forEach(join.pi, function(user_data, key) {
                        if (user_data.uid == $scope.sp_id) {
                            angular.forEach(user_data.gCards, function(value, key) {
                                angular.forEach(user_data.gCards[key], function(value1, key1) {
                                    var c_card = 0;
                                    jQuery.grep(user_data.cards, function(a) {
                                        if (a != value1) { 
                                            c_card = c_card + 1; 
                                        }
                                    });
                                    if (c_card == 13) {
                                        $scope.lists[key].cards.splice(key1, 1);

                                    }
                                });
                            });
                        }
                    });
                }
                $scope.jointst(join, 'RoundStarted');
            }, 100);
        }
        if (join.tst == 'Finished') {
            $scope.jointst(join, 'Finished');
            $scope.hakamfinish = true;
            $scope.pickcrds = false;
        }
        if ($scope.joinhere == false) {
            if (join.pi[$scope.set_index].cards.length >= 14) {
                $scope.pickcrds = true;
                $scope.user_turn_g = true;
            }
            if (join.pi[$scope.set_index].cards.length != 0) {
                // set player card 
                if (join.pi[$scope.set_index].gCards.length != 0) {
                    var la = 0;
                    angular.forEach(join.pi[$scope.set_index].gCards, function(value, key) {
                        $scope.lists.push({ cards: [], seq: 4 });
                        la = la + join.pi[$scope.set_index].gCards[key].length;
                        angular.forEach(join.pi[$scope.set_index].gCards[key], function(value1, key1) {
                            $scope.lists[key].cards.push({ card_detail: value1.substr(0, value1.length - 2), deck: value1.slice(-1) });
                        });
                    });
                    if (la < join.pi[$scope.set_index].cards.length) {
                        $scope.lists[join.pi[$scope.set_index].gCards.length - 1].cards.push({ card_detail: join.pi[$scope.set_index].cards[13].substr(0, join.pi[$scope.set_index].cards[13].length - 2), deck: join.pi[$scope.set_index].cards[13].slice(-1) });
                    } else if (la < join.pi[$scope.set_index].cards.length) {}
                    $scope.wildCard = join.wildCard.substr(0, join.wildCard.length - 2);
                    $scope.hakamchk = $scope.wildCard.substr(2);
                    $scope.tCard[0] = join.oDeck[join.oDeck.length - 2];
                    $scope.tCard[1] = join.oDeck[join.oDeck.length - 1];
                } else {
                    $scope.cardgroupset({ cards: join.pi[$scope.set_index].cards, tCard: join.oDeck[join.oDeck.length - 1], wildCard: join.wildCard });
                }
            } else {
                $scope.wildCard = join.wildCard.substr(0, join.wildCard.length - 2);
                $scope.hakamchk = $scope.wildCard.substr(2);
                $scope.tCard[0] = join.oDeck[join.oDeck.length - 2];
                $scope.tCard[1] = join.oDeck[join.oDeck.length - 1];
            }

            // player drop button validation
            if ($scope.join.pi[$scope.set_index].s == 'drop') {
                $scope.disabled_drop = true;
                $scope.dropbtn = false;
                $scope.drop_standup = true;
                $scope.short_btn_flag = false;
            }
        } else {
            $scope.wildCard = join.wildCard.substr(0, join.wildCard.length - 2);
            $scope.hakamchk = $scope.wildCard.substr(2);
            $scope.tCard[0] = join.oDeck[join.oDeck.length - 2];
            $scope.tCard[1] = join.oDeck[join.oDeck.length - 1];
        }
        $scope.bv = join.bv
        // winner screen
        if (join.tst == 'winnerDeclared' || join.tst == 'roundWinnerDeclared') {
            // $scope.winner_clear();
            $scope.clear_play_table();
        }

        // dealer icon set 
        if (join.dealer != -1 && join.pi[join.dealer].s != '' && join.pi[join.dealer].s != 'watch' && join.tst != 'winnerDeclared' && join.tst != 'Finished' && (join.tst == 'RoundStarted' || join.tst == 'StartDealingCard' || join.tst == 'StartDealerSelection' || join.tst == 'CardsDealt')) {
            $('.user_cards_user_' + join.dealer + '').addClass('active');
        }
        $scope.onecard_combine();
        $('body').css('pointer-events', 'auto');
    }
    //over rejoin table

    // round time start  function
    $scope.round_time_start = function(timer) {
        $scope.round_timer = timer;
        $('.not_click').removeClass('active');
        $interval.cancel($scope.timer_round);
        $scope.setting_menu_btn = false;

        $scope.timer_round = $interval(function() {
            $scope.round_timer = $scope.round_timer - 1;
            if ($scope.round_timer <= 0) {
                $interval.cancel($scope.timer_round);
                $scope.round_timer = 0;
            }
            if ($scope.round_timer <= 3 && $scope.waiting_status.length == $scope.gti_data.minS) {
                $scope.winner_scored = false;
                $scope.lastdeal = false;
                $scope.setting_menu_btn = true;
                $scope.switch_table_msg = false;
                $scope.common_popup_show = false;
                $scope.settin_menu_slid = 0;
            }
        }, 1000);
    }
    //over round time start  function


    // menu and table info popup out side click validation
    $(document).click(function(event) {
        $timeout(function() {

            if (!$(event.target).closest(".header_icons>img,.setting_btn_playing,.active_popup,.settin_menu_switch_on_off").length) {
                $scope.settin_menu_slid = 0;
                $scope.notifications = false;
            }
        }, 50);
    });
    //over menu and table info popup out side click validation

    // sequance validation check
    $scope.sequancevalidation = function(data, id, cmb) {
        $scope.selected_current_seq = 4;
        if (id != 'select') {
            $scope.purechecked = false;
            $scope.pure_impure = [];
        }
        angular.forEach(data, function(value, key) {
            data[key].seq = 4;
            if (value.cards.length != 0) {
                var cards_arrya = [];
                // get card number value
                $.each(value.cards, function(index, arrvalue) {
                    if (arrvalue.card_detail.charAt(0) != 'j') {
                        cards_arrya.push(parseInt(arrvalue.card_detail.substr(2)));
                    } else {
                        cards_arrya.push(-1);
                    }
                });
                //over get card number value

                // same card length count
                var totalcount = {};
                value.cards.map(function(o) { return o.card_detail; }).forEach(function(i) {
                    if (i.charAt(0) != 'j') {
                        totalcount[i.substr(2)] = (totalcount[i.substr(2)] || 0) + 1;
                    }
                });
                // same card length count over 

                // dublicate value count
                var deblicatecount = {};
                var deblicatecount_r = false;
                value.cards.map(function(o) { return o.card_detail; }).forEach(function(i) {
                    deblicatecount[i] = (deblicatecount[i] || 0) + 1;
                    if (deblicatecount[i] >= 2) {
                        deblicatecount_r = true;
                    }
                });
                // dublicate value count over

                // find joker
                var jokercount = [];
                $scope.joker.map(function(o) { return o; }).forEach(function(i) {
                    jQuery.grep(value.cards, function(a) {
                        if (a.card_detail == i) {
                            jokercount.push(a.card_detail);
                        }
                    });
                });
                // find joker over

                //wild card count 
                var wildcardcount = [];
                var wildcardcountimpinc = [];
                var wildcardcountimpdec = [];
                var wildcardcountpuredec = [];
                jQuery.grep(value.cards, function(a) {
                    if (a.card_detail.substr(2) == $scope.wildCard.substr(2) && a.card_detail.charAt(0) != 'j') {
                        wildcardcount.push(a.card_detail);
                        wildcardcountimpinc.push(a.card_detail);
                        wildcardcountimpdec.push(a.card_detail);
                        wildcardcountpuredec.push(a.card_detail);
                    }
                });
                //wild card count  over

                //get pure,impure value
                var pureinc = [];
                var puredec = [];
                var imppuredec = [];
                var f_puredec = [];
                var f_impuredec = [];
                var f_impuredec = [];
                var count_wild = 0;
                var min = cards_arrya.filter(function(x) { return x !== -1; })
                    .reduce(function(a, b) { return Math.min(a, b); }, Infinity);
                if (min != Infinity) { var pindex = cards_arrya.indexOf(min); } else { var pindex = 0; }
                var impindex = cards_arrya.indexOf(Math.max.apply(Math, cards_arrya));
                var first_pure = parseInt(value.cards[pindex].card_detail.substr(2));
                var first_impure = parseInt(value.cards[impindex].card_detail.substr(2));
                var color = value.cards[pindex].card_detail.charAt(0);
                var imcolor = value.cards[impindex].card_detail.charAt(0);
                for (var i = 0; i <= (value.cards.length - 1); i++) {
                    if (value.cards.filter(function(element) { return element.card_detail === '' + color + '-' + (first_pure + i) + '' })[0] != undefined) {
                        pureinc.push(value.cards.filter(function(element) { return element.card_detail === '' + color + '-' + (first_pure + i) + '' })[0]);
                        if (i == 0 && first_pure == 1) {
                            f_puredec.push(value.cards.filter(function(element) { return element.card_detail === '' + color + '-' + (first_pure + i) + '' })[0]);
                            if (wildcardcountpuredec.indexOf('' + color + '-' + (first_pure + i) + '') != -1) {
                                var re_idex2 = wildcardcountpuredec.indexOf('' + color + '-' + (first_pure + i) + '');
                                wildcardcountpuredec.splice(re_idex2, 1);
                            }
                        }
                    }
                    if (i != 0 && first_pure == 1 && value.cards.filter(function(element) { return element.card_detail === '' + color + '-' + (15 - (first_pure + i)) + '' })[0] != undefined) {
                        f_puredec.push(value.cards.filter(function(element) { return element.card_detail === '' + color + '-' + (15 - (first_pure + i)) + '' })[0]);
                        if (wildcardcountpuredec.indexOf('' + color + '-' + (15 - (first_pure + i)) + '') != -1) {
                            var re_idex2 = wildcardcountpuredec.indexOf('' + color + '-' + (15 - (first_pure + i)) + '');
                            wildcardcountpuredec.splice(re_idex2, 1);
                        }
                    }
                    if (wildcardcountimpinc.indexOf('' + color + '-' + (first_pure + i) + '') != -1) {
                        var re_idex = wildcardcountimpinc.indexOf('' + color + '-' + (first_pure + i) + '');
                        wildcardcountimpinc.splice(re_idex, 1);
                    }
                }
                for (var j = 0; j <= (value.cards.length - 1); j++) {
                    if (value.cards.filter(function(element) { return element.card_detail === '' + imcolor + '-' + (first_impure - j) + '' })[0] != undefined) {
                        puredec.push(value.cards.filter(function(element) { return element.card_detail === '' + imcolor + '-' + (first_impure - j) + '' })[0]);
                    }
                    if (wildcardcountimpdec.indexOf('' + imcolor + '-' + (first_impure - j) + '') != -1) {
                        var re_idex = wildcardcountimpdec.indexOf('' + imcolor + '-' + (first_impure - j) + '');
                        count_wild = count_wild + 1;
                        wildcardcountimpdec.splice(re_idex, 1);
                    }
                }
                //get pure,impure value over

                /////////// check sequance logic ////////////////

                // invalid logic
                if (deblicatecount_r == true) {
                    if (id == 'select') {
                        $('.highlight_cards').removeClass('active_green');
                        // $scope.selected_current_seq = 4;
                    } else {
                        // data[key].seq = 5;
                    }
                }
                // invalid logic over

                // impure logic
                var checkseq = false;
                if (value.cards.length >= 3 && (pureinc.length == (value.cards.length - wildcardcountimpinc.length) && wildcardcountimpinc.length >= 1
                ||    puredec.length == (value.cards.length - wildcardcountimpdec.length) && wildcardcountimpdec.length >= 1
                ||    f_puredec.length == (value.cards.length - wildcardcountpuredec.length) && wildcardcountpuredec.length >= 1)){
                    if (id == 'select') {
                        $('.highlight_cards').addClass('active_green');
                        $scope.selected_current_seq = 2;
                        checkseq = true;
                    } else {
                        data[key].seq = 2;
                        $scope.pure_impure.push(0);
                        checkseq = true;
                    }
                }


                if ((value.cards.length >= 3 || value.cards.length > 3) && (pureinc.length == (value.cards.length - jokercount.length) && jokercount.length >= 1
                ||    puredec.length == (value.cards.length - jokercount.length) && jokercount.length >= 1
                ||    f_puredec.length == (value.cards.length - jokercount.length) && jokercount.length >= 1)){
                    if (id == 'select') {
                        $('.highlight_cards').addClass('active_green');
                        $scope.selected_current_seq = 2;
                        checkseq = true;
                    } else {
                        data[key].seq = 2;
                        $scope.pure_impure.push(0);
                        checkseq = true;
                    }
                }

                if (value.cards.length >= 3 && ((f_puredec.length == (value.cards.length - wildcardcountpuredec.length) && wildcardcountpuredec.length >= 1
                ||    f_puredec.length == (value.cards.length - jokercount.length) && jokercount.length >= 1)
                ||  (pureinc.length == (value.cards.length - wildcardcountimpinc.length - jokercount.length) && wildcardcountimpinc.length >= 1 && jokercount.length >= 1 
                ||   puredec.length == (value.cards.length - wildcardcountimpdec.length - jokercount.length) && wildcardcountimpdec.length >= 1 && jokercount.length >= 1
                ||   f_puredec.length == (value.cards.length - wildcardcountpuredec.length - jokercount.length) && wildcardcountpuredec.length >= 1 && jokercount.length >= 1))){
                    if (id == 'select') {
                        $('.highlight_cards').addClass('active_green');
                        $scope.selected_current_seq = 2;
                        checkseq = true;
                    } else {
                        data[key].seq = 2;
                        $scope.pure_impure.push(0);
                        checkseq = true;
                    }
                }
                // impure logic over

                // set logi
                if(checkseq == false){
                    if (deblicatecount_r == false && (value.cards.length == 3 || value.cards.length == 4) && jokercount.length <= 1 &&
                        (totalcount[value.cards[0].card_detail.substr(2)] == 
                        value.cards.length || totalcount[value.cards[0].card_detail.substr(2)] == 
                        (value.cards.length - 1) && jokercount.length == 1 || totalcount[value.cards[0].card_detail.substr(2)] == 
                        (value.cards.length - 1) && wildcardcount.length == 1 || totalcount[value.cards[1].card_detail.substr(2)] == 
                        (value.cards.length - 1) && jokercount.length == 1 || totalcount[value.cards[1].card_detail.substr(2)] == 
                        (value.cards.length - 1) && wildcardcount.length == 1)) {
                        if (id == 'select') {
                            $('.highlight_cards').addClass('active_green');
                            $scope.selected_current_seq = 3;
                        } else {
                            data[key].seq = 3;
                        }
                    }

                    if (value.cards.length == 4 && jokercount.length == 2 && 
                        (totalcount[value.cards[0].card_detail.substr(2)] == value.cards.length
                        || totalcount[value.cards[0].card_detail.substr(2)] == (value.cards.length - jokercount.length) && jokercount.length == 2
                        || totalcount[value.cards[1].card_detail.substr(2)] == (value.cards.length - jokercount.length) && jokercount.length == 2
                        || totalcount[value.cards[2].card_detail.substr(2)] == (value.cards.length - jokercount.length) && jokercount.length == 2
                        || totalcount[value.cards[3].card_detail.substr(2)] == (value.cards.length - jokercount.length) && jokercount.length == 2
                        )) {
                        if (id == 'select') {
                            $('.highlight_cards').addClass('active_green');
                            $scope.selected_current_seq = 3;
                        } else {
                            data[key].seq = 3;
                        }
                    }

                    if (value.cards.length == 4 && wildcardcount.length == 2 && 
                        (totalcount[value.cards[0].card_detail.substr(2)] == value.cards.length 
                        || totalcount[value.cards[0].card_detail.substr(2)] == (value.cards.length - wildcardcount.length) && wildcardcount.length == 2
                        && value.cards[0].card_detail.substr(2) != wildcardcount[0].substr(2)
                        && value.cards[0].card_detail.substr(0) != value.cards[1].card_detail.substr(0)
                        && value.cards[0].card_detail.substr(0) != value.cards[2].card_detail.substr(0)
                        && value.cards[0].card_detail.substr(0) != value.cards[3].card_detail.substr(0)

                        || totalcount[value.cards[1].card_detail.substr(2)] == (value.cards.length - wildcardcount.length) && wildcardcount.length == 2
                        && value.cards[1].card_detail.substr(2) != wildcardcount[0].substr(2)
                        && value.cards[1].card_detail.substr(0) != value.cards[0].card_detail.substr(0)
                        && value.cards[1].card_detail.substr(0) != value.cards[2].card_detail.substr(0)
                        && value.cards[1].card_detail.substr(0) != value.cards[3].card_detail.substr(0)

                        || totalcount[value.cards[2].card_detail.substr(2)] == (value.cards.length - wildcardcount.length) && wildcardcount.length == 2
                        && value.cards[2].card_detail.substr(2) != wildcardcount[0].substr(2)
                        && value.cards[2].card_detail.substr(0) != value.cards[0].card_detail.substr(0)
                        && value.cards[2].card_detail.substr(0) != value.cards[1].card_detail.substr(0)
                        && value.cards[2].card_detail.substr(0) != value.cards[3].card_detail.substr(0)

                        || totalcount[value.cards[3].card_detail.substr(2)] == (value.cards.length - wildcardcount.length) && wildcardcount.length == 2
                        && value.cards[3].card_detail.substr(2) != wildcardcount[0].substr(2)
                        && value.cards[3].card_detail.substr(0) != value.cards[0].card_detail.substr(0)
                        && value.cards[3].card_detail.substr(0) != value.cards[1].card_detail.substr(0)
                        && value.cards[3].card_detail.substr(0) != value.cards[2].card_detail.substr(0)

                        )) {
                        if (id == 'select') {
                            $('.highlight_cards').addClass('active_green');
                            $scope.selected_current_seq = 3;
                        } else {
                            data[key].seq = 3;
                        }
                    }

                    if (deblicatecount_r == false && value.cards.length == 4 && wildcardcount.length == 1 && jokercount.length == 1 &&
                        (totalcount[value.cards[0].card_detail.substr(2)] == value.cards.length 
                        || totalcount[value.cards[0].card_detail.substr(2)] == (value.cards.length - (wildcardcount.length + jokercount.length)) && wildcardcount.length == 1 && jokercount.length == 1
                        || totalcount[value.cards[1].card_detail.substr(2)] == (value.cards.length - (wildcardcount.length + jokercount.length)) && wildcardcount.length == 1 && jokercount.length == 1
                        || totalcount[value.cards[2].card_detail.substr(2)] == (value.cards.length - (wildcardcount.length + jokercount.length)) && wildcardcount.length == 1 && jokercount.length == 1
                        || totalcount[value.cards[3].card_detail.substr(2)] == (value.cards.length - (wildcardcount.length + jokercount.length)) && wildcardcount.length == 1 && jokercount.length == 1
                        )) {
                        if (id == 'select') {
                            $('.highlight_cards').addClass('active_green');
                            $scope.selected_current_seq = 3;
                        } else {
                            data[key].seq = 3;
                        }
                    }
                }
                //set logic over

                // pure logi
                if (value.cards.length >= 3 && deblicatecount_r == false && jokercount.length == 0 && (pureinc.length == value.cards.length || f_puredec.length == value.cards.length)) {
                    if (id == 'select') {
                        $('.highlight_cards').addClass('active_green');
                        $scope.selected_current_seq = 1;
                    } else {
                        data[key].seq = 1;
                        $scope.purechecked = true;
                        $scope.pure_impure.push(0);
                    }
                }
                // pure logic over

                // singal jokercard / wildcard velid 
                if (value.cards.length == 2) {
                    if($scope.pure_impure.length >= 2 && (
                        (value.cards.length == 2 && (jokercount.length == 2 || wildcardcount.length == 2)) 
                        ||  (value.cards.length == 2 && (jokercount.length == 1 && wildcardcount.length == 1)))){
                        if(id != 'select'){
                            data[key].seq = 6;
                            $('.highlight_cards').addClass('active_green');
                        }
                    }
                }
                if (value.cards.length == 1) {
                    if($scope.pure_impure.length >= 2 && 
                        (value.cards.length == 1 && (jokercount.length == 1 || wildcardcount.length == 1))){
                        if(id != 'select'){
                            data[key].seq = 6;
                            $('.highlight_cards').addClass('active_green');
                        }
                    }
                    else{
                        data[key].seq = 8;
                    }
                }
                // singal jokercard / wildcard velid over

                /////////// check sequance logic  over ////////////////

            } else {
                if (id != 'select') {
                    // data[key].seq = 4;
                }
            }

            if (key == (data.length - 1)) {
                // card group array
                data.sort(function(a, b) {
                    return +a.seq - +b.seq;
                });
                // $scope.scd = [];
                $scope.cards_length = 0;
                angular.forEach(data, function(value, key) {
                    var cards_arrya = [];
                    // $scope.scd.push([]);
                    $.each(value.cards, function(index, arrvalue) {
                        $scope.cards_length = $scope.cards_length + 1;
                        cards_arrya.push(parseInt(arrvalue.card_detail.substr(2)));
                        // $scope.scd[key].push("" + arrvalue.card_detail + "-" + arrvalue.deck + "")
                    });
                });
                // card group array over

                // save card event send to server
                if (id == 'pick' || id == 'through' || id == 'drag') {
                    if ($scope.set_index <= 4) {
                        $scope.declare_list = { "dwd": [], "seq": [], "set": [], "pure": [] };
                        angular.forEach(data, function(value, key) {
                            if (value.cards.length != 0) {
                                if (value.seq == 1) {
                                    $scope.pure_arr = []
                                    angular.forEach(value.cards, function(pure, purekey) {
                                        $scope.pure_arr.push("" + pure.card_detail + "-" + pure.deck + "");
                                    });
                                    $scope.declare_list.pure.push($scope.pure_arr);
                                }
                                if (value.seq == 2) {
                                    $scope.impure_arr = []
                                    angular.forEach(value.cards, function(pure, purekey) {
                                        $scope.impure_arr.push("" + pure.card_detail + "-" + pure.deck + "");
                                    });
                                    $scope.declare_list.seq.push($scope.impure_arr);
                                }
                                if (value.seq == 3) {
                                    $scope.set_arr = []
                                    angular.forEach(value.cards, function(pure, purekey) {
                                        $scope.set_arr.push("" + pure.card_detail + "-" + pure.deck + "");
                                    });
                                    $scope.declare_list.set.push($scope.set_arr);
                                }
                                if (value.seq == 6) {
                                    $scope.set_arr = []
                                    if (($scope.declare_list.pure.length >= 1 && $scope.declare_list.seq.length >= 1) || $scope.declare_list.pure.length >= 2) {
                                        angular.forEach(value.cards, function(pure, purekey) {
                                            $scope.set_arr.push("" + pure.card_detail + "-" + pure.deck + "");
                                        });
                                        $scope.declare_list.set.push($scope.set_arr);

                                    } else {
                                        $scope.dwd_arr = []
                                        angular.forEach(value.cards, function(pure, purekey) {
                                            $scope.dwd_arr.push("" + pure.card_detail + "-" + pure.deck + "");
                                        });
                                        $scope.declare_list.dwd.push($scope.dwd_arr);
                                    }
                                }
                                if (value.seq == 4 || value.seq == 5 || value.seq == 7 || value.seq == 8) {
                                    $scope.dwd_arr = []
                                    angular.forEach(value.cards, function(pure, purekey) {
                                        $scope.dwd_arr.push("" + pure.card_detail + "-" + pure.deck + "");
                                    });
                                    $scope.declare_list.dwd.push($scope.dwd_arr);
                                }
                            }
                        });
                        if ($scope.howtoplay == false) {
                            $scope.sendData('SCD', {gCards: $scope.declare_list});
                        }
                    }
                    $scope.deadwood_points(data);
                }
                // save card event send to server over
                if (id == 'drag' || id != 'select') {
                    $scope.classes_width = (data.length);
                    $scope.classes_width0 = $('.playing_buttom_cards').width() - ($scope.vhTOpx(2) * $scope.classes_width)
                    $scope.classes_width1 = $scope.classes_width0 - ($scope.cards_length * $('.card_group .sort_custom-container .sort_custom').width())
                    $scope.classes_width11 = $scope.classes_width1 / ($scope.cards_length - $scope.classes_width)
                    $scope.classes_width3 = $scope.classes_width11;
                    $timeout(function() {
                        // call group animate function
                        $scope.group_animation(data);
                    }, 0);
                }
            }
        });
    }
    //over sequance validation check

    // cards margin function
    $scope.get_margin = function(cards_length, classes_width, ind) {
        $scope.classes_width0 = $('.playing_buttom_cards').width() - ($scope.vhTOpx(2) * $scope.classes_width)
        $scope.classes_width1 = $scope.classes_width0 - ($scope.cards_length * $('.card_group .sort_custom-container .sort_custom').width())
        $scope.classes_width11 = $scope.classes_width1 / ($scope.cards_length - $scope.classes_width)
        $scope.classes_width2 = $scope.classes_width11;
    }
    //over cards margin function

    // select card event
    $scope.select_gi = [];
    $scope.select_ci = [];
    $scope.select_card = function(event, i, j) {
        if ($scope.howtoplay == true) {
            if (($scope.lists[i].cards[j].card_detail == "l-" + $scope.htp_group_card + "" || $scope.lists[i].cards[j].card_detail == "f-" + $scope.htp_group_card + "" || $scope.lists[i].cards[j].card_detail == "c-" + $scope.htp_group_card + "")) {
                if ($scope.dragcards == false && !$(event.target).parents('.sort_custom').hasClass('highlight_cards')) { // && $scope.sortableOptions.disabled == false && $scope.ngclick_enabled == true
                    
                    if ($scope.htp_group_card == 7) {
                        $scope.pickcrds = false;
                    } else {
                        $scope.pickcrds = true;
                    }
                    $scope.select_gi.push(i);
                    $scope.select_ci.push(j);
                    $(event.target).parents('.sort_custom').addClass('highlight_cards active');
                    $scope.selected_dis_msg = false;
                    $('.sort_custom').removeClass('active_green');
                    $scope.select_lists[0].cards.push($scope.lists[i].cards[j]);
                    if ($scope.select_lists[0].cards.length >= 3) {
                        $('.howtoplay_tooltip p').removeClass('active');
                        $('.howtoplay_tooltip5').addClass('active');
                        $('.howtoplay_hand').removeClass('howtoplay_hand');
                        $('.group_btn').addClass('howtoplay_hand');
                    }
                    if ($scope.select_lists[0].cards.length == 1 && $scope.htp_group_card == 10) {
                        $('.howtoplay_tooltip p').removeClass('active');
                        $('.howtoplay_tooltip18').addClass('active');
                        $('.howtoplay_hand').removeClass('howtoplay_hand');
                        $('.play_discard').addClass('howtoplay_hand');
                    }
                    if ($scope.select_lists[0].cards.length == 1 && $scope.htp_group_card == 8) {
                        $('.howtoplay_tooltip p').removeClass('active');
                        $('.howtoplay_tooltip19').addClass('active');
                        $('.howtoplay_hand').removeClass('howtoplay_hand');
                        $('.play_finish').addClass('howtoplay_hand');
                    }
                    $scope.sequancevalidation($scope.select_lists, 'select');
                    $scope.select_lists[0].seq = $scope.selected_current_seq;
                }
                $scope.ngclick_enabled = true;
            }
        } else {
            if ($scope.dragcards == false) { // && $scope.sortableOptions.disabled == false && $scope.ngclick_enabled == true
                if ($(event.target).parents('.sort_custom').hasClass('highlight_cards')) {
                    $(event.target).parents('.sort_custom').removeClass('highlight_cards active active_green');
                    $(event.target).parents('.sort_custom').css({ 'top': '0vh' })
                    var index = $scope.select_lists[0].cards.map(function(d) { return d['card_detail']; }).indexOf($scope.lists[i].cards[j].card_detail);
                    $scope.select_lists[0].cards.splice(index, 1);
                    $scope.select_gi.splice(index, 1);
                    $scope.select_ci.splice(index, 1);
                    $scope.sequancevalidation($scope.select_lists, 'select');
                    $scope.select_lists[0].seq = $scope.selected_current_seq;
                    if ($scope.selected_current_seq == 4 || $scope.selected_current_seq == 5) {
                        $('.highlight_cards').removeClass('active_green');
                    }
                } else {
                    $scope.select_gi.push(i);
                    $scope.select_ci.push(j);
                    $(event.target).parents('.sort_custom').addClass('highlight_cards active');
                    $scope.selected_dis_msg = false;
                    $('.sort_custom').removeClass('active_green');
                    $scope.select_lists[0].cards.push($scope.lists[i].cards[j]);
                    $scope.sequancevalidation($scope.select_lists, 'select');
                    $scope.select_lists[0].seq = $scope.selected_current_seq;
                }
            }
        }
    }
    //over select card event

    // one card combine  group
    $scope.onecard_combine = function() {
        $timeout(function() {
            $scope.updatelisted = angular.copy($scope.lists);
            $scope.onelenth_count = [{ cards: [], seq: 4 }];
            $scope.onelenth_count2 = [];
            angular.forEach($scope.updatelisted, function(value, key) {
                if (value.cards.length == 1) {
                    $scope.updatelisted[key].seq = 5;
                    $scope.onelenth_count[0].cards.push(value.cards[0]);
                    $scope.onelenth_count2.push(key);
                }
            });
            if ($scope.onelenth_count[0].cards.length >= 2) {
                angular.forEach($scope.onelenth_count2, function(value2, key2) {
                    var d = $scope.onelenth_count2.length - key2;
                    if ($scope.onelenth_count2[0] != value2) {
                        $scope.updatelisted.splice($scope.onelenth_count2[d], 1);
                    }
                    $scope.updatelisted[$scope.onelenth_count2[0]] = $scope.onelenth_count[0];
                });
            }
            $scope.updatelisted.nullval_remove();
            $timeout(function() {
                // call sequancevalidation function
                $scope.sequancevalidation($scope.updatelisted, 'drag', 'combine');
            }, 50);
        }, 50);
    }
    //over one card combine  group

    // new group create
    $scope.create_new_group = function() {
        if ($scope.sortableOptions.disabled == false) {
            $scope.sortableOptions.disabled = true;
            $scope.updatelisted = angular.copy($scope.lists);
            $scope.onelenth_count = [{ cards: [], seq: 4 }];
            $scope.onelenth_count2 = [];
            jQuery.grep($scope.select_ci, function(a, index) {

                var removeind = $.map($scope.updatelisted[$scope.select_gi[index]].cards, function(element, index2) {
                    if (element.card_detail === $scope.select_lists[0].cards[index].card_detail && element.deck === $scope.select_lists[0].cards[index].deck) { 
                        return index2; 
                    }
                });
                $scope.updatelisted[$scope.select_gi[index]].cards.splice(removeind[0], 1);
                if (($scope.select_ci.length - 1) == index) {
                    // PUSH SELECT CARD ARRAY
                    var p_index = -1;
                    var im_index = -1;
                    var sets_index = -1;
                    
                    $scope.updatelisted.some(function(entry, i) {
                        if (entry.seq == 1) { p_index = i; }
                        if (entry.seq == 2) { im_index = i; }
                        if (entry.seq == 3) { sets_index = i; }
                    });
                    var i = 0;
                    var j = 0;
                    var temp_arra = $scope.select_lists[0].cards;
                    $scope.select_lists[0].cards = [];

                    for (i = 1; i < 14; i++) {
                        for (j = 0; j < temp_arra.length; j++) {
                            if (parseInt(temp_arra[j].card_detail.substr(2)) == i) {
                                $scope.select_lists[0].cards.push({card_detail: temp_arra[j].card_detail, deck: temp_arra[j].deck })
                            }
                        }
                    }


                    if ($scope.select_lists[0].seq == 1) {
                        if (p_index != -1) {
                            $scope.updatelisted.splice((p_index + 1), 0, $scope.select_lists[0]);
                        } else {
                            $scope.updatelisted.splice(0, 0, $scope.select_lists[0]);
                        }
                    } else if ($scope.select_lists[0].seq == 2) {
                        if (im_index != -1) {
                            $scope.updatelisted.splice((im_index + 1), 0, $scope.select_lists[0]);
                        } else if (p_index != -1) {
                            $scope.updatelisted.splice((p_index + 1), 0, $scope.select_lists[0]);
                        } else {
                            $scope.updatelisted.splice(0, 0, $scope.select_lists[0]);
                        }
                    } else if ($scope.select_lists[0].seq == 3) {
                        if (sets_index != -1) {
                            $scope.updatelisted.splice((sets_index + 1), 0, $scope.select_lists[0]);
                        } else if (im_index != -1) {
                            $scope.updatelisted.splice((im_index + 1), 0, $scope.select_lists[0]);
                        } else if (p_index != -1) {
                            $scope.updatelisted.splice((p_index + 1), 0, $scope.select_lists[0]);
                        } else {
                            $scope.updatelisted.splice(0, 0, $scope.select_lists[0]);
                        }
                    } else {
                        $scope.updatelisted.splice($scope.updatelisted.length - 1, 0, $scope.select_lists[0]);
                    }
                    angular.forEach($scope.updatelisted, function(value, key) {
                        if (value.cards.length == 1) {
                            $scope.updatelisted[key].seq = 5;
                            $scope.onelenth_count[0].cards.push(value.cards[0]);
                            $scope.onelenth_count2.push(key);
                        }
                    });
                    $timeout(function() {
                        if ($scope.onelenth_count[0].cards.length >= 2) {

                            angular.forEach($scope.onelenth_count2, function(value2, key2) {
                                var d = $scope.onelenth_count2.length - key2;
                                if ($scope.onelenth_count2[0] != value2) {
                                    $scope.updatelisted.splice($scope.onelenth_count2[d], 1);
                                }
                                $scope.updatelisted[$scope.onelenth_count2[0]] = $scope.onelenth_count[0];
                            });
                        }
                        $scope.updatelisted.nullval_remove();
                    }, 50);
                    $timeout(function() {
                        $scope.sequancevalidation($scope.updatelisted, 'drag');
                        $scope.short_btn_flag = false;
                        if ($scope.howtoplay == false) {
                            $scope.sendData('SORT', {tbid:$scope.table_id});
                        } else {
                            $('.not_click').removeClass('active');
                            $('.howtoplay_tooltip p').removeClass('active');
                            $('.howtoplay_tooltip7').addClass('active');
                            $scope.htp_group_card = 8;
                            $timeout(function() {
                                $('.howtoplay_hand').removeClass('howtoplay_hand');
                                $('.sort_custom3_2').addClass('howtoplay_hand');
                            },1000);
                            
                        }
                    }, 100);
                }
            });
        }
    }
    //over new  group create

    // group animate
    $scope.group_animation = function(data) {
        // $scope.lists = angular.copy(data);
        $scope.updatelisted = angular.copy(data);
        $timeout(function() {
            $scope.wi = true;
            $('.sort_custom').removeClass('highlight_cards active active_green');
            $scope.wi = false;
            $scope.sortableOptions.disabled = false;
            var sheet = document.createElement('style')
            sheet.innerHTML = ".card_group .sort_custom-container .sort_custom {position:relative;}";
            $('#style_add').html(sheet);
            $('.sort_custom').css({ 'position': 'relative', 'left': '0px', 'top': '0px', 'transform': 'scale(1)' }).removeClass('highlight_cards active custom_margin through_last');
            $('.sort_custom0 ').css({ 'margin-right': '-' + $scope.classes_width2 + 'px' });
            $('.sort_custom').resetKeyframe();
            $scope.lists = angular.copy($scope.updatelisted);
            $scope.classes_width2 = angular.copy($scope.classes_width3);
            $scope.select_gi = [];
            $scope.select_ci = [];
            if ($scope.finish_popup_show == false) {
                $scope.select_lists = [{ cards: [], seq: 4 }];
            }
        },20);
    }
    //over group animate

    // deadwood points count
    $scope.deadwood_points = function(cal_data_ponts) {
        $scope.deadwood_points_c = 80;
        $scope.deadwood_points_c2 = 0;
        $scope.group_points = [];
        $scope.group_points_val = 0;
        angular.forEach(cal_data_ponts, function(value, key) {
            $scope.group_points_val = 0;
            angular.forEach(value.cards, function(value1, key1) {
                if ($scope.pure_impure.length >= 2 && $scope.purechecked == true) {
                    if (value.seq == 4 || value.seq == 5 || value.seq == 7|| value.seq == 8) {
                        if (value1.card_detail.charAt(0) == 'j' || parseInt(value1.card_detail.substr(2)) == $scope.wildCard.substr(2)) {
                        } else if (parseInt(value1.card_detail.substr(2)) == 11 || parseInt(value1.card_detail.substr(2)) == 12 || parseInt(value1.card_detail.substr(2)) == 13 || parseInt(value1.card_detail.substr(2)) == 1) {
                            $scope.deadwood_points_c2 = $scope.deadwood_points_c2 + 10;
                            if (key == 0) {
                                $scope.group_points_val = $scope.group_points_val + 10;
                            } else if (key == 1) {
                                $scope.group_points_val = $scope.group_points_val + 10;
                            } else if (key == 2) {
                                $scope.group_points_val = $scope.group_points_val + 10;
                            } else if (key == 3) {
                                $scope.group_points_val = $scope.group_points_val + 10;
                            } else if (key == 4) {
                                $scope.group_points_val = $scope.group_points_val + 10;
                            } else if (key == 5) {
                                $scope.group_points_val = $scope.group_points_val + 10;
                            } else if (key == 6) {
                                $scope.group_points_val = $scope.group_points_val + 10;
                            } else if (key == 7) {
                                $scope.group_points_val = $scope.group_points_val + 10;
                            }
                        } else {
                            $scope.deadwood_points_c2 = $scope.deadwood_points_c2 + parseInt(value1.card_detail.substr(2));
                            if (key == 0) {
                                $scope.group_points_val = $scope.group_points_val + parseInt(value1.card_detail.substr(2));
                            } else if (key == 1) {
                                $scope.group_points_val = $scope.group_points_val + parseInt(value1.card_detail.substr(2));
                            } else if (key == 2) {
                                $scope.group_points_val = $scope.group_points_val + parseInt(value1.card_detail.substr(2));
                            } else if (key == 3) {
                                $scope.group_points_val = $scope.group_points_val + parseInt(value1.card_detail.substr(2));
                            } else if (key == 4) {
                                $scope.group_points_val = $scope.group_points_val + parseInt(value1.card_detail.substr(2));
                            } else if (key == 5) {
                                $scope.group_points_val = $scope.group_points_val + parseInt(value1.card_detail.substr(2));
                            } else if (key == 6) {
                                $scope.group_points_val = $scope.group_points_val + parseInt(value1.card_detail.substr(2));
                            } else if (key == 7) {
                                $scope.group_points_val = $scope.group_points_val + parseInt(value1.card_detail.substr(2));
                            }
                        }
                    }
                } else {
                    if (value1.card_detail.charAt(0) == 'j' || parseInt(value1.card_detail.substr(2)) == $scope.wildCard.substr(2)) {

                    } else if (parseInt(value1.card_detail.substr(2)) == 11 || parseInt(value1.card_detail.substr(2)) == 12 || parseInt(value1.card_detail.substr(2)) == 13 || parseInt(value1.card_detail.substr(2)) == 1) {
                        $scope.deadwood_points_c2 = $scope.deadwood_points_c2 + 10;
                        if (key == 0) {
                            $scope.group_points_val = $scope.group_points_val + 10;
                        } else if (key == 1) {
                            $scope.group_points_val = $scope.group_points_val + 10;
                        } else if (key == 2) {
                            $scope.group_points_val = $scope.group_points_val + 10;
                        } else if (key == 3) {
                            $scope.group_points_val = $scope.group_points_val + 10;
                        } else if (key == 4) {
                            $scope.group_points_val = $scope.group_points_val + 10;
                        } else if (key == 5) {
                            $scope.group_points_val = $scope.group_points_val + 10;
                        } else if (key == 6) {
                            $scope.group_points_val = $scope.group_points_val + 10;
                        } else if (key == 7) {
                            $scope.group_points_val = $scope.group_points_val + 10;
                        }
                    } else {
                        $scope.deadwood_points_c2 = $scope.deadwood_points_c2 + parseInt(value1.card_detail.substr(2));
                        if (key == 0) {
                            $scope.group_points_val = $scope.group_points_val + parseInt(value1.card_detail.substr(2));
                        } else if (key == 1) {
                            $scope.group_points_val = $scope.group_points_val + parseInt(value1.card_detail.substr(2));
                        } else if (key == 2) {
                            $scope.group_points_val = $scope.group_points_val + parseInt(value1.card_detail.substr(2));
                        } else if (key == 3) {
                            $scope.group_points_val = $scope.group_points_val + parseInt(value1.card_detail.substr(2));
                        } else if (key == 4) {
                            $scope.group_points_val = $scope.group_points_val + parseInt(value1.card_detail.substr(2));
                        } else if (key == 5) {
                            $scope.group_points_val = $scope.group_points_val + parseInt(value1.card_detail.substr(2));
                        } else if (key == 6) {
                            $scope.group_points_val = $scope.group_points_val + parseInt(value1.card_detail.substr(2));
                        } else if (key == 7) {
                            $scope.group_points_val = $scope.group_points_val + parseInt(value1.card_detail.substr(2));
                        }
                    }
                }
            });
            $scope.group_points.push({group_points: $scope.group_points_val})
        });
        $scope.deadwood_points_c = $scope.deadwood_points_c2;
    }
    //over deadwood points count

    // Pick Card From Deck
    $scope.pick_deck = function(id, pickdata) {
        $('#' + id + '').addClass('active4');
        var cards = pickdata.card;
        var index = $scope.lists.length;
        // check image load
        preloader.preloadImages([("../HTML5/img/card/" + cards.substr(0, cards.length - 2) + ".png"), ]).then(
            function handleResolve(imageLocations2) {
                // our pick card animaton
                if (pickdata.si == $scope.set_index && $scope.sortableOptions.disabled == false) {
                    if ($scope.bet_help == 3) {
                        $scope.bet_help = 4;
                    }
                    $scope.sortableOptions.disabled = true;

                    // get last group index
                    while (index-- && !$scope.lists[index].cards.length != 0);
                    $scope.lists[index].cards.push('');

                    $scope.cards_length = 14;
                    $scope.classes_width = ($scope.lists.length);
                    // call margin function
                    $scope.get_margin($scope.cards_length, $scope.classes_width, 2);
                    $scope.classes_width = (pickdata.length);

                    $('.playing_buttom_cards').css({ 'z-index': '1' });
                    // drop button bottom chips value
                    $scope.last_bv_bet = $scope.bet_val;

                    $scope.select_lists[0].cards = [];
                    $('.sort_custom').removeClass('highlight_cards active active_green');
                    var top = $('.sort_custom-container').find(".sort_custom").last().offset().top;
                    var left = $('.sort_custom-container').find(".sort_custom").last().offset().left;
                    var abcd = $('#' + id + '').offset().left;
                    var current_t = $('#' + id + '').offset().top;
                    var current_l = $('#' + id + '').offset().left;

                    //pick card animate
                    $('#' + id).animate({
                            left: "" + ((left - current_l)) + "px",
                            top: "" + ((top - current_t)) + "px",
                            width: "7.9vw"
                    }, 400, function() {
                        $scope.pickcrds = true;
                        if (id == 'close_deck') {
                            $.keyframe.define([{
                                name: 'rotate_cards',
                                '0%': {
                                    'transform': 'rotateY(180deg)'
                                },
                                '100%': {
                                    'transform': 'rotateY(0deg)'
                                }
                            }, ]);

                            // rotate card animate
                            $('#' + id + '').playKeyframe({
                                name: 'rotate_cards',
                                duration: '300ms',
                                timingFunction: 'linear',
                                delay: '0s',
                                iterationCount: 'infinite',
                                direction: 'normal',
                                fillMode: 'forwards',
                                complete: function() {
                                    $('#' + id + '').resetKeyframe();
                                }
                            });
                            $timeout(function() {
                                $scope.closedeck = cards;
                            }, 150);
                        }
                        $timeout(function() {
                            // card push real array
                            $scope.$apply(function() {
                                $scope.lists[index].cards[($scope.lists[index].cards.length - 1)] = { card_detail: cards.substr(0, cards.length - 2), deck: cards.slice(-1) };
                                $scope.updatelisted = angular.copy($scope.lists);
                            });
                            // return card to original Position
                            $scope.closedeck = 'close_card1-0';
                            if (id == 'open_deck') {
                                $('#' + id + '').css({ 'top': '0%', 'left': '0px', 'transform': 'rotateY(0deg)', 'width': '100%' }).removeClass('active');
                                $scope.tCard[1] = 0;
                            } else {
                                $('#' + id + '').css({ 'top': '0%', 'left': '0vw', 'transform': 'rotateY(180deg)', 'width': '100%' }).removeClass('active');
                            }
                            $timeout(function() {
                                // sequancevalidation function call
                                $scope.sequancevalidation($scope.updatelisted, 'pick');
                            }, 50);
                            $('#' + id + '').removeClass('active4');
                            $('.not_click').removeClass('active');
                        }, 320);
                    });
                } else {
                    // other pick card animaton
                        var top = $(".user_cards_user_" + pickdata.si + " .blankuser").offset().top + ($(".user_cards_user_" + pickdata.si + " .blankuser").height() / 2);
                        var left = $(".user_cards_user_" + pickdata.si + " .blankuser").offset().left + ($(".user_cards_user_" + pickdata.si + " .blankuser").width() / 2);
                        var current_t = $('#' + id + '').offset().top + ($('#' + id + '').height() / 2);
                        var current_l = $('#' + id + '').offset().left + ($('#' + id + '').width() / 2);

                    // pick card animaton
                    $.keyframe.define([{
                        name: 'pick_animations',
                        '0%': {
                            'transform': 'scale(1)',
                        },
                        '100%': {
                            'left': '' + ((left - current_l)) + 'px',
                            'top': '' + ((top - current_t)) + 'px',
                            'transform': 'scale(0)',
                        }
                    }, ]);
                    $('#' + id + '').playKeyframe({
                        name: 'pick_animations',
                        duration: '400ms',
                        timingFunction: 'linear',
                        delay: '0s',
                        iterationCount: '1',
                        direction: 'normal',
                        fillMode: 'forwards',
                        complete: function() {
                            if (id == 'close_deck') {
                                $('#' + id + '').css({ 'top': '0vw', 'left': '0vw', 'transform': 'rotateY(180deg) scale(0)' }).removeClass('active');
                            } else {
                                $scope.tCard[1] = 0;
                                $('#' + id + '').css({ 'top': '0px', 'left': '0px', 'transform': 'scale(0)' }).removeClass('active');
                            }
                            $timeout(function() {
                                $('#' + id + '').css({ 'transform': 'scale(1)' });
                            }, 500);
                            $('#' + id + '').removeClass('active4');
                            $('#' + id + '').resetKeyframe();
                        }
                    });
                }
            }
        );
    }
    //over Pick  Card From  Deck

    // pick dack event send
    $scope.pick_deckuser = function(deck) {
        if ($scope.userturn_click == true && $scope.pickcrds == false) {
            if ($scope.howtoplay == false) {
                if (deck == 'close_deck') {
                    $scope.sendData('PFCD', {});
                    $scope.dropbtn = false;
                    $scope.pickcrds = true;
                } else if (deck == 'open_deck' && $scope.tCard[1].substring(2).slice(0,-2) != $scope.wildCard.substring(2) && $scope.tCard[1].charAt(0) != 'j') {
                    $scope.sendData('PFOD', {});
                    $scope.dropbtn = false;
                    $scope.pickcrds = true;
                } else if (deck == 'open_deck' && ($scope.tCard[1].substring(2).slice(0,-2) == $scope.wildCard.substring(2)) || ($scope.tCard[1].charAt(0) == 'j')) {
                    $scope.open_dack_joker = true;
                    $timeout(function() {
                        $scope.open_dack_joker = false;
                    },3000)
                } else {
                    
                }
            } 
            if ($scope.howtoplay == true) {
                $('.playing_buttom_cards').removeClass('howtoplay_not').addClass('howtoplay_top')
                $('.howtoplay_hand').removeClass('howtoplay_hand');
                if (deck == 'close_deck') {
                    $scope.pick_deck_temp = {si: 0, uid: $scope.sp_id, card: "f-7-0", bet: 0}
                    $scope.pick_deck('close_deck', $scope.pick_deck_temp);
                    $scope.htp_group_card = 10;
                    $timeout(function() {
                        $('.shat_card').removeClass('howtoplay_top')
                        $('.howtoplay_tooltip p').removeClass('active');
                        $('.howtoplay_tooltip7').addClass('active');
                        $timeout(function() {
                            
                            $('.sort_custom2_1').addClass('howtoplay_hand');
                        }, 1000);
                    }, 600);
                } else if (deck == 'open_deck') {
                    $scope.pick_deck_temp = {si: 0, uid: $scope.sp_id, card: $scope.tCard[1], bet: 0}
                    $scope.pick_deck('open_deck', $scope.pick_deck_temp);
                    $scope.htp_group_card = 7;
                    $timeout(function() {
                        $('.drop_card_list').removeClass('howtoplay_top').addClass('howtoplay_not')
                        $('.howtoplay_tooltip p').removeClass('active');
                        $('.howtoplay_tooltip4').addClass('active');
                        $timeout(function() {
                            $('.sort_custom1_2').addClass('howtoplay_hand');
                            $('.sort_custom2_0').addClass('howtoplay_hand');
                            $('.sort_custom2_3').addClass('howtoplay_hand');
                        }, 1000);
                    }, 600);
                }
                $scope.pickcrds = true;
                $scope.dropbtn = false;
            }
        } else {
            if ($scope.drop_standup == false) {
                $scope.notturn = true;
                $timeout(function() {
                    $scope.notturn = false;
                }, 3000);
            }
        }
    };
    //over pick dack event send

    // delcare event send
    $scope.declare_btn = function() {
        if ($scope.howtoplay == true) {
            $('.dash_setting_playing').removeClass('howtoplay_not').addClass('howtoplay_top')
            $('.howtoplay_tooltip p').removeClass('active');
            $('.howtoplay_tooltip17').addClass('active');
            $('.howtoplay_hand').removeClass('howtoplay_hand');
            $scope.declarebtn = false;
        } else {
            $interval.cancel($scope.autofinish);
            $interval.cancel($scope.autofinishrejoin);
            $scope.declarebtn = false;
            $scope.declare_list = { dCards: { "dwd": [], "seq": [], "set": [], "pure": [] } };
            $interval.cancel($scope.turn_timer_fns);
            $('.ring_circle2').attr("stroke-dasharray", "0,100%");
            $('.ring_circle2').attr("stroke", "rgba(255,29,21,0)");

            // create declare card arry
            angular.forEach($scope.lists, function(value, key) {
                if (value.cards.length != 0) {
                    if (value.seq == 1) {
                        $scope.pure_arr = []
                        angular.forEach(value.cards, function(pure, purekey) {
                            $scope.pure_arr.push("" + pure.card_detail + "-" + pure.deck + "");
                        });
                        $scope.declare_list.dCards.pure.push($scope.pure_arr);
                    }
                    if (value.seq == 2) {
                        $scope.impure_arr = []
                        angular.forEach(value.cards, function(pure, purekey) {
                            $scope.impure_arr.push("" + pure.card_detail + "-" + pure.deck + "");
                        });
                        $scope.declare_list.dCards.seq.push($scope.impure_arr);
                    }
                    if (value.seq == 3) {
                        $scope.set_arr = []
                        angular.forEach(value.cards, function(pure, purekey) {
                            $scope.set_arr.push("" + pure.card_detail + "-" + pure.deck + "");
                        });
                        $scope.declare_list.dCards.set.push($scope.set_arr);
                    }
                    if (value.seq == 6) {
                        $scope.set_arr = []
                        if (($scope.declare_list.dCards.pure.length >= 1 && $scope.declare_list.dCards.seq.length >= 1) || $scope.declare_list.dCards.pure.length >= 2) {
                            angular.forEach(value.cards, function(pure, purekey) {
                            $scope.set_arr.push("" + pure.card_detail + "-" + pure.deck + "");
                        });
                        $scope.declare_list.dCards.set.push($scope.set_arr);

                        } else {
                            $scope.declare_list.dCards.dwd.push("" + pure.card_detail + "-" + pure.deck + "");
                        }
                    }
                    if (value.seq == 4 || value.seq == 5 || value.seq == 7 || value.seq == 8) {
                        angular.forEach(value.cards, function(pure, purekey) {
                            $scope.declare_list.dCards.dwd.push("" + pure.card_detail + "-" + pure.deck + "");
                        });
                    }
                }
            });
            $timeout(function() {
                $scope.sendData('DECL', $scope.declare_list);
                $interval.cancel($scope.autofinish);
                $interval.cancel($scope.autofinishrejoin);
            }, 200);
        }
    };
    //over delcare event send

    // drops cards event send
    $scope.dropcars = function() {
        if ($scope.dropbtn == true) {
            $scope.sendData('DRC', {});
        }
    }
    //over drops cards event send

    // discard
    $scope.discard = function(disdata, ind, indexd) {

        if (disdata.bbv == undefined) {
            $scope.bet_value = $scope.min_value;
        } else {
            $scope.bet_value = disdata.bbv;
            $scope.min_value = $scope.bet_value;
        }
        $scope.pickcrds = false;
        $scope.userturn_click = false;

        $('.playing_buttom_cards').css({ 'z-index': '4' });

        if ($('.fin_card').length == 0) {
            $scope.through_card = disdata.card;
        }
        if (disdata.isRaise != 0 && disdata.isRaise != undefined) {
            $timeout(function() {
                $('.bet_chips' + disdata.si + '').addClass('active3');
                $scope.ofcoin[0] = ($('.bet_rummybetincreaset').offset().left + $('.bet_rummybetincreaset').width() / 2) - $('.user_cards_user_' + disdata.si + ' .blankuser').offset().left;
                $scope.ofcoin[1] = ($('.bet_rummybetincreaset').offset().top + $('.bet_rummybetincreaset').height() / 2) - ($('.user_cards_user_' + disdata.si + ' .blankuser').offset().top + $scope.vhTOpx(1.5));

                // bet increase and player discard at that time show label animation
                $.keyframe.define([{
                    name: 'dealchipsanim',
                    '0%': {
                        'left': '' + $('.user_cards_user_' + disdata.si + ' .blankuser').outerWidth() / 2 + 'px',
                        'top': '' + $scope.vhTOpx(13) + 'px',
                    },
                    '100%': {
                        'left': '' + $scope.ofcoin[0] + 'px',
                        'top': '' + $scope.ofcoin[1] + 'px',
                    }
                }, ]);

                $('.bet_chips' + disdata.si + '').each(function(index) {
                    $(this).playKeyframe({
                        name: 'dealchipsanim',
                        duration: '1.5s',
                        timingFunction: 'linear',
                        delay: '0s',
                        iterationCount: 'infinite',
                        direction: 'normal',
                        fillMode: 'forwards',
                        complete: function() {
                            $('.bet_chips' + disdata.si + '').resetKeyframe();
                            $('.bet_chips' + disdata.si + '').removeClass('active3');
                        }
                    });
                });
            }, 500);
        }
        if (disdata.uid != $scope.sp_id && $('.fin_card').length == 0) {
            // other player throuw card animation calculation
            if($('.through_card' + disdata.si + '').parents('.user_cards_user_' + disdata.si + '').find('.blankuser').offset().top != undefined){
                var current_t = $('.through_card' + disdata.si + '').parents('.user_cards_user_' + disdata.si + '').find('.blankuser').offset().top;
                var current_l = $('.through_card' + disdata.si + '').parents('.user_cards_user_' + disdata.si + '').find('.blankuser').offset().left;
                if (disdata.finish == true) {
                    var top = $(".finish_box").offset().top;
                    var left = $(".finish_box").offset().left;
                } else {
                    var top = $(".drop_card_list").offset().top;
                    var left = $(".drop_card_list ").offset().left;
                }
            }

            $('.through_card' + disdata.si + '').css({ 'z-index': '5' });
            $('.drop_card_list').addClass('open_deck_not_click');

            $.keyframe.define([{
                name: 'through_card_animate',
                '0%': {
                    'left': '' + $scope.vhTOpx(6) + 'px',
                    'top': '' + $scope.vhTOpx(4.5) + 'px',
                    'width': "3vw"
                },
                '100%': {
                    'left': '' + ((left - current_l)) + 'px',
                    'top': '' + ((top - current_t)) + 'px',
                    'width': $('#open_deck').width()
                }
            }, ]);

            $('.through_card' + disdata.si + '').playKeyframe({
                name: 'through_card_animate',
                duration: '400ms',
                timingFunction: 'linear',
                delay: '0s',
                iterationCount: 'infinite',
                direction: 'normal',
                fillMode: 'forwards',
                complete: function() {
                    $('.through_card' + disdata.si + '').resetKeyframe();
                    $('.through_card').css({ 'z-index': '0' });
                    // $scope.tCard[1] = disdata.card;
                }
            });
            $timeout(function() {
                if (disdata.finish == true) {
                    $scope.finish_slot_card = disdata.card;
                } else {
                    if ($scope.tCard[1] !== 0) {
                        $scope.tCard[0] = $scope.tCard[1];
                    }
                    $scope.tCard[1] = disdata.card;
                    $timeout(function() {
                        $('.drop_card_list').removeClass('open_deck_not_click');
                    }, 100);
                }
                $('.through_card').css({ 'top': '4.5vh', 'left': '6vh','width': "3vw", 'z-index': '0' });
            }, 400);
        } else {
            // current player discard animation
            $('.highlight_cards').removeClass('active');
            $scope.last_bv_bet = $scope.bet_value;
            if ($('.highlight_cards').length == 1 || $('.fin_card').length == 1) {
                if ($('.highlight_cards').length == 1 && $('.fin_card').length == 0) {
                    var top = $(".drop_card_list").offset().top;
                    var left = $("#open_deck").offset().left - $('.playing_buttom_cards').offset().left;
                    $('.card_group').removeClass('fin_card_arre');
                    $('.sort_custom').removeClass('fin_card');
                    var current_l = $('.highlight_cards').offset().left;
                    var current_t = $('.highlight_cards').offset().top - $scope.vhTOpx(1);

                    if (indexd != undefined) {
                        var i = ind;
                        var j = indexd;
                    } else {
                        var i = $scope.select_gi[0];
                        var j = $scope.select_ci[0]
                    }
                    // other player throw card animation function
                    $scope.through_card_animate($('.highlight_cards'), (left), (top - current_t), i, j, disdata.card);
                    $scope.select_lists[0].cards = [];
                } else if ($('.fin_card').length == 1) {
                    var top = $(".finish_box").offset().top;
                    var left = $(".finish_box").offset().left - $('.playing_buttom_cards').offset().left;

                    var current_l = $('.fin_card').offset().left;
                    var current_t = $('.fin_card').offset().top - $scope.vhTOpx(1);
                    if (indexd != undefined) {
                        var i = ind;
                        var j = indexd;
                    } else {
                        var i = $('.fin_card_arre').index() - 1;
                        var j = $('.fin_card').index();
                    }
                    // other player throw card animation function
                    $scope.through_card_animate($('.fin_card'), (left), (top - current_t), i, j, disdata.card);
                }
            }
        }
    }
    //over discard

    // through animation
    $scope.through_card_animate = function(drag_pos, left, top, d_i, d_j, disdata) {
        $scope.sortableOptions.disabled = true;
        var tleft = $(drag_pos).offset().left;
        $(drag_pos).css({ 'position': 'absolute', 'left': '' + $(drag_pos).position().left + 'px', 'top': '' + $(drag_pos).position().top + 'px', });
        left = left;
        top = top;
        $scope.cards_length = 13;
        if (($scope.lists[d_i].cards.length - 1) <= 0) {
            $scope.classes_width = ($scope.lists.length - 1);
        } else {
            $scope.classes_width = ($scope.lists.length);
        }
        $scope.get_margin($scope.cards_length, $scope.classes_width, 2);
        if (($scope.lists[d_i].cards.length - 1) == d_j) {
            $('.sort_custom' + d_i + '_' + (d_j - 1) + '').addClass('through_last');
        }
        // throw card animation
        $.keyframe.define([{
            name: 'through_card_animate_cu',
            '0%': {
                'width': $('.card_group .sort_custom-container .sort_custom').width()
            },
            '100%': {
                'left': '' + (left) + 'px',
                'top': '' + (top) + 'px',
                'width': $('#open_deck').width()
            }
        }, ]);

        $(drag_pos).playKeyframe({
            name: 'through_card_animate_cu',
            duration: '400ms',
            timingFunction: 'linear',
            delay: '0s',
            iterationCount: '1',
            direction: 'normal',
            fillMode: 'forwards',
            complete: function() {
                if ($('.fin_card').length == 0) {
                    if ($scope.tCard[1] !== 0) {
                        $scope.tCard[0] = $scope.tCard[1];
                    }
                    $scope.tCard[1] = disdata;
                }
                $scope.updatelisted = angular.copy($scope.lists);
                $scope.updatelisted[d_i].cards.splice(d_j, 1);
                $scope.updatelisted.nullval_remove();
                $scope.outtime_data = '';
                $scope.select_gi = [];
                $scope.select_ci = [];
                // $scope.select_lists[0].cards = [];
                $timeout(function() {
                    $scope.lists[d_i].cards.splice(d_j, 1);
                    $(drag_pos).resetKeyframe();
                    $(drag_pos).css({ 'width': '"' + $('.card_group .sort_custom-container .sort_custom').width() + '"', 'position': 'relative', 'left': '0px', 'top': '0px' });
                    $scope.onecard_combine();
                }, 1);
            }
        });
    }
    //over through animation

    // discard btn click event send
    $scope.discard_btn = function(id) {
        $scope.selected_dis_msg = false;
        $scope.selected_dic_msg = false;
        if($scope.select_lists[0].cards.length == 1 && $scope.userturn_click == true && $scope.pickcrds == true){
            var cards = '' + $scope.select_lists[0].cards[0].card_detail + '-' + $scope.select_lists[0].cards[0].deck + '';
            if ($scope.userturn_click == true) {
                if (id == 'dis') {
                    if ($scope.howtoplay == false) {
                        if ($scope.modelset == 'Bet') {
                            $scope.sendData('DSCRD', { bet: $scope.bet_value, card: cards, secTime: $scope.remaing_time });
                        }else {
                            $scope.sendData('DSCRD', { card: cards, secTime: $scope.remaing_time });
                        }
                        $scope.userturn_click = false;
                    } else {
                        if ($scope.htp_group_card != 8) {
                            $scope.howtoplay_robot_pike_discard()
                            $scope.userturn_click = false;
                        }
                    }
                } else if (id == 'fin') {
                    if ($scope.howtoplay == false || ($scope.howtoplay == true && $scope.htp_group_card == 8)) {
                        $scope.setting_menu_btn = true;
                        $scope.settin_menu_slid = 0;
                        $scope.switch_table_msg = false;
                        $scope.popup[1] = 0;
                        $scope.finish_popup_show = true;
                        if ($scope.howtoplay == true) {
                            $('.not_click').addClass('active');
                            $scope.FNS_data = {si:0};
                            $scope.finish_popup_show = false;
                            $scope.setting_menu_btn = false;
                            $('.howtoplay_tooltip p').removeClass('active');
                            $('.howtoplay_tooltip11').addClass('active');
                            $timeout(function() {
                                $('.howtoplay_tooltip p').removeClass('active');
                                $('.howtoplay_tooltip12').addClass('active');
                                $('.card_group0>ul').addClass('border_active');
                                $timeout(function() {
                                    $('.card_group>ul').removeClass('border_active');
                                    $('.howtoplay_tooltip p').removeClass('active');
                                    $('.howtoplay_tooltip14').addClass('active');
                                    $('.card_group1>ul').addClass('border_active');
                                    $('.card_group2>ul').addClass('border_active');
                                    $timeout(function() {
                                        $('.card_group>ul').removeClass('border_active');
                                        $('.howtoplay_tooltip p').removeClass('active');
                                        $('.howtoplay_tooltip13').addClass('active');
                                        $('.card_group3>ul').addClass('border_active');
                                        $timeout(function() {
                                            $scope.declarebtn = true;
                                            $('.card_group>ul').removeClass('border_active');
                                            $('.howtoplay_tooltip p').removeClass('active');
                                            $('.howtoplay_tooltip16').addClass('active');
                                            $('.howtoplay_hand').removeClass('howtoplay_hand');
                                            $timeout(function() {
                                                $('.fin_t>a').addClass('howtoplay_hand');
                                            },100)    
                                        },5000)
                                    },5000);
                                },5000);
                            }, 3000);
                        }
                        if ($('.highlight_cards').length == 1) {
                            $('.highlight_cards').parents('.card_group').addClass('fin_card_arre');
                            $('.highlight_cards').addClass('fin_card');
                        }
                        var ind = $('.fin_card_arre').index() - 1;
                        var indexd = $('.fin_card').index();
                        $scope.discard({ si: $scope.set_index, cards: $scope.outtime_data.ctth }, ind, indexd);
                        $timeout(function() {
                            $scope.finish_slot_card = cards;
                        }, 410);
                    }
                } else {

                }
            }
        }
        else{
            if (id == 'dis') {
                $scope.selected_dis_msg = true;
            }
            else if (id == 'fin') {
                $scope.selected_dic_msg = true;
            }
            $timeout(function() {
                $scope.selected_dis_msg = false;
                $scope.selected_dic_msg = false;
            },3000);
        }
    }
    //over discard_btn click event send

    // Finished conform
    $scope.finsih_pop = function(id) {
        $scope.popup[1] = 0;
        if (id == 0) {
            $scope.D_card = $scope.select_lists[0].cards[0].card_detail + '-' + $scope.select_lists[0].cards[0].deck + '';
            $scope.setting_menu_btn = true;
            $scope.settin_menu_slid = 0;
            $scope.switch_table_msg = false;
            $scope.sendData('FNS', { card: $scope.D_card });
            $scope.userturn_click = false;
            $scope.finish_popup_show = false;
        }else{
            $scope.finsih_pop_cancel();
        }
    }
    // over Finished conform

    $scope.finsih_pop_cancel = function() {
        $scope.finish_popup_show = false;
        $scope.userturn_click = true;
        $('.fin_card').css({'opacity':'1'})
        $scope.sortableOptions.disabled = false;
        $scope.setting_menu_btn = false;
        var index = $scope.lists.length;

        // get last group index
        while (index-- && !$scope.lists[index].cards.length != 0);
        $scope.lists[index].cards.push('');

        $scope.cards_length = 14;
        $scope.classes_width = ($scope.lists.length);
        // call margin function
        $scope.get_margin($scope.cards_length, $scope.classes_width, 2);

        $('.playing_buttom_cards').css({ 'z-index': '1' });

        $('.sort_custom').removeClass('highlight_cards active active_green');
        var top = $('.sort_custom-container').find(".sort_custom").last().offset().top;
        var left = $('.sort_custom-container').find(".sort_custom").last().offset().left;
        var current_t = $('.finish_box .finish_card').offset().top;
        var current_l = $('.finish_box .finish_card').offset().left;

        //pick card animate
        $('.finish_box .finish_card, .finish_box .finish_card_jokar').animate({
            left: "" + ((left - current_l)) + "px",
            top: "" + ((top - current_t)) + "px",
            width: "7.9vw",
            height: "auto"
        }, 400, function() {
            $scope.pickcrds = true;
            // card push real array
            $scope.$apply(function() {
                $scope.lists[index].cards[($scope.lists[index].cards.length - 1)] = { card_detail: $scope.finish_slot_card.substr(0, $scope.finish_slot_card.length - 2), deck: $scope.finish_slot_card.slice(-1) };
                $scope.updatelisted = angular.copy($scope.lists);
            });
            // return card to original Position
            $('.finish_box .finish_card').css({ 'top': '0%', 'left': '0px', 'width': '100%', 'height': '100%', 'opacity':'0'}).removeClass('active');
            $scope.finish_slot_card = 0;
            $scope.setting_menu_btn = false;
            $scope.select_lists[0].cards = [];
            $timeout(function() {
                // sequancevalidation function call
                $scope.sequancevalidation($scope.updatelisted, 'drag');
                $('.card_group').removeClass('fin_card_arre');
                $('.sort_custom').removeClass('fin_card');

            }, 10);

            $('.not_click').removeClass('active');
        });
    }

    // calculate  vh to px
    $scope.vhTOpx = function(value) {
        var w = window,
            d = document,
            e = d.documentElement,
            g = d.getElementsByTagName('body')[0],
            x = w.innerWidth || e.clientWidth || g.clientWidth,
            y = w.innerHeight || e.clientHeight || g.clientHeight;

        var result = (y * value) / 100;
        return result;
    }
    //over calculate  vh to px

    // calculate  vw to px
    $scope.vwTOpx = function(value) {
        var w = window,
            d = document,
            e = d.documentElement,
            g = d.getElementsByTagName('body')[0],
            x = w.innerWidth || e.clientWidth || g.clientWidth,
            y = w.innerHeight || e.clientHeight || g.clientHeight;

        var result = (x * value) / 100;
        return result;
    }
    //over calculate  vw to px

    $scope.pxTOvh = function(value) {
        var w = window,
            d = document,
            e = d.documentElement,
            g = d.getElementsByTagName('body')[0],
            x = w.innerWidth || e.clientWidth || g.clientWidth,
            y = w.innerHeight|| e.clientHeight|| g.clientHeight;

        var result = (100*value)/y;
        // document.getElementById("result_px_vh").innerHTML = result;  // affichage du résultat (facultatif)
        return result;
    }

    $scope.pxTOvw = function(value) {
        var w = window,
            d = document,
            e = d.documentElement,
            g = d.getElementsByTagName('body')[0],
            x = w.innerWidth || e.clientWidth || g.clientWidth,
            y = w.innerHeight|| e.clientHeight|| g.clientHeight;

        var result = (100*value)/x;
        // document.getElementById("result_px_vw").innerHTML = result;  // affichage du résultat (facultatif)
        return result;
    }

    $scope.width_table = ($scope.vhTOpx(100) * 0.3) + $scope.vhTOpx(100);

    //card distribution group
    $scope.cardgroupset = function(data) {
        $scope.discarded_popup = false;
        $scope.wildCard = data.wildCard.substr(0, data.wildCard.length - 2);
        $scope.hakamchk = $scope.wildCard.substr(2);
        $scope.tCard[1] = data.tCard;
        // push card in array
        if (data.cards != undefined) {
            $scope.lists = [{ cards: [], seq: 4 }, { cards: [], seq: 4 }, { cards: [], seq: 4 }, { cards: [], seq: 4 }, { cards: [], seq: 4 }];
            if ($scope.short_btn_flag == false) {
                angular.forEach(data.cards, function(value, key) {
                    if (value.charAt(0) == 'k') {
                        $scope.lists[0].cards.push({ card_detail: value.substr(0, value.length - 2), deck: value.slice(-1) });
                    } else if (value.charAt(0) == 'c') {
                        $scope.lists[1].cards.push({ card_detail: value.substr(0, value.length - 2), deck: value.slice(-1) });
                    } else if (value.charAt(0) == 'f') {
                        $scope.lists[2].cards.push({ card_detail: value.substr(0, value.length - 2), deck: value.slice(-1) });
                    } else if (value.charAt(0) == 'l') {
                        $scope.lists[3].cards.push({ card_detail: value.substr(0, value.length - 2), deck: value.slice(-1) });
                    } else {
                        $scope.lists[4].cards.push({ card_detail: value.substr(0, value.length - 2), deck: value.slice(-1) });
                    }
                });
            } else {
            
                angular.forEach(data.cards, function(value, key) {
                    $scope.lists[0].cards.push({ card_detail: value.substr(0, value.length - 2), deck: value.slice(-1) });
                })
                $scope.cards_length = 13;
                $scope.classes_width = ($scope.lists.length);
                $scope.lists.nullval_remove();
                $scope.get_margin($scope.cards_length, $scope.classes_width, 2);
                $scope.onecard_combine();
                $('.playing_buttom_cards').addClass('card_deactive');
                $scope.deadwood_points_c = 80;
                $scope.deadwood_points(data);
                setTimeout(function() {
                    $('.playing_buttom_cards').removeClass('card_deactive');
                    $('.playing_buttom_cards').addClass('card_wpr')
                    setTimeout(function(){
                        $('.playing_buttom_cards').removeClass('card_wpr')
                        $scope.card_flip_animation = false;
                        $('.drop_card_list').removeClass('open_deck_not_click');
                        setTimeout(function() {
                            $scope.setting_menu_btn = false;
                        },500)
                    }, 1600)
                },500);
            }
        } else {
            $scope.setting_menu_btn = false;
        }
        // $scope.cards_length = 13;
        // $scope.classes_width = ($scope.lists.length);
        // $scope.lists.nullval_remove();
        // $scope.get_margin($scope.cards_length, $scope.classes_width, 2);
        // $scope.onecard_combine();
        // $scope.deadwood_points_c = 80;
    }
    //over card distribution group

    $(window).resize(function() { 
        $scope.cards_length = $('.sort_lists').length;
        $scope.updatelisted = angular.copy($scope.lists);
        $scope.classes_width = ($scope.lists.length);
        $scope.get_margin($scope.cards_length, $scope.classes_width, 2);
    }); 


    $scope.sort_cards = function() {
        $scope.short_btn_flag = false;
        $scope.short_card_save = $scope.lists[0].cards;
        $scope.lists = [{ cards: [], seq: 4 }, { cards: [], seq: 4 }, { cards: [], seq: 4 }, { cards: [], seq: 4 }, { cards: [], seq: 4 }];

        angular.forEach($scope.short_card_save, function(value_data) {
            if (value_data.card_detail.charAt(0) == 'k') {
                $scope.lists[0].cards.push({ card_detail: value_data.card_detail, deck: value_data.deck });
            } else if (value_data.card_detail.charAt(0) == 'c') {
                $scope.lists[1].cards.push({ card_detail: value_data.card_detail, deck: value_data.deck });
            } else if (value_data.card_detail.charAt(0) == 'f') {
                $scope.lists[2].cards.push({ card_detail: value_data.card_detail, deck: value_data.deck });
            } else if (value_data.card_detail.charAt(0) == 'l') {
                $scope.lists[3].cards.push({ card_detail: value_data.card_detail, deck: value_data.deck });
            } else {
                $scope.lists[4].cards.push({ card_detail: value_data.card_detail, deck: value_data.deck });
            }
        });

        var i = 0;
        var j = 0;
        if ($scope.lists[0].cards.length != 0) {
            var temp_arra0 = $scope.lists[0].cards;
            $scope.lists[0].cards = [];
            for (i = 1; i < 14; i++) {
                for (j = 0; j < temp_arra0.length; j++) {
                    if (parseInt(temp_arra0[j].card_detail.substr(2)) == i) {
                        $scope.lists[0].cards.push({card_detail: temp_arra0[j].card_detail, deck: temp_arra0[j].deck })
                    }
                }
            }
        }

        if ($scope.lists[1].cards.length != 0) {
            var temp_arra1 = $scope.lists[1].cards;
            $scope.lists[1].cards = [];
            for (i = 1; i < 14; i++) {
                for (j = 0; j < temp_arra1.length; j++) {
                    if (parseInt(temp_arra1[j].card_detail.substr(2)) == i) {
                        $scope.lists[1].cards.push({card_detail: temp_arra1[j].card_detail, deck: temp_arra1[j].deck })
                    }
                }
            }
        }

        if ($scope.lists[2].cards.length != 0) {
            var temp_arra2 = $scope.lists[2].cards;
            $scope.lists[2].cards = [];
            for (i = 1; i < 14; i++) {
                for (j = 0; j < temp_arra2.length; j++) {
                    if (parseInt(temp_arra2[j].card_detail.substr(2)) == i) {
                        $scope.lists[2].cards.push({card_detail: temp_arra2[j].card_detail, deck: temp_arra2[j].deck })
                    }
                }
            }
        }

        if ($scope.lists[3].cards.length != 0) {
            var temp_arra3 = $scope.lists[3].cards;
            $scope.lists[3].cards = [];
            for (i = 1; i < 14; i++) {
                for (j = 0; j < temp_arra3.length; j++) {
                    if (parseInt(temp_arra3[j].card_detail.substr(2)) == i) {
                        $scope.lists[3].cards.push({card_detail: temp_arra3[j].card_detail, deck: temp_arra3[j].deck })
                    }
                }
            }
        }

        if ($scope.lists[4].cards.length != 0) {
            var temp_arra4 = $scope.lists[4].cards;
            $scope.lists[4].cards = [];
            for (i = 1; i < 14; i++) {
                for (j = 0; j < temp_arra4.length; j++) {
                    if (parseInt(temp_arra4[j].card_detail.substr(2)) == i) {
                        $scope.lists[4].cards.push({card_detail: temp_arra4[j].card_detail, deck: temp_arra4[j].deck })
                    }
                }
            }
        }

        $scope.cards_length = $scope.short_card_save.length;
        $scope.updatelisted = angular.copy($scope.lists);
        $scope.classes_width = ($scope.lists.length);
        $scope.lists.nullval_remove();
        $scope.get_margin($scope.cards_length, $scope.classes_width, 2);
        $scope.onecard_combine();
        $scope.deadwood_points_c = 80;

        if ($scope.howtoplay == false) {
            $scope.sendData('SORT', {tbid:$scope.table_id});
        } else {
            $('.howtoplay_tooltip p').removeClass('active');
            $('.howtoplay_tooltip3').addClass('active');
            $('.howtoplay_hand').removeClass('howtoplay_hand');
            $('.shat_card').addClass('howtoplay_hand');
            $('.shat_card').removeClass('howtoplay_not').addClass('howtoplay_top')
            $scope.howtoplay_user_pike_discard()
        }
    }



    // group null value remove
    Array.prototype.nullval_remove = function() {
        for (var i = 0; i < this.length; i++) {
            if (this[i].cards.length == 0) {
                this.splice(i, 1);
                i--;
            }
        }
        return this;
    };
    //over group null value remove

    $scope.sign_up_in = function(data) {
        var _emailid = $('.form_details input[name="email"]').val()
        var _password = $('.form_details input[name="password"]').val()


         
        var temp_obj = {'Email': _emailid, 'Password': _password, 'GmailSocialId': '', 'FcebookSocialId': '', 'UserReferCode': '', 'TokenIOS': '', 'TokenFireBase': '', Token: ''}

        $http.post('https://api.tigerrummy.com/v1/user/register-new', temp_obj).then(function (response) {
            console.log(response)

        });
    }

    //popup menu
    $scope.popup_hide_show = function(data) {
        if (data == 1) {
            if ($scope.popup[1] == 0) {
                $scope.popup[1] = 1;
                $scope.ButtonClick_sound();
            } else {
                $scope.popup[1] = 0;
            }
        }
        if (data == 'sound_playing') {
            $scope.ButtonClick_sound();
        }
        if (data == 'score_bord') {
            $scope.ButtonClick_sound();
            $scope.winner_scored = false;
            $scope.lastdeal = false;
        }
        if (data == 'leader_board') {
            $scope.ButtonClick_sound();
            $scope.LB_data = [];
        }
        if (data == 'daily_bonus') {
            $scope.ButtonClick_sound();
            $scope.CFDB_data = [];
        }
        if (data == 'password_toltip') {
            $scope.ButtonClick_sound();
            if ($scope.password_toltip == true) {
                $scope.password_toltip = false;
            } else {
                $scope.password_toltip = true;
            }
        }
        if (data == 'daily_bonus_spinner') {
            $scope.ButtonClick_sound();
            $scope.GSD_data = [];
            $interval.cancel($scope.spinInt);
        }
        if (data == 'refer_earn_popup') {
            $scope.ButtonClick_sound();
            $scope.refer_earn_popup = true;
        }
        if (data == 'wallet_popup') {
            $scope.ButtonClick_sound();
            $scope.wallet_popup = true;
        }
        if (data == 'switch_table_msg') {
            $scope.switch_table_msg = false;
            if ($scope.declarebtn == false) {
                $('.timer_counter').removeClass('active')
                $scope.sendData('SWTL', {});
                $scope.SDC_data = [];
                $scope.user_dealer = -1;
                $scope.settin_menu_slid = 0;
                $timeout(function() {
                    $timeout(function() {
                        $scope.setting_menu_btn = true;
                    },2000)
                    $scope.winner_scored_data = '';
                }, 500);
            }
        }

        if (data == 'game_info') {
            $scope.ButtonClick_sound();
            $scope.GPTI_data = [];
        }
        if (data == 'feedback') {
            $scope.ButtonClick_sound();
            if ($('.text_area_before>textarea').val() != '') {
                $scope.sendData('FM', {text: $('.text_area_before>textarea').val()});
                $('.text_area_before').removeClass('error')
                $('.text_area_before>textarea').val('')
                $('.username_before_icon>input').val('')
                $scope.feedback_popup = false;
            } else {
                $('.text_area_before').addClass('error')
            }
        }
        if (data == 'report_pro') {
            $scope.ButtonClick_sound();
            $scope.RPD_data = [];
        }
        if (data == 'out_chips') {
            $scope.ButtonClick_sound();
            $scope.out_chips = false;
        }
        if (data == 'last_play') {
            $scope.ButtonClick_sound();
            $scope.last_play = '';
        }
        if (data == 'common') {
            $scope.ButtonClick_sound();
            $scope.pop_msg = '';
        }
        if (data == 'user_profile') {
            $scope.ButtonClick_sound();
            $scope.edit_profile_value = false;
            $(".edit_text_email").removeClass('active');
            $(".edit_text_phno").removeClass('active');
            $(".edit_text_password").removeClass('active');
            $(".edit_text_password").attr('type', 'password');
            $(".edit_text_name").removeClass('active');
            $scope.view_profile_detail = [];
        }
        if (data == 'maintainence_clo') {
            $scope.ButtonClick_sound();
            $scope.m_c_flag = 'false';
        }
        if (data === 'multiple') {
            $scope.ButtonClick_sound();
            $scope.multiuser_connect = false;
            // socket_reconnect = true;
            // $window.socket.connect();
            location.reload();
        }
        if (data == 'add_cash_close' || data == 'add_cash_show') {
            $scope.ButtonClick_sound();
            if (data == 'add_cash_show') {
                $scope.add_cash_popup_show = true;
            } else {
                $scope.add_cash_popup_show = false;
            }
        }
        // if ($scope.round_timer > 3 || $scope.round_timer <= 0) {
        //     $timeout(function() {
        //         $scope.setting_menu_btn = false;
        //     }, 600);
        // }
    }
    //over popup menu

    $scope.sound_on_off_playing = function(flag) {
        if (flag == 'on' && $scope.sound_on_off == 0) {
            $scope.sendData('CGS', {flag:'sound'});
        }
    }

    // How to play
    $scope.howto_play_click = function(data) {
        $('.menu_side_1').removeClass('deactive_left deactive_right menu_right_to_center menu_center_to_left menu_left_to_center menu_center_to_right').addClass('menu_left_to_center');
        $('.menu_side_2').removeClass('deactive_left deactive_right menu_right_to_center menu_center_to_left menu_left_to_center menu_center_to_right').addClass('deactive_right');
        $('.menu_side_3').removeClass('deactive_left deactive_right menu_right_to_center menu_center_to_left menu_left_to_center menu_center_to_right').addClass('deactive_right');
        $('.menu_side_tab_1').removeClass('deactive_left deactive_right menu_right_to_center menu_center_to_left menu_left_to_center menu_center_to_right menu_side_tab_bg menu_side_tab_fix').addClass('deactive_right')
        $('.menu_side_tab_2').removeClass('deactive_left deactive_right menu_right_to_center menu_center_to_left menu_left_to_center menu_center_to_right').addClass('deactive_right');
        if (data == true) {
            $scope.howtoplay = true;
            $scope.screen[2] = 1;
            $scope.clear_play_table();
            
            $scope.theme_color = 'red';
            $scope.table_user[0] = {ap: 1, si: 0, uid: $scope.sp_id, un: $scope.user_detail.un, pp: $scope.user_detail.pp, _ir: 1, secTime: 0, Chips: $scope.user_detail.Chips, totalCash: $scope.user_detail.totalcash, bet: 0, s: "", msg: "", key: "JOIN_TABLE"}
            $scope.table_user[1] = {ap: 2, si: 1, uid: "123456789", un: "MTR_12345678", pp: "", _ir: 1, secTime: 0, Chips: 500, totalCash: 500, bet: 0, s: "", msg: "", key: "JOIN_TABLE"}
            $scope.user_setting_ar = [
                [2, 5]
            ];
            $scope.short_btn_flag = true;
            $scope.sdc_cards = true;
            $scope.wildCard = 'k-1';
            $scope.gti_data = [];
            $scope.smccard = { cards: [ 'k-8-0', 'k-9-0', 'l-7-0', 'c-7-0', 'c-8-0', 'l-13-0', 'k-5-0', 'k-6-0', 'l-12-0', 'c-4-0', 'c-5-0', 'l-10-0', 'c-9-0' ], wildCard: 'c-9-0', tCard: 'k-12-0', si: [0, 1] }
            $scope.cardgroupset($scope.smccard);
            $timeout(function() {
                $('.dash_setting_playing').removeClass('howtoplay_top').addClass('howtoplay_not')
                $('.table_heading').addClass('howtoplay_top');
                $('.howtoplay_tooltip1').addClass('active');
                $('.playing_buttom_cards').removeClass('howtoplay_top').addClass('howtoplay_not')
                $scope.sortableOptions.items = '';
                $timeout(function() {
                    $('.howtoplay_tooltip p').removeClass('active');
                    $('.howtoplay_tooltip2').addClass('active');
                    $timeout(function() {
                        $('.howtoplay_tooltip p').removeClass('active');
                        $('.howtoplay_tooltip10').addClass('active');
                        $('.playing_buttom_cards').removeClass('howtoplay_not').addClass('howtoplay_top');
                        $('.current_user').removeClass('howtoplay_not').addClass('howtoplay_top');
                        $('.howtoplay_hand').removeClass('howtoplay_hand');
                        $('.sort_button').addClass('howtoplay_hand');
                        // $('.not_click').addClass('active');
                        $scope.sortableOptions.disabled = false;
                        $scope.htp_group_card = 0;
                        $scope.short_btn_flag = true;
                        $scope.set_index = 0;
                    }, 3000);
                }, 3000);
            }, 100);
        } else {
            $scope.clear_play_table();
            $scope.table_user = [0, 0, 0, 0, 0, 0];
            $scope.htp_group_card = 0;
            $scope.short_btn_flag = true;
            $('.howtoplay_top').removeClass('howtoplay_top');
            $('.howtoplay_not').addClass('howtoplay_not');
            $('.howtoplay_tooltip p').removeClass('active');
            $('.howtoplay_hand').removeClass('howtoplay_hand');
            $('.dash_setting_playing').removeClass('howtoplay_top').addClass('howtoplay_not')
            $timeout(function() {
                $scope.screen[2] = 0;
                $scope.howtoplay = false;
            }, 100);
        }
    }
    // Over how to play

    $scope.howtoplay_robot_pike_discard = function(data) {
        $('.howtoplay_tooltip p').removeClass('active');
        $('.howtoplay_tooltip8').addClass('active');
        $('.howtoplay_hand').removeClass('howtoplay_hand');
        $scope.discard_temp = {si: 0, uid: $scope.sp_id, card: "l-" + $scope.htp_group_card + "-0", finish: false, bbv: 0, time: 0, isRaise: 0}
        $scope.discard($scope.discard_temp);
        $('.shat_card').removeClass('howtoplay_top').addClass('howtoplay_not')
        $('.playing_buttom_cards').removeClass('howtoplay_top').addClass('howtoplay_not')
        $('.current_user').removeClass('howtoplay_top').addClass('howtoplay_not')
        $('.userlist3').addClass('howtoplay_top')
        $scope.remaing_time = 30;
        $scope.AnotherUserTurn_sound();
        $scope.anim_userturn_f($scope.config.STT, 1, 1);
        $scope.userturn_click = false;
        $scope.dropbtn = false;
        $scope.user_turn_g = false;
        $timeout(function() {
            $scope.pick_robot_temp = {si: 1, uid: '123456789', card: "l-1-0", thp: 0, bet: 0}
            $scope.pick_deck('close_deck', $scope.pick_robot_temp);
            $timeout(function() {
                $scope.discard_robot_temp = {si: 1, uid: '123456789', card: "l-1-0", finish: false, bbv: 0, time: 0, cdd: false, isRaise: 0}
                $scope.discard($scope.discard_robot_temp);
                $('.ring_circle2').attr("stroke-dasharray", "0,100%");
                $('.ring_circle2').attr("stroke", "rgba(255,29,21,0)");
                $('.timer_counter').removeClass('active');
                $interval.cancel($scope.turn_timer);
                $interval.cancel($scope.turn_timer_counter);
                $('.drop_card_list').removeClass('howtoplay_not').addClass('howtoplay_top');
                $('.howtoplay_tooltip p').removeClass('active');
                $('.howtoplay_tooltip9').addClass('active');
                $('.howtoplay_hand').removeClass('howtoplay_hand');
                $('.drop_card_list').addClass('howtoplay_hand');
                $scope.howtoplay_user_pike_discard()
            }, 2000);    
        }, 1500);
    }

    $scope.howtoplay_user_pike_discard = function(data) {
        $('.playing_buttom_cards').removeClass('howtoplay_top').addClass('howtoplay_not')
        $('.current_user').removeClass('howtoplay_not').addClass('howtoplay_top');
        $('.userlist3').removeClass('howtoplay_top');
        $scope.userturn_click = true;
        $scope.dropbtn = true;
        $scope.user_turn_g = true;
        $('.drop_button').addClass('howtoplay_deactive');
    }


    $scope.common_popup_click = function(data) {
        if (data == 'backtolobby_yes') {
            $scope.ButtonClick_sound();
            $scope.common_popup_show = false;
            $scope.sendData('LT', {});
        }
        if (data == 'backtolobby_no') {
            $scope.ButtonClick_sound();
            $scope.common_popup_show = false;
        }
        if (data == 'common_popup_show') {
            $scope.ButtonClick_sound();
            $scope.common_popup_show = true;
        }
    }
    // select theme color
    $scope.theme_color_select = function(data) {
        if (data == 'cyan') {
            $scope.theme_color = 'cyan';
        } else {
            $scope.theme_color = 'red';
        }
    }
    // over select theme color

    // discard slider event send
    $scope.discarded_slider = function() {
        $scope.ButtonClick_sound();
        if ($scope.discarded_popup == false && $scope.howtoplay == false) {
            $scope.sendData('DC', {});
            $scope.discarded_popup = true;
        } else {
            $scope.discarded_popup = false;
        }
    }
    //over discard slider event send

    // user turn color
    $scope.percentColors = [
        { pct: 0.0, color: { r: 255, g: 29, b: 21 } },
        { pct: 0.5, color: { r: 0xff, g: 0xff, b: 0 } },
        { pct: 1.0, color: { r: 0, g: 255, b: 133 } }
        ];
    //over user turn color

    // animation user turn
    $scope.anim_userturn_f = function(c_time, i, flag) {
        // if ($scope.set_index == i) {
        //     window.navigator.vibrate(200);
        // }
        var interval = 30;
        var totla_px = 88;
        if (flag == 0) {
            var timer_remain = 88;
        } else {
            var timer_remain = totla_px - (($scope.config.STT - c_time) * (totla_px / $scope.config.STT));
        }
        $scope.circle = document.getElementsByClassName('turn_timer_' + i + '')[0];
        var circle_top2 = document.getElementsByClassName('patern_2')[0];
        $('.user_cards_user_' + i + ' .timer_counter').addClass('active');
        if (flag == 0) {
            var angle_increment = (totla_px / ((parseInt(1000 / interval) * interval) * c_time)) * interval;
        } else {
            var angle_increment = (totla_px / ((parseInt(1000 / interval) * interval) * $scope.config.STT)) * interval;
        }
        $interval.cancel($scope.turn_timer);
        $interval.cancel($scope.turn_timer_counter);

        $scope.pass_time = c_time;
        $scope.turn_timer_counter = $interval(function() {
            $scope.pass_time = $scope.pass_time - 1;
            if (flag == 0) {
                $scope.remaing_time = $scope.remaing_time - 1;
                if ($scope.pass_time <= 1 && $scope.set_index == i) {
                    if ($scope.finish_popup_show == true) {
                        $scope.finsih_pop_cancel();
                    }
                }
            }
        },1000);

        $scope.turn_timer = $interval(function() {
            $scope.circle.setAttribute("stroke-dasharray", (totla_px * (timer_remain / totla_px * 100) / 100) + ",100%");
            if (flag == 0) {
                $scope.circle.setAttribute("stroke", "rgba(255,29,21,1)");
            } else {
                $scope.circle.setAttribute("stroke", $scope.getColorForPercentage(parseInt(timer_remain / totla_px * 100) / 100));
            }
            if (parseInt(timer_remain / totla_px * 100) <= 0) {
                if (parseInt(timer_remain / totla_px * 100) <= -2) {
                    $('.timer_counter').removeClass('active');
                    $interval.cancel($scope.turn_timer_counter);
                    $interval.cancel($scope.turn_timer);
                }
                $scope.circle.setAttribute("stroke-dasharray", "0,100%");
                if (flag == 0) {
                    $scope.dropbtn = false;
                    $scope.pass_time = 0;
                }
            }
            timer_remain = timer_remain - angle_increment;
        }, interval);
    }
    //over animation user turn

    //user turn from to color generate 
    $scope.getColorForPercentage = function(pct) {
        for (var i = 1; i < $scope.percentColors.length - 1; i++) {
            if (pct < $scope.percentColors[i].pct) {
                break;
            }
        }

        var lower = $scope.percentColors[i - 1];
        var upper = $scope.percentColors[i];
        var range = upper.pct - lower.pct;
        var rangePct = (pct - lower.pct) / range;
        var pctLower = 1 - rangePct;
        var pctUpper = rangePct;
        var color = {
            r: Math.floor(lower.color.r * pctLower + upper.color.r * pctUpper),
            g: Math.floor(lower.color.g * pctLower + upper.color.g * pctUpper),
            b: Math.floor(lower.color.b * pctLower + upper.color.b * pctUpper)
        };
        return 'rgb(' + [color.r, color.g, color.b].join(',') + ')';
    }
    //over user turn from to color generate 

    // only first word get
    $scope.first_word_set = function(data) {
        return data.split(' ')[0];
    }
    //over only first word get

    // sortable stop event
    $scope.drag_and_through_card = function(e, ui) {
        $('.drop_card_list_img_top_yellow').removeClass('active');
        // var p_left = Math.abs(ui.originalPosition.left - ui.position.left);
        // var p_top = Math.abs(ui.originalPosition.top - ui.position.top);
        // throw card validation check
        if ((0 - ui.item.context.clientHeight) >= ui.position.top && $scope.user_turn_g == true && $scope.pickcrds == true) {
            // set card position
            $(ui.item).css({ 'top': '' + ui.position.top + 'px', 'left': '' + ui.position.left + 'px', 'position': 'absolute' });
            var autodarag_offset = $('.drop_card_list').offset();
            var autodarag_offset_left = autodarag_offset.left - ui.offset.left;
            var autodarag_offset_top = autodarag_offset.top - ui.offset.top;
            var cards = '' + $scope.start_ui.item.card_detail + '-' + $scope.start_ui.item.deck + '';
            $(ui.item.context).css({ 'top': '' + ui.position.top + 'px', 'left': '' + (ui.position.left) + 'px', 'position': 'absolute' });
            // throw card function call
            $scope.through_card_animate(ui.item.context, (ui.position.left + autodarag_offset_left), (ui.position.top + autodarag_offset_top), $scope.start_ui.$parent.top_index, $scope.start_ui.$index, cards);
            $scope.select_lists[0].cards = [];
            if ($scope.modelset == 'Bet') {
                $scope.sendData('DSCRD', {bet: $scope.bet_value, card: cards, secTime: $scope.remaing_time});
            } else {
                $scope.sendData('DSCRD', {card: cards, secTime: $scope.remaing_time});
            }
            // cancel sortable
            ui.item.sortable.cancel();
        } else if ($scope.user_turn_g == true && $scope.pickcrds == false) {
            $(ui.item).css({ 'left': '0px', 'top': '0px' });
             if ((0 - ui.item.context.clientHeight) >= ui.position.top) {
                $scope.pick_card_msg = true;
                $timeout(function() {
                    $scope.pick_card_msg = false;
                }, 3000);
            }
        } else {
            $(ui.item).css({ 'left': '0px', 'top': '0px' });
            if ((0 - ui.item.context.clientHeight) >= ui.position.top) {
                $scope.notturn = true;
                $timeout(function() {
                    $scope.notturn = false;
                }, 3000);
            }
        }
    }
    //over sortable stop event

    // cards sorting options set
    $scope.start_ui_placeholder;
    $scope.dragcards = false;
    $scope.up_sort = false;
    $scope.finish_box_left = 0;
    $scope.finish_box_width = 0;
    $scope.finish_box_right = 0;
    $scope.finish_box_top = 0;
    $scope.finish_box_height = 0;
    $scope.finish_box_bottom = 0;
    $scope.sortableOptions = {
        placeholder: "sort_custom",
        connectWith: ".sort_custom-container",
        containment: '.active_screen',
        animation: 800,
        revert: false,
        disabled: true,
        items: '',
        refreshPositions: true,
        change: function(container, p) {
            // right margin class add
            $('.sort_custom').removeClass('custom_margin');
            if ($scope.start_ui.$last == true) {
                $($scope.start_ui_placeholder).prev('.sort_custom').addClass('custom_margin');
            }
        },
        start: function(e, ui) {
            $scope.dragcards = false;
            $('.sort_custom').css({ "margin-right": $scope.classes_width2 + "px"});
            $scope.start_ui = ui.item.scope();
            $scope.start_ui_placeholder = ui.item;
            $scope.drag_c_img = $scope.lists[$scope.start_ui.$parent.top_index].cards[$scope.start_ui.$index].card_detail;
            $('.playing_buttom_cards').css({ 'z-index': '4' });
            $scope.ngclick_enabled = false;

        },
        update: function(e, ui) {

        },
        sort: function(e, ui) {
            // get card original position
            var p_left = Math.abs(ui.originalPosition.left - ui.position.left);
            var p_top = Math.abs(ui.originalPosition.top - ui.position.top);
            $scope.dragcards = true;
            $scope.finish_box_left = 0;
            $scope.finish_box_width = 0;
            $scope.finish_box_right = 0;
            $scope.finish_box_top = 0;
            $scope.finish_box_height = 0;
            $scope.finish_box_bottom = 0;
            $scope.discarded_popup = false;
            // selected card down validation check
            if (p_left >= 10 || p_top >= 10) {
                $('.sort_custom').removeClass('active_green highlight_cards active');
                $scope.select_gi = [];
                $scope.select_ci = [];
                $scope.select_lists[0].cards = [];
            }

            
            if ($('.finish_box').length != 0 && $scope.user_turn_g == true && $scope.pickcrds == true) {
                $scope.ui_left = $scope.pxTOvw(ui.position.left) + $scope.pxTOvw($('.playing_buttom_cards').offset().left) + $scope.pxTOvw(2);
                $scope.finish_box_left = $scope.pxTOvw($('.finish_box .card_glow_img').offset().left);
                $scope.finish_box_width = $scope.pxTOvw($('.finish_box .card_glow_img').width());
                $scope.finish_box_right = $scope.finish_box_left + $scope.finish_box_width;

                $scope.ui_top = $scope.pxTOvh(ui.position.top) - $scope.pxTOvh(ui.originalPosition.top) + $scope.pxTOvh(10);
                $scope.finish_box_top = $scope.pxTOvh($('.finish_box .card_glow_img').offset().top);
                $scope.finish_box_height = $scope.pxTOvh($('.finish_box .card_glow_img').height());
                $scope.finish_box_bottom = $scope.finish_box_top - $scope.finish_box_height;
            }

            if ($scope.ui_left >= $scope.finish_box_left && ($scope.ui_left <= $scope.finish_box_right) && ('' + $scope.ui_top + '' <= '-' + $scope.finish_box_top + '') && $scope.pxTOvh(p_top) >= 16.66) {
                $(this).parents('.card_group').addClass('fin_card_arre')
                $(this).find('.ui-sortable-helper').addClass('fin_card')
                $scope.card_glow_img_show = true;
            }else{
                $('.card_group').removeClass('fin_card_arre')
                $('.sort_custom').removeClass('fin_card')
                $scope.card_glow_img_show = false;
            }

            // open deck yellow card hide  show validation
            if ((0 - ui.item.context.clientHeight) >= ui.position.top && $scope.user_turn_g == true && $scope.pickcrds == true) {
                $scope.up_sort = true;
                $('.drop_card_list_img_top_yellow').addClass('active');
            } else {
                $scope.up_sort = false;
                $('.drop_card_list_img_top_yellow').removeClass('active');
            }
        },
        remove: function(e, ui) {
            
        },
        beforeStop: function(e, ui) {
            $scope.even = e;
            $scope.uie = ui;
            var p_top = Math.abs(ui.originalPosition.top - ui.position.top);

            if ($('.finish_box').length != 0 && $scope.user_turn_g == true && $scope.pickcrds == true) {
                $scope.ui_left = $scope.pxTOvw(ui.position.left) + $scope.pxTOvw($('.playing_buttom_cards').offset().left) + $scope.pxTOvw(2);
                $scope.finish_box_left = $scope.pxTOvw($('.finish_box .card_glow_img').offset().left);
                $scope.finish_box_width = $scope.pxTOvw($('.finish_box .card_glow_img').width());
                $scope.finish_box_right = $scope.finish_box_left + $scope.finish_box_width;

                $scope.ui_top = $scope.pxTOvh(ui.position.top) - $scope.pxTOvh(ui.originalPosition.top) + $scope.pxTOvh(10);
                $scope.finish_box_top = $scope.pxTOvh($('.finish_box .card_glow_img').offset().top);
                $scope.finish_box_height = $scope.pxTOvh($('.finish_box .card_glow_img').height());
                $scope.finish_box_bottom = $scope.finish_box_top - $scope.finish_box_height;
            }

            if ($scope.ui_left >= $scope.finish_box_left && ($scope.ui_left <= $scope.finish_box_right) && ('' + $scope.ui_top + '' <= '-' + $scope.finish_box_top + '') && $scope.pxTOvh(p_top) >= 16.66) {
                $scope.select_lists[0].cards.push({card_detail: $scope.start_ui.item.card_detail, deck: $scope.start_ui.item.deck })
                var ind = 0;
                var indexd = 0
                $scope.setting_menu_btn = true;
                $scope.settin_menu_slid = 0;
                $scope.popup[1] = 0;
                $scope.finish_popup_show = true;
                $scope.finish_slot_card = $scope.start_ui.item.card_detail + '-' + $scope.start_ui.item.deck;
                $timeout(function() {
                    $scope.updatelisted = angular.copy($scope.lists);
                    angular.forEach($scope.updatelisted, function(array, index) {
                        var ind = index;
                        angular.forEach(array.cards, function(card, i) {
                            var indexd = i;
                            if (card.card_detail == $scope.start_ui.item.card_detail && card.deck == $scope.start_ui.item.deck) {
                                $scope.updatelisted[ind].cards.splice(indexd, 1);
                                $scope.updatelisted.nullval_remove();
                                $scope.lists[ind].cards.splice(indexd, 1);
                                $scope.onecard_combine();
                            }
                        });
                    })
                }, 100);
            }else{
                $scope.drag_and_through_card($scope.even, $scope.uie);
            }

            $scope.card_glow_img_show = false;
        },
        receive: function(e, ui) {
            $scope.sortableOptions.disabled = true;

            // check card validation
            if ($scope.outtime_data.ctth != undefined && $scope.up_sort == false) {
                if ($scope.outtime_data.ctth.length == 0) {
                    $scope.onecard_combine();
                }
            } else if ($scope.up_sort == false) {
                $scope.onecard_combine();
            }
        },
        stop: function(e, ui) {
            $scope.dragcards = false;
            $('.sort_custom').removeClass('custom_margin'); 
            $('.playing_buttom_cards').css({ 'z-index': '4' });
            $scope.up_sort = false;
        },
    };
    // over cards sorting options set
    // preload image function
    $scope.imageLocations = [
        ("./img/tbl_cyan.png"),
        ("./img/tbl_red.png"),

        ("./img/profile/statistics.png"),
        ("./img/profile/btn_camera.png"),
        ("./img/profile/profile_popup_bg.png"),


        ("./img/user_profile0.png"),
        ("./img/user_profile1.png"),
        ("./img/user_profile2.png"),
        ("./img/user_profile3.png"),
        ("./img/user_profile4.png"),
        ("./img/user_profile5.png"),
        ("./img/user_profile_dropped.png"),
        ("./img/popup_bg.png"),
        ("./img/ava_bal_info_bg.png"),
        ("./img/your_score_bg.png"),


        ("./img/card/c-1.png"),
        ("./img/card/c-2.png"),
        ("./img/card/c-3.png"),
        ("./img/card/c-4.png"),
        ("./img/card/c-5.png"),
        ("./img/card/c-6.png"),
        ("./img/card/c-7.png"),
        ("./img/card/c-8.png"),
        ("./img/card/c-9.png"),
        ("./img/card/c-10.png"),
        ("./img/card/c-11.png"),
        ("./img/card/c-12.png"),
        ("./img/card/c-13.png"),
        ("./img/card/k-1.png"),
        ("./img/card/k-2.png"),
        ("./img/card/k-3.png"),
        ("./img/card/k-4.png"),
        ("./img/card/k-5.png"),
        ("./img/card/k-6.png"),
        ("./img/card/k-7.png"),
        ("./img/card/k-8.png"),
        ("./img/card/k-9.png"),
        ("./img/card/k-10.png"),
        ("./img/card/k-11.png"),
        ("./img/card/k-12.png"),
        ("./img/card/k-13.png"),
        ("./img/card/f-1.png"),
        ("./img/card/f-2.png"),
        ("./img/card/f-3.png"),
        ("./img/card/f-4.png"),
        ("./img/card/f-5.png"),
        ("./img/card/f-6.png"),
        ("./img/card/f-7.png"),
        ("./img/card/f-8.png"),
        ("./img/card/f-9.png"),
        ("./img/card/f-10.png"),
        ("./img/card/f-11.png"),
        ("./img/card/f-12.png"),
        ("./img/card/f-13.png"),
        ("./img/card/l-1.png"),
        ("./img/card/l-2.png"),
        ("./img/card/l-3.png"),
        ("./img/card/l-4.png"),
        ("./img/card/l-5.png"),
        ("./img/card/l-6.png"),
        ("./img/card/l-7.png"),
        ("./img/card/l-8.png"),
        ("./img/card/l-9.png"),
        ("./img/card/l-10.png"),
        ("./img/card/l-11.png"),
        ("./img/card/l-12.png"),
        ("./img/card/l-13.png"),
        ("./img/card/j-1.png"),
        ("./img/card/j-2.png"),
        ("./img/card/j-3.png"),
        ("./img/card/j-4.png"),
    ];
    $scope.imageLocations2 = [
        ("./img/splash/splash_bg.png")
    ];

    
            
    var stop = $interval(function() {
        // console.log('========>2222',tempObj);
        if(tempObj != undefined && tempObj != ''){
            $scope.loginDetails = tempObj;
            // console.log('========>1111',$scope.loginDetails)
            
            if($scope.loginDetails.DeviceId != '' && $scope.loginDetails.DeviceId != undefined){
                $interval.cancel(stop);
                preloader.preloadImages($scope.imageLocations2).then(
                    function handleResolve(imageLocations) {
                        $timeout(function() {
                            $scope.screen[3] = 0;
                            $scope.screen[4] = 1;
                            $scope.data = {
                                ult: $scope.loginDetails.ult,
                                det: 'html',
                                nwt: 'wifi',
                                DeviceId: $scope.loginDetails.DeviceId
                            } // send signup  event
                            $scope.sendData = function(event, data) {
                                $scope.obj = { en: event, data: data };
                                socket.emit('reqw', Encryption($scope.obj)); // Encryption socket responce and send
                                // console.log(">>>> SEND",$scope.obj);
                            }
                            $scope.sendData('SP', $scope.data);
                            $scope.sendData('GGC', $scope.data);
                            preloader.preloadImages($scope.imageLocations).then(function handleResolve(imageLocations) {
                                $timeout(function() {
                                    $scope.screen[1] = 1;
                                    var counterloading = 0;
                                    var par_loding = $interval(function() {
                                        counterloading = counterloading + 20;
                                        // parcentage_loding
                                        $scope.parcentage_loding = $scope.loading_progress + counterloading;
                                            if ($scope.parcentage_loding == 200 && $scope.user_detail != '' && $scope.user_detail != undefined) {
                                                $interval.cancel(par_loding);
                                                // $scope.getAndroidVersion();
                                                $scope.getiosVersion();
                                                $scope.Notification_sound();
                                                var i = 1;

                                                $scope.screen[3] = 0;
                                                $scope.screen[4] = 0;
                                                $scope.screen[1] = 1;
                                            }
                                            if ($scope.parcentage_loding == 200 && ($scope.user_detail == '' || $scope.user_detail == undefined)) {
                                                $interval.cancel(par_loding);
                                            }
                                    },200);
                                }, 1500);
                            },
                            function handleReject(imageLocation) {
                                console.error("Image Failed", imageLocation);
                                console.info("Preload Failure");
                            },
                            function handleNotify(event) {
                                $scope.parcentage_loding = Math.round(event.percent);
                            });
                        }, 1000);
                    },
                    function handleReject(imageLocation) {
                        console.error("Image Failed", imageLocation);
                        console.info("Preload Failure");
                    },
                    function handleNotify(event) {
                        $scope.loading_progress = event.percent;
                    }
                );
            }
        }
    }, 200);
    // preload image function over

    // rejoin time table finish declare validation
    $scope.jointst = function(join, tst) {
        $interval.cancel($scope.autofinish);
        $scope.dropd_chips = join.pv;
        $scope.dropd_chips_first = join.pv;
        $scope.sdc_cards = true;
        if (join.pv != 0) {
            $scope.dropd_chips_d = true;
        }
        if (tst === 'Finished') {
            angular.forEach(join.pi, function(pi_data, pi_data_key) {
                // finish timer set
                $scope.popup = [0, 0];
                $scope.declarebtn = true;

                $timeout(function() {
                    // console.log(pi_data)
                    $scope.setting_menu_btn = true;
                    $scope.settin_menu_slid = 0;
                    $scope.fns_user_si = join.fnsPlayer;
                    if(pi_data.s != 'watch' && pi_data.s != 'drop'){
                        if (pi_data.si == $scope.set_index) {
                            $scope.setting_menu_btn = true;
                            var interval_fns = 30;
                            var totla_px_fns = 88;
                            var timer_fns = 88;
                            var timer_remain = totla_px_fns - (($scope.config.FNS - join.Timer) * (totla_px_fns / $scope.config.FNS));
                            var circle_fns = document.getElementsByClassName('turn_timer_' + pi_data.si)[0];
                            var circle_top_fns = document.getElementsByClassName('patern_2')[0];
                            var angle_increment_fns = (totla_px_fns / ((parseInt(1000 / interval_fns) * interval_fns) * join.Timer)) * interval_fns;
                            var angle_fns = timer_fns;

                            $scope.turn_timer_fns = $interval(function() {
                                circle_fns.setAttribute("stroke-dasharray", (totla_px_fns * (timer_remain / totla_px_fns * 100) / 100) + ",100%");
                                circle_fns.setAttribute("stroke", $scope.getColorForPercentage(parseInt(timer_remain / totla_px_fns * 100) / 100));
                                if (parseInt(timer_remain / totla_px_fns * 100) <= 0) {
                                    $interval.cancel($scope.turn_timer_fns);
                                    $('.ring_circle2').attr("stroke-dasharray", "0,100%");
                                    $('.ring_circle2').attr("stroke", "rgba(255,29,21,0)");
                                    circle_fns.setAttribute("stroke-dasharray", "0,100%");
                                    $scope.declare_btn();
                                }
                                timer_remain = timer_remain - angle_increment_fns;
                            }, interval_fns);
                            $scope.setting_menu_btn = true;
                            $scope.settin_menu_slid = 0;
                            $scope.declarebtn = true;
                        }
                    }
                    // set finish timer message
                    if ($scope.set_index != 5) {
                        
                        $scope.popup[1] = 0;
                        if (join.pi[$scope.set_index].s == 'declare') {
                            // "waiting for all the players to declare"
                            console.log('rejoin declare');
                            $scope.disabled_drop = true;
                            // $scope.fin_msg = 'Waiting for all the players to finish';
                            // $scope.fin_msg2 = "finished";

                        } else if (join.pi[$scope.set_index].s == 'finish') {
                            // "you have finished the game"
                            $scope.setting_menu_btn = true;
                            console.log('rejoin finsih');
                            $scope.pickcrds = false;
                            // $scope.fin_msg = 'You have declared the game';
                            // "please arrange your cards in sets and sequences"
                            // $scope.fin_msg2 = 'Declare';

                        } else {
                            // is declaring
                            console.log('rejoin finsih other');
                            // $scope.fin_msg = join.pi[join.fnsPlayer].un + ' is declaring';
                            // "please arrange your cards in sets and sequences"
                            // $scope.fin_msg2 = 'Please arrange your cards in sets and sequences and tap Finish';
                        }
                        if (pi_data.s == 'playing') {
                            
                        }
                        if (join.pi[$scope.set_index].s == '' || join.pi[$scope.set_index].s == 'drop') {
                            // "waiting for all the players to declare"
                            console.log('rejoin drop');
                            // $scope.fin_msg = 'Waiting for all the players to finish';
                            // $scope.fin_msg2 = "";
                            $scope.declarebtn = false;
                        }
                        if (join.pi[$scope.set_index].s == 'watch') {
                            // " is declaring"
                            console.log('rejoin watch ');

                            // $scope.fin_msg = join.pi[join.fnsPlayer].un + ' is declaring';
                            // "waiting for all the players to declare"
                            // $scope.fin_msg2 = 'Waiting for all the players to finish';
                        }
                        if (join.pi[$scope.set_index].s == '' || join.pi[$scope.set_index].s == 'watch') {
                            $scope.setting_menu_btn = false;
                        }
                    } else {
                        // "waiting for all the players to declare"
                        // $scope.fin_msg = 'Waiting for all the players to finish';
                        // $scope.fin_msg2 = "";
                        $scope.declarebtn = false;
                    }
                }, 500);

                // player profile label text set 
                if (pi_data.s == 'drop') {
                    $scope.declaret[pi_data.si] = 2;
                } else if (pi_data.s == 'declare') {
                    $scope.declaret[pi_data.si] = 3;
                    if (pi_data.si == $scope.set_index) {
                        $scope.declarebtn = false;
                    }
                } else if (pi_data.s == 'finish') {

                }
            });     
        }
    }
    //over rejoin time table finish declare validation

    // set key frame animation
    $.keyframe.define([{
        name: 'delstartcount',
        '0%': {
            'opacity': '0',
            'top': '0px',
            'transform': 'scale(0)'
        },
        '30%': {
            'opacity': '1',
            'top': '0px',
            'transform': 'scale(2)'
        },
        '50%': {
            'top': '0px',
            'transform': 'scale(2)'
        },
        '100%': {
            'transform': 'scale(1)',
            'top': '' + $scope.vhTOpx(12.2) + 'px',
            'opacity': '1',
        }
    }, {
        name: 'delarpointupdate',
        '0%': {
            'top': '4vh',
            'opacity': '0',
        },
        '25%': {
            'top': '0vh',
            'opacity': '1',
        },
        '75%': {
            'top': '0vh',
            'opacity': '1',
        },
        '100%': {
            'top': '-4vh',
            'opacity': '0',
        }
    }]);

    $scope.m_counter = function(timer, flag) {
        $scope.m_c_flag = flag;
        if (flag == 'end') {
            timer = timer - $scope.user_detail.StartAfter;
        }
        $scope.stopper;
        $scope.mmn = parseInt((timer) * 1000);
        $scope.getDay = Math.floor($scope.mmn / (1000 * 60 * 60 * 24));
        $scope.getHours = Math.floor(($scope.mmn % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
        $scope.getMinutes = Math.floor(($scope.mmn % (1000 * 60 * 60)) / (1000 * 60));
        $scope.getSeconds = Math.floor(($scope.mmn % (1000 * 60)) / 1000);
        $timeout(function() {
            $scope.progressCountdown();
        }, 1000);
    }

    // -------------show hide pass------------------
    $scope.showhide = function() {
        $scope.typePassword = !$scope.typePassword;
    };
    // ----show hide pass-------------------
    // -----------edit profile-----------
    $scope.edit_profile = function(data) {
        $scope.edit_profile_value = true;
        $(".edit_text_email").addClass('active')
        $(".edit_text_phno").addClass('active')
        $(".edit_text_password").addClass('active')
        $(".edit_text_password").attr('type', 'text');
        $(".edit_text_name").addClass('active')
    }
    $scope.save_profile = function(data) {
        $scope.edit_profile_value = false;
        $(".edit_text_email").removeClass('active')
        $(".edit_text_phno").removeClass('active')
        $(".edit_text_password").removeClass('active')
        $(".edit_text_password").attr('type', 'password');
        $(".edit_text_name").removeClass('active')
    }
    // -----------edit profile-----------



    $scope.progressCountdown = function() {
        document.getElementById("mmn1").innerHTML = $scope.getHours + "H : " + $scope.getMinutes + "M : " + $scope.getSeconds + "S";
        document.getElementById("mmn2").innerHTML = $scope.getHours + "H : " + $scope.getMinutes + "M : " + $scope.getSeconds + "S";
        $scope.stopper = $timeout($scope.progressCountdown, 1000);
        if ($scope.getSeconds == 0 && $scope.getMinutes == 0 && $scope.getHours == 0 && $scope.getDay > 0) {
            $scope.getSeconds = 60;
            $scope.getMinutes = 59;
            $scope.getHours = 24;
            $scope.getDay -= 1;
        }
        if ($scope.getSeconds == 0 && $scope.getMinutes == 0 && $scope.getHours > 0) {
            $scope.getSeconds = 60;
            $scope.getMinutes = 59;
            $scope.getHours -= 1;
        }
        if ($scope.getSeconds == 0 && $scope.getMinutes > 0) {
            $scope.getSeconds = 60;
            $scope.getMinutes -= 1;
        }
        if ($scope.getSeconds > 0) {
            $scope.getSeconds -= 1;
        }
        if ($scope.getSeconds == 0 && $scope.getMinutes == 0 && $scope.getHours == 0 && $scope.getDay == 0) {
            if ($scope.m_c_flag == 'start' || $scope.m_c_flag == 'false') {
                $scope.m_counter($scope.user_detail.RemoveAfter, 'end')
            } else {
                $timeout(function() {
                    $scope.m_c_flag = '';
                    window.location.reload(true);
                    // window.parent.location = '' + $scope.config.BU + 'login';
                }, 10);
            }
            $timeout.cancel($scope.stopper);
        }
    }    

    // game table visible or hidden event
    $scope.handleVisibilityChange = function() {
        // $scope.getiosVersion_data_abc = '0000';
        if (document.visibilityState == "visible") {
            $scope.sound_onPause = false;
            if ($scope.getiosVersion_data == '[12.0.1]') {
                // $window.socket.connect();
                // $scope.getiosVersion_data_abc = 'Done';
            }
        }else{
            $scope.sound_onPause = true;
            // $scope.getiosVersion_data_abc = 'NOT OK';
        }
    };
    document.addEventListener('visibilitychange', $scope.handleVisibilityChange, false);
    //over game table visible or hidden event


    $scope.ButtonClick_sound = function(){
        if($scope.sound_onPause == false && $scope.sound_on_off == 1){
            VolumeSample.toggle('ButtonClick_audio');
        }
    }
    $scope.PopupOpen_sound = function() {
        if($scope.sound_onPause == false && $scope.sound_on_off == 1){
            VolumeSample.toggle('PopupOpen_audio');
        }
    }
    $scope.Users_Turn_sound = function() {
        if($scope.sound_onPause == false && $scope.sound_on_off == 1){
            VolumeSample.toggle('Users_Turn_audio');
        }
    }
    $scope.AnotherUserTurn_sound = function() {
        if($scope.sound_onPause == false && $scope.sound_on_off == 1){
            VolumeSample.toggle('AnotherUserTurn_audio');
        }
    }
    $scope.Drop_sound = function() {
        if($scope.sound_onPause == false && $scope.sound_on_off == 1){
            VolumeSample.toggle('Drop_audio');
        }
    }
    $scope.Notification_sound = function() {
        if($scope.sound_onPause == false && $scope.sound_on_off == 1){
            VolumeSample.toggle('Notification_audio');

        }
    }
    $scope.Winner_sound = function() {
        if($scope.sound_onPause == false && $scope.sound_on_off == 1){
            VolumeSample.toggle('Winner_audio');
        }
    }
    $scope.DealPoolRummyWinner_sound = function() {
        if($scope.sound_onPause == false && $scope.sound_on_off == 1){
            VolumeSample.toggle('DealPoolRummyWinner_audio');
        }
    }
    $scope.Declare_sound = function() {
        if($scope.sound_onPause == false && $scope.sound_on_off == 1){
            VolumeSample.toggle('Declare_audio');
        }
    }
    $scope.Card_Distribution_sound = function() {
        if($scope.sound_onPause == false && $scope.sound_on_off == 1){
            VolumeSample.toggle('Card_Distribution_audio');
        }
    }
    $scope.Card_Pick_sound = function() {
        if($scope.sound_onPause == false && $scope.sound_on_off == 1){
            VolumeSample.toggle('Card_Pick_audio');
        }
    }
    $scope.Card_Discard_sound = function() {
        if($scope.sound_onPause == false && $scope.sound_on_off == 1){
            VolumeSample.toggle('Card_Discard_audio');
        }
    }
    $scope.ClockTicking5SecsLeft_sound = function() {
        if($scope.sound_onPause == false && $scope.sound_on_off == 1){
            VolumeSample.toggle('ClockTicking5SecsLeft_audio');
        }
    }
    $scope.CoinDepositonWinning_sound = function() {
        if($scope.sound_onPause == false && $scope.sound_on_off == 1){
            VolumeSample.toggle('CoinDepositonWinning_audio');
        }
    }
    $scope.CoinsCollectInDealORPool_sound = function() {
        if($scope.sound_onPause == false && $scope.sound_on_off == 1){
            VolumeSample.toggle('CoinsCollectInDealORPool_audio');
        }
    }
});

function getShortCurrency(d_bonus) {
    return (Number(d_bonus) > 9999999) ? (d_bonus / 10000000) + 'Cr' : (Number(d_bonus) > 99999) ? (d_bonus / 100000) + 'L' : d_bonus;
}


// add web audio code
function BufferLoader(context, urlList, callback) {
    this.context = context;
    this.urlList = urlList;
    this.onload = callback;
    this.bufferList = new Array();
    this.loadCount = 0;
}

BufferLoader.prototype.loadBuffer = function(url, index) {
    // Load buffer asynchronously
    var request = new XMLHttpRequest();
    request.open("GET", url, true);
    request.responseType = "arraybuffer";

    var loader = this;

    request.onload = function() {
        // Asynchronously decode the audio file data in request.response
        loader.context.decodeAudioData(
        request.response,
        function(buffer) {
            if (!buffer) {
                alert('error decoding file data: ' + url);
                return;
            }
            loader.bufferList[index] = buffer;
            if (++loader.loadCount == loader.urlList.length){
                loader.onload(loader.bufferList);
            }
        },
        function(error) {
            console.error('decodeAudioData error', error);
        }
    );
    }
    request.onerror = function() {
        alert('BufferLoader: XHR error');
    }
    request.send();
}

BufferLoader.prototype.load = function() {
    for (var i = 0; i < this.urlList.length; ++i)
    this.loadBuffer(this.urlList[i], i);
}

var VolumeSample = {
};

// Gain node needs to be mutated by volume control.
VolumeSample.gainNode = null;
VolumeSample.play = function(sound_type) {
    if (!context.createGain){
        context.createGain = context.createGainNode;
    }
    this.gainNode = context.createGain();
    var source = context.createBufferSource();
    if (sound_type == 'ButtonClick_audio') {
        source.buffer = BUFFERS.ButtonClick;
    }
    if (sound_type == 'PopupOpen_audio') {
        source.buffer = BUFFERS.PopupOpen;
    }
    if (sound_type == 'Users_Turn_audio') {
        source.buffer = BUFFERS.Users_Turn;
    }
    if (sound_type == 'AnotherUserTurn_audio') {
        source.buffer = BUFFERS.AnotherUserTurn;
    }
    if (sound_type == 'Drop_audio') {
        source.buffer = BUFFERS.Drop;
    }
    if (sound_type == 'Notification_audio') {
        source.buffer = BUFFERS.Notification;
    }
    if (sound_type == 'Winner_audio') {
        source.buffer = BUFFERS.Winner;
    }
    if (sound_type == 'DealPoolRummyWinner_audio') {
        source.buffer = BUFFERS.DealPoolRummyWinner;
    }
    if (sound_type == 'Declare_audio') {
        source.buffer = BUFFERS.Declare;
    }
    if (sound_type == 'Card_Distribution_audio') {
        source.buffer = BUFFERS.Card_Distribution;
    }
    if (sound_type == 'Card_Pick_audio') {
        source.buffer = BUFFERS.Card_Pick;
    }
    if (sound_type == 'Card_Discard_audio') {
        source.buffer = BUFFERS.Card_Discard;
    }
    if (sound_type == 'ClockTicking5SecsLeft_audio') {
        source.buffer = BUFFERS.ClockTicking5SecsLeft;
    }
    if (sound_type == 'CoinDepositonWinning_audio') {
        source.buffer = BUFFERS.CoinDepositonWinning;
    }
    if (sound_type == 'CoinsCollectInDealORPool_audio') {
        source.buffer = BUFFERS.CoinsCollectInDealORPool;
    }

    // Connect source to a gain node
    source.connect(this.gainNode);
    // Connect gain node to destination
    this.gainNode.connect(context.destination);
    // Start playback in a loop
    source.loop = false;
    if (!source.start){
        source.start = source.noteOn;
    }
    source.start(0);
    this.source = source;
};

// VolumeSample.stop = function() {
//     if (!this.source.stop){
//         this.source.stop = source.noteOff;
//         this.source.stop(0);
//     }else{
        
//     }
// };

VolumeSample.toggle = function(sound_type) {
    this.play(sound_type);
};

// Keep track of all loaded buffers.
var BUFFERS = {};
// Page-wide audio context.
var context = null;

// An object to track the buffers to load {name: path}
var BUFFERS_TO_LOAD = {
    ButtonClick: '../HTML5/audio/ButtonClick.mp3',
    PopupOpen: '../HTML5/audio/PopupOpen.mp3',
    Users_Turn: '../HTML5/audio/Users_Turn.mp3',
    AnotherUserTurn: '../HTML5/audio/AnotherUserTurn.mp3',
    Drop: '../HTML5/audio/Drop.mp3',
    Notification: '../HTML5/audio/Notification.mp3',
    Winner: '../HTML5/audio/Winner.mp3',
    DealPoolRummyWinner: '../HTML5/audio/DealPoolRummyWinner.mp3',
    Declare: '../HTML5/audio/Declare.mp3',
    Card_Distribution: '../HTML5/audio/Card_Distribution.mp3',
    Card_Pick: '../HTML5/audio/Card_Pick.mp3',
    Card_Discard: '../HTML5/audio/Card_Discard.mp3',
    ClockTicking5SecsLeft: '../HTML5/audio/ClockTicking5SecsLeft.mp3',
    CoinDepositonWinning: '../HTML5/audio/CoinDepositonWinning.mp3',
    CoinsCollectInDealORPool: '../HTML5/audio/CoinsCollectInDealORPool.mp3',
};

// Loads all sound samples into the buffers object.
function loadBuffers() {
    // Array-ify
    var names = [];
    var paths = [];
    for (var name in BUFFERS_TO_LOAD) {
        var path = BUFFERS_TO_LOAD[name];
        names.push(name);
        paths.push(path);
    }
    bufferLoader = new BufferLoader(context, paths, function(bufferList) {
        for (var i = 0; i < bufferList.length; i++) {
            var buffer = bufferList[i];
            var name = names[i];
            BUFFERS[name] = buffer;
        }
    });
    bufferLoader.load();
}

document.addEventListener('DOMContentLoaded', function() {
    try {
        // Fix up prefixing
        window.AudioContext = window.AudioContext || window.webkitAudioContext;
        context = new AudioContext();
        var fixAudioContext = function (e) {
            if (window.audioContext) {
                // Create empty buffer
                var buffer = window.audioContext.createBuffer(1, 1, 22050);
                var source = window.audioContext.createBufferSource();
                source.buffer = buffer;
                // Connect to output (speakers)
                source.connect(window.audioContext.destination);
                // Play sound
                if (source.start) {
                    source.start(0);
                } else if (source.play) {
                    source.play(0);
                } else if (source.noteOn) {
                    source.noteOn(0);
                }
            }
            // Remove events
            document.removeEventListener('touchstart', fixAudioContext);
            document.removeEventListener('touchend', fixAudioContext);
        };
        // iOS 6-8
        document.addEventListener('touchstart', fixAudioContext);
        // iOS 9
        document.addEventListener('touchend', fixAudioContext);
    }
    catch(e) {
        alert("Web Audio API is not supported in this browser");
    }
    loadBuffers();
});

// otp varification
function getCodeBoxElement(index) {
    return document.getElementById('codeBox' + index);
  }
  function onKeyUpEvent(index, event) {
    const eventCode = event.which || event.keyCode;
    if (getCodeBoxElement(index).value.length === 1) {
      if (index !== 6) {
        getCodeBoxElement(index+ 1).focus();
      } else {
        getCodeBoxElement(index).blur();
        // Submit code
        console.log('submit code ');
      }
    }
    if (eventCode === 8 && index !== 1) {
      getCodeBoxElement(index - 1).focus();
    }
  }
  function onFocusEvent(index) {
    for (item = 1; item < index; item++) {
      const currentElement = getCodeBoxElement(item);
      if (!currentElement.value) {
          currentElement.focus();
          break;
      }
    }
  }


