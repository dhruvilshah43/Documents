var encKey = "DFK8s58uWFCF4Vs8NCrgTxfMLwjL9WUy";

Encryption = data => {
  try {
    /* +-------------------------------------------------------------------+
    desc: this function encrypt the data.
    i/p: plain data
    o/p: encrypted data
    +-------------------------------------------------------------------+ */
    // Encrypt
    var ciphertext = CryptoJS.Rabbit.encrypt(
      JSON.stringify(data),
      encKey
    ).toString();
    return ciphertext;
  } catch (e) {}
};
Decryption = data => {
  try {
    /* +-------------------------------------------------------------------+
        desc: this function decrypt the data.
        i/p: encrypted data
        o/p: decrypted data
    +-------------------------------------------------------------------+ */
    // Decrypt
    var bytes = CryptoJS.Rabbit.decrypt(data, encKey);
    var decryptedData = JSON.parse(bytes.toString(CryptoJS.enc.Utf8));
    console.log(decryptedData);

    return decryptedData;
  } catch (e) {}
};
