var mongod = require('mongodb');
config = module.exports = require("./config.json"); 
rq = module.exports = require('request');
 
 
 
c = module.exports = function(data){ console.log(data) };
commonClass = module.exports = require('./classes/common.class.js');
cdClass = module.exports = require('./classes/commonData.class.js');
trackClass = module.exports = require('./classes/track.class.js');
FB  = module.exports = require('fb');
ses = module.exports = require('nodemailer-ses-transport');
nodemailer = module.exports = require('nodemailer');

var MongoClient = mongod.MongoClient;
MongoID = module.exports = mongod.ObjectID; //reporting conversion class instavle to global for convert string to objectt
MongoClient.connect('mongodb://'+config.DB_USERNAME+':'+config.DB_PASSWORD+'@'+config.DB_HOST+':'+config.DB_PORT+'/'+config.DB_NAME,   //live
// MongoClient.connect('mongodb://'+config.DB_HOST+':'+config.DB_PORT+'/'+config.DB_NAME,  //local
function(err, dClient){  
  	if(err){

		console.log(err);
  	} 
  	else
  	{
		db = module.exports = dClient.db(config.DB_NAME);
		console.log("Cron run >> "+new Date());
	
		// weeklyResult();
		// userDecrementTracking();
		realTimeUserDecrementTracking();
		//dailyFlashNotification();
		manageTracking();
		//RepairOnlineUser();
	    dailyChipsDetail();
		// dailyCronjobDetail();
		setTimeout(function () {
			process.kill();
		}, 100000);		
  	}
});
function userDecrementTracking(){  //notfiy if user suddenly decremented
	var sDate = new Date(commonClass.AddTime(-260100));    //time two days before with 900 sec less for accuracy
 	var eDate = new Date(commonClass.AddTime(-85500));     //time one daya before with 900 sec more for accuracy
 	console.log('sDate: ',sDate,' \neDate: ',eDate);

 	db.collection('track_au').aggregate([{$match:{cd:{$gte:sDate,$lte:eDate},type:'day'}},{$group:{_id:null,Android:{$sum:'$android'},Ios:{$sum:'$ios'},Flash:{$sum:'$flash'}}}]).toArray(function(err1,tDaysData){
 		console.log('userDecrementTracking-------->>>>tDaysData: ',tDaysData);

 		var dr = new Date(new Date().getFullYear(), new Date().getMonth(), new Date().getDate(), 0, 0, 0);
		var dString = dr.getFullYear()+"-"+(dr.getMonth()+1)+"-"+dr.getDate();
 		
 		console.log('dString: ',dString);
 		db.collection('track_au').findOne({dString:dString},function(err2,tData){
 			console.log('tData: ',tData);
 			if(tData){

	 			var twoDaysAverage = (tDaysData[0].Android + tDaysData[0].Ios + tDaysData[0].Flash)/2;
	 			var todaysTotal = tData.android + tData.ios + tData.flash;

	 			console.log('twoDaysAverage: ',twoDaysAverage,' todaysTotal: ',todaysTotal);
	 			if(twoDaysAverage > 0){
	 				console.log('twoDaysAverage-------->>>: ',Math.round(twoDaysAverage));
	 				if(todaysTotal/twoDaysAverage < 0.5){
	 					var nd = new Date();
	 					var iDate = nd.getDate()+'/'+(nd.getMonth()+1)+'/'+ nd.getFullYear();
							 
						var html = '<!DOCTYPE html> <html> <body><h2>Large user decrement On Date : '+iDate+'</h2> <table border="1">';
						html += '<tr><td>Current Total</td><td>'+todaysTotal+'</td></tr>';
						html += '<tr><td>Average Users</td><td>'+twoDaysAverage+'</td></tr>';
						html += '</table> </body> </html>';

						// temperory removed

						// var transport = nodemailer.createTransport(ses({
						// 	   AWSAccessKeyID: "AKIAIVXBXBLLRYUL4PSA",
						// 	   AWSSecretKey: "RFZIJaf+Fdpevx2tjoNkDEN6T3kKHbkOS7AThC9UAKIAIVXBXBLLRYUL4PS"
						// }));
						// 	  // Message object
						// transport.sendMail({
						// 	from : 'Indian Rummy 2 Alert <noreply@artoonentertainment.com>',
						// 	to : 'akshay.dodiya@artoon.in',
						// 	subject : 'Indian Rummy 2  User Decrement ['+iDate+']',
						// 	html: html
						// },function(error){ console.log(error) });

						
						
	 					console.log('mail sent')
	 				}
	 				else{
	 					console.log('mail not sent');
	 				}
	 			}
 			}

 		});
 	});
}
function realTimeUserDecrementTracking(){

	console.log('realTimeUserDecrementTracking-------->>>>>>');
	var sDate = commonClass.GetFormatedDate(new Date(commonClass.AddTime(-172800)));    
 	var eDate = commonClass.GetFormatedDate(new Date(commonClass.AddTime(-86400)));      
 	console.log('sDate: ',sDate,' \neDate: ',eDate);

 	db.collection('dhu').aggregate([{$match:{$or:[{day:sDate},{day:eDate}]}},{$group:{_id:null,total:{$sum:'$players'}}}]).toArray(function(err,twoDaysData){
 		console.log('twoDaysData: ',twoDaysData);

 		if(twoDaysData && twoDaysData.length > 0 && twoDaysData[0].total){

 			var today = commonClass.GetFormatedDate(new Date());
 			console.log('today: ',today);
 			db.collection('dhu').findOne({day:today},function(err1,crntData){
 				if(crntData){

 					console.log('crntData: ',crntData.players);

 					var todayData = crntData.players;
 					var avgData = twoDaysData[0].total;

 					var ratio = todayData/avgData;
 					console.log('todayData: ',todayData,'avgData: ',avgData,' ratio: ',ratio);
 					if(ratio < 0.5){

 						var nd = new Date();
	 					var iDate = nd.getDate()+'/'+(nd.getMonth()+1)+'/'+ nd.getFullYear();
							 
						var html = '<!DOCTYPE html> <html> <body><h2>Large realtime active user decrement On Date : '+iDate+'</h2> <table border="1">';
						html += '<tr><td>Current Total</td><td>'+todayData+'</td></tr>';
						html += '<tr><td>Average Users</td><td>'+avgData+'</td></tr>';
						html += '</table> </body> </html>';

 						//var transport = nodemailer.createTransport(ses({
						// 	   AWSAccessKeyID: "AKIAIVXBXBLLRYUL4PSA",
						// 	   AWSSecretKey: "RFZIJaf+Fdpevx2tjoNkDEN6T3kKHbkOS7AThC9UAKIAIVXBXBLLRYUL4PS"
						// }));
						// 	  // Message object
						// transport.sendMail({
						// 	from : 'Indian Rummy 2 Alert <noreply@artoonentertainment.com>',
						// 	to : 'akshay.dodiya@artoon.in',
						// 	subject : 'Indian Rummy 2  RealTime active User Decrement ['+iDate+']',
						// 	html: html
						// },function(error){ console.log(error) });

 						console.log('mail sent');
 					}
 					else{
 						console.log('mail not sent');
 					}
 				}
 			});
 		}
 	});
}
function dailyCronjobDetail(){
	
	var nd = new Date();
	var st = new Date(nd.getFullYear(), nd.getMonth(), nd.getDate(), 0,0,0);
	var end = new Date(nd.getFullYear(), nd.getMonth(), nd.getDate(), 23,59,59);
	
	//getting userlogintype wise and devicetype wise data.
	db.collection('game_users').aggregate({ $match : { cd : { $gte : st, $lte : end } }},
	{ $group : { _id : { ult : "$ult", det : '$det' }, ct: { $sum: 1 } } },
	{$limit : 10}, 
	function(err,samp){
		 
		  var obj = { FBCount : 0, GuestCount: 0, fStr : '', gStr : '', fTitle : '', gTitle : '' };
		  for(x in samp)
		  {
			  if(samp[x]._id.ult == 'FB')
			  {
				  obj.FBCount = obj.FBCount + samp[x].ct;
				  obj.fStr+= (obj.fStr != '')? ' + '+samp[x].ct : samp[x].ct;
				  obj.fTitle+= (obj.fTitle != '')? '-'+samp[x]._id.det : samp[x]._id.det;
			  }
			  else
			  {
				  obj.GuestCount = obj.GuestCount + samp[x].ct;
				  obj.gStr+= (obj.gStr != '')? ' + '+samp[x].ct : samp[x].ct;
				  obj.gTitle+= (obj.gTitle != '')? '-'+samp[x]._id.det : samp[x]._id.det;
			  }
		  }
		
		//getting total user count whom register today.
		db.collection('game_users').find( { cd : { $gte : st, $lte : end },'flags._ir':0 }).count(function(err, totReg){ 
			obj.totalUser = totReg;
			
			//getting users whom not played the game
			db.collection('game_users').find( { cd : { $gte : st, $lte : end }, "counters.thp" : 0 }).count(function(err, np){ 
				obj.notPlayed = np;
				
				//couting feedback for yesterday that we received.
				db.collection('feedback').find( { CreatedOn : { $gte : st, $lte : end }}).count(function(err, febCt){ 
					obj.feedbackCount = febCt;
					
					//counting yesterday revenue.
					db.collection('payment_details').aggregate({ $match : { CreatedOn : { $gte : st, $lte : end }, PaymentStatus :'completed' }},
					{ $group : { _id : null , ct: { $sum: "$Price" } } },
					{$limit : 1},function(err,samp2){
						
						
						db.collection('game_users').aggregate({ $group : { _id : null , total: { $sum: "$Chips" } } },
						{$limit : 1},function(err,samp3){
						 
						 var dr = new Date();
						 var dString = dr.getFullYear()+"-"+(dr.getMonth()+1)+"-"+dr.getDate();
						 var mString = dr.getFullYear()+"-"+(dr.getMonth()+1);
						 db.collection('track_au').find({$or : [{dString : dString},{mString : mString}]},{android : 1, ios : 1, flash : 1, html: 1,type : 1}).
						 limit(2).sort({type : 1}).toArray(function(err, daumau){ 
						 	 
							 if(daumau.length == 2){

							 	obj.dauAndroid = daumau[0].android;
								obj.dauIos = daumau[0].ios;
								obj.dauFlash = daumau[0].flash;
								obj.dauHtml = daumau[0].html;
								obj.dauTotal = daumau[0].flash + daumau[0].android + daumau[0].ios + daumau[0].html;
								obj.mauAndroid = daumau[1].android;
								obj.mauIos = daumau[1].ios;
								obj.mauFlash = daumau[1].flash;
								obj.mauHtml = daumau[1].html;
								obj.mauTotal = daumau[1].flash + daumau[1].android + daumau[1].ios + daumau[1].html;
							 }
								
							 obj.revenue = (samp2.length > 0 ) ? samp2[0].ct.toFixed(2) : 0;
							 obj.totalChips = (samp3.length > 0) ? samp3[0].total : 0;
							 var iDate = nd.getDate()+'/'+(nd.getMonth()+1)+'/'+ nd.getFullYear();
							 
							 var template = '<!DOCTYPE html> '+
							 ' <html> <body><h2>Report On Date : '+iDate+'</h2> '+
							 '<table border="1">'+
							 '<tr> <td>Total Chips</td> <td>[[totalChips]]</td> </tr>'+
							 '<tr> <td>Total User</td> <td>[[totalUser]]</td> </tr>'+
							 '<tr> <td>Not Played</td> <td>[[notPlayed]]</td> </tr> '+
							 '<tr> <td>Feedback</td> <td>[[feedbackCount]]</td> </tr> '+
							 '<tr> <td>Revenue</td> <td>$[[revenue]]</td> </tr> '+
							 '<tr> <td>FB = [[fTitle]]</td> <td>[[FBCount]] = [[fStr]]</td> </tr> '+
							 '<tr> <td>Guest = [[gTitle]]</td> <td>[[GuestCount]] = [[gStr]]</td> </tr>'+
							 '<tr> <td>DAU = ([[dauTotal]])</td> <td>Android = [[dauAndroid]]<br />ios = [[dauIos]]<br />Flash = [[dauFlash]]<br /> Html = [[dauHtml]] <br /></td> </tr>'+
							 '<tr> <td>MAU = ([[mauTotal]])</td> <td>Android = [[mauAndroid]]<br />ios = [[mauIos]]<br />Flash = [[mauFlash]]<br /> Html = [[mauHtml]] <br /></td> </tr>'+
							 '</table> </body> </html>';
                              
                             AreportDailyUserData(obj);
							 var html = commonClass.KeywordReplacer(obj, template);
							 /*var transport = nodemailer.createTransport(ses({
										   AWSAccessKeyID: "AKIAIF2D4O5KZNVEJ7RQ",
										   AWSSecretKey: "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"
							  }));
							  // Message object
							  transport.sendMail({
								   from : 'Indian Rummy 2 Report <noreply@artoonentertainment.com>',
								   to : 'akshay.dodiya@artoon.in',
								   subject : 'Indian Rummy Stastics Report ['+iDate+']',
								   html: html
								},function(error){ });*/
						});
					});
				    });
				});
			});
		});
	});
}
function dailyChipsDetail() {
    console.log('dailyChipsDetail----->>> ');
    var df = commonClass.GetFormatedDate(new Date());
     db.collection('game_users').aggregate([{$group: {_id: '$flags._ir', total: {$sum: "$Chips"}}}]).toArray(function(err,uChips){

     	console.log('dailyChipsDetail------------>>>>>>uChips: ',uChips);
        var Chips = uChips[0].total;
        var rChips = uChips[1].total;
        
    	db.collection('dailyMarketChips').save({dString: df, cd: new Date(), Chips: Chips,rChips:rChips}, function (err1, newData){
    		console.log('dailyChipsDetail--------->>>newData: ',newData.ops[0]);
    		var sDate = commonClass.GetFormatedDate(new Date(commonClass.AddTime(-172800)));
    		var eDate = commonClass.GetFormatedDate(new Date(commonClass.AddTime(-86400)));


    		db.collection('dailyMarketChips').aggregate([{$match:{$or:[{dString:sDate},{dString:eDate}]}},{$group:{_id:null,uChips:{$sum:'$Chips'},rChips:{$sum:'$rChips'}}}]).toArray(function(err2,lastDaysData){
    			console.log('lastDaysData: ',lastDaysData);
    			var userAvgChips = lastDaysData[0].uChips/2;
    			var userCrntChips = newData.ops[0].Chips;
    			
    			
    			console.log('userAvgChips: ',userAvgChips,' userCrntChips: ',userCrntChips);

    			if(userCrntChips > 0 && userAvgChips > 0){

    				//checking if todays users total chips is not exceeded  users  average chips, if yes then ratio will be < 0.67
    				var ratio = userAvgChips/userCrntChips;
    				console.log('ratio: ',ratio);
    				if(ratio  < 0.67){

    					var nd = new Date();
	 					var iDate = nd.getDate()+'/'+(nd.getMonth()+1)+'/'+ nd.getFullYear();
							 
						var html = '<!DOCTYPE html> <html> <body><h2>Sudden rise in user chips On Date : '+iDate+'</h2> <table border="1">';
						html += '<tr><td>Current Total Chips in market</td><td>'+userCrntChips+'</td></tr>';
						html += '<tr><td>Average Chips in market</td><td>'+userAvgChips+'</td></tr>';
						html += '</table> </body> </html>';

						

						// var transport = nodemailer.createTransport(ses({
						// 	   AWSAccessKeyID: "AKIAIVXBXBLLRYUL4PSA",
						// 	   AWSSecretKey: "RFZIJaf+Fdpevx2tjoNkDEN6T3kKHbkOS7AThC9UAKIAIVXBXBLLRYUL4PS"
						// }));
						// 	  // Message object
						// transport.sendMail({
						// 	from : 'Indian Rummy 2 Alert <noreply@artoonentertainment.com>',
						// 	to : 'akshay.dodiya@artoon.in',
						// 	subject : 'Indian Rummy 2  Sudden rise in chips ['+iDate+']',
						// 	html: html
						// },function(error){ console.log(error) });


    					console.log('mail sent');
    				}
    				else{
    					console.log('mail not sent');
    				}
    			}
    			console.log('dailyChipsDetail------->>>>lastDaysData: ',lastDaysData);
    		});
    		console.log('dailyChipsDetail--->>>>sDate: ',sDate,' eDate: ',eDate);

        	return;
    	});
    });
}
function weeklyResult(){
	//first we have to detect midnight for every sunday.
	if(new Date().getDay() == 6)
	{
		cdClass.Get4WeekWinners(function(obj){ 
			//getting first three winner for last week range
			var wr = commonClass.getCurrentWeekRange();
			
			db.collection('game_users').find({ _id : { $nin : obj.flu }, wc : { $gt : 0 }, "lasts.ll" : { $gte : wr.wsd }},{un : 1, pp : 1, wc : 1, ue : 1,det:1 ,iv:1,av:1})
			.sort({wc : -1}).limit(3).toArray(function(err, winners){ 
				
				wr.users = [];
				
				var rewardsArr = [config.WW1R, config.WW2R, config.WW3R];
				for(x in winners)
				{
					//cdClass.UpdateUserChips(winners[x]._id, rewardsArr[x], "Weekly Winner", "");
					if((winners[x].det == "ios" && winners[x].iv  < 1.7) || (winners[x].det == "android" && winners[x].av < 1.5)|| winners[x].det == 'flash'){
						//cdClass.UpdateUserChips(winners[x]._id, rewardsArr[x], "Weekly Winner", "");
                                               cdClass.UpdateUserData(winners[x]._id.toString(), {$inc : {Chips : rewardsArr[x]}}, function () {});
					}
					winners[x]._icm = 2;
					wr.users.push(winners[x]);
					cdClass.UpdateUserData(winners[x]._id.toString(), {$set: {"flags.WWU": 1 , "flags.WWR" :parseInt(x)}}, function () {});
				}
			
				//saving three winners to database. with user email.
				if(wr.users.length > 0)
					db.collection('weekly_result').insert(wr, function(){ });
				
				//after result declare we need to reset flag to database.
				var filter = commonClass.AddTime(-2592000);
				db.collection('game_users').update({ "lasts.ll" : { $gte : new Date(filter) } },{ $set : { "flags._wwv":0 ,wc : 0 }}, { multi : true }, function(){});
			});
		});
	}
}


function RepairOnlineUser(){
		
		//This will repair all the online users whic remains online due to server crash
		var today = new Date();
		var yesterday = new Date(today);
  		 yesterday.setDate(today.getDate() - 1);
		db.collection('game_users').update({ "flags._io" : 1,"lasts.ll":{ $lte : yesterday }},{ $set : { "flags._io" : 0, sck: "", tbid : "" }},{ multi:true}, function(){});
}
function manageTracking(){
	//reset all userid which we stored in array for current day.
	var dr = new Date(new Date().getFullYear, new Date().getMonth(), new Date().getDate(), 0, 0, 0);
	var dString = dr.getFullYear()+"-"+(dr.getMonth()+1)+"-"+dr.getDate();
	db.collection("track_au").update({ dString : dString, type : "day"}, { $set: { uid_android: [], uid_ios : [],uid_flash : [], uid_html : [] }}, function(){ });
	
	//make tomorrow entry by cron job.
	var tomorrow = new Date();
	tomorrow.setTime(new Date().getTime() + (30 * 60 * 1000));
	var tString = tomorrow.getFullYear()+"-"+(tomorrow.getMonth()+1)+"-"+tomorrow.getDate();
	db.collection("track_au").insert({ cd : tomorrow, type : "day", android : 0, ios : 0, flash : 0, html : 0, uid_android : [], uid_ios : [], uid_flash : [], uid_html:[], 
	dString : tString}, function(){ });
	
	//making month's tracking null
	var lastDay = new Date(new Date().getFullYear(), new Date().getMonth() + 1, 0);
	///empty previous month array 
	if(new Date().getDate() == lastDay.getDate())
	{
		var cmString = lastDay.getFullYear()+"-"+(lastDay.getMonth()+1); //current month string
		
		var newMonth = new Date(new Date().getFullYear(), new Date().getMonth()+1, 1, 0,0,0);
		var nmString  = newMonth.getFullYear()+"-"+(newMonth.getMonth()+1); //new month string
		
		db.collection("track_au").update({ mString : cmString, type : "month"},{ $set: { uid_android: [], uid_ios : [],uid_flash : [] , uid_html:[]}}, function(){ });
		db.collection("track_au").insert({ cd : newMonth, type : "month", android : 0, ios : 0, flash : 0, html : 0, uid_android : [], uid_ios : [], uid_flash : [], uid_html: [],
            mString: nmString}, function () {
        });
    }
}
function manageTracking_old(){
	//reset all userid which we stored in array for current day.
	var dr = new Date(new Date().getFullYear, new Date().getMonth(), new Date().getDate(), 0, 0, 0);
	var dString = dr.getFullYear()+"-"+(dr.getMonth()+1)+"-"+dr.getDate();
	db.collection("track_au").update({ dString : dString, type : "day"}, { $set: { uid_android: [], uid_ios : [],uid_flash : [] }}, function(){ });
	
	//make tomorrow entry by cron job.
	var tomorrow = new Date();
	tomorrow.setTime(new Date().getTime() + (30 * 60 * 1000));
	var tString = tomorrow.getFullYear()+"-"+(tomorrow.getMonth()+1)+"-"+tomorrow.getDate();
	db.collection("track_au").insert({ cd : tomorrow, type : "day", android : 0, ios : 0, flash : 0, uid_android : [], uid_ios : [], uid_flash : [], 
	dString : tString}, function(){ });
	
	//making month's tracking null
	var lastDay = new Date(new Date().getFullYear(), new Date().getMonth() + 1, 0);
	///empty previous month array 
	if(new Date().getDate() == lastDay.getDate())
	{
		var cmString = lastDay.getFullYear()+"-"+(lastDay.getMonth()+1); //current month string
		
		var newMonth = new Date(new Date().getFullYear(), new Date().getMonth()+1, 1, 0,0,0);
		var nmString  = newMonth.getFullYear()+"-"+(newMonth.getMonth()+1); //new month string
		
		db.collection("track_au").update({ mString : cmString, type : "month"},{ $set: { uid_android: [], uid_ios : [],uid_flash : [] }}, function(){ });
		db.collection("track_au").insert({ cd : newMonth, type : "month", android : 0, ios : 0, flash : 0, uid_android : [], uid_ios : [], uid_flash : [],
            mString: nmString}, function () {
        });
    }
}
function AreportDailyUserData(obj) {
    c("AreportDailyUserData ");
    var sendDataToUrl = new Object();
    db.collection('game_users').count(function (err, tu) {
        var today = commonClass.GetFormatedDate(new Date());
        var dr = commonClass.GetDayRange();
        //c("Players >>" + counter);//LOG
        db.collection('dhu').findOne({day: today}, {fields: {players: 1}},function (err, resp) {
            db.collection('game_users').aggregate({$match: {cd: {$gte: dr.StartTime, $lte: dr.EndTime}}}, {$group: {_id: {det: '$det', utl: '$ult'}, total: {$sum: 1}}}, function (err, tnu) {

                for (var t in tnu) {
                    switch (tnu[t]._id.det) {
                        case 'flash':
                            var nfu = tnu[t].total;
                            break;
                        case 'ios':

                            if (tnu[t]._id.utl == 'FB')
                                var nifu = tnu[t].total;
                            else
                                var nieu = tnu[t].total;
                            break;
                        case 'android':
                            if (tnu[t]._id.utl == 'FB')
                                var nafu = tnu[t].total;
                            else
                                var naeu = tnu[t].total;
                            break;
                    }
                }
                sendDataToUrl.nfu = nfu;
                sendDataToUrl.nifu = nifu;
                sendDataToUrl.nieu = nieu;
                sendDataToUrl.nafu = nafu;
                sendDataToUrl.naeu = naeu;
                db.collection('game_users').aggregate({$match: {cd: {$gte: dr.StartTime, $lte: dr.EndTime}, thp: 0}}, {$group: {_id: {det: '$det', utl: '$ult'}, total: {$sum: 1}}}, function (err, npnu) {

                    for (var t in npnu) {
                        switch (npnu[t]._id.det) {
                            case 'flash':
                                var npfu = npnu[t].total;
                                break;
                            case 'ios':

                                if (npnu[t]._id.utl == 'FB')
                                    var npifu = npnu[t].total;
                                else
                                    var npieu = npnu[t].total;
                                break;
                            case 'android':
                                if (npnu[t]._id.utl == 'FB')
                                    var npafu = npnu[t].total;
                                else
                                    var npaeu = npnu[t].total;
                                break;
                        }
                    }
                    sendDataToUrl.npfu = (npfu) ? npfu : 0 ;
                    sendDataToUrl.npifu = (npifu) ? npifu : 0;
                    sendDataToUrl.npieu = (npieu) ? npieu : 0;                    
                    sendDataToUrl.npafu = (npafu) ? npafu : 0;                    
                    sendDataToUrl.npaeu = (npaeu) ? npaeu : 0;
                    

                    sendDataToUrl.tc = obj.totalChips;
                    sendDataToUrl.tnu = obj.totalUser;
                    sendDataToUrl.tu = tu;
                    sendDataToUrl.npu = obj.notPlayed;
                    sendDataToUrl.nfu = obj.notPlayed;
                    sendDataToUrl.tdau = obj.dauTotal;
                    sendDataToUrl.tidau = obj.dauIos;
                    sendDataToUrl.tadau = obj.dauAndroid;
                    sendDataToUrl.tfdau = obj.dauFlash;
                    sendDataToUrl.tmau = obj.mauTotal;
                    sendDataToUrl.timau = obj.mauIos;
                    sendDataToUrl.tamau = obj.mauAndroid;
                    sendDataToUrl.tfmau = obj.mauFlash;
                    sendDataToUrl.rthu = (resp) ? resp.players : 0;
                    sendDataToUrl.game = config.PAYMENT_CALL_KEY;
                    //console.log("sendDataToUrl - ", sendDataToUrl);

                    var url = config.PAYMENT_CALL_URL + 'adud';
                    var options = {
                        method: 'post',
                        body: sendDataToUrl,
                        json: true,
                        url: url
                    };
                    rq(options, function (err, res, body) {
                        if (err) {
                        	console.log("Err ",err);
                            //inspect(err, 'error posting json')
                        }
                        var headers = res.headers
                        var statusCode = res.statusCode
                        // console.log("callToOtherSeverSavePaymentData -- headers -- ", headers, ", statusCode -- ", statusCode);
                        
                    });
                });
            });
        });
    });
}