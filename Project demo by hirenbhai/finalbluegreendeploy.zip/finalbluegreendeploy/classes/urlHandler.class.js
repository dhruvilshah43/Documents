var exec = require('child_process').exec;
var bodyParser = require('body-parser');
var favicon = require('serve-favicon');
app.set('env', 'production');
var env = app.get('env');
var methodOverride = require('method-override');
var multer=require('multer');
var multerS3=require('multer-s3');
var AWS = require('aws-sdk');

module.exports = {
	BindWithCluster : function(){
        /* +-------------------------------------------------------------------+
            desc:main function for express routes
        +-------------------------------------------------------------------+ */
        c('BindWithCluster----------------->>>>>>>');
		var selfInst = this;
        if ('production' == env) {
            // c('production====env');
            //requiring for template parsing system when we use sendMail function to send the mail
            app.engine('.html', require('ejs').__express);
            app.set('views', './views');
            app.use(express.static('./views'));
            app.use(favicon('views/favicon.png'));
            app.use(bodyParser.urlencoded({extended: true}));
            app.use(bodyParser.json());
            app.use(methodOverride());


            app.all('*', function(req, res, next) {

                res.header('Access-Control-Allow-Origin', '*');
                res.header('Access-Control-Allow-Methods', 'PUT, GET, POST, DELETE, OPTIONS');
                res.header('Access-Control-Allow-Headers', 'Content-Type');
                next();
            });

        }
        //cdClass.PrepareDataCodes();

        /*AWS.config.update({
            accessKeyId: 'AKIAJXRU5ZL7Y4PXEN2Q',
            secretAccessKey: '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',
            region: 'ap-south-1'
        });

        var s3 = new AWS.S3();
        var upload = multer({
            storage: multerS3({
                s3:s3,
                dirname: 'uploads/user_profiles',
                bucket: 'rws-game-uploads',
                secretAccessKey: 'ItxcU4Le/cvjq2I6EM7hO+8D5+msZv+/sez0BMOg',
                accessKeyId: 'AKIAJXRU5ZL7Y4PXEN2Q',
                region: 'ap-south-1',
                key: function (req, file, cb) {

                    console.log('file: ',file);
                    cb(null, "uploads/user_profiles/u_" + Date.now() + ".png")
                }
            })
        })*/
        /*app.post('/upload', upload.single('file'), function (req, res) {
            var id = req.body.id;
            var path = req.file.key;
            console.log('/upload-------------->>>>>>id: '+id+' path: ',path,' req.file: ',req.file);
            if (typeof id == "undefined" || typeof path == "undefined" || id == null || path == null){
                console.log("/upload------------------>>>>>Error")
                var data = {isUploaded: false}
                res.send(data);
                return false;
            }
            else{
                if (typeof id != "string"){
                    id = id.toString();
                    console.log("not a string")
                    var data = {isUploaded: false}
                    res.send(data);
                    return false;
                }
                if (id.length != 24){
                    console.log("YOur id is fake")
                    var data = {isUploaded: false}
                    res.send(data);
                    return false;
                }
                else{
                    db.collection("game_users").update({_id: MongoID(id)}, {$set: {pp: config.RABU + path,ppId:''}}, function (err, response){
                        console.log("err" + err)
                        if (!err){
                            if (response){
                                var data = {image: config.RABU + path, isUploaded: true}
                                res.send(data);
                            }
                            else{
                                var data = {isUploaded: false}
                                res.send(data);
                            }
                        }
                        else{
                            var data = {isUploaded: false}
                            res.send(data);
                        }
                    });
                }
            }
        });*/

        app.get('/p', function (req, res) {   //for testing server 
            c("call get p method",req.headers);
            res.send('ok');
        });
        app.post('/p', function(req, res){
            c('/p--------post----------->>>>req.body: ',req.body);
        });
        app.get('/test',function(req,res){
            // res.render('test/test.html',config);
            var sendData = { RemoveAfter : 1300 ,FBAN : 'Myteam11-rummy',code:123};
            res.render('maintenance/index.html',sendData);
        });
        app.get('/preview',function(req,res){ //temperory
            c('/preview---------->>>>>>req.headers: ',req.headers['user-agent'],' type: ',typeof req.headers['user-agent'],' test: '+/WhatsApp/i.test(req.headers['user-agent']));
            
            res.render('facebook_meta.html', {gn: config.GAME_NAME, bs: config.BU, url: req.url});
        });
        app.get('/showConfig', function (req, res) {  //direct link
            c('/showConfig----1---->>>>>>');
            c('/showConfig----2---->>>>>>',config);
            var cObj = {config:JSON.stringify(config),cfgError:0};
            res.render('config_view.html',cObj);
        });
        app.get('/chooseServer', function (req, res) {
            c('/chooseServer------------------->>>>req.query: ',req.query);
            //we are getting servers from least connections.
            commonClass.LoadBalancer(function (json) {
                c('chooseServer----------->>>>>>json: ',json);
                
                
                if ( !json){
                   
                    var json = {m_mode: true};
                    res.send(commonClass.Enc(json));
                    return false;
                }
                
                var dtdiff1 = commonClass.GetTimeDifference(new Date(), new Date(config.MMSD));
                var dtdiff2 = commonClass.GetTimeDifference(new Date(), new Date(config.MMED));
                
                dtdiff1=dtdiff1<0?0:dtdiff1;
                dtdiff2=dtdiff2<0?0:dtdiff2;
                dtdiff2 = dtdiff2-dtdiff1;
                if(commonClass.InMaintenanceMode()){
                    
                    config.MM=true;
                }
                else{
                    config.MM=false;
                }
                json.config = commonClass.GetGameConfig();

                if(config.MM == true && config.MMSFLAG == true && dtdiff2 > 0){
                   
                    json.StartAfter=0;
                    json.RemoveAfter = dtdiff2;
                    // json.m_mode = config.MM;  
                    json.config.StartAfter = 0;
                    json.config.RemoveAfter = dtdiff2;   
                }
                else{
                   
                    json.StartAfter=dtdiff1;
                    json.RemoveAfter = dtdiff2;
                    // json.m_mode = false;
                    config.MM = false;   
                    json.config.StartAfter = dtdiff1;
                    json.config.RemoveAfter = dtdiff2;
                }
                json.MM = config.MM;
                json.MMSFLAG = config.MMSFLAG;
                json.ENCKEY = 'DFK8s58uWFCF4Vs8NCrgTxfMLwjL9WUy';

                c('/chooseServer---------->>>>json:',json);
                c('/chooseServer---------->>>>IP: '+json.IP+' MM: '+config.MM);
                
                if(req.query.det != null && req.query.det != 'undefined' && req.query.det == 'html'){
                    // res.send(json);
                    res.send(commonClass.enc_web(json));
                }
                else{
                    res.send(commonClass.Encbs(json));
                }
            });
        });
        app.get('/referrer', function (req, res) {
            var code = commonClass.Dec(decodeURIComponent(req.query.t));
            c('/referrer------------>>>>>>code: ',code);

            //basic data validation
            if (!code || code.length != 10 || code.split('-').length != 2){
                c('/referrer-----1-------->>>>>"Error: 403"');
                res.send('Forbidden!', 403);
                return false;
            }
            
            //validation on database
            db.collection('game_users').findOne({rfc: code.split('-')[0]},{fields:{rfc: 1,tbid:1}},function (err, resp) {

                if (!resp){

                    res.send('Forbidden!', 403);
                    c('/referrer-----2-------->>>>>"Error: 403"');
                    return false;
                }

                //now we need to detect device type and redirect user to appropriate app store.
                var refInfo = resp;

                //if sharing link with facebook then we also have to load meta tags into it.
                c('/referrer-------------->>>>>>>req.headers: ',req.headers);
                if (/facebookexternalhit/i.test(req.headers['user-agent'])){ //messenger
                    c('/referrer-------------->>>>>>"redirect to fb meta  tag"');
                    res.render('facebook_meta.html', {gn: config.GAME_NAME, bs: config.BU, url: req.url});
                    return false;
                }

                var obj = commonClass.DetectDevice(req);
                c('/referrer------------->>>>>>obj: ',obj,' ip: ',req.connection.remoteAddress);
                if (obj.Mobile == true && (obj.iPhone || obj.iPad || obj.iPod)){

                    c('/referrer-------------->>>>>>"ios"');
                    var uIp = commonClass.getIpadFromUrl(req);
                    
                    db.collection('request_track').update({ip: uIp},{$set:{refCode: code, ip: uIp, cd: new Date()}},{upsert:true}, function () {});
                    c('/referrer----------->>>>uIp: '+uIp+' refInfo._id: '+refInfo._id+' refInfo.tbid: '+refInfo.tbid);
                    if(uIp && uIp != ''){

                        db.collection('table_invites').updateOne({uid: refInfo._id.toString(), tbid: refInfo.tbid},{$addToSet:{to:uIp}},function(){});
                    }

                    var passOBJ = {
                        det: 'iOS',
                        code: code
                    }
                    c('/referrer------ios------->>>>passOBJ: ',passOBJ);
                    res.render('test.html', passOBJ);
                }
                else if (obj.Mobile == true && obj.Android){
                    c('/referrer---------->>>>>"android"');
                    
                    var uIp = commonClass.getIpadFromUrl(req);
                    db.collection('request_track').update({ip: uIp},{$set:{refCode: code, ip: uIp, cd: new Date()}},{upsert:true}, function () {});
                    c('/referrer----------->>>>uIp: '+uIp+' refInfo._id: '+refInfo._id+' refInfo.tbid: '+refInfo.tbid);
                    if(uIp && uIp != ''){
                        db.collection('table_invites').updateOne({uid: refInfo._id.toString(), tbid: refInfo.tbid},{$addToSet:{to:uIp}},function(){});
                    }
                    var passOBJ = {
                        det: 'android',
                        code: code
                    }
                    c('/referrer------and------->>>>passOBJ: ',passOBJ);
                    res.render('test.html', passOBJ);
                }
                else if( /WhatsApp/i.test(req.headers['user-agent']) || /checkgzipcompression.com/i.test(req.headers['user-agent']) /*|| req.headers['user-agent'] == 'checkgzipcompression.com robot'*/){ //whatsapp
                    c('/referrer------------>>>>>"checkgzipcompression"');

                    res.render('facebook_meta.html', {gn: config.GAME_NAME, bs: config.BU, url: req.url});
                }
                else{
                    code = commonClass.uenc(req.query.t);
                    c('/referrer-------------->>>>>>"html"---->>>>code: '+code);
                    var passOBJ = {
                        det: 'html',
                        code: code
                    }
                    c('/referrer------and------->>>>passOBJ: ',passOBJ);
                    res.render('test.html', passOBJ);
                    // res.redirect('https://apps.facebook.com/' + config.FBAN + "?referrer=" + code);
                }
            });
        });
        app.get('/joinTable', function(req,res){

            console.log('req',req.query);
            var obj = commonClass.DetectDevice(req);
            c('/joinTable------------->>>>>>obj: ',obj,' ip: ',req.connection.remoteAddress);
            if (obj.Mobile == true && (obj.iPhone || obj.iPad || obj.iPod)){

                var passOBJ = {
                   det: 'ios',
                   type: "joinTable",
                   randomNo: req.query.jcode,
                   t_id:req.query.tbid
                };
                res.render('join_table.html', passOBJ);
            }
            else if(obj.Mobile == true && obj.Android){
                
                var passOBJ = {
                   det: 'android',
                   type: "joinTable",
                   randomNo: req.query.jcode,
                   t_id:req.query.tbid
                };
                res.render('join_table.html', passOBJ);
            }
            else{

                var passOBJ = {
                   det: 'html',
                   type: "joinTable",
                   randomNo: req.query.jcode,
                   t_id:req.query.tbid
                };
                res.render('join_table.html', passOBJ);
            }    
        });

        app.get('/tableapi/:trid', function (req, res) {
            c('/tableapi----------------->>>>>>>>>req.query.trid: '+req.params.trid);
            db.collection("chips_track").findOne({_id:MongoID(req.params.trid.toString())}, function(err,resp){
                var json = { 
                    Status: true,
                    StatusCode: 200,
                    Data:
                    { 
                        Token: '6287C181-9DBA-46E4-8CE0-25CA865DED37',
                        Result:
                        { 
                            TransactionId: resp._id.toString(),
                            Userid: resp.uid,
                            Date: resp.cd,
                            CediteAmount: resp.chips,
                            DebitAmount: 0,
                            TransactionStatus: '',
                            TransactionType: resp.description,
                            Totalbalnce: resp.balance //user's totalamount after this transaction 
                        }
                    } 
                };
                res.send(json);
            });
        });
        /*
         +----------------------------------------------------------+
         Loading facebook application.
         +----------------------------------------------------------+
        */
        app.get('/crossdomain.xml', function (req, res) {
            res.sendfile('crossdomain.xml');
        });

        app.get('/Auth', function (req, res) {
            //generate token for create queue service call.
            var tkStr = commonClass.GetRandomString(8);
            var token = commonClass.Enc(tkStr, true);
            res.set('x-bearer-token', token); //setting header token;
            

            var queue = req.get('x-bearer-queue');

            //deleting old queue 
            // if (queue){

            //     rClient.del("session:" + queue);
            // }


            res.send('1');
            tkStr = null;
            tokne = null;
        });

        /*
         +----------------------------------------------------------+
         This will refresh the data codes means error message & 
         success message in array. and this handler will being 
         call from admin panle when data added or updated by
         admin in the admin panel.
         +----------------------------------------------------------+
         */
        
        app.get('/RefreshDataCodes', function (req, res) {
            c('/RefreshDataCodes----------------->>>>>>>>>');
            cdClass.PrepareDataCodes();

            //prepare data codes on all servers dat we have.
            jobExchange.publish('other', {en: 'RDC', data: {}});


            res.send('Data refreshed on server.');
        });

        app.get('/PrepareFeatureCodes', function (req, res) {

            c("/PrepareFeatureCodes--------->>>>>>req.query.id: "+req.query.id+" id type: "+typeof req.query.id);
            cdClass.PrepareFeatureData();

            if(typeof req.query.id != 'undefined'){
                id = req.query.id.toString();
            }
            else{
                id = req.query.id;
            }
            db.collection('feature_roll_feedback').findOne({_id:MongoID(id)},function(err,frfInfo){
                c('/PrepareFeatureCodes------------->>>>>>frfInfo: ',frfInfo);
                res.send('/PrepareFeatureCodes on server.');
            });
        });

        var allowedHost = [
            '192.168.0.206',
            '35.154.254.78', 
            'game.artoon.in',
            'new-dev.artoon.in',
            '192.168.0.242', 
            '192.168.0.135', 
            '192.168.0.121',
            '192.168.0.228',
            '27.54.182.197'
            ];
        app.get('/getConfig', function (req, res) {
            c('/getConfig-------------------->>>>>>>>',req.connection.remoteAddress.toString()/*.split(':')[3]*/,' req.query.authKey: '+req.query.authKey);
            if (req.query.authKey && req.query.authKey == '1ZxJT47BvY2o69ya7cPCDB9vS70qDUs1' && _.contains(allowedHost, req.connection.remoteAddress.toString()/*.split(':')[3]*/)){
                res.send(config);
            }
            else{
                res.send(401, 'Unauthorized Access.');
            }
        });

        /*
         +----------------------------------------------------------+
         This will handle post request from admin panel and save 
         config data into file, and also refresh the config global
         variable on server.
         +----------------------------------------------------------+
         */
        app.post('/saveConfig', function (req, res) {
            if (req.query.authKey && req.query.authKey == '1ZxJT47BvY2o69ya7cPCDB9vS70qDUs1' && _.contains(allowedHost, req.connection.remoteAddress.toString().split(':')[3])){
                fs.writeFile("./config.json", JSON.stringify(req.body), function (err) {
                    config = req.body;

                    //publishing config using amqp to all server.
                    jobExchange.publish('other', {en: 'SCNF', data: config});

                    res.send('OK');
                });
            }
            else{

                res.send(401, 'Unauthorized access.');
            }
        });

        app.post('/setConfig',function(req,res){  //direct link
            c('/setConfig---------->>>>>req: ',req.body.upCfg,' type: ',typeof req.body.upCfg);
            var cObj = {cfgError:0};
            if(req && req.body && typeof req.body.upCfg == 'string'){
                try{

                    req.body.upCfg = req.body.upCfg.replace(/\r\n/g,'');
                    var cf = JSON.parse(req.body.upCfg);   
                    config = cf;  //incase config is assigned with false data
                    
                    fs.writeFileSync('./config.json',req.body.upCfg);
                    
                    jobExchange.publish('other', {en: 'SCNF', data: config});
                    cObj.cfgError = 0;  

                }
                catch(e){
                    c('/setConfig:::::::::::::Error: "Config Error!!!"');
                    cObj.cfgError = 1;
                }
            }
            else{
                cObj.cfgError = 1;
            }
            c('/setConfig------->>>>>config: ',config);
            cObj.config = JSON.stringify(config);
            res.render('config_view.html',cObj);
        });

        app.get('/setBotMaker',function(req,res){
            c('/setBotMaker--------------->>>>>>');
            jobExchange.publish('other', {en: 'SBM', data: {}});
            res.send('Bot maker data refreshed on server.');
        });
        app.get('/setBotCards',function(req,res){
            c('/setBotCards--------------->>>>>>');
            jobExchange.publish('other',{en:'SBC',data:{}});
            res.send('Bot Cards data refreshed on server.');
        });
        app.get('/setBotDrop', function (req, res) {
            c('/setBotDrop------------->>>>>>')
            jobExchange.publish('other', {en: 'SBD', data: {}});
            res.send('Bot Drop Data refreshed on server.');
        });
         /*
         +----------------------------------------------------------+
         Handling deauthorization of application for send event to
         flash that users has just removed the application access.
         +----------------------------------------------------------+
         */
        app.post('/deauthorizedApp/', function (req, res) {
            res.send('OK');
        });

        //==================HTML5 setup=====================================
        app.get('/game',function(req,res){
            res.render('index.html');
        });

        app.get('/temp',function(req,res){
            c("---------------------------in temp");
            if(res){
                 res.render('sample/index.html');
            }
        });

        app.get('/getSocket',function(req,res){
            c('/getSocket------------------->>>>>req.query: ',req.query);
            commonClass.LoadBalancer(function (json) {
                c('/getSocket--------------->>>>>json: ',json);
                 
                if (req.query.authKey && req.query.authKey == '1ZxJT47BvY2o69ya7cPCDB9vS70qDUs1' /*&& ((req.connection.remoteAddress.toString().split(':')[3] == '13.126.84.108' || req.connection.remoteAddress.toString().split(':')[3] == 'newdev.gamewithpals.com' || req.connection.remoteAddress.toString().split(':')[3] == '192.168.0.135')) */){
                    
                    if(json && typeof json.port != 'undefined' && json.port != null && json.port != ''){

                        res.send({url:json.proto+'://'+json.host+':'+json.port+'/'});
                    }
                    else{
                        res.send({url:''})
                    }
                }
                else{
                    c('/getSocket------------------->>>>>>>"Unauthorized access"');
                    res.send('Unauthorized Access');
                }

            });
        });
        app.get('/getServer',function(req,res){
            c('/getServer------------------->>>>>req.query: ',req.query);
            commonClass.LoadBalancer(function (json) {
                c('/getServer--------------->>>>>json: ',json);
                var obj = {url:''};
                if(json && typeof json.port != 'undefined' && json.port != null && json.port != ''){
                    obj = {url:json.proto+'://'+json.host+':'+json.port+'/'};
                }
                obj = JSON.stringify(obj);
                obj = commonClass.enc_web(obj);
                res.send(obj);
            });
        });
        
        app.post('/getActivities', function (req, res) {
            db.collection("p2p_gifts").find().toArray(function (err, resp) {
                res.send(commonClass.Enc(resp));
            });
        });

        app.post("/deleteUser",function(req,res){
            
            var id = req.body.id.toString();
            c('/deleteUser-------------->>>>>>id: ',id);
            if(typeof id == "undefined" || id.length != 24) {
                return res.status(400).json({success:0})
            } else {
                db.collection("game_users").findOne({_id:MongoID(id)},function(err,userInfo) {
                    if(!err && userInfo && userInfo.tbid == '') {
                       
                        db.collection("game_users").remove({_id:MongoID(id)},function(err,isOk) {
                            if(!err && isOk) {
                                return res.status(200).json({success:1})
                            } else {
                                return res.status(400).json({success:0})                        
                            }
                        });
                    } else {
                        return res.status(400).json({success:0})    
                    }
                });
            }
        });

        /*phone pe integration*/
        app.get('/initPhonePe',function(req, res){
            
            c('/initPhonePe----------get--------->>>>>');
            res.render('HTML5/index.html');
            //res.render('testPhonePe/index.html');
        });

        app.get('/myTeam11',function(req, res){
            
            c('/initPhonePe----------get--------->>>>>');
            res.render('HTML5/index.html');
            //res.render('testPhonePe/index.html');
        });
        
        app.post('/initPhonePe',function(req, res){
            c('/initPhonePe------post------->>>>');
            res.send('ok');
        });

        app.get('/phonePeAccess',function(req, res){
            c('/phonePeAccess------->>>>req.query: ',req.query);
            if(req.query.grantToken || req.query.grantToken != ''){
                c('/phonePeAccess------------>>>>"token found"');
                let payload = {
                    "merchantId": config.PP_MERCHANT_ID,
                    "grantToken": req.query.grantToken,
                }

                ppClass.phonePeRequest('service/access', {}, payload, function(err, body){
                    c('/phonePeAccess--------->>>>>err: ',err,' body: ',body);
                    if(body && body.data && body.data.userDetails){

                        if(body.data.userDetails.phoneNumber){

                            res.redirect(config.BU+'phonePeLogin?DeviceId='+body.data.userDetails.phoneNumber);
                        }
                        else{
                            c('/phonePeAccess------cannot access---->>>>>');
                            res.redirect(config.BU+'phonePeLogin');
                        }
                    }
                    else{
                        c('/phonePeAccess---------->>>"user details not found"');
                        res.send('token not found');
                    }
                });
            }
            else{
                c('/phonePeAccess---------->>>"grant token not found"');
                res.redirect(config.BU+'phonePeLogin');
                //res.send('token not found');
            }
        });
        app.get('/phonePeLogin', function(req, res){
            c('/phonePeLogin------------->>>>req.query: ',req.query);
            var DeviceId = '';
            if(req.query.DeviceId){
                DeviceId = req.query.DeviceId;
            } 
            var obj = {};

            commonClass.LoadBalancer(function(sObj){
                c('/phonePeLogin------------->>>>sObj: ',sObj);
                if (!sObj){
                    c('/login--------------->>>>>>>"no obj"');
                    res.send('<h1>Server Is Under Maintenance!!</h1>')
                    return false;
                }

                var obj = {serviceUrl :sObj.proto+"://"+sObj.host+":"+sObj.port,RABU:config.RABU};
                obj.MTIME = 0;
                obj.BU = config.BU;   

                if(DeviceId && DeviceId != ''){
                    obj.DeviceId = DeviceId;
                    obj.ult = 'phonePe';
                }
                else{
                    obj.DeviceId = commonClass.GetRandomInt(1, 99999999);
                    obj.ult = 'phonePe';
                    //obj.DeviceId = '';
                }
                c('/phonePeLogin----------------->>>>obj: ',obj);
                //var res1 = {flvars : commonClass.enc_dec(obj)};
                obj = JSON.stringify(obj);
                obj = commonClass.enc_web(obj);
                res.send(obj);
            });
        });
	},
    CheckingForPermissions: function (prms) {
        /* +-------------------------------------------------------------------+
            desc:function to for checking facebook permissions
            i/p: prms
        +-------------------------------------------------------------------+ */
        var arr = {prms: [], notGiven: []};
        for (x in prms){
            if (prms[x].status == 'declined'){
                arr.notGiven.push(prms[x].permission);
            }
            else{
                arr.prms.push(prms[x].permission);
            }
        }
        return arr;
    },
    setRoomPreferences: function (sender_psid) {
        c('setRoomPreferences------------>>>>sender_psid: '+sender_psid);
        let response = {
            attachment: {
                type: "template",
                payload: {
                    template_type: "button",
                    text: "OK, let's set your room preferences so I won't need to ask for them in the future.",
                    buttons: [{
                        type: "web_url",
                        url: "https://www.messenger.com",
                        title: "Set preferences",
                        webview_height_ratio: "compact",
                        messenger_extensions: true
                    }]
                }
            }
        };
        return response;
    },
    callSendAPI : function (sender_psid, response) {
        // Construct the message body
        c('callSendAPI----------------->>>>>sender_psid: ',sender_psid,' response: ',response);
        let request_body = {
            "recipient": {
                "id": sender_psid
            },
            "message": response
        };
        c('callSendAPI--------------->>>>request_body: ',request_body);
        // Send the HTTP request to the Messenger Platform
        request({
            "uri": "https://graph.facebook.com/"+config.FB_INSTANT_API_V+"/me/messages",
            "qs": {"access_token": config.FB_PAGE_ACCESS_TOKEN},
            "method": "POST",
            "json": request_body
        }, (err, res, body) => {
            if (!err) {
                c('callSendApi------------->>>>>message sent! body: ',body)
            } else {
                c("callSendAPI--------------->>>>> Unable to send message:" + err);
            }
        });
    },
    handleGamePlay:function(event){
        c('handleGamePlay---------------->>>>event: ',event);
       if(event && event.game_play && event.game_play.player_id && event.sender && event.sender.id){
            c('handleGamePlay-------if--------->>>>');

            db.collection('game_users').updateOne({fid:event.game_play.player_id},{$addToSet:{sn:event.sender.id},$set:{'lasts.lsn':event.sender.id}},function(err,resp){});
       }
       else{
            c('handleGamePlay--------else--------->>>>>""');
       } 
    }
}