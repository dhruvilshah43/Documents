module.exports = {
	FTAJ :function(data,client){  //find table and join; data = {bv}
		/* +-------------------------------------------------------------------+
            desc:event to find classic table and join 
            i/p: data = {bv = bot value},client = socket object
        +-------------------------------------------------------------------+ */
		c('FTAJ------>>>>client.uid: ',client.uid,' data: ',data);
		cdClass.GetUserInfo(client.uid,{ip:1,Chips:1,counters:1},function(userInfo){
			if(userInfo){
				if(typeof data.catid != 'undefined' && data.catid != null){
					db.collection('playing_category').findOne({_id:MongoID(data.catid)},function(err,resp){

						if(userInfo.Chips >= resp.cpp*config.MAX_DEADWOOD_PTS){
							data.chips = userInfo.Chips;
							data.bv = parseInt(resp.cpp);
							data.lvc = userInfo.counters.lvc;
							data.mode = "practice";
							data.pCount = resp.pCount;
							data.theme = (data.theme != null && typeof data.theme != 'undefined') ? data.theme : 'cyan';
							// data.ip = userInfo.ip;
							playingTableClass.findTableAndJoin(data,client,0);
						}
						else{
							var reqChips = resp.cpp*config.MAX_DEADWOOD_PTS;
							commonClass.SendData(client,'PUP', {chips:reqChips,flag:'noChips',reqChips:reqChips},'error:1020');  //Don't have sufficient chips
							// strClass.outOfChipsPop(client,{chips:data.bv*config.MAX_DEADWOOD_PTS,flag:'noChips',reqChips:reqChips});
						}
					})
				}
				else{
					data.pCount = (typeof data.pCount != 'undefined') ? data.pCount : config.PPPP;
					db.collection('playing_category').find({/*lBound:{$lte:userInfo.Chips},*/pCount:data.pCount,mode:'practice'}).sort({cpp:1}).toArray(function(err,category){
						if(category.length > 0 && category[0].cpp*config.MAX_DEADWOOD_PTS <= userInfo.Chips){
							var tData = {
								bv:category[0].cpp,
								chips:userInfo.Chips,
								lvc:userInfo.counters.lvc,
								mode:"practice",
								theme:(data.theme != null && typeof data.theme != 'undefined') ? data.theme : 'cyan',
								// data.ip:userInfo.ip,
								pCount:category[0].pCount
							};
							playingTableClass.findTableAndJoin(tData,client,0);  //player seats on higher boot value
						}
						else{
							c('\nFTAJ----else------>>>>>');

							db.collection('playing_category').find({}).sort({cpp:1}).toArray(function(err,category1){

								if(category1 && category1.length > 0){
									var reqChips = category1[0].lBound;
								}	
								else{
									var reqChips = 0;
								}
								commonClass.SendData(client,'PUP', {flag:'noChips',reqChips:reqChips},'error:1020');  //Don't have sufficient chips
								// strClass.outOfChipsPop(client,{flag:'noChips',reqChips:reqChips});
							});

						}
					});
				}
			} 
			else{
				c('FTAJ:::::::::::::::::::::::>>>>>>Error: "user not found!!!"');
			}
		});
	},
	FTAJC :function(data,client){  //find table and join; data = {bv}
		/* +-------------------------------------------------------------------+
            desc:event to find classic table and join 
            i/p: data = {bv = bot value},client = socket object
        +-------------------------------------------------------------------+ */
		c('FTAJC------>>>>client.uid: ',client.uid,' data: ',data);
		cdClass.GetUserInfo(client.uid,{totalcash:1,depositcash:1,wincash:1,bonuscash:1,counters:1},function(userInfo){
			if(userInfo){
				if(typeof data.catid != 'undefined' && data.catid != null){
					db.collection('playing_category').findOne({_id:MongoID(data.catid)},function(err,resp){
						if(resp){
							var ef = resp.cpp*config.MAX_DEADWOOD_PTS;
							var cb = ef*config.CASH_BONUS/100;
							c("FTAJC-------------------------ef:",ef);
							c("FTAJC-------------------------cb:",cb);
							c("FTAJC-------------------------totalcash:",userInfo.totalcash);
							c("FTAJC-------------------------depositcash:",userInfo.depositcash);
							c("FTAJC-------------------------wincash:",userInfo.wincash);
							c("FTAJC-------------------------bonuscash:",userInfo.bonuscash);
							if (userInfo.totalcash >= ef && (parseInt(userInfo.depositcash) + parseInt(userInfo.wincash) >= ef || (parseInt(userInfo.depositcash) + parseInt(userInfo.wincash) >= ef-parseInt(cb) && userInfo.bonuscash >= parseInt(cb)))) {
								data.lvc = userInfo.counters.lvc;
								data.cash = userInfo.totalcash;
								data.bv = parseInt(resp.cpp);
								data.mode = 'cash';
								data.pCount = resp.pCount;
								// data.ip = userInfo.ip,
								data.theme = (typeof data.theme != 'undefined') ? data.theme : 'cyan';
								playingTableClass.findTableAndJoin(data,client,0);
							}
							else{
								var reqChips = resp.cpp*config.MAX_DEADWOOD_PTS;
								commonClass.SendData(client,'PUP', {chips:data.bv*config.MAX_DEADWOOD_PTS,flag:'noCash',reqChips:reqChips},'error:1020');  //Don't have sufficient chips
								// strClass.outOfChipsPop(client,{chips:data.bv*config.MAX_DEADWOOD_PTS,flag:'noChips',reqChips:reqChips});
							}
						}
					})
				}
				else{
					var cash = parseInt(userInfo.depositcash) + parseInt(userInfo.wincash);
					db.collection('playing_category').find({lBound:{$lte:cash}}).sort({cpp:-1}).toArray(function(err,category){
						if(category.length > 0){
							var ef1 = category[0].cpp*config.MAX_DEADWOOD_PTS;
							var cb = ef1*config.CASH_BONUS/100;
							if (userInfo.totalcash >= ef1 && (parseInt(userInfo.depositcash) + parseInt(userInfo.wincash) >= ef1 || (parseInt(userInfo.depositcash) + parseInt(userInfo.wincash) >= ef1-parseInt(cb) && userInfo.bonuscash >= parseInt(cb)))) {

								playingTableClass.findTableAndJoin({bv:category[0].cpp,lvc:userInfo.counters.lvc,pCount:category[0].pCount,/*ip:userInfo.ip,*/cash: userInfo.totalcash,mode: 'cash'},client,0);  //player seats on higher boot value
							}
						}
						else{
							c('\nFTAJC----else----------->>>>>');

							db.collection('playing_category').find({}).sort({cpp:1}).toArray(function(err,category1){

								if(category1 && category1.length > 0){
									var reqChips = category1[0].lBound;
								}	
								else{
									var reqChips = 0;
								}
								commonClass.SendData(client,'PUP', {flag:'noChips',reqChips:reqChips},'error:1020');  //Don't have sufficient chips
								// strClass.outOfChipsPop(client,{flag:'noChips',reqChips:reqChips});
							});

						}
					});
				}
			} 
			else{
				c('FTAJ:::::::::::::::::::::::>>>>>>Error: "user not found!!!"');
			}
		});
	},
	FTAJDM:function(data,client){  //find table and join deal mode; data = {catid}
		/* +-------------------------------------------------------------------+
            desc:event to find deal table and join 
            i/p: data = {catid = category id of table},client = socket object
        +-------------------------------------------------------------------+ */
		c('FTAJDM---------->>>>>>client.uid: ',client.uid,' data: ',data);
		if(data && data.catid){

			cdClass.GetUserInfo(client.uid,{Chips:1,counters:1},function(userInfo){
				if(userInfo){
					db.collection('deal_category').findOne({_id:MongoID(data.catid)},function(err,resp){
						if(resp.fee <= userInfo.Chips){ //user has enough chips to play
							data.gt = 'Deal';
							data.pCount = data.pCount;
							data.bv = resp.fee;
							data.mode = "practice";
							data.lvc = userInfo.counters.lvc;
							data.theme = (typeof data.theme != 'undefined') ? data.theme : 'cyan';

							if(resp && resp.reke){
								data.reke = resp.reke;
								// data.prize = parseInt(resp.fee*resp.pCount*((100-resp.reke)*0.01));  //table prize
							}
							else{
								data.reke = 0;
								// data.prize = resp.fee*resp.pCount;
							}
							c('FTAJDM---------->>>>>>>data.reke: '+data.reke);

							playingTableClass.findTableAndJoin(data,client,0);
						}
						else{
							var reqChips = resp.fee;
							commonClass.SendData(client,'PUP', {chips:resp.fee,flag:'noChips',reqChips:reqChips},'error:1020');  //Don't have sufficient chips
							// strClass.outOfChipsPop(client,{chips:resp.fee,flag:'noChips',reqChips:reqChips});
						}
					});
				}
			});
		}
		else{
			c('FTAJDM:::::::::::::::::::::>>>>Error: "category not founds"');
		}
	},
	FTAJDMC:function(data,client){  //find table and join deal mode; data = {catid}
		/* +-------------------------------------------------------------------+
            desc:event to find deal table and join 
            i/p: data = {catid = category id of table},client = socket object
        +-------------------------------------------------------------------+ */
		c('FTAJDM---------->>>>>>client.uid: ',client.uid,' data: ',data);
		if(data && data.catid){

			cdClass.GetUserInfo(client.uid,{Chips:1,counters:1,totalcash:1,depositcash:1,bonuscash:1,wincash:1},function(userInfo){
				if(userInfo){
					db.collection('deal_category').findOne({_id:MongoID(data.catid)},function(err,resp){
						// if(resp.fee <= userInfo.Chips){ //user has enough chips to play
						var cb = resp.fee*config.CASH_BONUS/100;
						if (userInfo.totalcash >= resp.fee && (parseInt(userInfo.depositcash) + parseInt(userInfo.wincash) >= resp.fee || (parseInt(userInfo.depositcash) + parseInt(userInfo.wincash) >= resp.fee-parseInt(cb) && userInfo.bonuscash >= parseInt(cb)))) {

							data.gt = 'Deal';
							data.pCount = data.pCount;
							data.bv = resp.fee;
							data.mode = "cash";
							data.lvc = userInfo.counters.lvc;
							data.theme = (typeof data.theme != 'undefined') ? data.theme : 'cyan';

							if(resp && resp.reke){
								data.reke = resp.reke;
								// data.prize = parseInt(resp.fee*resp.pCount*((100-resp.reke)*0.01));  //table prize
							}
							else{
								data.reke = 0;
								// data.prize = resp.fee*resp.pCount;
							}
							c('FTAJDM---------->>>>>>>data.reke: '+data.reke);

							playingTableClass.findTableAndJoin(data,client,0);
						}
						else{
							var reqChips = resp.fee;
							commonClass.SendData(client,'PUP', {chips:resp.fee,flag:'noChips',reqChips:reqChips},'error:1020');  //Don't have sufficient chips
							// strClass.outOfChipsPop(client,{chips:resp.fee,flag:'noChips',reqChips:reqChips});
						}
					});
				}
			});
		}
		else{
			c('FTAJDM:::::::::::::::::::::>>>>Error: "category not founds"');
		}
	},
	FTAJPM_old:function(data,client){ //find table and join pool mode; data = {catid}
		/* +-------------------------------------------------------------------+
            desc:event to find pool table and join 
            i/p: data = {catid = category id of table},client = socket object
        +-------------------------------------------------------------------+ */
		c('FTAJPM---------------->>>>>>client.uid: ',client.uid,' data:',data);

		if(data && data.catid){
			cdClass.GetUserInfo(client.uid,{Chips:1,counters:1},function(userInfo){
				if(userInfo){
					if(typeof data.bv != 'undefined' && data.bv != null && data.bv > 0){
						db.collection('pool_category').findOne({fee:data.bv,pCount:data.pCount},function(err,resp){
							if(resp.fee <= userInfo.Chips){

								data.chips = userInfo.Chips;
								data.bv = parseInt(data.bv);
								data.mode = "practice";
								data.pCount = resp.pCount;
								data.pt = data.pt;
								data.lvc = userInfo.counters.lvc; 
								data.theme = (typeof data.theme != 'undefined') ? data.theme : 'cyan';

								playingTableClass.findTableAndJoin(data,client,0);
							}
							else{
								var reqChips = resp.fee;
								commonClass.SendData(client,'PUP', {chips:data.bv*config.MAX_DEADWOOD_PTS,flag:'noChips',reqChips:reqChips},'error:1020');  //Don't have sufficient chips
								// strClass.outOfChipsPop(client,{chips:data.bv*config.MAX_DEADWOOD_PTS,flag:'noChips',reqChips:reqChips});
							}
						});
					}
					else{

						db.collection('pool_category').findOne({_id:MongoID(data.catid)},function(err,resp){
							if(resp.fee <= userInfo.Chips){
								data.gt = 'Pool';
								data.pCount = resp.pCount; /*resp.pCount;*/
								data.bv = resp.fee;
								data.mode = "practice";
								data.pt = data.pt;
								data.lvc = userInfo.counters.lvc; 
								data.theme = (typeof data.theme != 'undefined') ? data.theme : 'cyan';

								if(resp && resp.reke){
									data.reke = resp.reke;
									// data.prize = parseInt(resp.fee*resp.pCount*((100-resp.reke)*0.01));
								}
								else{
									data.reke = 0;
									// data.prize = resp.fee*resp.pCount;
								}
								c('FTAJPM-------------->>>data.reke: '+data.reke);
								playingTableClass.findTableAndJoin(data,client,0);
							}
							else{
								var reqChips = resp.fee;
								commonClass.SendData(client,'PUP',{chips:resp.fee,flag:'noChips',reqChips:reqChips},'error:1020'); //Don't have sufficient chips
								// strClass.outOfChipsPop(client,{chips:resp.fee,flag:'noChips',reqChips:reqChips});
							}
						});
					}
				}
			});
		}
		else{
			c('FTAJPM:::::::::::::::::>>>>>>Error: "category not found "');
		}
	},
	FTAJPM:function(data,client){ //find table and join pool mode; data = {catid}
		/* +-------------------------------------------------------------------+
            desc:event to find pool table and join 
            i/p: data = {catid = category id of table},client = socket object
        +-------------------------------------------------------------------+ */
		c('FTAJPM---------------->>>>>>client.uid: ',client.uid,' data:',data);
		c('FTAJPM---------------->>>>>>client.uid: ',client._ir,' data:',data);

		cdClass.GetUserInfo(client.uid,{Chips:1,totalcash:1,depositcash:1,wincash:1,bonuscash:1,counters:1},function(userInfo){
			if(userInfo){
				if(data && data.catid){
					db.collection('pool_category').findOne({_id:MongoID(data.catid)},function(err,resp){
						if(resp.fee <= userInfo.Chips){
							data.gt = 'Pool';
							data.pCount = resp.pCount; /*resp.pCount;*/
							data.bv = resp.fee;
							data.mode = "practice";
							data.pt = data.pt;
							data.lvc = userInfo.counters.lvc; 
							data.theme = (data.theme != null || typeof data.theme != 'undefined') ? data.theme : 'red';

							if(resp && resp.reke){
								data.reke = resp.reke;
								// data.prize = parseInt(resp.fee*resp.pCount*((100-resp.reke)*0.01));
							}
							else{
								data.reke = 0;
								// data.prize = resp.fee*resp.pCount;
							}
							c('FTAJPM-------------->>>data.reke: '+data.reke);
							playingTableClass.findTableAndJoin(data,client,0);
						}
						else{
							var reqChips = resp.fee;
							commonClass.SendData(client,'PUP',{chips:resp.fee,flag:'noChips',reqChips:reqChips},'error:1020'); //Don't have sufficient chips
							// strClass.outOfChipsPop(client,{chips:resp.fee,flag:'noChips',reqChips:reqChips});
						}
					});
				}
				else{
					db.collection('playing_category').find({pCount:config.PPPP,mode:'practice'}).sort({fee:1}).toArray(function(err,category){
						if(category[0].fee <= userInfo.Chips){
							var tData = {
								bv:category[0].fee,
								chips:userInfo.Chips,
								gt:'pool',
								pt : data.pt,
								lvc:userInfo.counters.lvc,
								mode:"practice",
								theme:(typeof data.theme != 'undefined') ? data.theme : 'cyan',
								pCount:category[0].pCount
							};
							playingTableClass.findTableAndJoin(tData,client,0);  //player seats on higher boot value
						}
						else{
							c('\nFTAJ----else------>>>>>');

							db.collection('playing_category').find({}).sort({cpp:1}).toArray(function(err,category1){

								if(category1 && category1.length > 0){
									var reqChips = category1[0].lBound;
								}	
								else{
									var reqChips = 0;
								}
								commonClass.SendData(client,'PUP', {flag:'noChips',reqChips:reqChips},'error:1020');  //Don't have sufficient chips
								// strClass.outOfChipsPop(client,{flag:'noChips',reqChips:reqChips});
							});
						}
					});
				}
			}
		})
	},
	FTAJPMC:function(data,client){ //find table and join pool mode; data = {catid}
		/* +-------------------------------------------------------------------+
            desc:event to find pool table and join 
            i/p: data = {catid = category id of table},client = socket object
        +-------------------------------------------------------------------+ */
		c('FTAJPMC---------------->>>>>>client.uid: ',client.uid,' data:',data);
		cdClass.GetUserInfo(client.uid,{Chips:1,totalcash:1,depositcash:1,wincash:1,bonuscash:1,counters:1},function(userInfo){
			if(userInfo){
				if(data && data.catid){
					db.collection('pool_category').findOne({_id:MongoID(data.catid)},function(err,resp){
						var cb = resp.fee*config.CASH_BONUS/100;
						if (userInfo.totalcash >= resp.fee && (parseInt(userInfo.depositcash) + parseInt(userInfo.wincash) >= resp.fee || (parseInt(userInfo.depositcash) + parseInt(userInfo.wincash) >= resp.fee-parseInt(cb) && userInfo.bonuscash >= parseInt(cb)))) {
							data.gt = 'Pool';
							data.pCount = resp.pCount; /*resp.pCount;*/
							data.bv = resp.fee;
							data.mode = "cash";
							data.pt = data.pt;
							data.lvc = userInfo.counters.lvc; 
							data.theme = (typeof data.theme != 'undefined') ? data.theme : 'cyan';

							if(resp && resp.reke){
								data.reke = resp.reke;
								// data.prize = parseInt(resp.fee*resp.pCount*((100-resp.reke)*0.01));
							}
							else{
								data.reke = 0;
								// data.prize = resp.fee*resp.pCount;
							}
							c('FTAJPMC-------------->>>data.reke: '+data.reke);
							playingTableClass.findTableAndJoin(data,client,0);
						}
						else{
							var reqChips = resp.fee;
							commonClass.SendData(client,'PUP',{chips:resp.fee,flag:'noChips',reqChips:reqChips},'error:1020'); //Don't have sufficient chips
							// strClass.outOfChipsPop(client,{chips:resp.fee,flag:'noChips',reqChips:reqChips});
						}
					});
				}
				else{
					db.collection('playing_category').find({pCount:config.PPPP,mode:'practice'}).sort({fee:1}).toArray(function(err,category){
						var cb = category[0].fee*config.CASH_BONUS/100;

						if (userInfo.totalcash >= category[0].fee && (parseInt(userInfo.depositcash) + parseInt(userInfo.wincash) >= category[0].fee || (parseInt(userInfo.depositcash) + parseInt(userInfo.wincash) >= category[0].fee-parseInt(cb) && userInfo.bonuscash >= parseInt(cb)))) {
							var tData = {
								bv:category[0].fee,
								chips:userInfo.Chips,
								gt:'pool',
								pt : data.pt,
								lvc:userInfo.counters.lvc,
								mode:"cash",
								theme:(typeof data.theme != 'undefined') ? data.theme : 'cyan',
								pCount:category[0].pCount
							};
							playingTableClass.findTableAndJoin(tData,client,0);  //player seats on higher boot value
						}
						else{
							c('\nFTAJPMC----else------>>>>>');

							db.collection('playing_category').find({}).sort({cpp:1}).toArray(function(err,category1){

								if(category1 && category1.length > 0){
									var reqChips = category1[0].lBound;
								}	
								else{
									var reqChips = 0;
								}
								commonClass.SendData(client,'PUP', {flag:'noChips',reqChips:reqChips},'error:1020');  //Don't have sufficient chips
								// strClass.outOfChipsPop(client,{flag:'noChips',reqChips:reqChips});
							});

						}
					});
				}
			}
		});
	},
	FTAJBM:function(data,client){ //find table and join bet mode; data = {} 
		/* +-------------------------------------------------------------------+
            desc:event to find bet table and join 
            i/p: data = {},client = socket object
        +-------------------------------------------------------------------+ */
		c('FTAJBM---------->>>>>client.uid: '+client.uid+' data: ',data);
		cdClass.GetUserInfo(client.uid,{Chips:1,counters:1},function(userInfo){
			if(userInfo){
				if(data && data.catid){
					db.collection('deal_category').findOne({_id:MongoID(data.catid)},function(err,resp){
						if(resp.cpp*config.MAX_DEADWOOD_PTS <= userInfo.Chips){
							data.chips = userInfo.Chips;
							data.bv = parseInt(resp.cpp);
							data.lvc = userInfo.counters.lvc;
							data.mode = "practice";
							data.pCount = resp.pCount;
							data.theme = (typeof data.theme != 'undefined') ? data.theme : 'cyan';

							playingTableClass.findTableAndJoin(data,client,0);
						}
						else{
							var reqChips = resp.cpp*config.MAX_DEADWOOD_PTS;
							commonClass.SendData(client,'PUP', {chips:reqChips,flag:'noChips',reqChips:reqChips},'error:1020');  //Don't have sufficient chips
							// strClass.outOfChipsPop(client,{chips:data.bv*config.MAX_DEADWOOD_PTS,flag:'noChips',reqChips:reqChips});
						}
					});
				}
				else{

					db.collection('bet_category').find({from:{$lte:userInfo.Chips}}).sort({cpp:-1}).toArray(function(err,category){
						if(category.length > 0 && category[0].cpp*config.MAX_DEADWOOD_PTS <= userInfo.Chips){
							playingTableClass.findTableAndJoin({bv:category[0].cpp,chips:userInfo.Chips,gt : 'Bet',lvc:userInfo.counters.lvc,pCount:data.pCount,mode:'practice'},client,0); //player seats oon higher boot value
						}
						else{
							c('\nFTAJBM----------else------------------>>>>>');

							db.collection('bet_category').find({}).sort({cpp:1}).toArray(function(err,category1){
								if(category1 && category1.length > 0){
									var reqChips = category1[0].from;
								}
								else{
									var reqChips = 0;
								}
								commonClass.SendData(client,'PUP',{flag:'noChips',reqChips:reqChips},'error:1020');  //Don't have sufficient chips
								// strClass.outOfChipsPop(client,{flag:'noChips',reqChips:reqChips});
							});
						}
					});
				}
			}
		});
	},
	FTAJBMC:function(data,client){ //find table and join bet mode; data = {} 
		/* +-------------------------------------------------------------------+
            desc:event to find bet table and join 
            i/p: data = {},client = socket object
        +-------------------------------------------------------------------+ */
		c('FTAJBMC---------->>>>>client.uid: '+client.uid+' data: ',data);
		cdClass.GetUserInfo(client.uid,{totalcash:1,counters:1,depositcash:1,bonuscash:1,wincash:1},function(userInfo){
			if(userInfo){
				// var cash = parseInt(userInfo.depositcash) + parseInt(userInfo.wincash);
				db.collection('bet_category').find({from:{$lte:totalcash}}).sort({cpp:-1}).toArray(function(err,category){
					var ef = category[0].cpp*config.MAX_DEADWOOD_PTS;
					var cb = ef*config.CASH_BONUS/100;
					if (userInfo.totalcash >= ef && (parseInt(userInfo.depositcash) + parseInt(userInfo.wincash) >= ef || (parseInt(userInfo.depositcash) + parseInt(userInfo.wincash) >= ef-parseInt(cb) && userInfo.bonuscash >= parseInt(cb)))) {
						
						playingTableClass.findTableAndJoin({bv:category[0].cpp,chips:userInfo.Chips,lvc:userInfo.counters.lvc,gt:'Bet',pCount:data.pCount,mode:'cash'},client,0); //player seats oon higher boot value
					}
					else{
						c('\nFTAJBMC----------else------------------>>>>>');

						db.collection('bet_category').find({}).sort({cpp:1}).toArray(function(err,category1){
							if(category1 && category1.length > 0){
								var reqChips = category1[0].from;
							}
							else{
								var reqChips = 0;
							}
							commonClass.SendData(client,'PUP',{flag:'noChips',reqChips:reqChips},'error:1020');  //Don't have sufficient chips
							// strClass.outOfChipsPop(client,{flag:'noChips',reqChips:reqChips});
						});
					}
				});
			}
		});
	},
	REFRESH:function(data,client){
		c('REFRESH:----------------->>>>>>>>client.uid: '+client.uid+'----->>>>>>data.tbid: '+data.tbid+'---------->>>>data.si: '+data.si);
		// cdClass.GetTbInfo(data.tbid,{},function(table){
			// c('REFRESH--------------table.pi[data.si].cards:',table.pi[data.si].cards);
			// var gCards = {pure:[],seq:[],set:[],dwd:[table.pi[data.si].cards]};
			db.collection('playing_table').findAndModify({_id:MongoID(data.tbid),tst:'RoundStarted','pi.si': data.si},{},{$set:{la:new Date(),/*'pi.$.gCards':gCards,*/'pi.$.sort':true}},{new:true},function(err,table){
				if(table && table.value){
					
					c('REFRESH-------'+client.tbid+'-------->>>>>>Msg: "cards updated!!!"');
					commonClass.SendData(client,'REFRESH',{/*cards:table.value.pi[data.si].gCards,*/sort:table.value.pi[data.si].sort});
				}
				else{
					c('REFRESH------'+client.tbid+'------->>>>Msg:"cards not updated!!!"');
				}
			});
		// });	
	},
	GTI : function(data,client,cb){  //Get Table Info ; data = {tbid,_isHelp}
		/* +-------------------------------------------------------------------+
            desc:event to get table details
            i/p: data = {tbid = _id of table,_isHelp = 1/0 is help is on or not},client = socket object, cb = callback function
        +-------------------------------------------------------------------+ */
		c('GTI---------------->>>>>>data: ',data);
		cdClass.GetTbInfo(data.tbid,{},function(table){

			if(table){

				if(typeof client.si != "undefined" && !_.isEmpty(table.pi[client.si])){
					table.dealerImg = table.pi[client.si].dealerImg;
					table.dealerId = table.pi[client.si].dealerId;
				}
				else{
					for(var i in table.stdP){
						if(table.stdP[i].uid == client.uid && table.stdP[i].dealerId){
							table.dealerImg = table.stdP[i].dealerImg;
							table.dealerId = table.stdP[i].dealerId;
						}
					}
				}

				if(typeof client.si != "undefined" && !_.isEmpty(table.pi[client.si])){
					if(!_.isEmpty(table.pi[client.si].gCards)){
						var temp = [];
						if(table.pi[client.si].gCards.pure.length > 0){
							for(var j in table.pi[client.si].gCards.pure){
								temp.push(table.pi[client.si].gCards.pure[j])
							}
						}

						if(table.pi[client.si].gCards.seq.length > 0){
							for(var j in table.pi[client.si].gCards.seq){
								temp.push(table.pi[client.si].gCards.seq[j])
							}
						}

						if(table.pi[client.si].gCards.set.length > 0){
							for(var j in table.pi[client.si].gCards.set){
								temp.push(table.pi[client.si].gCards.set[j])
							}
						}

						if(table.pi[client.si].gCards.dwd.length > 0){
							for(var j in table.pi[client.si].gCards.dwd){
								temp.push(table.pi[client.si].gCards.dwd[j])
							}
						}

						table.pi[client.si].gCards = temp;
					}
				}


				table.rejoin = data.rejoin;
				playingTableClass.__InTableConfiguration(table,data._isHelp,client,cb);
			}
			else{
				c('GTI----------------------->>>>"table not found"');
			}
			
		});
	},
	GPT:function(data,client){   //Get Private Table
		/* +-------------------------------------------------------------------+
            desc:event to get the information about various category
            i/p: data = {},client = socket object
            o/p:classicData = classic table category
            	dealData = deal table category
            	poolData = pool table category
            	betData = bet table category
        +-------------------------------------------------------------------+ */
        var classicData = [];
        var dealData = {pCount2:[],pCount5:[]};
        var poolData = {pCount3:[],pCount5:[]};
        var betData = [];
        db.collection('playing_category').find({}).sort({cpp:1}).toArray(function(err,cat1){
        	if(cat1 && cat1.length > 0 ){
        		classicData = cat1;
        	}
        	db.collection('deal_category').find({}).sort({fee:1}).toArray(function(err1,cat2){
        		if(cat2 && cat2.length > 0){
        			
        			for(var i in cat2){
        				if(cat2[i].pCount == 2){
        					dealData.pCount2.push(cat2[i]);
        				}
        				else{
        					dealData.pCount5.push(cat2[i]);
        				}
        			}
        		}
        		db.collection('pool_category').find({}).sort({fee:1}).toArray(function(err2,cat3){
        			if(cat3 && cat3.length > 0){
        				for(var i in cat3){
	        				if(cat3[i].pCount == 3){
	        					poolData.pCount3.push(cat3[i]);
	        				}
	        				else{
	        					poolData.pCount5.push(cat3[i]);
	        				}
	        			}
        			}
        			db.collection('bet_category').find({}).sort({cpp:1}).toArray(function(err3,cat4){
        				if(cat4 && cat4.length > 0){
        					betData = cat4;
        				}
        				commonClass.SendData(client,'GPT',{classicData:classicData,dealData:dealData,poolData:poolData,betData:betData})
        			});
        		});
        	});
        });
	},
	CPT:function(data,client){ //Create Private Table
		/* +-------------------------------------------------------------------+
            desc:event to create private table
            i/p: data = {bv=boot value,gt:gameType,pCount=player count},client = socket object
        +-------------------------------------------------------------------+ */

        cdClass.GetUserInfo(client.uid,{},function(userInfo){
        	if(userInfo){

	        	playingTableClass.findTableExistence(client,false,function(check){
					if(check == 1){
				   
				        if(data.gt == 'Deal'){
				  			if(data.mode == 'practice'){

					        	db.collection('deal_category').findOne({pCount:data.pCount,fee:data.bv},function(err1,category){
									if(category && data.bv <= userInfo.Chips){
										
										reke = category.reke;
										playClass.generateTable({bv: data.bv,_ip:true,lvc:userInfo.counters.lvc,gt:'Deal',mode:data.mode,pCount:data.pCount,reke:reke}, function(tbInfo) {
		                                    playingTableClass.joinSeat(tbInfo._id.toString(), client);
		                                });
									}
									else{
										var reqChips = (data.bv > 0)?data.bv:0;
										// strClass.outOfChipsPop(client,{flag:'noChips',reqChips:reqChips});
									}
								});
				  			}
				  			else if (data.mode == 'cash') {
				  				db.collection('deal_category').findOne({pCount:data.pCount,fee:data.bv},function(err1,category){
									// if(category && data.bv <= userInfo.Chips){
										
									var cb = category.fee*config.CASH_BONUS/100;
									if (userInfo.totalcash >= category.fee && (parseInt(userInfo.depositcash) + parseInt(userInfo.wincash) >= category.fee || (parseInt(userInfo.depositcash) + parseInt(userInfo.wincash) >= category.fee-parseInt(cb) && userInfo.bonuscash >= parseInt(cb)))) {
										reke = category.reke;
										playClass.generateTable({bv: data.bv,_ip:true,lvc:userInfo.counters.lvc,gt:'Deal',mode:data.mode,pCount:data.pCount,reke:reke}, function(tbInfo) {
		                                    playingTableClass.joinSeat(tbInfo._id.toString(), client);
		                                });
									}
									else{
										var reqChips = (data.bv > 0)?data.bv:0;
										// strClass.outOfChipsPop(client,{flag:'noChips',reqChips:reqChips});
									}
									// }
								});
				  			}
				        }
				        else if(data.gt == 'Pool'){
				        	db.collection('pool_category').findOne({_id:MongoID(data.catid)},function(err1,category){

					        	if(category.mode == 'practice'){

									if(category && category.fee <= userInfo.Chips){
										
										reke = category.reke;
										playClass.generateTable({bv: category.fee,_ip:true,lvc:userInfo.counters.lvc,gt:'Pool',mode:category.mode,pCount:category.pCount,reke:reke,pt:category.pt}, function(tbInfo) {
		            
		                                    playingTableClass.joinSeat(tbInfo._id.toString(),data.theme,client);
		                                });
									}
									else{
										// var reqChips = (data.bv > 0)?data.bv:0;
										// strClass.outOfChipsPop(client,{flag:'noChips',reqChips:reqChips});
									}
					        	}
					        	else if (data.mode == 'cash') {
									
									var cb = category.fee*config.CASH_BONUS/100;
									if (userInfo.totalcash >= category.fee && (parseInt(userInfo.depositcash) + parseInt(userInfo.wincash) >= category.fee || (parseInt(userInfo.depositcash) + parseInt(userInfo.wincash) >= category.fee-parseInt(cb) && userInfo.bonuscash >= parseInt(cb)))) {	
										
										reke = category.reke;
										playClass.generateTable({bv: category.fee,_ip:true,lvc:userInfo.counters.lvc,gt:'Pool',mode:category.mode,pCount:category.pCount,reke:reke,pt:category.pt}, function(tbInfo) {
		            
		                                    playingTableClass.joinSeat(tbInfo._id.toString(),data.theme,client);
		                                });
									}
									else{
										// var reqChips = (data.bv > 0)?data.bv:0;
										// strClass.outOfChipsPop(client,{flag:'noChips',reqChips:reqChips});
									}
					        	}
				        	});
				        }
				        else if(data.gt == 'Bet'){
				        	
				        	if (data.mode == 'practice') {
					        	if(data.bv*config.MAX_DEADWOOD_PTS <= userInfo.Chips){
					        		playClass.generateTable({bv: data.bv,mode:data.mode,_ip:true,lvc:userInfo.counters.lvc,gt:'Bet',pCount:data.pCount}, function(tbInfo) {
	                                    playingTableClass.joinSeat(tbInfo._id.toString(), client);
	                                });
					        	}
					        	else{
					        		var reqChips = (data.bv > 0)?data.bv*config.MAX_DEADWOOD_PTS:0;
									// strClass.outOfChipsPop(client,{flag:'noChips',reqChips:reqChips});
					        	}
				        	}
				        	else if (data.mode == 'cash') {
				        		var ef = data.bv*config.MAX_DEADWOOD_PTS;
				        		var cb = ef*config.CASH_BONUS/100;
				        		if (userInfo.totalcash >= ef && (parseInt(userInfo.depositcash) + parseInt(userInfo.wincash) >= ef || (parseInt(userInfo.depositcash) + parseInt(userInfo.wincash) >= ef-parseInt(cb) && userInfo.bonuscash >= parseInt(cb)))) {	
				        			playClass.generateTable({bv: data.bv,mode:data.mode,_ip:true,lvc:userInfo.counters.lvc,gt:'Bet',pCount:data.pCount}, function(tbInfo) {
	                                    playingTableClass.joinSeat(tbInfo._id.toString(), client);
	                                });
				        		}
				        		else{
				        			var reqChips = (data.bv > 0)?data.bv*config.MAX_DEADWOOD_PTS:0;
									// strClass.outOfChipsPop(client,{flag:'noChips',reqChips:reqChips});
				        		}
				        	}
				        }
				        else{
				        	db.collection('playing_category').findOne({_id:MongoID(data.catid)},function(err,resp){

					        	if (resp.mode == 'practice') {

									if(resp.cpp*config.MAX_DEADWOOD_PTS <= userInfo.Chips){
										playClass.generateTable({bv: resp.cpp,gt:'Classic',_ip:true,lvc:userInfo.counters.lvc,mode:resp.mode,pCount:data.pCount,pt:101}, function(tbInfo) {
		                                     
		                                    playingTableClass.joinSeat(tbInfo._id.toString(),data.theme,client);
		                                });
									}
									else{
										var reqChips = (resp.cpp > 0)?resp.cpp*config.MAX_DEADWOOD_PTS:0;
										// strClass.outOfChipsPop(client,{flag:'noChips',reqChips:reqChips});
									}
					        	}
					        	else if (resp.mode == 'cash') {
					        		var ef = resp.cpp*config.MAX_DEADWOOD_PTS;
					        		var cb = ef*config.CASH_BONUS/100;
					        		if (userInfo.totalcash >= ef && (parseInt(userInfo.depositcash) + parseInt(userInfo.wincash) >= ef || (parseInt(userInfo.depositcash) + parseInt(userInfo.wincash) >= ef-parseInt(cb) && userInfo.bonuscash >= parseInt(cb)))) {	
										playClass.generateTable({bv: resp.cpp,gt:'Classic',_ip:true,lvc:userInfo.counters.lvc,mode:resp.mode,pCount:data.pCount,pt:101}, function(tbInfo) {
		                                     
		                                    playingTableClass.joinSeat(tbInfo._id.toString(),data.theme,client);
		                                });
									}
									else{
										var reqChips = (resp.cpp > 0)?resp.cpp*config.MAX_DEADWOOD_PTS:0;
										// strClass.outOfChipsPop(client,{flag:'noChips',reqChips:reqChips});
									}
					        	}
				        	});
				        }
					}
					else{
						c('CPT----------------------->>>"table can not be created"');
					}
				});
        	}
        	else{
        		c('CPT----------------->>>>"user not found"');
        	}
        });
	},
	JFT : function(data,client){ //join friend's table
		/* +-------------------------------------------------------------------+
            desc:fuction used join buddi table.
            i/p: data = {bid = buddi user id}
        +-------------------------------------------------------------------+ */
		if(data.code == ''){
            c('JFT------------>>>>>"invalid id"');
            return;
        }
        cdClass.GetUserInfo(client.uid,{},function(userInfo){
        	if(userInfo){
				
            	db.collection('playing_table').findOne({tjid:data.code,$where:'this.ap < this.ms'},{},function(err1,tbInfo){
                    if(tbInfo){
                    	var cond = true;
                    	if(tbInfo.gt == 'Deal'){
                            if(tbInfo.mode == 'practice'){

	                            cond = _.contains(['','RoundTimerStarted'/*,'RoundStarted'*/],tbInfo.tst) && tbInfo.round == 0;
	                            if(userInfo.Chips < tbInfo.bv){
	                                commonClass.SendData(client,'PUP', {flag:'joinErr'},'error:1020'); //no sufficient chips
	                                return;
	                            }
                            }
                            else{

                            	cond = _.contains(['','RoundTimerStarted'/*,'RoundStarted'*/],tbInfo.tst) && tbInfo.round == 0;
                            	var cb = tbInfo.bv*config.CASH_BONUS/100;
								if (userInfo.totalcash >= tbInfo.bv && (parseInt(userInfo.depositcash) + parseInt(userInfo.wincash) >= tbInfo.bv || (parseInt(userInfo.depositcash) + parseInt(userInfo.wincash) >= tbInfo.bv-parseInt(cb) && userInfo.bonuscash >= parseInt(cb)))) {
									c("good to go...!");
								}
								else{
									commonClass.SendData(client,'PUP', {flag:'joinErr'},'error:1020'); //no sufficient chips
	                                return;
								}
                            }
                        }
                        else if(tbInfo.gt == 'Pool'){
                            if(tbInfo.mode == 'practice'){

	                            cond = _.contains(["","RoundTimerStarted"],tbInfo.tst) && tbInfo.round == 0;
	                            if(userInfo.Chips < tbInfo.bv){
	                                commonClass.SendData(client,'PUP', {flag:'joinErr'},'error:1020'); //no sufficient chips
	                                return;
	                            }
                            }
                            else{
	                            
	                            cond = _.contains(["","RoundTimerStarted"],tbInfo.tst) && tbInfo.round == 0;
	                            var cb = tbInfo.bv*config.CASH_BONUS/100;
								if (userInfo.totalcash >= tbInfo.bv && (parseInt(userInfo.depositcash) + parseInt(userInfo.wincash) >= tbInfo.bv || (parseInt(userInfo.depositcash) + parseInt(userInfo.wincash) >= tbInfo.bv-parseInt(cb) && userInfo.bonuscash >= parseInt(cb)))) {
									c("good to go...!");
								}
								else{
									commonClass.SendData(client,'PUP', {flag:'joinErr'},'error:1020'); //no sufficient chips
	                                return;
								}
                            }
                        }
                        else if(tbInfo.gt == 'Bet'){
                            if(tbInfo.mode == 'practice'){

	                            // cond = !_.contains(['StartDealingCard','CardsDealt','winnerDeclared'],tbInfo.tst);
	                            cond = _.contains(["","RoundTimerStarted"],tbInfo.tst);
	                            if(userInfo.Chips < tbInfo.bv*config.MAX_DEADWOOD_PTS){
	                                commonClass.SendData(client,'PUP', {flag:'joinErr'},'error:1020'); //no sufficient chips
	                                return;
	                            }
                            }
                            else{
	                            
	                            cond = _.contains(["","RoundTimerStarted"],tbInfo.tst);
                            	var ef = tbInfo.bv*config.MAX_DEADWOOD_PTS;
				        		var cb = ef*config.CASH_BONUS/100;
				        		if (userInfo.totalcash >= ef && (parseInt(userInfo.depositcash) + parseInt(userInfo.wincash) >= ef || (parseInt(userInfo.depositcash) + parseInt(userInfo.wincash) >= ef-parseInt(cb) && userInfo.bonuscash >= parseInt(cb)))) {	
									c("good to go...!");
				        		}
				        		else{
				        			commonClass.SendData(client,'PUP', {flag:'joinErr'},'error:1020'); //no sufficient chips
	                                return;
				        		}
                            }
                        }
                        else{ //default condition for classic rummy
                            if(tbInfo.mode == 'practice'){

	                            cond = _.contains(["","RoundTimerStarted"],tbInfo.tst);
	                            if(userInfo.Chips < tbInfo.bv*config.MAX_DEADWOOD_PTS){
	                                commonClass.SendData(client,'PUP', {flag:'joinErr'},'error:1020'); //no sufficient chips
	                                return;
	                            }
                            }
                            else{
	                            
	                            cond = _.contains(["","RoundTimerStarted"],tbInfo.tst);
                            	var ef = tbInfo.bv*config.MAX_DEADWOOD_PTS;
				        		var cb = ef*config.CASH_BONUS/100;
				        		if (userInfo.totalcash >= ef && (parseInt(userInfo.depositcash) + parseInt(userInfo.wincash) >= ef || (parseInt(userInfo.depositcash) + parseInt(userInfo.wincash) >= ef-parseInt(cb) && userInfo.bonuscash >= parseInt(cb)))) {	
									c("good to go...!");
				        		}
				        		else{
				        			commonClass.SendData(client,'PUP', {flag:'joinErr'},'error:1020'); //no sufficient chips
	                                return;
				        		}
                            }
                        }

                        if(cond){ //means table is ready to join
                            //find the seat and join logic here
                            c('JFT------------>>>>>>"table join"');
                            //trackClass.TEA({table:'track_primary_data',category:'game',label:'player_joined_via_invite',option:client.uid,action:userInfo.un},{uid:client.uid}); 
                            if(userInfo.tbid == ''){ //means user is not playing in table
                                c('JFT---------------->>>>>"user is not playing in any table"');
                                playingTableClass.joinSeat(tbInfo._id.toString(),'red',client);
                            }
                            else{ //means user is playing some table so remove from table first
                                c('JFT------------>>>>"user is playing in table"');
                                playingTableClass.findTableExistence(client,true,function(check){
                                    if(check == 1){
                                        c('JFT------------>>>>>"join table"');
                                        playingTableClass.joinSeat(tbInfo._id.toString(),'cyan',client);
                                    }
                                    else{
                                        c('JFT------------>>>>>"unable to join table"');
                                    }
                                });
                            } 
                        }
                        else{
                            c('JFT------------>>>>>"game is running can\'t join the table"');
                            commonClass.SendData(client,'PUP',{flag: 'joinErr'},'error:1027'); //game is running so can't join the table  
                        }
                    }
                    else{	
                        c('JFT------------>>>>>"table not found or no seat are there to seat"');
                        commonClass.SendData(client,'PUP',{flag:'joinErr'},'error:1029'); //no empty seat available 
                    }
                });
        	}
        	else{
        		c('JFT------------->>>>>"user not found"');
        	}
        })
	},
	LASTDEAL: function(data,client){
		c("LASTDEAL-------------------------data: ",data);
		db.collection('last_deal').findOne({tbid:data.tbid.toString(),"pi.uid":client.uid.toString()},function(err1,lddata){
			if(lddata){
				c("LASTDEAL-------------------------data: ",data);
				commonClass.SendData(client,'LASTDEAL',lddata);
			}
			else{
				commonClass.SendData(client, 'PUP', {flag:'ld'}, 'error:1050');
			}
		});
	},
	GPTI : function(data,client){
		db.collection('playing_table').findOne({_id:MongoID(data.tbId.toString())},function(err,tbData) {
			if(tbData){

				if(tbData.ms == 2){
					var tn = 'TwoPlayer_' + tbData.tjid;
				}
				else if(tbData.ms == 4){
					var tn = 'FourPlayer_' + tbData.tjid;
				}
				else if(tbData.ms == 6){
					var tn = 'SixPlayer_' + tbData.tjid;
				}

				// gid : tbData.round,
				var tdata = {
					extra : config.SECONDARY_TIMER + ' Sec',
					move : config.STT + ' Sec',
					max_extra : config.SECONDARY_TIMER / config.MAX_TIMEOUT + ' Sec',
					table_name : tn,
					gid : tbData.tjid,
					game_type : tbData.mode,
					point_value : tbData.bbv,
					variant : 13 + ' Cards ' + tbData.gt,
					decks : 2,
					first_drop : config.FIRST_DROP * 100,
					middle_drop : config.MIDDLE_DROP * 100
				};

				commonClass.SendData(client,'GPTI',tdata);
			}
		});
	},
	__InTableConfiguration: function(result,_isHelp,client,cb){
		/* +-------------------------------------------------------------------+
            desc:function to set table configurations
            i/p: result = table details,_isHelp = 1/0 is help is enabled or not,client = socket object, cb = callback function
        +-------------------------------------------------------------------+ */
		if(!result){
			return false;
		}
		c('playingTableClass -- >> __InTableConfiguration' + result._id);
		var tbId = result._id.toString();
		var st = new Date();
		
		//client.tbid = tbId; //saving current table to session.	
		var rst = config.RST;
		var stt = config.STT;
		var fns = config.FNS;
		
		//getting Timer information to client so they can show timer on profile picture
		result.maxRst = rst;
		result.secT = false;
		if(result.tst == "RoundTimerStarted"){

			result.Timer = parseInt(rst)- commonClass.GetTimeDifference(result.ctt, st,'second');
		}
		else if (result.tst == "RoundStarted" ){
			result.Timer =  parseInt(stt) - commonClass.GetTimeDifference(result.ctt, st,'second');

			if(result.Timer <= 0){

				var time = config.SECONDARY_TIMER / config.MAX_TIMEOUT;
				c('__InTableConfiguration--------1--------->>>>time: '+time);
				var t = result.pi[result.turn].secTime;
				/*if(t > time){
					t = time;
				}*/

				stt = stt + t;
				result.secT = true;
				result.Timer =  parseInt(stt) - commonClass.GetTimeDifference(result.ctt, st,'second');
			} 
		}
		else if(result.tst == "Finished"){
			result.Timer = parseInt(fns) - commonClass.GetTimeDifference(result.ctt , st , 'second');	
		}
		else{
			result.Timer = 0;	
		}
		result._isHelp = _isHelp;

		var pi = result.pi;
		var aSi = [];
		for(var k in pi){
			if(!_.isEmpty(pi[k]) && typeof pi[k].si != 'undefined' && (pi[k].s == 'playing' || pi[k].s == 'finish' || pi[k].s == 'declare')){
				aSi.push(pi[k].si);
			}

			if(pi[k].theme == null || typeof pi[k].theme == 'undefined'){
				pi[k].theme == 'red';
			}
		}

		result.asi = aSi;
		if(result.gt == 'Bet'){
			var scaleN = config.BET_RAISE_SCALE;
			if(scaleN == 0){
				scaleN = 5;
			}
			var scale = Math.round(result.maxBet/scaleN);
			scale = scale-scale%50;
			scale = (scale == 0) ? 50 : scale;
		}
		else{
			scale = 0;
		}

		result.scale = scale;

		cdClass.GetUserInfo(client.uid,{},function(userInfo){
			if(userInfo){

				c('__InTableConfiguration---------->>>>>lort: ',userInfo.lasts.lort);

				if(userInfo.lasts.lort == ''){
					result.deal_timer = 0;
				}
				else {

					var diff = commonClass.GetTimeDifference(userInfo.lasts.lort,new Date()); //how much time spent after closing offer
					c('__InTableConfiguration------------>>>>>>diff: ',diff);

					var timer = config.DEAL_BTN_TIMER*60; //convert into sec
					if(diff <= timer){
						var remain = timer - diff;
						result.deal_timer = remain;
					}
					else{
						result.deal_timer = 0;
					}
				}
				commonClass.SendData(client,'GTI',result);

			}

			if(typeof cb == 'function'){
				cb();
			}
		});
	},
	findTableExistence:function(client,onInvite,cb){
		/* +-------------------------------------------------------------------+
            desc:function to check whether the user is set on any table or not
            i/p: client = socket object,onInvite = true/false if called when user is invited by someone,cb = callback function
        +-------------------------------------------------------------------+ */
		db.collection('playing_table').find({$or:[{'pi.uid':client.uid},{'stdP.uid':client.uid}]}).project({pi:1}).toArray(function(err,table){
			c('findTableExistence------------->>>>>>>table: ',table);
			
			if(table && table.length > 0){
				for(var i in table[0].pi){

					if(!_.isEmpty(table[0].pi[i]) && table[0].pi[i].uid == client.uid){
						c('findTableExistence-------------->>>>>>player on playing table');
						client.tbid = table[0]._id.toString();
						client.si = table[0].pi[i].si;
						client.gt = table[0].gt;
						playClass.LT({flag:"remain",onInvite:onInvite},client,function(check){
							if(typeof cb == 'function'){
								c("findTableExistence----1---->>>>>check :",check);
								cb(check);
							}
						});
						return;
					}
				}
				//means player is in standup
				c('findTableExistence---------------->>>>>>player is standup');
				client.tbid = table[0]._id.toString();
				c('findTableExistence-------------->>>>si: '+client.si+'  client.tbid: '+client.tbid);
				playClass.LT({flag:"remain",onInvite:onInvite},client,function(check){
					if(typeof cb == 'function'){
						c("findTableExistence-----2---->>>>>check :",check);
						cb(check);
					}
				});		
			}
			else{
				cb(1);
			}
		});
	},
	findTableAndJoin : function(data,client,fCount){ // : data = {gt,pCount,reke,bv,chips} ; table finding function    //reke and pCount iff gt == Deal or Pool
		/* +-------------------------------------------------------------------+
            desc:generic function to find table for user 
            i/p: data = {gt = game type,pCount = max player count,reke = reke to cut if any,bv = boot value of table,chips = chips of user}
        +-------------------------------------------------------------------+ */
		playingTableClass.findTableExistence(client,false,function(check){

			c('findTableAndJoin--------------->>>>>>check: '+check);
			data.mode = (typeof data.mode != 'undefined') ? data.mode : 'practice';
			data.pCount = (typeof data.pCount != 'undefined') ? data.pCount : 2;
			data.pt = (typeof data.pt != 'undefined') ? data.pt : 101;
			if(check == 1){

				//playClass.isFirstTimeUser(client.uid,function(isSpc,RobotCount,HumanCount){

					if(data.gt && data.gt == 'Deal'){ //if user want to play deal rummy
						/*if(isSpc){
							c('\nfindTableAndJoin-------deal------>>>>"first timer user"');
							playClass.generateTable({bv:data.bv,repick:1,pCount:data.pCount,reke:data.reke,gt:'Deal'},function(tbInfo){
								//join table logic here 
								playingTableClass.joinSeat(tbInfo._id.toString(),client);
							});
						}*/
						// else{

							var where = {
								$and:[
									{
										_ip:{$ne:1},
										bv: data.bv,
										gt:'Deal',
										ap:{$lt:data.pCount},
										mode:data.mode,
										uCount:{$gt:0},
										ms: data.pCount,
										'pi.uid':{$ne:client.uid},
										'stdP.uid':{$ne:client.uid},
										/*$or : [
											{lvc:{$lt:data.lvc}},
											{lvc:{$gt:data.lvc}}
										],*/
										tst: {
											$in:["","RoundTimerStarted"]
										},
										round:0
									}/*,
									{
										$or:[
											{
												spcSi:{$ne:-1},
												$where : 'this.uCount < this.HumanCount+1'
											},
											{
												spcSi:-1
											}
										]
									}*/		
								]
							};
							db.collection('playing_table').find(where).limit(10).toArray(function(err,resp){
								if(resp.length > 0){  //user found appropriate table
									//join table logic here
									playingTableClass.joinSeat(resp[0]._id.toString(),data.theme,client);
								}
								else{
									//table generate logic here


									playClass.generateTable({bv:data.bv,lvc: data.lvc,pCount:data.pCount,reke:data.reke,gt:'Deal',mode:data.mode},function(tbInfo){
										//join table logic here 
										playingTableClass.joinSeat(tbInfo._id.toString(),data.theme,client);
									});
								}
							});
						// }
					}	
					else if(data.gt && data.gt == 'Pool'){//if user wants to play pool rummy

						/*if(isSpc){
							c('\nfindTableAndJoin------pool------->>>>>"first time user"');
							playClass.generateTable({bv:data.bv,repick:1,pCount:data.pCount,reke:data.reke,gt:'Pool'},function(tbInfo){
								///join table logic here 
								playingTableClass.joinSeat(tbInfo._id.toString(),client);
							});
						}*/
						// else{

							var where = {
								$and:[
									{
										_ip:{$ne:1},
										bv:data.bv,
										gt:'Pool',
										ap:{$lt:data.pCount},
										mode:data.mode,
										ms:data.pCount,
										pt:data.pt,
										/*"pi.ip":{$ne: data.ip},*/
										/*$or : [
											{lvc:data.lvc},
											{lvc:parseInt(data.lvc) + 1},
											{lvc:parseInt(data.lvc) - 1}
										],*/
										'pi.uid':{$ne:client.uid},
										'stdP.uid':{$ne:client.uid},
										tst:{
											$in:["","RoundTimerStarted"]
										},
										round:0
									}/*,
									{
										$or:[
											{
												spcSi:{$ne:-1},
												$where : 'this.uCount < this.HumanCount+1'
											},
											{
												spcSi:-1
											}
										]
									}*/	
								]
							};
							db.collection('playing_table').find(where).limit(10).toArray(function(err,resp){
								if(resp.length > 0){ //user found appropriate table
									//join table logic here
									playingTableClass.joinSeat(resp[0]._id.toString(),data.theme,client);
								}
								else{
									//table generate logic here

									playClass.generateTable({bv:data.bv,pCount:data.pCount,lvc: data.lvc,reke:data.reke,gt:'Pool',pt:data.pt,mode:data.mode},function(tbInfo){
										///join table logic here 
										playingTableClass.joinSeat(tbInfo._id.toString(),data.theme,client);
									});
								}
							});
						// }
					}
					else if(data.gt && data.gt == 'Bet'){ //if user wants to play bet rummy

						/*if(isSpc){
							c('\nfindTableAndJoin-------bet------>>>>>"first time user"');
							playClass.generateTable({bv:data.bv,gt:'Bet'},function(tbInfo){
								c('\nfindTableAndJoin----else----------->>>>>>');
								playingTableClass.joinSeat(tbInfo._id.toString(),client);
							});
						}*/
						// else{

							if(data.tbid){
								var where = {
									$and:[
										{
											_ip:{$ne:1},
											bv:data.bv,
											gt:'Bet',
											mode:data.mode,
											_id:{$ne:MongoID(data.tbid)},
											ap:{$lt:data.pCount},
											'pi.uid':{$ne:client.uid},
											'stdP.uid':{$ne:client.uid},
											tst:{
												$in:["", "RoundTimerStarted"]
											}
										}/*,
										{
											$or:[
												{
													spcSi:{$ne:-1},
													$where : 'this.uCount < this.HumanCount+1'
												},
												{
													spcSi:-1
												}
											]
										}*/
									]
								};
							}
							else{
								var where = {
									$and:[
										{
											_ip:{$ne:1},
											bv:data.bv,
											gt:'Bet',
											mode:data.mode,
											ap:{$lt:{pCount:data.pCount}},
											'pi.uid':{$ne:client.uid},
											'stdP.uid':{$ne:client.uid}, 
											tst:{
												$in: ["", "RoundTimerStarted"]
											}
										}/*,
										{
											$or:[
												{
													spcSi:{$ne:-1},
													$where : 'this.uCount < this.HumanCount'
												},
												{
													spcSi:-1
												}
											]
										}*/
									]
								}
							}

							db.collection('playing_table').find(where).toArray(function(err,resp){
								if(resp.length > 0){ //user found appropriate
									c('\nfindTableAndJoin----if---->>>>>');
									playingTableClass.joinSeat(resp[0]._id.toString(),data.theme,client);
								}
								else{
									//table generate logic here
									playClass.generateTable({bv:data.bv,gt:'Bet',lvc: data.lvc},function(tbInfo){
										c('\nfindTableAndJoin----else----------->>>>>>');
										playingTableClass.joinSeat(tbInfo._id.toString(),data.theme,client);
									});
								}
							});
						// }
					}
					else{

						/*if(isSpc && config.PLAYING_CATEGORIES){
							c('\nfindTableAndJoin------classic------->>>"first timer user with category"');
                        	playClass.generateTable({
                                bv: data.bv,
                                repick: 1
                            }, function(tbInfo) {
                                c('\nfindTableAndJoin----else----------->>>>>>');
                                playingTableClass.joinSeat(tbInfo._id.toString(), client);
                            });
                        }
                        else if(isSpc){
                        	c('\nfindTableAndJoin-----classic-------->>>>>"first timer user without category"');
                        	db.collection('playing_category').find({lBound:{$lte:data.chips}}).sort({cpp:-1}).toArray(function(err1,catData1){
								c('findTableAndJoin------------>>>>catData1: ',catData1);
								if(catData1 && catData1.length > 0 && catData1[0].cpp*config.MAX_DEADWOOD_PTS <= data.chips){

									playClass.generateTable({bv:catData1[0].cpp,repick:1},function(tbInfo){
										c('\nfindTableAndJoin----else----->>>>>');
										playingTableClass.joinSeat(tbInfo._id.toString(),client);
									});
								}
								else{
									c('\nfindTableAndJoin--------if------>>>>no sufficient chips');
									var reqChips = catData1[0].cpp*config.MAX_DEADWOOD_PTS;
									commonClass.SendData(client,'PUP', {flag:'noChips',reqChips:reqChips},'error:1020');  //Don't have sufficient chips
									// strClass.outOfChipsPop(client,{flag:'noChips',reqChips:reqChips});
								}
							});
                        }*/
                        //else{

							if(data.tbid){

								// var where = {bv:data.bv,gt:'Classic',_id: {$ne:MongoID(data.tbid)}, ap:{$lt:5},'pi.uid':{$ne:client.uid},'stdP.uid':{$ne:client.uid}, tst:{$nin:['StartDealingCard','CardsDealt','RoundStarted','winnerDeclared']}};
								var where = {
									$and:[
										{
											_ip:{$ne:1},
											bv:data.bv,
											mode:data.mode,
											gt:'Classic',
											uCount:{$gt:0},
											_id: {$ne:MongoID(data.tbid)}, 
											ap:{$lt:data.pCount},
											/*"pi.ip":{$ne: data.ip},*/
											ms:data.pCount,
											/*$or : [
												{lvc:data.lvc},
												{lvc:parseInt(data.lvc) + 1},
												{lvc:parseInt(data.lvc) - 1}
											],*/
											'pi.uid':{$ne:client.uid},
											'stdP.uid':{$ne:client.uid}, 
											tst:{
												$in: ["", "RoundTimerStarted"]
											}
										}/*,
										{
											$or:[
												{
													spcSi:{$ne:-1},
													$where : 'this.uCount < this.HumanCount+1'
												},
												{
													spcSi:-1
												}
											]
										}*/
									]
								}
							}
							else{
								var where = {
									$and:[
										{
											_ip:{$ne:1},
											bv:data.bv,
											mode:data.mode,
											gt:'Classic',
											uCount:{$gt:0},
											ap:{$lt:data.pCount},
											ms:data.pCount,
											/*"pi.ip":{$ne: data.ip},*/
											/*$or : [
												{lvc:data.lvc},
												{lvc:parseInt(data.lvc) + 1},
												{lvc:parseInt(data.lvc) - 1}
											],*/
											'pi.uid':{$ne:client.uid},
											'stdP.uid':{$ne:client.uid}, 
											tst:{
												$in: ["", "RoundTimerStarted"]
											}
										}/*,
										{
											$or:[
												{
													spcSi:{$ne:-1},
													$where : 'this.uCount < this.HumanCount+1'
												},
												{
													spcSi:-1
												}
											]
										}*/
									]
								};
							}
							c('\n findTableAndJoin------------------>>>>>>where: ',where);
							db.collection('playing_table').find(where).toArray(function(err,resp){
								if(resp && resp.length > 0 ){    //user found appropriate table to play
									c('\nfindTableAndJoin----if----->>>>>');
									playingTableClass.joinSeat(resp[0]._id.toString(),data.theme,client);
								}
								else{ 
									//no table found
		                            c('\nfindTableAndJoin------------->>>>>>>>>"create a new table with the same specs"');

		                            
		                            if (config.PLAYING_CATEGORIES) {
		                                c('\nfindTableAndJoin------------->>>>>>"PLAYING_CATEGORIES is enabled"');
		                                playClass.generateTable({
		                                    bv: data.bv,
		                                    mode: data.mode,
		                                    pCount: data.pCount,
		                                    lvc: data.lvc
		                                }, function(tbInfo) {
		                                    c('\nfindTableAndJoin----else----------->>>>>>');
		                                    playingTableClass.joinSeat(tbInfo._id.toString(), data.theme, client);
		                                });
		                            }

		                            //so check the category one step down
		                            else if(typeof fCount != 'undefined' && fCount != null && fCount < config.FIND_TABLE_ATTEMPT){  //table find attempt remains
										db.collection('playing_category').find({cpp:{$lt:data.bv}}).sort({cpp:-1}).toArray(function(err,catData){
											if(catData.length > 0){   //if category left then find the table of that category
												playingTableClass.findTableAndJoin({bv:catData[0].cpp,chips:data.chips,tbid:data.tbid},client,fCount+1);
											}
											else{  //no category left so generate table as per the original chips per point
												c('findTableAndJoin---------->>>>>>data.chips: ',data.chips);
												db.collection('playing_category').find({lBound:{$lte:data.chips}}).sort({cpp:-1}).toArray(function(err1,catData1){
													c('findTableAndJoin------------>>>>catData1: ',catData1);
													if(catData1 && catData1.length > 0 && catData1[0].cpp*config.MAX_DEADWOOD_PTS <= data.chips){

														playClass.generateTable({bv:catData1[0].cpp,lvc: data.lvc,mode:data.mode,pCount: data.pCount},function(tbInfo){
															c('\nfindTableAndJoin----else----->>>>>');
															playingTableClass.joinSeat(tbInfo._id.toString(),data.theme,client);
														});
													}
													else{
														c('\nfindTableAndJoin--------if------>>>>no sufficient chips');
														var reqChips = catData1[0].cpp*config.MAX_DEADWOOD_PTS ;
														commonClass.SendData(client,'PUP', {flag:'noChips',reqChips:reqChips},'error:1020');  //Don't have sufficient chips
														// strClass.outOfChipsPop(client,{flag:'noChips',reqChips:reqChips});
													}
												});
											}
										});
									}
									else{   //table attempt finish so generate table as per original chips per point

										db.collection('playing_category').find({lBound:{$lte:data.chips}}).sort({cpp:-1}).toArray(function(err1,catData1){
											c('findTableAndJoin---------->>>>>catData1: ',catData1);
											if(catData1 && catData1.length > 0 && catData1[0].cpp*config.MAX_DEADWOOD_PTS <= data.chips){

												playClass.generateTable({bv:catData1[0].cpp,lvc: data.lvc,mode:data.mode,pCount: data.pCount},function(tbInfo){
													c('\nfindTableAndJoin----else----->>>>>');
													playingTableClass.joinSeat(tbInfo._id.toString(),data.theme,client);
												});
											}
											else{
												c('\nfindTableAndJoin----else------------->>>>>no chips');
												var reqChips = catData1[0].cpp*config.MAX_DEADWOOD_PTS;
												commonClass.SendData(client,'PUP', {flag:'noChips',reqChips:reqChips},'error:1020');  //Don't have sufficient chips
												// strClass.outOfChipsPop(client,{flag:'noChips',reqChips:reqChips});
											}
										});
									}
									
								}
							});
                        //}
					}
				//});
			}
			else{
				c('findTableAndJoin------------------>>>>>>table can\'t be join');
			}
		});
		// db.collection('playing_table').find({bv:data.bv,ap:{$lt:4},tst:{$in:['','RoundTimerStarted']}}).limit(5).toArray(function(err,resp){
	},
	findEmptySeat: function (pi) {
		/* +-------------------------------------------------------------------+
            desc:function to find empty seat for player
            i/p: pi = details of player on table
        +-------------------------------------------------------------------+ */
		//console.log("findEmptySeat >>",pi);
		for (x in pi){

			if (typeof pi[x] == 'object' && pi[x] != null && typeof pi[x].si == 'undefined')
			{
				return parseInt(x);
				break;
			}
		}
		return -1;
	},
	joinSeat_old: function(tbId, client,isQst){ //data = table data
		/* +-------------------------------------------------------------------+
            desc:function to join seat for user
            i/p: tbId = _id of table,client = socket object
        +-------------------------------------------------------------------+ */
		// cdClass.GetTbInfo(tbId,{},function(tbData){
		c('joinSeat-------------->>>>>client._ir:'+client._ir+' client.uid: '+client.uid+' tbId: '+tbId);
		db.collection('playing_table').findOne({_id:MongoID(tbId.toString()),ap:{$lt:5}},function(err,tbData) {
			if(!tbData){
				c('joinSeat::::::::::::::::::>>>>>>>Error: "tbData not found!!!"');
				return false;
			}

			cdClass.GetUserInfo(client.uid,{_id:1,un:1,pp:1,flags:1,Chips:1,wc:1,tbid:1,counters:1},function(userInfo){
				if(userInfo){

					//playClass.isFirstTimeUser(userInfo._id.toString(),function(isSpc,RobotCount,HumanCount){
						//console.log("joinSeat----------->>>>>>>isSpc :"+isSpc+"RobotCount :"+RobotCount+"HumanCount :"+HumanCount)
						if(client.isInvite){
							// isSpc = false;
							delete client.isInvite;
						}
						/*if(tbData._ip == 1){ //means  table is private so user should not consider as first time user
							isSpc = false;
						}*/

						var seat = playingTableClass.findEmptySeat(tbData.pi);
						if(seat == -1 && userInfo.flags._ir == 0){  //seat not found
							c('joinSeat----------->>>>>>seat == -1');
							playingTableClass.findTableAndJoin({gt: tbData.gt,pCount: tbData.ms,bv:tbData.bv,reke:tbData.reke,mode: tbData.mode,chips: userInfo.Chips,tbid:tbData._id.toString()},client,0);
							return false;   ///if game stucks look here
						}
						else if(seat == -1 && client._ir == 1){
							c('joinSeat--------------->>>>>Msg:"no seat for robot!!!"');
							return false;   ///if game stucks look here
						}

						var rType = '';
						var uName = userInfo.un;
						if(client._ir == 1){
							if(client.rType){
								rType = client.rType;
								// uName = client.rType;
							}
							else{
								rType = 'Newbie';
								// uName = 'Newbie';
							}
						}

						c('joinSeat------------>>>>>userInfo: ',userInfo);
						var sts = '';

						if( (_.contains(['Classic','Bet'],tbData.gt) &&  !_.contains(["","RoundTimerStarted"],tbData.tst)) || (_.contains(['Deal','Pool'],tbData.gt) && ( !_.contains(["","RoundTimerStarted"],tbData.tst) || tbData.round > 0 ))   ){
							sts = 'watch';
						}

						var di = "uploads/NewDealerImage/Dealer-1_1533300586.png"; 
						var id = "5b644f731bfdb4fe67fa3be7";

							var updateInfo = {
								uid : userInfo._id.toString(),   				//	user id
								jt : new Date(),					    		//	join time
								gst : new Date(),								//  game start time
								gedt : new Date(),								//  game end time
								rndCount : 0,									//  round count
								si : seat,										//	seat index
								un : uName,										//	user name
								pp : userInfo.pp,								//	profile picture 
								Chips: userInfo.Chips,							// 	player chips
								_ir : userInfo.flags._ir,						//	is robot or not 
								rType : rType,									// 	robot type not applicable for user
			 					s : sts,										//	status
								GiftId:'',										//  gift id
								GiftType:'',									//	GiftType
								dealerImg:di,									//  dealer image
								dealerId:id,									//  dealer id
								play : 0,										//  is playing in current deal
								tCount : 0,										//	timeout count				
								ps : 0,											//	cards points (deadwood)
								dps : 0,										//  deal total points
								bet : tbData.bv,								//  bet set by players
								cards : [],										//	player cards
								gCards : [],									//  group cards formatted array
								dCards : {},									//  declared cards
								score : 0,										//	user score
								wc : 0,											//  win chips
								pts : 0,										//  points to be multiplied with bv
								pickCount: 0,									//  cards pick count
								//isSpc:isSpc,									//  is special user
								thp : userInfo.counters.thp,					//  total game played by user		
								lpc : '',										//	last picked card
								_iw : 0,										//  is winner or not 
								isCollect : 0,									//	is boot value collected
								isQst:isQst?true:false,							//  is user has came from quest play now button or not
								lgR : 0,   										// 	league rank
								lgN : 0 										// 	league no
							}
							c('joinSeat----------->>>>>tbData.jid: ',tbData.jid);
							
							// jtClass.cancelJobOnServers(tbData._id.toString(),tbData.jid);


							c('joinSeat-----1111111---->>> name: ',userInfo.un,'seat: ',seat,' tableid: ',tbData._id);
							
							
							var Chips = userInfo.Chips;
							
							var where = {_id:MongoID(tbData._id.toString())};
							where['pi.'+seat+'.si'] = {$exists:false};
							
							var extraChips = 0;  
							var cond = false;
							var cpp = 0;
							if(config.MAX_DEADWOOD_PTS > 0){

								cpp = (tbData.gt == 'Deal' || tbData.gt == 'Pool') ? tbData.bv/config.MAX_DEADWOOD_PTS:tbData.bv;
							}
							c('joinSeat------------------------>>>>>>cpp: '+cpp);
							db.collection('robot_chips').find({lowerCpp:{$lte:cpp}}).sort({lowerCpp:-1}).toArray(function(error,robotChips){

								if(robotChips && robotChips.length > 0 && client._ir == 1){
									c('joinSeat---------------------->>>>>>robotChips: ',robotChips);
									var robotExtraChips = 0;
									robotExtraChips = commonClass.GetRandomInt(robotChips[0].lowerChips,robotChips[0].upperChips);
									c('joinSeat------------1---------->>>>>>>robotExtraChips: '+robotExtraChips);
									robotExtraChips = robotExtraChips - robotExtraChips%100;  //rounding robot chips  to 100
									extraChips = robotExtraChips - Chips;
									Chips = robotExtraChips;
									cond = true;
									c('joinSeat----------2------------->>>>>>extraChips: '+extraChips+' Chips: '+Chips);
								}
								

								var extraMulti = 1;

								if(rType == 'Newbie'){
									extraMulti = 1.5;
								}
								else if(rType == 'Amateur'){
									extraMulti = 2;
								}
								else if(rType == 'Pro'){
									extraMulti = 2.5;
								}
								else if(rType == 'God'){
									extraMulti = 3;
								}
								else{
									extraMulti = 1;
								}



								var cond1 = (tbData.gt == 'Deal' || tbData.gt == 'Pool') ? Chips < tbData.bv : Chips < (tbData.bv*config.MAX_DEADWOOD_PTS);
								if(client._ir == 1){


									if(cond1){  
										if(tbData.gt == 'Deal' || tbData.gt == 'Pool'){
											extraChips = tbData.bv*extraMulti;
										}
										else{
											extraChips = tbData.bv*config.MAX_DEADWOOD_PTS*extraMulti;
										}

										Chips = userInfo.Chips+extraChips; 

									}
									updateInfo.Chips = Chips;
								}

								playClass.getUserScore(updateInfo.uid,tbData.bv,tbData.gt,function(score){
									updateInfo.score = score;

									


									eval('var upData = {$set : {la:new Date(),"pi.'+seat+'":updateInfo},$inc:{ap:1}}');

									/*if(isSpc){
										upData.$set.spcSi = seat;
										upData.$set.nrg = 1;
										upData.$set.minS = RobotCount+1;
										upData.$set.RobotCount = RobotCount;
										upData.$set.HumanCount = HumanCount;
									}*/

									if(client._ir == 0){
										upData.$inc.uCount = 1;
									}


									db.collection('playing_table').findAndModify(where,{},upData,{new:true},function(err1,resp){
										resp = resp.value;
										c('joinSeat------222222222--->>> name: ',userInfo.un,'seat: ',seat,' tableid: ',tbData._id);

										if(!resp){
											if(client._ir == 0){  //seat not found
												c('joinSeat----------->>>>>>MSG:"seat occupied"');
												playingTableClass.findTableAndJoin({gt: tbData.gt,pCount: tbData.ms,bv:tbData.bv,reke:tbData.reke,chips:Chips,tbid:userInfo.tbid},client,0);
												return false;   ///if game stucks look here
											}
											else if(client._ir == 1){
												c('joinSeat--------------->>>>>Msg:"no seat for robot!!!"');
												return false;   ///if game stucks look here
											}
											else{
												return false;   ///if game stucks look here
											}
										}

										
										var _isHelp = 0; 
										var deal_c = userInfo.counters.deal_c;
										var pool_c = userInfo.counters.pool_c;
										var bet_c = userInfo.counters.bet_c;
										if(deal_c < config.DEAL_TUTF_SES && resp.gt == 'Deal'){
											deal_c++;
											_isHelp = 1;
										}
										else if(pool_c < config.POOL_TUTF_SES && resp.gt == 'Pool'){ // flag for help screen for pool rummy
											pool_c++;
											_isHelp = 1;
										} 
										else if(bet_c < config.BET_TUTF_SES && resp.gt == 'Bet'){
											bet_c++;
											_isHelp = 1;
										}
										c('joinSeat------333333--->>> name: '+userInfo.un+'seat: '+seat+' tableid: '+tbData._id+' updateInfo: ',updateInfo,' _isHelp: '+_isHelp);
										
										
										playingTableClass.GTI({"tbid": resp._id.toString(),_isHelp:_isHelp,"rejoin":0}, client,function(){

											if(client._ir == 0){
												

												var single = client.sck.replace(SERVER_ID+".","");
												c('joinSeat-----before----->>>>connected sockets: ',io.sockets.adapter.rooms[resp._id.toString()]);
												c('joinSeat--------->>>>>>single: ',single);
												if(io.sockets.connected[single]){
													io.sockets.connected[single].join(resp._id.toString());
													
													client.tbid = resp._id.toString(); //adding  tableid to client
													client.si = seat; //adding seat index to client
													client.gt = resp.gt;
													
												}
												c('joinSeat-----after----->>>>connected sockets: ',io.sockets.adapter.rooms[resp._id.toString()]);
												c('joinSeat---------->>>>>>>>client.tbid: ',client.tbid,' client.si: ',client.si);
												cdClass.UpdateUserData(userInfo._id,{$set:{tbid:resp._id.toString(),bv:resp.bv,sck:client.sck,"counters.deal_c":deal_c,"counters.pool_c":pool_c,"counters.bet_c":bet_c}},function(userInfo1){});
											}
											else{
												// if(userInfo.Chips < resp.bv*config.MAX_DEADWOOD_PTS){  
												var rSck = SERVER_ID+'.'+commonClass.GetRandomString(20);
												var game_id = tbData.game_id;
												var sub_id = tbData.sub_id;

												if(_.contains(['','RoundTimerStarted','CollectingBootValue','StartDealingCard'],tbData.tst)){
									                game_id = game_id+1;
									                sub_id = sub_id+1;
									            }
									            
									            if(tbData.gt == 'Deal' || tbData.gt == 'Pool'){ 


									                if(tbData.round == 0){
									                    game_id = game_id+'.1';
									                    
									                }
									                else{
									                    game_id = game_id+'.'+sub_id;

									                }
									                
									            }


												c('joinSeat-------------->>>>>>rSck: ',rSck);
												if(cond || cond1){
													cdClass.UpdateUserChips(userInfo._id.toString(),extraChips,'Extra Chips');
													cdClass.UpdateUserData(userInfo._id,{$set:{tbid:resp._id.toString(),sck:rSck,'lasts.ll':new Date(),s:'busy','counters.opc':0},$inc:{sessId:1}},function(rbInfo){});
												}
												else{
													cdClass.UpdateUserData(userInfo._id,{$set:{tbid:resp._id.toString(),sck:rSck,'lasts.ll':new Date(),s:'busy','counters.opc':0},$inc:{sessId:1}},function(rbInfo){});
												}
											}


											commonClass.FireEventToTable(resp._id.toString(), { en : 'JT', data : {ap:resp.ap,si : seat,rpsts:resp.pi[seat].rpsts,_rp:resp.pi[seat]._rp,uid : userInfo._id.toString(),un : uName,pp : userInfo.pp,_ir : userInfo.flags._ir,Chips : Chips,bet:resp.bv,s:sts}, flag : true },'JOIN_TABLE');
											
											playingTableClass.initializeGame(resp._id.toString());
										});
									});
								});
							});
						// });
					//});
				}
				else{
					c('joinSeat-------------->>>>>"user data not found"');
				}

			});
			// });
		});
	},
	joinSeat: function(tbId,theme,client){ //data = table data
		/* +-------------------------------------------------------------------+
            desc:function to join seat for user
            i/p: tbId = _id of table,client = socket object
        +-------------------------------------------------------------------+ */
		// cdClass.GetTbInfo(tbId,{},function(tbData){
		c('joinSeat-------------->>>>>client._ir:'+client._ir+' client.uid: '+client.uid+' tbId: '+tbId);
		if (theme == null || typeof theme == "undefined"){
			theme = 'red'
		}
		db.collection('playing_table').findOne({_id:MongoID(tbId.toString()),ap:{$lt:6}},function(err,tbData) {
			if(!tbData){
				c('joinSeat::::::::::::::::::>>>>>>>Error: "tbData not found!!!"');
				return false;
			}

			cdClass.GetUserInfo(client.uid,{_id:1,un:1,pp:1,ip:1,flags:1,Chips:1,totalcash:1,wc:1,tbid:1,counters:1},function(userInfo){
				if(userInfo){

					//playClass.isFirstTimeUser(userInfo._id.toString(),function(isSpc,RobotCount,HumanCount){
						//console.log("joinSeat----------->>>>>>>isSpc :"+isSpc+"RobotCount :"+RobotCount+"HumanCount :"+HumanCount)
						if(client.isInvite){
							// isSpc = false;
							delete client.isInvite;
						}
						

						var seat = playingTableClass.findEmptySeat(tbData.pi);
						if(seat == -1 && userInfo.flags._ir == 0){  //seat not found
							c('joinSeat----------->>>>>>seat == -1');
							playingTableClass.findTableAndJoin({gt: tbData.gt,pCount: tbData.ms,bv:tbData.bv,reke:tbData.reke,mode: tbData.mode,chips: userInfo.Chips,tbid:tbData._id.toString()},client,0);
							return false;   ///if game stucks look here
						}
						else if(seat == -1 && client._ir == 1){
							c('joinSeat--------------->>>>>Msg:"no seat for robot!!!"');
							return false;   ///if game stucks look here
						}

						var rType = '';
						var uName = userInfo.un;
						if(client._ir == 1){
							if(client.rType){
								rType = client.rType;
								// uName = client.rType;
							}
							else{
								rType = 'Newbie';
								// uName = 'Newbie';
							}
						}

						c('joinSeat------------>>>>>userInfo: ',userInfo);
						var sts = '';

						if( (_.contains(['Classic','Bet'],tbData.gt) &&  !_.contains(["","RoundTimerStarted"],tbData.tst)) || (_.contains(['Deal','Pool'],tbData.gt) && ( !_.contains(["","RoundTimerStarted"],tbData.tst) || tbData.round > 0 ))   ){
							sts = 'watch';
						}

						var di = "uploads/NewDealerImage/Dealer-1_1533300586.png"; 
						var id = "5b644f731bfdb4fe67fa3be7";

							var updateInfo = {
								uid : userInfo._id.toString(),   				//	user id
								jt : new Date(),					    		//	join time
								gst : new Date(),								//  game start time
								gedt : new Date(),								//  game end time
								rndCount : 0,									//  round count
								si : seat,										//	seat index
								un : uName,										//	user name
								pp : userInfo.pp,								//	profile picture 
								ip : userInfo.ip,
								theme : theme,									//  color theme of table
								Chips: userInfo.Chips,							// 	player chips
								totalCash: userInfo.totalcash,
								_ir : userInfo.flags._ir,						//	is robot or not 
								rType : rType,									// 	robot type not applicable for user
			 					s : sts,										//	status
								GiftId:'',										//  gift id
								GiftType:'',									//	GiftType
								dealerImg:di,									//  dealer image
								dealerId:id,									//  dealer id
								play : 0,										//  is playing in current deal
								tCount : 0,										//	timeout count				
								sort : true,									//  show sort button
								ps : 0,											//	cards points (deadwood)
								dps : 0,										//  deal total points
								pts : 0,										//  points to be multiplied with bv
								secTime : config.SECONDARY_TIMER,				// 	secondary remaining time
								sct : false,									//	secondary timer flag
								tsd : new Date(),								// 	timer start time
								ted : new Date(),								//	timer end time
								bet : tbData.bv,								//  bet set by players
								cards : [],										//	player cards
								gCards : {pure:[],seq:[],set:[],dwd:[]},		//  group cards formatted array
								dCards : {},									//  declared cards
								score : 0,										//	user score
								wc : 0,											//  win chips
								pickCount: 0,									//  cards pick count
								//isSpc:isSpc,									//  is special user
								thp : userInfo.counters.thp,					//  total game played by user		
								lpc : '',										//	last picked card
								occ : 0,
								_iw : 0,										//  is winner or not 
								isCollect : 0,									//	is boot value collected
							}
							c('joinSeat----------->>>>>tbData.jid: ',tbData.jid);
							
							// jtClass.cancelJobOnServers(tbData._id.toString(),tbData.jid);


							c('joinSeat-----1111111---->>> name: ',userInfo.un,'seat: ',seat,' tableid: ',tbData._id);
							
							
							var Chips = userInfo.Chips;
							var cash = userInfo.totalcash;

							var where = {_id:MongoID(tbData._id.toString())};
							where['pi.'+seat+'.si'] = {$exists:false};
							
							var extraChips = 0;  
							var cond = false;
							var cpp = 0;
							if(config.MAX_DEADWOOD_PTS > 0){

								cpp = (tbData.gt == 'Deal' || tbData.gt == 'Pool') ? tbData.bv/config.MAX_DEADWOOD_PTS:tbData.bv;
							}
							c('joinSeat------------------------>>>>>>cpp: '+cpp);
							db.collection('robot_chips').find({lowerCpp:{$lte:cpp},mode:tbData.mode}).sort({lowerCpp:-1}).toArray(function(error,robotChips){

								if(robotChips && robotChips.length > 0 && client._ir == 1){
									c('joinSeat---------------------->>>>>>robotChips: ',robotChips);
									var robotExtraChips = 0;
									robotExtraChips = commonClass.GetRandomInt(robotChips[0].lowerChips,robotChips[0].upperChips);
									c('joinSeat------------1---------->>>>>>>robotExtraChips: '+robotExtraChips);
									robotExtraChips = robotExtraChips - robotExtraChips%100;  //rounding robot chips  to 100
									var ch;
									if (tbData.mode == 'cash') {
										extraChips = robotExtraChips - cash;
									}
									else{
										extraChips = robotExtraChips - Chips;
									}
									Chips = robotExtraChips;
									cond = true;
									c('joinSeat----------2------------->>>>>>extraChips: '+extraChips+' Chips: '+Chips);
								}
								

								var extraMulti = 1;

								if(rType == 'Newbie'){
									extraMulti = 1.5;
								}
								else if(rType == 'Amateur'){
									extraMulti = 2;
								}
								else if(rType == 'Pro'){
									extraMulti = 2.5;
								}
								else if(rType == 'God'){
									extraMulti = 3;
								}
								else{
									extraMulti = 1;
								}



								var cond1 = (tbData.gt == 'Deal' || tbData.gt == 'Pool') ? Chips < tbData.bv : Chips < (tbData.bv*config.MAX_DEADWOOD_PTS);
								if(client._ir == 1){


									if(cond1){  
										if(tbData.gt == 'Deal' || tbData.gt == 'Pool'){
											extraChips = tbData.bv*extraMulti;
										}
										else{
											extraChips = tbData.bv*config.MAX_DEADWOOD_PTS*extraMulti;
										}

										if (tbData.mode == 'cash') {
											Chips = userInfo.totalcash+extraChips; 
										}
										else{
											Chips = userInfo.Chips+extraChips; 
										}

									}

									if (tbData.mode == 'practice') {

										updateInfo.Chips = Chips;
									}
									else if (tbData.mode == 'cash') {

										updateInfo.cash = Chips;
									}
								}

								playClass.getUserScore(updateInfo.uid,tbData.bv,tbData.gt,function(score){
									updateInfo.score = score;

									var link = config.BU + 'joinTable?jcode=' + tbData.tjid +'&tbid=' + tbData._id.toString();

									eval('var upData = {$set : {la:new Date(),link:link,"pi.'+seat+'":updateInfo},$inc:{ap:1}}');

									/*if(isSpc){
										upData.$set.spcSi = seat;
										upData.$set.nrg = 1;
										upData.$set.minS = RobotCount+1;
										upData.$set.RobotCount = RobotCount;
										upData.$set.HumanCount = HumanCount;
									}*/

									if(client._ir == 0){
										upData.$inc.uCount = 1;
									}


									db.collection('playing_table').findAndModify(where,{},upData,{new:true},function(err1,resp){
										resp = resp.value;
										c('joinSeat------222222222--->>> name: ',userInfo.un,'seat: ',seat,' tableid: ',tbData._id);

										if(!resp){
											if(client._ir == 0){  //seat not found
												c('joinSeat----------->>>>>>MSG:"seat occupied"');
												playingTableClass.findTableAndJoin({gt: tbData.gt,pCount: tbData.ms,bv:tbData.bv,reke:tbData.reke,mode: tbData.mode,chips:Chips,tbid:userInfo.tbid},client,0);
												return false;   ///if game stucks look here
											}
											else if(client._ir == 1){
												c('joinSeat--------------->>>>>Msg:"no seat for robot!!!"');
												return false;   ///if game stucks look here
											}
											else{
												return false;   ///if game stucks look here
											}
										}

										
										var _isHelp = 0; 
										var deal_c = userInfo.counters.deal_c;
										var pool_c = userInfo.counters.pool_c;
										var bet_c = userInfo.counters.bet_c;
										if(deal_c < config.DEAL_TUTF_SES && resp.gt == 'Deal'){
											deal_c++;
											_isHelp = 1;
										}
										else if(pool_c < config.POOL_TUTF_SES && resp.gt == 'Pool'){ // flag for help screen for pool rummy
											pool_c++;
											_isHelp = 1;
										} 
										else if(bet_c < config.BET_TUTF_SES && resp.gt == 'Bet'){
											bet_c++;
											_isHelp = 1;
										}
										c('joinSeat------333333--->>> name: '+userInfo.un+'seat: '+seat+' tableid: '+tbData._id+' updateInfo: ',updateInfo,' _isHelp: '+_isHelp);
										
										
										playingTableClass.GTI({"tbid": resp._id.toString(),_isHelp:_isHelp,"rejoin":0}, client,function(){

											if(client._ir == 0){
												

												var single = client.sck.replace(SERVER_ID+".","");
												c('joinSeat-----before----->>>>connected sockets: ',io.sockets.adapter.rooms[resp._id.toString()]);
												c('joinSeat--------->>>>>>single: ',single);
												if(io.sockets.connected[single]){
													io.sockets.connected[single].join(resp._id.toString());
													
													client.tbid = resp._id.toString(); //adding  tableid to client
													client.si = seat; //adding seat index to client
													client.gt = resp.gt;
													
												}
												c('joinSeat-----after----->>>>connected sockets: ',io.sockets.adapter.rooms[resp._id.toString()]);
												c('joinSeat---------->>>>>>>>client.tbid: ',client.tbid,' client.si: ',client.si);
												cdClass.UpdateUserData(userInfo._id,{$set:{tbid:resp._id.toString(),bv:resp.bv,sck:client.sck,"counters.deal_c":deal_c,"counters.pool_c":pool_c,"counters.bet_c":bet_c}},function(userInfo1){});
											}
											else{
												// if(userInfo.Chips < resp.bv*config.MAX_DEADWOOD_PTS){  
												var rSck = SERVER_ID+'.'+commonClass.GetRandomString(20);
												var game_id = tbData.game_id;
												var sub_id = tbData.sub_id;

												if(_.contains(['','RoundTimerStarted','CollectingBootValue','StartDealingCard'],tbData.tst)){
									                game_id = game_id+1;
									                sub_id = sub_id+1;
									            }
									            
									            if(tbData.gt == 'Deal' || tbData.gt == 'Pool'){ 


									                if(tbData.round == 0){
									                    game_id = game_id+'.1';
									                    
									                }
									                else{
									                    game_id = game_id+'.'+sub_id;

									                }
									                
									            }


												c('joinSeat-------------->>>>>>rSck: ',rSck);
												if(cond || cond1){
													if(resp.mode == 'practice'){
														cdClass.UpdateUserChips(userInfo._id.toString(),extraChips,'Extra Chips');
													}
													else if(resp.mode == 'cash'){
														cdClass.UpdateUserCash(userInfo._id.toString(),extraChips,'Extra Cash');
													}
													cdClass.UpdateUserData(userInfo._id,{$set:{tbid:resp._id.toString(),sck:rSck,'lasts.ll':new Date(),s:'busy','counters.opc':0},$inc:{sessId:1}},function(rbInfo){});
												}
												else{
													cdClass.UpdateUserData(userInfo._id,{$set:{tbid:resp._id.toString(),sck:rSck,'lasts.ll':new Date(),s:'busy','counters.opc':0},$inc:{sessId:1}},function(rbInfo){});
												}
											}


											commonClass.FireEventToTable(resp._id.toString(), { en : 'JT', data : {ap:resp.ap,si : seat,rpsts:resp.pi[seat].rpsts,pts:resp.pi[seat].pts,_rp:resp.pi[seat]._rp,uid : userInfo._id.toString(),un : uName,pp : userInfo.pp,_ir : userInfo.flags._ir,secTime : resp.pi[seat].secTime,Chips : Chips,totalCash : userInfo.totalcash,bet:resp.bv,s:sts}, flag : true },'JOIN_TABLE');
											
											playingTableClass.initializeGame(resp._id.toString());
										});
									});
								});
							});
						// });
					//});
				}
				else{
					c('joinSeat-------------->>>>>"user data not found"');
				}

			});
			// });
		});
	},
	initializeGame : function(tbId){   //tries to start the game of there are enough players otherwise puts robots
		/* +-------------------------------------------------------------------+
            desc:function to initialize game
            i/p: tbId = table id
        +-------------------------------------------------------------------+ */
		c('initializeGame-------'+tbId+'------>>>>>');
		cdClass.GetTbInfo(tbId,{},function(resp){
			// cdClass.UpdateTableData(tbId,{$set:{tst:'RoundTimerStarted',jid:jobId}},function(resp){
			// c('initializeGame-------->>>>resp: ',resp);
			if(!resp){
				c('initializeGame------------------>>>>>Error:"table not found!!!"');
				return false;
			}
			var pi = playClass.getPlayingUserInRound(resp.pi);

			var rSi = [];
		
			c('initializeGame------->>>>pi: ',pi);
			var rCount = 0,uCount = 0;
			for(x in pi){
				if(pi[x]._ir == 1){
					rCount++;
					rSi.push(pi[x].si);
				}
				else if(pi[x]._ir == 0){
					uCount++;
				}
			}

			
			c('initializeGame------------>>>>>uCount: ',uCount,' rCount: ',rCount,' stdP.length: ',resp.stdP.length);
			

			if(uCount == 0 && rCount >= 0 && resp.stdP.length == 0){ //means there is not live user in table and not any standup user 
				c('initializeGame------------>>>>>delete table')
			 	robotsClass.removeRobots(resp._id.toString());
			}
			else{

				if(resp.gt == 'Deal'){   //initialize deal rummy
					var game_id = resp.game_id+'.'+resp.sub_id;
					c('initializeGame-------deal------->>>>>>rSi: ',rSi);
					if(uCount >= 3 && resp.round == 1 && rSi.length > 0){   //means leave robot as there are more human players
						var rInt = commonClass.GetRandomInt(0,1); //50% probability of robot leave
						if(rInt == 1){
							c('initializeGame------------>>>>>>rInt: '+rInt);
							playClass.LT({flag:"enfply"},{uid:resp.pi[rSi[0]].uid,_ir:resp.pi[rSi[0]]._ir ,si : rSi[0],tbid : resp._id.toString()});
						}
					}

					var cond = resp._ip != 1 && config.USE_ROBOT && uCount > 0 && resp.ap < 2 && resp.ap < resp.ms;
					var MIN_SEAT_TO_FILL_DEAL = 2;

					/*if(resp._ip != 1 && typeof resp.spcSi != 'undefined' && resp.spcSi != -1){  //means setup for special user
						var RobotCount = resp.RobotCount?resp.RobotCount:0;
						var HumanCount = resp.HumanCount?resp.HumanCount:0;
						RobotCount += HumanCount;

						

						if(MIN_SEAT_TO_FILL_DEAL < RobotCount+1 && RobotCount+1 <= resp.ms){
							MIN_SEAT_TO_FILL_DEAL = RobotCount+1;
						}
						else if(MIN_SEAT_TO_FILL_DEAL < RobotCount+1 && RobotCount+1 > resp.ms){
							MIN_SEAT_TO_FILL_DEAL = resp.ms;  //player should not exceed max seat
						}

						cond = uCount > 0 && resp.ap < resp.ms && resp.ap < MIN_SEAT_TO_FILL_DEAL;
					}*/

					if(cond){
						c('initializeGame--------->>>>>>>>uCount: '+uCount+' resp.jid: '+resp.jid);
						c('initializeGame------------',resp._id,'--------------->>>>>>ap==1');
						setTimeout(function(){
							robotsClass.putRobotOnSeat(resp._id.toString());
						},config.ROBOT_SEAT_TIMER*1000);
					}
					else if(resp.ap >= MIN_SEAT_TO_FILL_DEAL && resp.tst == ''){
						//game start logic here
						c('initializeGame--------------'+resp._id+' ----------->>>>>>>ap: '+resp.ap);
						var jobId = commonClass.GetRandomString(10);
						// var rst = config.RST;
						var rst = (resp._artFlag == 1 || resp._qstWin == 1)? (config.RST+config.ART):config.RST;

						cdClass.UpdateTableData(resp._id.toString(),{$set:{tst:'RoundTimerStarted',jid:jobId,ctt:new Date()}},function(upData){
							if(upData){

								rCount = 0;

								for(var j in resp.pi){
									if(!_.isEmpty(resp.pi[j]) && typeof resp.pi[j]._ir != 'undefined' && resp.pi[j]._ir ==  1){
										rCount++;
									}
								}

								/*for(k in resp.pi){
									if(!_.isEmpty(resp.pi[k]) && typeof resp.pi[k]._ir != 'undefined'){

										trackClass.gameInitTrack(resp._id.toString(),resp.pi[k].uid,{ap : resp.ap,rCount:rCount,gt:resp.gt,bv:resp.bv,round:resp.round,game_id:resp.game_id,sub_id:resp.sub_id});
									}
								}*/

								commonClass.FireEventToTable(upData._id.toString(),{en:'RTS',data:{timer:rst,_artFlag:resp._artFlag}});
								var stt = commonClass.AddTime(rst);
								schedule.scheduleJob(upData.jid,new Date(stt),function(){
									schedule.cancelJob(upData.jid);
									playingTableClass.startRound(resp._id.toString());
								});
							}
							else{

								c('initializeGame-------------------->>>>>>Error:"table not found"');
							}
						});   //resp.ap > 1 && resp.tst == ''
					}
				}
				else if(resp.gt == 'Pool'){
					
					c('initializeGame----------pool---------->>>>>>>rSi: ',rSi);
					
					/*if(uCount >= 3 && resp.round == 0 && rSi.length > 0 ){ //means leave robot as there are more human players
						
						var rInt = commonClass.GetRandomInt(0,1); //50% probability of robot leave
						if(rInt == 1){
							
							c('initializeGame-------------->>>>>>rInt: '+rInt);
							playClass.LT({flag:"enfply"},{uid:resp.pi[rSi[0]].uid,_ir:resp.pi[rSi[0]]._ir ,si : rSi[0],tbid : resp._id.toString()});
						}
					}*/
					var cond = resp._ip != 1 && config.USE_ROBOT && uCount > 0  && resp.ap < resp.ms && resp.ap < resp.minS && resp.round == 0;
					var MIN_SEAT_TO_FILL_POOL = resp.minS;

					/*if(resp._ip != 1 && typeof resp.spcSi  != 'undefined' && resp.spcSi != -1){  //means setup for special user
						var RobotCount = resp.RobotCount?resp.RobotCount:0;
						var HumanCount = resp.HumanCount?resp.HumanCount:0;
						RobotCount += HumanCount;

						MIN_SEAT_TO_FILL_POOL = RobotCount+1;
						
						cond = uCount > 0 && resp.ap < resp.ms && resp.ap < MIN_SEAT_TO_FILL_POOL && resp.round == 0;
					}*/

					if(cond){
						c('initializeGame------------>>>>>uCount: '+uCount+' resp.jid: '+resp.jid);
						c('initializeGame--------------'+resp._id+'---------->>>>>>ap==1');
						setTimeout(function(){
							robotsClass.putRobotOnSeat(resp._id.toString());
						},config.ROBOT_SEAT_TIMER*1000);
					}
					else if((resp.ap >= MIN_SEAT_TO_FILL_POOL && resp.round == 0 || resp.ap > 1 && resp.round > 0)  && resp.tst == ''){
						//game start logic here
						c('initializeGame--------------'+resp._id+'------------>>>>ap: '+resp.ap);
						var jobId = commonClass.GetRandomString(10);
						var rst = config.RST;
						// var rst = (resp._artFlag == 1 || resp._qstWin == 1)? (config.RST+config.ART):config.RST;

						cdClass.UpdateTableData(resp._id.toString(),{$set:{tst:'RoundTimerStarted',jid:jobId,ctt:new Date()}},function(upData){
							if(upData){


								rCount = 0;

								for(var j in resp.pi){
									if(!_.isEmpty(resp.pi[j]) && typeof resp.pi[j]._ir != 'undefined' && resp.pi[j]._ir ==  1){
										rCount++;
									}
								}

								/*for(k in resp.pi){
									if(!_.isEmpty(resp.pi[k]) && typeof resp.pi[k]._ir != 'undefined'){

										trackClass.gameInitTrack(resp._id.toString(),resp.pi[k].uid,{ap : resp.ap,rCount:rCount,gt:resp.gt,bv:resp.bv,round:resp.round,game_id:resp.game_id,sub_id:resp.sub_id});
									}
								}*/

								commonClass.FireEventToTable(upData._id.toString(),{en:'RTS',data:{timer:rst,round:resp.round}});
								var stt = commonClass.AddTime(rst);
								schedule.scheduleJob(upData.jid,new Date(stt),function(){
									schedule.cancelJob(upData.jid);
									playingTableClass.startRound(resp._id.toString());
								});
							}
							else{

								c('initializeGame----------------->>>>Error:"table not found"');
							}
						});
					}
				}
				else if(resp.gt == 'Bet'){
					c('initializeGame--------bet------->>>>>>>rSi:',rSi);
					var minS = (resp.minS)?resp.minS : config.MIN_SEAT_TO_FILL_BET;
					if(uCount >= 3 &&  rSi.length > 0){ //means leave robot as there are more human players
						var rInt = commonClass.GetRandomInt(0,1);
						if(rInt == 1){
							c('initializeGame------------>>>>rInt: '+rInt);
							playClass.LT({flag:"enfply"},{uid:resp.pi[rSi[0]].uid,_ir:resp.pi[rSi[0]]._ir ,si : rSi[0],tbid : resp._id.toString()});
						}
					}

					var MIN_SEAT_TO_FILL_BET = (resp._ip == 1)?2:minS;
					var cond = resp._ip != 1 && config.USE_ROBOT && (uCount > 0 || resp.stdP.length > 0) && resp.ap < resp.ms && (resp.ap < MIN_SEAT_TO_FILL_BET && (rCount < config.MAX_ROBOT_PER_TABLE || resp.stdP.length > 0));

					/*if(resp._ip != 1 && typeof resp.spcSi  != 'undefined' && resp.spcSi != -1){  //means setup for special user
						var RobotCount = resp.RobotCount?resp.RobotCount:0;
						var HumanCount = resp.HumanCount?resp.HumanCount:0;
						RobotCount += HumanCount;

						var MAX_ROBOT_PER_TABLE = config.MAX_ROBOT_PER_TABLE;
						
						MIN_SEAT_TO_FILL_BET = RobotCount+1;
					
						MAX_ROBOT_PER_TABLE = RobotCount;

						cond = uCount > 0 && resp.ap < resp.ms && resp.ap < MIN_SEAT_TO_FILL_BET && rCount < MAX_ROBOT_PER_TABLE;
					}*/

					if(cond){ //if not enough player then put robot
						
						c('initializeGame--------->>>>>>uCount: ',uCount,' resp.jid: ',resp.jid);
						c('initializeGame------------------'+resp._id+'---------->>>>>less players');
			
						setTimeout(function(){
							robotsClass.putRobotOnSeat(resp._id.toString());
						},config.ROBOT_SEAT_TIMER*1000);
					
					}
					else if(resp.ap >= MIN_SEAT_TO_FILL_BET && resp.ap > 1 && resp.tst == ''){
						c('initializeGame----------------'+resp._id+'----------->>>>>ap: '+resp.ap);
						var jobId = commonClass.GetRandomString(10);
						// var rst = config.RST;
						var rst = (resp._artFlag == 1 || resp._qstWin == 1)? (config.RST+config.ART):config.RST;
						cdClass.UpdateTableData(resp._id.toString(),{$set:{tst:'RoundTimerStarted',jid:jobId,ctt:new Date()}},function(upData){
							if(upData){

								rCount = 0;

								for(var j in resp.pi){
									if(!_.isEmpty(resp.pi[j]) && typeof resp.pi[j]._ir != 'undefined' && resp.pi[j]._ir ==  1){
										rCount++;
									}
								}

								commonClass.FireEventToTable(upData._id.toString(), { en : 'RTS', data : {timer:rst,_artFlag:resp._artFlag}});
								
								var stt = commonClass.AddTime(rst);
								schedule.scheduleJob(upData.jid,new Date(stt),function(){
									schedule.cancelJob(upData.jid);
									playingTableClass.startRound(resp._id.toString());
								});
							}
							else{
								c('initializeGame------------>>>>Error:"table not found"');
							}
						});
					}
				}
				else{  //initialize classic rummy

					c('initializeGame------else-------->>>>>>rSi: ',rSi);
					/*if(uCount >= 3 &&  rSi.length > 0){   //means leave robot as there are more human players
						var rInt = commonClass.GetRandomInt(0,1); //50% probability of robot leave
						if(rInt == 1){
							c('initializeGame------------>>>>>>rInt: '+rInt);
							playClass.LT({flag:"enfply"},{uid:resp.pi[rSi[0]].uid,_ir:resp.pi[rSi[0]]._ir ,si : rSi[0],tbid : resp._id.toString()});
						}
					}*/

					var minS = (typeof resp.minS != 'undefined') ? resp.minS : config.MIN_SEAT_TO_FILL;
					var cond = resp._ip != 1 && config.USE_ROBOT && resp.tst != 'CardsDealt' && resp.tst != 'RoundStarted' && (uCount > 0 || resp.stdP.length > 0) && resp.ap < resp.ms && (resp.ap < minS && (rCount < config.MAX_ROBOT_PER_TABLE || resp.stdP.length > 0));
					var MIN_SEAT_TO_FILL = (resp._ip == 1) ? 2 : minS;
					var ROBOT_SEAT_TIMER = config.ROBOT_SEAT_TIMER;
					// console.log("&&&&&&&&&&&&&&&#################### MAX_ROBOT_PER_TABLE:"+MAX_ROBOT_PER_TABLE)
					/*if(resp._ip != 1 && typeof resp.spcSi != 'undefined' && resp.spcSi != -1){  //means setup for special user
						
						var RobotCount = (typeof resp.RobotCount != 'undefined') ? resp.RobotCount : 0;
						var HumanCount = (typeof resp.HumanCount != 'undefined') ? resp.HumanCount : 0;
						RobotCount += HumanCount;
						var MAX_ROBOT_PER_TABLE = config.MAX_ROBOT_PER_TABLE;
						
						MIN_SEAT_TO_FILL = RobotCount+1;
					
						MAX_ROBOT_PER_TABLE = RobotCount;
				
						console.log("&&&&&&&&&&&&&&&#################### MAX_ROBOT_PER_TABLE:"+MAX_ROBOT_PER_TABLE)
						console.log("&&&&&&&&&&&&&&&#################### MIN_SEAT_TO_FILL:"+MIN_SEAT_TO_FILL)
						cond = uCount > 0 && resp.ap < resp.ms && resp.ap < MIN_SEAT_TO_FILL && rCount < MAX_ROBOT_PER_TABLE;
						ROBOT_SEAT_TIMER = config.ROBOT_SEAT_TIMER_FTU;
					}*/


					if(cond){ //if not enough player then put robot  
					
						c('initializeGame------->>>>>>>>>>uCount: ',uCount,' resp.jid: ',resp.jid);
						c('initializeGame----------------'+resp._id+'------------->>>>>less players');
						setTimeout(function(){
							robotsClass.putRobotOnSeat(resp._id.toString()); 
						}, ROBOT_SEAT_TIMER*1000);	
					}
					else if(resp.ap >=  MIN_SEAT_TO_FILL && resp.ap > 1 && resp.tst == ''){
						c('initializeGame----------------'+resp._id+'------------->>>>>ap: '+resp.ap);
						var jobId = commonClass.GetRandomString(10);
						var rst = config.RST;
						// var rst = (resp._artFlag == 1 || resp._qstWin == 1)? (config.RST+config.ART):config.RST;
						cdClass.UpdateTableData(resp._id.toString(),{$set:{tst:'RoundTimerStarted',jid:jobId,ctt:new Date()}},function(upData){
							if(upData){

								/*rCount = 0;

								for(var j in resp.pi){
									if(!_.isEmpty(resp.pi[j]) && typeof resp.pi[j]._ir != 'undefined' && resp.pi[j]._ir ==  1){
										rCount++;
									}
								}*/
								var pi = [];
								for(var j in resp.pi){
									var dt = {
										uid : resp.pi[j].uid,
										si : resp.pi[j].si,
										s : resp.pi[j].s
									};
									pi.push(dt);
								}
								
								// setTimeout(function(){

									commonClass.FireEventToTable(upData._id.toString(), { en : 'RTS', data : {timer:rst,pi:pi,round:resp.round}});
									var stt = commonClass.AddTime(rst);
									schedule.scheduleJob(upData.jid,new Date(stt),function(){
										schedule.cancelJob(upData.jid);
										playingTableClass.startRound(resp._id.toString());
									});
								// }, 2*1000);
							}
							else{
								c('initializeGame-------------->>>>>>Error:"table not found"');
							}
						});
					}
					else{
						c("initializeGame---------------->>>>>>>>>>>>>>Error:table cand start")
					}
				}
			}
		});
	},
	startRound: function(tbId){    //starts the game assumes that all the players are ready to play
		/* +-------------------------------------------------------------------+
            desc:function to start round
            i/p: tbId = table id
        +-------------------------------------------------------------------+ */
		c('startRound---------->>>>');
		// cdClass.UpdateTableData(tbId,{$set:{tst:'StartDealingCard',ctt:new Date()}},function(resp){
		cdClass.GetTbInfo(tbId,{},function(resp){
			
			if(resp){


				var uScores = [];
				for(var i in resp.pi){ 
					if(!_.isEmpty(resp.pi[i]) && resp.pi[i]._ir == 0){

		                uScores.push(resp.pi[i].score);    
		            }
		        }

		        var tScore = 0;
		        if(uScores.length  > 1){
		            tScore = commonClass.getMedian(uScores);
		        }
		        else{
		            tScore = (uScores.length == 1) ? uScores[0] : 0;
		        }


		        var game_id = resp.game_id;
		        if(resp.gt == 'Deal' || resp.gt == 'Pool'){ 
		            if(resp.round == 0){
		            	game_id = game_id+1;
		            	game_id = game_id+'.1';
		            }
		            else{

		            	game_id = game_id+'.'+(resp.sub_id+1);
		            }
		        }
		        else{
		        	game_id = game_id+1;
		        }


				if(resp.gt == 'Deal'){   //deal rummy 

					if(resp.ap > 1){
						cdClass.UpdateTableData(resp._id.toString(),{$set:{tst:'CollectingBootValue',ctt:new Date(),_artFlag:0,_qstWin:0},$inc:{round:1}},function(upData){
							if(!upData){
								console.log('startRound---deal-----'+resp._id+'--------->>>>>>Error:"table not found"');
								return false;
							}
							c('startRound-------------'+upData._id+'----------ap: '+upData.ap+'---------->>>>');

							//collect boot value logic here
							// var players = playClass.getPlayingUserInRound(upData.pi);
							var pi = upData.pi;
							var pv = upData.pv;
							if(upData.round == 1 ){  //if round == 1 then only boot value will be collected

								var newChips = [];

								for(var i in pi){

									if(!_.isEmpty(pi[i]) && typeof pi[i].si != 'undefined'){
										
										if(upData.mode == 'practice'){
											newChips.push({si:pi[i].si,chips:(pi[i].Chips-upData.bv)});
											pi[i].Chips-= upData.bv;
										}
										else if(upData.mode == 'cash'){
											newChips.push({si:pi[i].si,cash:(pi[i].cash-upData.bv)});
											pi[i].cash-= upData.bv;
										}
										pi[i].play = 1;
										pi[i].isCollect = 1;
										playingTableClass.collectBootValue(upData._id.toString(),upData.mode,pi[i].uid,upData.bv);

									}
								}


								c('startRound----------->>>>>newChips: ',newChips);
								c('startRound------------->>>>>upData: ',upData);
								c('startRound--------->>>>>bv: '+upData.bv+' ap: '+upData.ap+' reke: '+upData.reke);
								
								if(upData.mode == 'practice'){
									
									pv = parseInt(upData.bv*upData.ap*((100-upData.reke)*0.01));  //table pot value
								}
								else{
									
									var tpv = parseInt(upData.bv)*upData.ap;
									pv = (tpv*config.TDS)/100;
								}
								c('startRound---------->>>>>pv: '+pv);
								
								var jobId = commonClass.GetRandomString(10);
								cdClass.UpdateTableData(upData._id.toString(),{$set:{jid:jobId,pv:pv,pi:pi,sub_id:1},$inc:{game_id:1}},function(upData1){
									
									if(upData1){
										commonClass.FireEventToTable(upData._id.toString(), { en : 'CBV', data : {pv:pv,pChips:newChips,round:upData1.round,game_id:upData1.game_id,sub_id:upData1.sub_id}, flag : true });

										var bct = commonClass.AddTime(config.BCT);
										c('startRound--deal--before---'+upData._id.toString()+'---jid: '+upData1.jid+'---bct: '+bct+'-------->>>>>'+new Date());
										schedule.scheduleJob(upData1.jid,new Date(bct),function(){
											schedule.cancelJob(upData1.jid);
											
											c('startRound----------->>>>>pv: '+pv);
											c('startRound--deal -after----'+upData1._id.toString()+'---jid: '+upData1.jid+'---bct: '+bct+'-------->>>>>'+new Date());
											playingTableClass.dealCards(upData1._id.toString(),pv,pi);
										});
									}
									else{
										c('startRound----deal---xxxxxx'+upData._id.toString()+'---jid: '+jobId+'--pv: '+pv+'   bct: '+bct+'----xxxxxx>>>>>Error:"table not found"'+new Date());
									}
								});
							}
							else{

								c('startRound----------->>>>>pv: '+pv);
								cdClass.UpdateTableData(upData._id.toString(),{$inc:{sub_id:1}},function(){

									playingTableClass.dealCards(upData._id.toString(),pv,pi);
								});
							}	
							// });
						});
					}
					else if(resp.ap == 1 || resp.ap < 2){
						c('startRound--------->>>>ap == 1 or 0');
						cdClass.UpdateTableData(resp._id.toString(),{$set:{tst: '',ctt:new Date(),_artFlag:0,_qstWin:0}},function(upData){

							playingTableClass.initializeGame(resp._id.toString());
						});
					}
				}
				else if(resp.gt == 'Pool'){
					if(resp.ap > 1){
						cdClass.UpdateTableData(resp._id.toString(),{$set:{tst:'CollectingBootValue',ctt:new Date(),_artFlag:0,_qstWin:0},$inc:{round:1}},function(upData){
							if(!upData){
								console.log('startRound----pool-----'+resp._id+'---------->>>>>Error:"table not found"');
								return false;
							}
							c('startRound-------------'+upData._id+'----------ap: '+upData.ap+'---------->>>>');
							//collect boot value logic here 
							var pi = upData.pi;
							var pv = upData.pv;
							if(upData.round == 1){ //if round == 1 then only boot value will be collected
								var newChips = [];


								for(var i in pi){

									if(!_.isEmpty(pi[i]) && typeof pi[i].si != 'undefined'){
										if(upData.mode == 'practice'){
											newChips.push({si:pi[i].si,chips:(pi[i].Chips-upData.bv)});
											pi[i].Chips-= upData.bv;
										}
										else if(upData.mode == 'cash'){
											newChips.push({si:pi[i].si,cash:(pi[i].totalCash-upData.bv)});
											pi[i].totalCash-= upData.bv;
										}
										pi[i].play = 1;
										pi[i].isCollect = 1;
										playingTableClass.collectBootValue(upData._id.toString(),upData.mode,pi[i].uid,upData.bv);

									}
								}

								c('startRound----------->>>>>newChips: ',newChips);
								
								c('startRound------------->>>>>upData: ',upData);
								c('startRound--------->>>>>bv: '+upData.bv+' ap: '+upData.ap+' reke: '+upData.reke);

								pv = parseInt(upData.bv*upData.ap*((100-upData.reke)*0.01));  //table pot value
								// if(upData.mode == 'practice'){
								// 	pv = parseInt(upData.bv*upData.ap*((100-upData.reke)*0.01));  //table pot value
								// }
								// else{
									
								// 	var tpv = parseInt(upData.bv)*upData.ap;
								// 	pv = (tpv*config.TDS)/100;
								// }

								// commonClass.FireEventToTable(upData._id.toString(), { en : 'CBV', data : {pv:pv,pChips:newChips,round:upData.round,game_id:upData.game_id,sub_id:upData.sub_id}, flag : true });

								var jobId = commonClass.GetRandomString(10);
								cdClass.UpdateTableData(upData._id.toString(),{$set:{jid:jobId,pv:pv,pi:pi,sub_id:1},$inc:{game_id:1}},function(upData1){
									if(upData1){
										commonClass.FireEventToTable(upData._id.toString(), { en : 'CBV', data : {pv:pv,pChips:newChips,round:upData1.round,game_id:upData1.game_id,sub_id:upData1.sub_id}, flag : true });

										var bct = commonClass.AddTime(config.BCT);
										c('startRound--pool--before---'+upData._id.toString()+'---jid: '+upData1.jid+'---bct: '+bct+'-------->>>>>'+new Date());
										schedule.scheduleJob(upData1.jid,new Date(bct),function(){
											schedule.cancelJob(upData1.jid);
											
											c('startRound----------->>>>>pv: '+pv);
											c('startRound--pool -after----'+upData1._id.toString()+'---jid: '+upData1.jid+'---bct: '+bct+'------->>>>>'+new Date());
											playingTableClass.dealCards(upData1._id.toString(),pv,pi);
										});

									}
									else{
										c('startRound----pool---xxxxxx'+upData._id.toString()+'---jid: '+jobId+'--pv: '+pv+'----bct: '+bct+'----xxxxxx>>>>>Error:"table not found"'+new Date());
									}
								});
							}
							else{
								cdClass.UpdateTableData(upData._id.toString(),{$inc:{sub_id:1}},function(){

									c('startRound----------->>>>>pv: '+pv);
									playingTableClass.dealCards(upData._id.toString(),pv,pi);
								});
							}
						});
					}
				}
				else if(resp.gt == 'Bet'){
					var minS = (resp.minS)?resp.minS:config.MIN_SEAT_TO_FILL_BET;
					var MIN_SEAT_TO_FILL_BET = (resp._ip == 1)?2:minS;
					if(resp.ap >= MIN_SEAT_TO_FILL_BET && resp.ap > 1){
						cdClass.UpdateTableData(resp._id.toString(),{$set:{_artFlag:0,_qstWin:0},$inc:{round:1,game_id:1}},function(upTb){
							if(upTb){

								c('startRound---------------->>>>>>upTb: ',upTb);
								playingTableClass.dealCards(upTb._id.toString(),0,upTb.pi);
							}
							else{
								c('startRound---------------->>>>>Error:"table not found"');
							}
						});
						
					}
					else if(resp.ap < MIN_SEAT_TO_FILL_BET || resp.ap == 1){
						c('startRound-------else if------->>>>>>');
						cdClass.UpdateTableData(resp._id.toString(),{$set:{tst: '',ctt:new Date(),_artFlag:0,_qstWin:0}},function(upData){

							playingTableClass.initializeGame(resp._id.toString());
						});
					}
				}
				else{  //classic rummy
					var minS = (resp.minS)?resp.minS:config.MIN_SEAT_TO_FILL;
					var MIN_SEAT_TO_FILL = (resp._ip == 1)?2:minS;
					c("sttartrnd-----------------minS:",minS);
					if(resp.ap >= MIN_SEAT_TO_FILL && resp.ap > 1){
						cdClass.UpdateTableData(resp._id.toString(),{$set:{_artFlag:0,_qstWin:0},$inc:{round:1,game_id:1}},function(upTb){
							if(upTb){

								c('startRound---------------->>>>>>upTb: ',upTb);
								playingTableClass.dealCards(upTb._id.toString(),0,upTb.pi);
							}
							else{
								c('startRound-------------------->>>>>Error: "table not found"');
							}
						});
						
					}
					else if(resp.ap < MIN_SEAT_TO_FILL || resp.ap == 1){
						c('startRound-------else if------->>>>>>');
						cdClass.UpdateTableData(resp._id.toString(),{$set:{tst: '',ctt:new Date(),_artFlag:0,_qstWin:0}},function(upData){

							playingTableClass.initializeGame(resp._id.toString());
						});
					}
				}
			}
			else{
				c('startRound:::::::::::::::::::::>>>>Error : "table not exist"')
				return false;
			}
		});
	},
	startRound_new: function(tbId){    //starts the game assumes that all the players are ready to play
		/* +-------------------------------------------------------------------+
            desc:function to start round
            i/p: tbId = table id
        +-------------------------------------------------------------------+ */
		c('startRound---------->>>>');
		// cdClass.UpdateTableData(tbId,{$set:{tst:'StartDealingCard',ctt:new Date()}},function(resp){
		cdClass.GetTbInfo(tbId,{},function(resp){
			
			if(resp){


				var uScores = [];
				for(var i in resp.pi){ 
					if(!_.isEmpty(resp.pi[i]) && resp.pi[i]._ir == 0){

		                uScores.push(resp.pi[i].score);    
		            }
		        }

		        var tScore = 0;
		        if(uScores.length  > 1){
		            tScore = commonClass.getMedian(uScores);
		        }
		        else{
		            tScore = (uScores.length == 1) ? uScores[0] : 0;
		        }


		        var game_id = resp.game_id;
		        if(resp.gt == 'Deal' || resp.gt == 'Pool'){ 
		            if(resp.round == 0){
		            	game_id = game_id+1;
		            	game_id = game_id+'.1';
		            }
		            else{

		            	game_id = game_id+'.'+(resp.sub_id+1);
		            }
		        }
		        else{
		        	game_id = game_id+1;
		        }


				if(resp.gt == 'Deal'){   //deal rummy 

					if(resp.ap > 1){
						cdClass.UpdateTableData(resp._id.toString(),{$set:{tst:'CollectingBootValue',ctt:new Date()},$inc:{round:1}},function(upData){
							if(!upData){
								console.log('startRound---deal-----'+resp._id+'--------->>>>>>Error:"table not found"');
								return false;
							}
							c('startRound-------------'+upData._id+'----------ap: '+upData.ap+'---------->>>>');

							//collect boot value logic here
							// var players = playClass.getPlayingUserInRound(upData.pi);
							var pi = upData.pi;
							var pv = upData.pv;
							if(upData.round == 1 ){  //if round == 1 then only boot value will be collected

								var newChips = [];

								for(var i in pi){

									if(!_.isEmpty(pi[i]) && typeof pi[i].si != 'undefined'){
										
										if(upData.mode == 'practice'){
											newChips.push({si:pi[i].si,chips:(pi[i].Chips-upData.bv)});
											pi[i].Chips-= upData.bv;
										}
										else if(upData.mode == 'cash'){
											newChips.push({si:pi[i].si,cash:(pi[i].totalCash-upData.bv)});
											pi[i].totalCash-= upData.bv;
										}
										pi[i].play = 1;
										pi[i].isCollect = 1;
										playingTableClass.collectBootValue(upData._id.toString(),upData.mode,pi[i].uid,upData.bv);

									}
								}


								c('startRound----------->>>>>newChips: ',newChips);
								c('startRound------------->>>>>upData: ',upData);
								c('startRound--------->>>>>bv: '+upData.bv+' ap: '+upData.ap+' reke: '+upData.reke);
								
								if(upData.mode == 'practice'){
									
									pv = parseInt(upData.bv*upData.ap*((100-upData.reke)*0.01));  //table pot value
								}
								else{
									
									var tpv = parseInt(upData.bv)*upData.ap;
									pv = (tpv*config.TDS)/100;
								}
								c('startRound---------->>>>>pv: '+pv);
								
								var jobId = commonClass.GetRandomString(10);
								cdClass.UpdateTableData(upData._id.toString(),{$set:{jid:jobId,pv:pv,pi:pi,sub_id:1},$inc:{game_id:1}},function(upData1){
									
									if(upData1){
										commonClass.FireEventToTable(upData._id.toString(), { en : 'CBV', data : {pv:pv,pChips:newChips,round:upData1.round,game_id:upData1.game_id,sub_id:upData1.sub_id}, flag : true });

										var bct = commonClass.AddTime(config.BCT);
										c('startRound--deal--before---'+upData._id.toString()+'---jid: '+upData1.jid+'---bct: '+bct+'-------->>>>>'+new Date());
										schedule.scheduleJob(upData1.jid,new Date(bct),function(){
											schedule.cancelJob(upData1.jid);
											
											c('startRound----------->>>>>pv: '+pv);
											c('startRound--deal -after----'+upData1._id.toString()+'---jid: '+upData1.jid+'---bct: '+bct+'-------->>>>>'+new Date());
											playingTableClass.dealCards(upData1._id.toString(),pv,pi);
										});
									}
									else{
										c('startRound----deal---xxxxxx'+upData._id.toString()+'---jid: '+jobId+'--pv: '+pv+'   bct: '+bct+'----xxxxxx>>>>>Error:"table not found"'+new Date());
									}
								});
							}
							else{

								c('startRound----------->>>>>pv: '+pv);
								cdClass.UpdateTableData(upData._id.toString(),{$inc:{sub_id:1}},function(){

									playingTableClass.dealCards(upData._id.toString(),pv,pi);
								});
							}	
							// });
						});
					}
					else if(resp.ap == 1 || resp.ap < 2){
						c('startRound--------->>>>ap == 1 or 0');
						cdClass.UpdateTableData(resp._id.toString(),{$set:{tst: '',ctt:new Date(),_artFlag:0,_qstWin:0}},function(upData){

							playingTableClass.initializeGame(resp._id.toString());
						});
					}
				}
				else if(resp.gt == 'Pool'){
					if(resp.ap > 1){
						cdClass.UpdateTableData(resp._id.toString(),{$set:{tst:'CollectingBootValue',ctt:new Date(),_artFlag:0,_qstWin:0},$inc:{round:1}},function(upData){
							if(!upData){
								console.log('startRound----pool-----'+resp._id+'---------->>>>>Error:"table not found"');
								return false;
							}
							c('startRound-------------'+upData._id+'----------ap: '+upData.ap+'---------->>>>');
							//collect boot value logic here 
							var pi = upData.pi;
							var pv = upData.pv;
							if(upData.round == 1){ //if round == 1 then only boot value will be collected
								var newChips = [];


								for(var i in pi){

									if(!_.isEmpty(pi[i]) && typeof pi[i].si != 'undefined'){
										if(upData.mode == 'practice'){
											newChips.push({si:pi[i].si,chips:(pi[i].Chips-upData.bv)});
											pi[i].Chips-= upData.bv;
										}
										else if(upData.mode == 'cash'){
											newChips.push({si:pi[i].si,cash:(pi[i].totalCash-upData.bv)});
											pi[i].totalCash-= upData.bv;
										}
										pi[i].play = 1;
										pi[i].isCollect = 1;
										playingTableClass.collectBootValue(upData._id.toString(),upData.mode,pi[i].uid,upData.bv);

									}
								}

								c('startRound----------->>>>>newChips: ',newChips);
								
								c('startRound------------->>>>>upData: ',upData);
								c('startRound--------->>>>>bv: '+upData.bv+' ap: '+upData.ap+' reke: '+upData.reke);

								pv = parseInt(upData.bv*upData.ap*((100-upData.reke)*0.01));  //table pot value
								// if(upData.mode == 'practice'){
								// 	pv = parseInt(upData.bv*upData.ap*((100-upData.reke)*0.01));  //table pot value
								// }
								// else{
									
								// 	var tpv = parseInt(upData.bv)*upData.ap;
								// 	pv = (tpv*config.TDS)/100;
								// }

								// commonClass.FireEventToTable(upData._id.toString(), { en : 'CBV', data : {pv:pv,pChips:newChips,round:upData.round,game_id:upData.game_id,sub_id:upData.sub_id}, flag : true });

								var jobId = commonClass.GetRandomString(10);
								cdClass.UpdateTableData(upData._id.toString(),{$set:{jid:jobId,pv:pv,pi:pi,sub_id:1},$inc:{game_id:1}},function(upData1){
									if(upData1){
										commonClass.FireEventToTable(upData._id.toString(), { en : 'CBV', data : {pv:pv,pChips:newChips,round:upData1.round,game_id:upData1.game_id,sub_id:upData1.sub_id}, flag : true });

										var bct = commonClass.AddTime(config.BCT);
										c('startRound--pool--before---'+upData._id.toString()+'---jid: '+upData1.jid+'---bct: '+bct+'-------->>>>>'+new Date());
										schedule.scheduleJob(upData1.jid,new Date(bct),function(){
											schedule.cancelJob(upData1.jid);
											
											c('startRound----------->>>>>pv: '+pv);
											c('startRound--pool -after----'+upData1._id.toString()+'---jid: '+upData1.jid+'---bct: '+bct+'------->>>>>'+new Date());
											playingTableClass.dealCards(upData1._id.toString(),pv,pi);
										});

									}
									else{
										c('startRound----pool---xxxxxx'+upData._id.toString()+'---jid: '+jobId+'--pv: '+pv+'----bct: '+bct+'----xxxxxx>>>>>Error:"table not found"'+new Date());
									}
								});
							}
							else{
								cdClass.UpdateTableData(upData._id.toString(),{$inc:{sub_id:1}},function(){

									c('startRound----------->>>>>pv: '+pv);
									playingTableClass.dealCards(upData._id.toString(),pv,pi);
								});
							}
						});
					}
				}
				else if(resp.gt == 'Bet'){
					var minS = (resp.minS)?resp.minS:config.MIN_SEAT_TO_FILL_BET;
					var MIN_SEAT_TO_FILL_BET = (resp._ip == 1)?2:minS;
					if(resp.ap >= MIN_SEAT_TO_FILL_BET && resp.ap > 1){
						cdClass.UpdateTableData(resp._id.toString(),{$set:{_artFlag:0,_qstWin:0},$inc:{round:1,game_id:1}},function(upTb){
							if(upTb){

								c('startRound---------------->>>>>>upTb: ',upTb);
								playingTableClass.dealCards(upTb._id.toString(),0,upTb.pi);
							}
							else{
								c('startRound---------------->>>>>Error:"table not found"');
							}
						});
						
					}
					else if(resp.ap < MIN_SEAT_TO_FILL_BET || resp.ap == 1){
						c('startRound-------else if------->>>>>>');
						cdClass.UpdateTableData(resp._id.toString(),{$set:{tst: '',ctt:new Date(),_artFlag:0,_qstWin:0}},function(upData){

							playingTableClass.initializeGame(resp._id.toString());
						});
					}
				}
				else{  //classic rummy
					var minS = (resp.minS)?resp.minS:config.MIN_SEAT_TO_FILL;
					var MIN_SEAT_TO_FILL = (resp._ip == 1)?2:minS;
					c("sttartrnd-----------------minS:",minS);
					if(resp.ap >= MIN_SEAT_TO_FILL && resp.ap > 1){
						
						cdClass.UpdateTableData(resp._id.toString(),{$set:{tst:'CollectingBootValue',ctt:new Date()},$inc:{round:1}},function(upData){
							
							if(!upData){
								console.log('startRound---deal-----'+resp._id+'--------->>>>>>Error:"table not found"');
								return false;
							}
							c('startRound-------------'+upData._id+'----------ap: '+upData.ap+'---------->>>>');
							var pi = upData.pi;
							var pv = upData.pv;
							var newChips = [];
							var cutchip = upData.bv*config.MAX_DEADWOOD_PTS;
							for(var i in pi){

								if(!_.isEmpty(pi[i]) && typeof pi[i].si != 'undefined'){
									
									if(upData.mode == 'practice'){
										newChips.push({si:pi[i].si,chips:(pi[i].Chips-cutchip)});
										pi[i].Chips-= cutchip;
									}
									else if(upData.mode == 'cash'){
										newChips.push({si:pi[i].si,cash:(pi[i].totalCash-cutchip)});
										pi[i].totalCash-= cutchip;
									}

									pi[i].play = 1;
									pi[i].isCollect = 1;
									playingTableClass.collectBootValue(upData._id.toString(),upData.mode,pi[i].uid,upData.bv);
								}
							}
						})

						var jobId = commonClass.GetRandomString(10);
						cdClass.UpdateTableData(upData._id.toString(),{$set:{jid:jobId,pi:pi},$inc:{game_id:1}},function(upData1){
							
							if(upData1){
								commonClass.FireEventToTable(upData._id.toString(), { en : 'CBV', data : {pChips:newChips,round:upData1.round,game_id:upData1.game_id}, flag : true });

								var bct = commonClass.AddTime(config.BCT);
								c('startRound--deal--before---'+upData._id.toString()+'---jid: '+upData1.jid+'---bct: '+bct+'-------->>>>>'+new Date());
								schedule.scheduleJob(upData1.jid,new Date(bct),function(){
									schedule.cancelJob(upData1.jid);
									
									c('startRound----------->>>>>pv: '+pv);
									c('startRound--deal -after----'+upData1._id.toString()+'---jid: '+upData1.jid+'---bct: '+bct+'-------->>>>>'+new Date());
									playingTableClass.dealCards(upData1._id.toString(),pv,pi);
								});
							}
							else{
								c('startRound----deal---xxxxxx'+upData._id.toString()+'---jid: '+jobId+'--pv: '+pv+'   bct: '+bct+'----xxxxxx>>>>>Error:"table not found"'+new Date());
							}
						});
						// cdClass.UpdateTableData(resp._id.toString(),{$set:{_artFlag:0,_qstWin:0},$inc:{round:1,game_id:1}},function(upTb){
						// 	if(upTb){

						// 		c('startRound---------------->>>>>>upTb: ',upTb);
						// 		playingTableClass.dealCards(upTb._id.toString(),0,upTb.pi);
						// 	}
						// 	else{
						// 		c('startRound-------------------->>>>>Error: "table not found"');
						// 	}
						// });
						
					}
					else if(resp.ap < MIN_SEAT_TO_FILL || resp.ap == 1){
						c('startRound-------else if------->>>>>>');
						cdClass.UpdateTableData(resp._id.toString(),{$set:{tst: '',ctt:new Date(),_artFlag:0,_qstWin:0}},function(upData){

							playingTableClass.initializeGame(resp._id.toString());
						});
					}
				}
			}
			else{
				c('startRound:::::::::::::::::::::>>>>Error : "table not exist"')
				return false;
			}
		});
	},
	collectBootValue:function(tbId,mode,uid,chips){  //collects boot value
		/* +-------------------------------------------------------------------+
            desc:function to collect boot value from players
            i/p: tbId = table id,uid = user id,chips =  chips of player
        +-------------------------------------------------------------------+ */
		if(mode == 'practice'){

			cdClass.UpdateUserChips(uid,-chips,'Collect Boot Value',function(uChips){
				// c('collectBootValue----------->>>>>uChips: ',uChips);
				// db.collection('playing_table').update({_id:MongoID(tbId),'pi.uid':uid},{$set:{la:new Date(),'pi.$.Chips':uChips,'pi.$.play':1,'pi.$.isCollect':1}},function(){});
			})
		}
		else if (mode == 'cash') {
			var bc = chips*config.CASH_BONUS/100;
			cdClass.UpdateUserCashforgame(uid,-chips,bc,'Collect Boot Value',function(uChips){
				// c('collectBootValue----------->>>>>uChips: ',uChips);
				// db.collection('playing_table').update({_id:MongoID(tbId),'pi.uid':uid},{$set:{la:new Date(),'pi.$.Chips':uChips,'pi.$.play':1,'pi.$.isCollect':1}},function(){});
			})
		}
	},
	dealCards_old:function(tbId,pv,pi){ // deal cards
		/* +-------------------------------------------------------------------+
            desc:function to generate cards for players on table
            i/p: tbId = table id ,pv = pot value,pi = player details
        +-------------------------------------------------------------------+ */
        cdClass.GetTbInfo(tbId, function(tbInfo){
        	if(tbInfo){

        		var totalPlayers = playClass.getPlayingUserInRound(tbInfo.pi); 

        		if(totalPlayers.length > 1){

					cdClass.UpdateTableData(tbId,{$set:{tst:'StartDealingCard',pv:pv,ctt:new Date()}},function(resp){
						if(resp){

							c('dealCards-------------'+resp._id+'----------ap: '+resp.ap+'---------->>>>');

							//cheating logic here
							// var pi1 = resp.pi;
							// c('dealCards------------>>>>>>pi1: ',pi1);
							// var playCount = 0;
							// for(var i = 0;i < resp.ms; i++){
							// 	if(!_.isEmpty(pi1[i]) && typeof pi1[i].si != 'undefined'){
							// 		pi1[i].s = (resp.gt == 'Deal' && pi1[i].play == 1 || resp.gt != 'Deal') ? "playing" : "";
							// 		playCount = (resp.gt == 'Deal' && pi1[i].play == 1 || resp.gt != 'Deal') ? playCount+1 : playCount;
							// 		// playCount++;
							// 	}
							// }


							var pi1 = resp.pi;//(resp.gt == 'Classic' || resp.gt == 'Bet')?resp.pi:pi;
							c('dealCards-------1----->>>>>>pi1: ',pi1);
							var uCount = 0;
							var chipsArray = [];
							var playCount = 0;
							for(var i = 0;i < resp.ms; i++){
								if(!_.isEmpty(pi1[i]) && typeof pi1[i].si != 'undefined'){
									
									profileClass.ManageUserLevel('play',pi1[i].uid)
									pi1[i].s = ((resp.gt == 'Deal' || resp.gt == 'Pool') && pi1[i].play == 1 || resp.gt == 'Classic' || resp.gt == 'Bet') ? "playing" : "watch";
									
									playCount = ((resp.gt == 'Deal' || resp.gt == 'Pool') && pi1[i].play == 1 || resp.gt == 'Classic' || resp.gt == 'Bet') ? playCount+1 : playCount;

									pi1[i].rndCount = pi1[i].rndCount ? pi1[i].rndCount:0;
									if(pi1[i].s == 'playing'){
										pi1[i].gst = new Date();
										pi1[i].rndCount += 1;
									}
									if(pi1[i]._ir == 0){
										uCount++;
									}
									chipsArray.push(pi1[i].Chips);
									// playCount++;
								}
							}

							//logic for getting max bet value according to the least valued chips player
							var minChips = 0;
							var maxBet = 0;
							if(resp.gt == 'Bet'){
								minChips = _.min(chipsArray);
								maxBet = Math.round(minChips/160);
								// if(config.BET_RAISE_SCALE > 0){ //to round the max bet value
								// 	maxBet = maxBet-maxBet%config.BET_RAISE_SCALE;
								// 	maxBet = (maxBet <= resp.bbv) ? resp.bbv : maxBet;
								// }
								maxBet = maxBet-maxBet%50;
								maxBet = (maxBet <= resp.bbv) ? resp.bbv : maxBet;
							}

							c('dealCards---2---->>>>>pi1: ',pi1);
							// var cards = cardsClass.cardDistribution(resp);
							// var cards = cardsClass.cardDistribution({pi:pi1,ap:resp.ap});
							var players = playClass.getPlayingUserInRound(pi1,true); 
							c('dealCards--------->>>>>players: ',players);
							var thp = 0;
		
							//db.collection('player_cards').find({}).toArray(function(err,cdata){
								//if(cdata){
									//c('dealCards---------------->>>>>cdata: ',cdata);
									//var rInt1 = commonClass.GetRandomInt(1,cdata.length);
									/*var rInt1 = cdata[0]._id.toString();
									var rInt = commonClass.GetRandomInt(1,100);
									var bound = parseInt(cdata[0].prob);
									
									for(var i=0;i<cdata.length;i++){
										c('dealCards--------------------i:'+i);
										if(rInt <= bound){
											rInt1 = cdata[i]._id.toString();
											break;
										}
										else{
											bound = bound + parseInt(cdata[i+1].prob);
										}
									}*/

									//db.collection('player_cards').findOne({_id:MongoID(rInt1)},{},function(err,ftjData){

										// c('dealCards---------------->>>>>ftjData: ',ftjData);
									

										var obj = {
											pure: 0,
											seq: 0,
											set: 0,
											joker: 0,
											wildcard: 0,
											cSeq: 0,
											cSet: 0
										}

										/*if(ftjData){
											obj.pure = (ftjData.pure)?ftjData.pure:0;
											obj.seq = (ftjData.seq)?ftjData.seq:0;
											obj.set = (ftjData.set)?ftjData.set:0;
											obj.joker = (ftjData.joker)?ftjData.joker:0;
											obj.wildcard = (ftjData.wildcard)?ftjData.wildcard:0;
											obj.cSeq = (ftjData.cSeq)?ftjData.cSeq:0;
											obj.cSet = (ftjData.cSet)?ftjData.cSet:0;
										}*/

										
										// c('dealCards----------------->>>>>obj: ',obj);
										var cards = cardsClass.cardDistribution(pi1,obj);
										c('dealCards------->>>>>cards: ',cards);
										// var turn = playClass.chooseTurnUser(resp);
										// var turn = 0;
										c('dealCards----3--->>>>>pi1: ',pi1,' resp.dealer: ',resp.dealer,' ms: ',resp.ms);
										/*var tosscards = cardsClass.cardDistributionToss(pi1);
										var tcds = [];
										for(var k = 0;k < resp.ms; k++){
											if(!_.isEmpty(pi1[k]) && typeof pi1[k].si != 'undefined' && pi1[k].s == 'playing'){
												pi1[k].tcard = tosscards.sCards[k];
												tcds.push(tosscards.sCards[k]);
											}
										}*/

										/*var highcd = cardsClass.getHighCard(tcds);
										for(var j = 0;j < resp.ms; j++){
											if(pi1[j].tcard == tcds[highcd]){
												resp.dealer = pi1[j].si;
												resp.turn = pi1[j].si;
												turn = pi1[j].si;
											}
										}*/
										var dealer = playClass.chooseTurnUser({pi:pi1,dealer:resp.dealer,ms:resp.ms});
										resp.dealer = dealer;
										resp.turn = dealer;
										var nextTurn = playClass.getNextPlayer(resp);		
										var turn = nextTurn.nxt;
										//if turn user not found
										if(turn == -1){
											console.log('dealCards:::::'+resp._id+'::::turn: '+turn+':::::totalPlayers: ',totalPlayers,':::pi1: ',pi1,'::>>>>Error: "turn user not found" '+new Date());
											return false;
										}

										//logic for creating seat index array with dealer index first
										// var players = playClass.getPlayingUserInRound(resp.pi);
										
										//out of chips alert logic here

										var game_id = resp.game_id;
								        if(resp.gt == 'Deal' || resp.gt == 'Pool'){ 
								           
								            game_id = game_id+'.'+resp.sub_id;
								        }


										/*for(var i in players){
											var reqChips = (resp.gt == 'Deal' || resp.gt == 'Pool') ? resp.bv*2 : resp.bv*config.MAX_DEADWOOD_PTS*2;
											c('dealCards----------'+resp._id+'------->>>>>>>reqChips: '+reqChips);
											if(players[i].Chips < reqChips){
												//send alert logic here
												// strClass.alertPop(players[i].uid,reqChips,resp.bv,resp.gt);
											}
										}*/

										var seats = [];
										// var nCards = []; //temp logic
										for(var x in players){
											seats.push(players[x].si);
											// nCards.push(players[x].cards);
										}
										
										var t,u;
										for(var i in seats){
											if(seats[0] == turn){
												break;
											}
											else{
												t = seats.splice(0,1)[0];
												seats.push(t);
												
											}
										}
										
										var jobId = commonClass.GetRandomString(10);
										// playClass.getTableScore(resp._id.toString(),function(tScore){
											
											// var pi1 = resp.pi;
											// c('dealCards------------>>>>>>pi1: ',pi1);
											// var playCount = 0;
											// for(var i = 0;i < resp.ms; i++){
											// 	if(!_.isEmpty(pi1[i]) && typeof pi1[i].si != 'undefined'){
											// 		pi1[i].s = (pi1[i].play == 1) ? "playing" : "";
											// 		playCount = (pi1[i].play == 1) ? playCount+1 : playCount;
											// 		// playCount++;
											// 	}
											// }
										c('dealCards-------4---->>>>>pi1: ',pi1);

										var activePlayers = playClass.getPlayingUserInRound(pi1);



										c('dealCards-----------5------->>>> uCount: '+uCount+' activePlayers: ',activePlayers);


										cdClass.UpdateTableData(resp._id,{$set:{ap:activePlayers.length,uCount:uCount,pi:pi1,playCount:playCount,turn:turn,dealer:dealer,jid:jobId, maxBet:maxBet}},function(table){
											if(!table){
												console.log('dealCards:::::::::'+resp._id+':::::::::>>>>>>>>Error:"table not found"'+new Date());
												return false;
											}
											commonClass.FireEventToTable(table._id.toString(), { en : 'SDS', data : {dealer:table.dealer,round:table.round,game_id:table.game_id,sub_id:table.sub_id,si:seats,maxBet:table.maxBet}, flag : true });
											trackClass.PlayTrack(table._id.toString());
											var dst = commonClass.AddTime(config.DST);
											schedule.scheduleJob(table.jid,new Date(dst),function(){
												schedule.cancelJob(table.jid);
												cdClass.GetTbInfo(table._id.toString(),{pi:1,ms:1},function(resp1){
													if(!resp1){
														console.log('dealCards::::::'+table._id.toString()+':::::::>>>>>Error:"table not found!!!"'+new Date());
														return false;
													}
													var pi2 =  resp1.pi;

													for(var j = 0;j < resp1.ms; j++){
														if(!_.isEmpty(pi2[j]) && typeof pi2[j].si != 'undefined' && pi2[j].s == 'playing'){
															pi2[j].cards = cards.sCards[j];
															pi2[j].gCards = [];
														}
													}

													cdClass.UpdateTableData(resp1._id.toString(),{$set:{pi:pi2,wildCard:cards.wildCard,cDeck:cards.cDeck},$push:{oDeck:cards.tCard}},function(table1){
														if(table1){

															c('dealCards-------upd-------->>>>>table1: ',table1);
															commonClass.FireEventToTable(table1._id.toString(), { en : 'SDC', data : {dealer:table1.dealer,si : seats,wildCard:cards.wildCard,tCard:cards.tCard,ap:table1.ap,round: table1.round/*,nCards:nCards*/}, flag : true });
															//distributing cards to all players

															for(var x = 0;x < table1.ms; x++){
																if(!_.isEmpty(table1.pi[x]) && typeof table1.pi[x].si != 'undefined'){
																	
																	playingTableClass.sendCards(table1.pi[x].uid,table1.pi[x]._ir,table1.pi[x].s,table1.pi[x].cards,table1.oDeck[0],table1.wildCard,seats);
																	
																}
															}
															cdClass.UpdateTableData(table1._id.toString(),{$set:{tst:'CardsDealt',ctt:new Date()}},function(table3){

																setTimeout(function(){  //delay after cards distribution
																	cdClass.UpdateTableData(table1._id.toString(),{$set:{tst:'RoundStarted',ctt:new Date()}},function(table2){
																		
																	
																		if(table2){
																			
																			c('dealCards----------->>>>>userturn2');
																			playingTableClass.startUserTurn(table2._id.toString(),'cards_dealt');
																			
																		}
																		else{
																			console.log('dealCards---1----'+table1._id.toString()+'----->>>>>>Msg:"table not found!!!"'+new Date());
																		}
																	});
																},6000);
															});
														}
														else{
															console.log('dealCards--2----'+resp1._id.toString()+'::pi2: ',pi2,'---->>>>>>Error:"table not found"'+new Date());
														}
													});
												});
											});
										});
										// });
									//});
								//}
							//});		

						}
						else{
							console.log('dealCards:::::'+tbId+':::::::>>>>>>Error: "table not found"'+new Date());
						}
					});
        		}
        		else{
        			console.log('dealCards:::::::'+tbId+':::totalPlayers: ',totalPlayers,':::\npi: ',tbInfo.pi,'::::pv: '+pv+'::>>>>"not sufficient user found on table"'+new Date());
        		}
        	}
        	else{
        		console.log('dealCards:::::::::'+tbId+':::pv: '+pv+':::::pi: ',pi,':::>>>>"Table not found"'+new Date());
        	}
        });
	},
	dealCards:function(tbId,pv,pi){ // deal cards
		/* +-------------------------------------------------------------------+
            desc:function to generate cards for players on table
            i/p: tbId = table id ,pv = pot value,pi = player details
        +-------------------------------------------------------------------+ */
        cdClass.GetTbInfo(tbId, function(tbInfo){
        	if(tbInfo){

        		var totalPlayers = playClass.getPlayingUserInRound(tbInfo.pi); 

        		if(totalPlayers.length > 1){

					cdClass.UpdateTableData(tbId,{$set:{tst:'StartDealingCard',pv:pv,ctt:new Date()}},function(resp){
						if(resp){

							c('dealCards-------------'+resp._id+'----------ap: '+resp.ap+'---------->>>>');

							//cheating logic here
							// var pi1 = resp.pi;
							// c('dealCards------------>>>>>>pi1: ',pi1);
							// var playCount = 0;
							// for(var i = 0;i < resp.ms; i++){
							// 	if(!_.isEmpty(pi1[i]) && typeof pi1[i].si != 'undefined'){
							// 		pi1[i].s = (resp.gt == 'Deal' && pi1[i].play == 1 || resp.gt != 'Deal') ? "playing" : "";
							// 		playCount = (resp.gt == 'Deal' && pi1[i].play == 1 || resp.gt != 'Deal') ? playCount+1 : playCount;
							// 		// playCount++;
							// 	}
							// }


							var pi1 = resp.pi;//(resp.gt == 'Classic' || resp.gt == 'Bet')?resp.pi:pi;
							c('dealCards-------1----->>>>>>pi1: ',pi1);
							var uCount = 0;
							var chipsArray = [];
							var playCount = 0;
							for(var i = 0;i < resp.ms; i++){
								if(!_.isEmpty(pi1[i]) && typeof pi1[i].si != 'undefined'){
									
									profileClass.ManageUserLevel('play',pi1[i].uid)
									pi1[i].s = ((resp.gt == 'Deal' || resp.gt == 'Pool') && pi1[i].play == 1 || resp.gt == 'Classic' || resp.gt == 'Bet') ? "playing" : "watch";
									
									playCount = ((resp.gt == 'Deal' || resp.gt == 'Pool') && pi1[i].play == 1 || resp.gt == 'Classic' || resp.gt == 'Bet') ? playCount+1 : playCount;

									pi1[i].rndCount = pi1[i].rndCount ? pi1[i].rndCount:0;
									if(pi1[i].s == 'playing'){
										pi1[i].gst = new Date();
										pi1[i].rndCount += 1;
									}
									if(pi1[i]._ir == 0){
										uCount++;
									}
									chipsArray.push(pi1[i].Chips);
									// playCount++;
								}
							}

							//logic for getting max bet value according to the least valued chips player
							var minChips = 0;
							var maxBet = 0;
							if(resp.gt == 'Bet'){
								minChips = _.min(chipsArray);
								maxBet = Math.round(minChips/160);
								// if(config.BET_RAISE_SCALE > 0){ //to round the max bet value
								// 	maxBet = maxBet-maxBet%config.BET_RAISE_SCALE;
								// 	maxBet = (maxBet <= resp.bbv) ? resp.bbv : maxBet;
								// }
								maxBet = maxBet-maxBet%50;
								maxBet = (maxBet <= resp.bbv) ? resp.bbv : maxBet;
							}

							c('dealCards---2---->>>>>pi1: ',pi1);
							// var cards = cardsClass.cardDistribution(resp);
							// var cards = cardsClass.cardDistribution({pi:pi1,ap:resp.ap});
							var players = playClass.getPlayingUserInRound(pi1,true); 
							c('dealCards--------->>>>>players: ',players);
							var thp = 0;
		
							//db.collection('player_cards').find({}).toArray(function(err,cdata){
								//if(cdata){
									//c('dealCards---------------->>>>>cdata: ',cdata);
									//var rInt1 = commonClass.GetRandomInt(1,cdata.length);
									/*var rInt1 = cdata[0]._id.toString();
									var rInt = commonClass.GetRandomInt(1,100);
									var bound = parseInt(cdata[0].prob);
									
									for(var i=0;i<cdata.length;i++){
										c('dealCards--------------------i:'+i);
										if(rInt <= bound){
											rInt1 = cdata[i]._id.toString();
											break;
										}
										else{
											bound = bound + parseInt(cdata[i+1].prob);
										}
									}*/

									//db.collection('player_cards').findOne({_id:MongoID(rInt1)},{},function(err,ftjData){

										// c('dealCards---------------->>>>>ftjData: ',ftjData);
									

										var obj = {
											pure: 0,
											seq: 0,
											set: 0,
											joker: 0,
											wildcard: 0,
											cSeq: 0,
											cSet: 0
										}

										/*if(ftjData){
											obj.pure = (ftjData.pure)?ftjData.pure:0;
											obj.seq = (ftjData.seq)?ftjData.seq:0;
											obj.set = (ftjData.set)?ftjData.set:0;
											obj.joker = (ftjData.joker)?ftjData.joker:0;
											obj.wildcard = (ftjData.wildcard)?ftjData.wildcard:0;
											obj.cSeq = (ftjData.cSeq)?ftjData.cSeq:0;
											obj.cSet = (ftjData.cSet)?ftjData.cSet:0;
										}*/

										
										// c('dealCards----------------->>>>>obj: ',obj);
										var cards = cardsClass.cardDistribution(pi1,obj);
										c('dealCards------->>>>>cards: ',cards);
										// var turn = playClass.chooseTurnUser(resp);
										var turn = resp.turn;
										var dealer = resp.dealer;
										c('dealCards----3--->>>>>pi1: ',pi1,' resp.dealer: ',resp.dealer,' ms: ',resp.ms);
										if(pi1 && pi1.length > 1 && resp.dealer == -1){

											// var tosscards = cardsClass.cardDistributionToss(pi1);
											var tosscards = cardsClass.getCardsForToss(pi1);
											var tcds = [];
											var tcards = [];
											var toss = false;
											for(var k = 0;k < resp.ms; k++){
												if(!_.isEmpty(pi1[k]) && typeof pi1[k].si != 'undefined' && pi1[k].s == 'playing'){
													pi1[k].tcard = tosscards.sCards[k][0];
													c("tosscards.sCards[k]:",tosscards.sCards[k][0]);
													tcds.push(tosscards.sCards[k][0]);
													tcards.push({uid:pi1[k].uid,si:pi1[k].si,tcard:tosscards.sCards[k][0]})
												}
											}


											var highcd = cardsClass.getHighCard(tcds);
											console.log("dealCards--------------->>>>>>>>highcd: "+highcd)
											for(var j = 0;j < resp.ms; j++){
												if(pi1[j].tcard == tcds[highcd]){
													resp.dealer = pi1[j].si;
													resp.turn = pi1[j].si;
													turn = pi1[j].si;
													dealer = pi1[j].si;
													toss = true;
												}
											}
										} else {
											var i = 0,k = resp.dealer;
											tcards = [];
											while(i < resp.ms){

												k = (k+1)%resp.ms;
												if(!_.isEmpty(pi1[k]) && pi1[k].s == 'playing'){
													resp.dealer = k;
													resp.turn = k;
													turn = k;
													dealer = k;
													toss = false;
													break;
												}
												i++;
											}
										}
										/*var dealer = playClass.chooseTurnUser({pi:pi1,dealer:resp.dealer,ms:resp.ms});
										resp.dealer = dealer;
										resp.turn = dealer;
										var nextTurn = playClass.getNextPlayer(resp);		
										var turn = nextTurn.nxt;*/
										//if turn user not found
										if(turn == -1){
											console.log('dealCards:::::'+resp._id+'::::turn: '+turn+':::::totalPlayers: ',totalPlayers,':::pi1: ',pi1,'::>>>>Error: "turn user not found" '+new Date());
											return false;
										}

										//logic for creating seat index array with dealer index first
										// var players = playClass.getPlayingUserInRound(resp.pi);
										
										//out of chips alert logic here

										var game_id = resp.game_id;
								        if(resp.gt == 'Deal' || resp.gt == 'Pool'){ 
								           
								            game_id = game_id+'.'+resp.sub_id;
								        }


										/*for(var i in players){
											var reqChips = (resp.gt == 'Deal' || resp.gt == 'Pool') ? resp.bv*2 : resp.bv*config.MAX_DEADWOOD_PTS*2;
											c('dealCards----------'+resp._id+'------->>>>>>>reqChips: '+reqChips);
											if(players[i].Chips < reqChips){
												//send alert logic here
												// strClass.alertPop(players[i].uid,reqChips,resp.bv,resp.gt);
											}
										}*/

										var seats = [];
										// var nCards = []; //temp logic
										for(var x in players){
											seats.push(players[x].si);
											// nCards.push(players[x].cards);
										}
										
										var t,u;
										for(var i in seats){
											if(seats[0] == turn){
												break;
											}
											else{
												t = seats.splice(0,1)[0];
												seats.push(t);
												
											}
										}
										
										var jobId = commonClass.GetRandomString(10);
										// playClass.getTableScore(resp._id.toString(),function(tScore){
											
											// var pi1 = resp.pi;
											// c('dealCards------------>>>>>>pi1: ',pi1);
											// var playCount = 0;
											// for(var i = 0;i < resp.ms; i++){
											// 	if(!_.isEmpty(pi1[i]) && typeof pi1[i].si != 'undefined'){
											// 		pi1[i].s = (pi1[i].play == 1) ? "playing" : "";
											// 		playCount = (pi1[i].play == 1) ? playCount+1 : playCount;
											// 		// playCount++;
											// 	}
											// }
										c('dealCards-------4---->>>>>pi1: ',pi1);

										var activePlayers = playClass.getPlayingUserInRound(pi1);



										c('dealCards-----------5------->>>> uCount: '+uCount+' activePlayers: ',activePlayers);


										cdClass.UpdateTableData(resp._id,{$set:{ap:activePlayers.length,uCount:uCount,pi:pi1,playCount:playCount,turn:turn,dealer:dealer,jid:jobId, maxBet:maxBet}},function(table){
											if(!table){
												console.log('dealCards:::::::::'+resp._id+':::::::::>>>>>>>>Error:"table not found"'+new Date());
												return false;
											}
											commonClass.FireEventToTable(table._id.toString(), { en : 'SDS', data : {dealer:table.dealer,toss:toss,tcards:tcards,round:table.round,game_id:table.game_id,sub_id:table.sub_id,si:seats,maxBet:table.maxBet}, flag : true });
											trackClass.PlayTrack(table._id.toString());
											if(toss == true){
												var dst = commonClass.AddTime(config.DST);
											}
											else{
												var dst = commonClass.AddTime(config.DST2);;
											}
											schedule.scheduleJob(table.jid,new Date(dst),function(){
												schedule.cancelJob(table.jid);
												cdClass.GetTbInfo(table._id.toString(),{pi:1,ms:1},function(resp1){
													if(!resp1){
														console.log('dealCards::::::'+table._id.toString()+':::::::>>>>>Error:"table not found!!!"'+new Date());
														return false;
													}
													var pi2 =  resp1.pi;

													for(var j = 0;j < resp1.ms; j++){
														if(!_.isEmpty(pi2[j]) && typeof pi2[j].si != 'undefined' && pi2[j].s == 'playing'){
															pi2[j].cards = cards.sCards[j];
															pi2[j].gCards = {pure:[],seq:[],set:[],dwd:[]};
														}
													}

													cdClass.UpdateTableData(resp1._id.toString(),{$set:{pi:pi2,wildCard:cards.wildCard,cDeck:cards.cDeck},$push:{oDeck:cards.tCard}},function(table1){
														if(table1){

															c('dealCards-------upd-------->>>>>table1: ',table1);
															commonClass.FireEventToTable(table1._id.toString(), { en : 'SDC', data : {dealer:table1.dealer,si : seats,wildCard:cards.wildCard,tCard:cards.tCard,ap:table1.ap,round: table1.round/*,nCards:nCards*/}, flag : true });
															//distributing cards to all players

															for(var x = 0;x < table1.ms; x++){
																if(!_.isEmpty(table1.pi[x]) && typeof table1.pi[x].si != 'undefined'){
																	
																	playingTableClass.sendCards(table1.pi[x].uid,table1.pi[x]._ir,table1.pi[x].s,table1.pi[x].cards,table1.oDeck[0],table1.wildCard,seats);
																	
																}
															}
															cdClass.UpdateTableData(table1._id.toString(),{$set:{tst:'CardsDealt',ctt:new Date()}},function(table3){

																setTimeout(function(){  //delay after cards distribution
																	cdClass.UpdateTableData(table1._id.toString(),{$set:{tst:'RoundStarted',ctt:new Date()}},function(table2){
																		
																	
																		if(table2){
																			
																			c('dealCards----------->>>>>userturn2');
																			playingTableClass.startUserTurn(table2._id.toString(),'cards_dealt');
																			
																		}
																		else{
																			console.log('dealCards---1----'+table1._id.toString()+'----->>>>>>Msg:"table not found!!!"'+new Date());
																		}
																	});
																},6000);
															});
														}
														else{
															console.log('dealCards--2----'+resp1._id.toString()+'::pi2: ',pi2,'---->>>>>>Error:"table not found"'+new Date());
														}
													});
												});
											});
										});
										// });
									//});
								//}
							//});		

						}
						else{
							console.log('dealCards:::::'+tbId+':::::::>>>>>>Error: "table not found"'+new Date());
						}
					});
        		}
        		else{
        			console.log('dealCards:::::::'+tbId+':::totalPlayers: ',totalPlayers,':::\npi: ',tbInfo.pi,'::::pv: '+pv+'::>>>>"not sufficient user found on table"'+new Date());
        		}
        	}
        	else{
        		console.log('dealCards:::::::::'+tbId+':::pv: '+pv+':::::pi: ',pi,':::>>>>"Table not found"'+new Date());
        	}
        });
	},
	GPTCL:function(data,client){    //Get Pool Table Category List; data = {pCount}
        /* +-------------------------------------------------------------------+
            desc:this event is used to get pool rummy category list
            i/p: data = {}, client = socket object
            o/p: GPTCL event, data = pool category list
        +-------------------------------------------------------------------+ */
        data.mode = (typeof data.mode != 'undefined') ? data.mode : 'practice';
        data.pCount = (typeof data.pCount != 'undefined') ? data.pCount : 4;
        db.collection('pool_category').find({mode:data.mode,pCount:data.pCount}).sort({fee:1}).toArray(function(err,resp){
            c('GPTCL-------------->>>>>resp: ',resp);
            if(resp && resp.length > 0 ){
                for(var i in resp){
                    resp[i].prize = (resp[i].fee*resp[i].pCount*(100-resp[i].reke))/100;
                }
                c('GPTCL------------>>>>resp: ',resp);

                commonClass.SendData(client,'GPTCL',resp);
            }
            else{

                commonClass.SendData(client,'PUP',{},'error:1021'); //category list not found
            }
        });
    },
    GPTC:function(data,client){ //get point table category
    	
    	data.mode = (typeof data.mode != 'undefined') ? data.mode : 'practice';
        data.pCount = (typeof data.pCount != 'undefined') ? data.pCount : 4;
        db.collection('playing_category').find({mode:data.mode,pCount:data.pCount}).sort({cpp:1}).toArray(function(err,resp){
            c('GPTC-------------->>>>>resp: ',resp);
            if(resp && resp.length > 0 ){

                commonClass.SendData(client,'GPTC',resp);
            }
            else{

                commonClass.SendData(client,'PUP',{},'error:1021'); //category list not found
            }
        });
    },
    GDTC:function(data,client){ //get deal table category
    	data.mode = (typeof data.mode != 'undefined') ? data.mode : 'practice';
        db.collection('deal_category').find({mode:data.mode,deals:data.deals}).sort({fee:1}).toArray(function(err,resp){
            c('GDTC-------------->>>>>resp: ',resp);
            if(resp && resp.length > 0 ){

                commonClass.SendData(client,'GDTC',resp);
            }
            else{

                commonClass.SendData(client,'PUP',{},'error:1021'); //category list not found
            }
        });
    },
    GBTC:function(data,client){ //get bet rummy table category
    	data.mode = (typeof data.mode != 'undefined') ? data.mode : 'practice';
        db.collection('playing_category').find({mode:data.mode}).sort({cpp:1}).toArray(function(err,resp){
            c('GBTC-------------->>>>>resp: ',resp);
            if(resp && resp.length > 0 ){

                commonClass.SendData(client,'GBTC',resp);
            }
            else{

                commonClass.SendData(client,'PUP',{},'error:1021'); //category list not found
            }
        });
    },
	sendCards:function(uid,_ir,sts,cards,top,wildCard,seats){  //send data to users
		/* +-------------------------------------------------------------------+
            desc:function to deal cards to players on table
            i/p: uid = _id of user
            	_ir = is robot or not
            	sts = status of player
            	cards = cards of player
            	top = top card
            	wildCard = wildcard
            	seats = seat index of user
            o/p: SMC event : data = {
            					cards = cards of player
            					wildCard = wildcard
            					tCard = top card for game
            					si = seat index}
        +-------------------------------------------------------------------+ */
		if(_ir == 0 && sts == "playing"){
			c('sendCards----------->>>>_ir: '+_ir);
			commonClass.SendDirect(uid, { en : 'SMC', data : { cards : cards,wildCard:wildCard,tCard:top,si:seats}},true);
		}	
	},
	changeTableTurn: function(tbId,lastAction){   //change turn on table
		/* +-------------------------------------------------------------------+
            desc:function to change table turn
            i/p: tbId = table id 
        +-------------------------------------------------------------------+ */
		cdClass.GetTbInfo(tbId,{_id:1,ms:1,turn:1,ap:1,pi:1,dealer:1,rSeq:1},function(table){
			if(table){

				c('changeTableTurn---------->>>>>>table: ',table);
				var nextTurn = playClass.getNextPlayer(table);
				if(typeof nextTurn == 'undefined' || nextTurn == null || typeof nextTurn.nxt == 'undefined'){
					c('changeTableTurn:::::::::::>>>>>Error:"turn user not found"');
					return false;
				}

				c('changeTableTurn--------',table._id,'-------->>>>nextTurn: ',nextTurn);   //nextTurn will only undefined when there is only one player is there with status playing

				var upData = {$set:{turn:nextTurn.nxt}};
				if(nextTurn.chRound){
					upData['$inc'] = {rSeq:1};
				}
				cdClass.UpdateTableData(table._id.toString(), upData, function(table1){
					if(table1){
						c('changeTableTurn-------->>>>userturn1');
						playingTableClass.startUserTurn(table1._id.toString(),lastAction);
					}
					else{
						c('changeTableTurn----------->>>>Error:"table not found"');
					}
				});
			}
			else{
				c('changeTableTurn:::::::::'+tbId+'::::::::>>>>>Error:"table not found!!!"');
			}
		});
	},
	startUserTurn:function(tbId,lastAction){  //initializes the user timer and handovers the control to the turn user 
		/* +-------------------------------------------------------------------+
            desc:function to start user turn
            i/p: tbId = table id 
        +-------------------------------------------------------------------+ */
		var jobId = commonClass.GetRandomString(10);
		cdClass.UpdateTableData(tbId,{$set:{jid:jobId,ctt:new Date()}},function(table){

			if(!table){    //condition will be true when there is only one player on table
				c('startUserTurn:::::::::::::::>>>Error: "table not found!!!"');
				return false;
			}
			if(typeof table.turn == 'undefined' || table.turn == null){
				c('startUserTurn::::::::::::if::::::::::>>>>Error: "turn user not found!!!"');
				return false;
			}
			c('startUserTurn----------'+table._id+'-----------'+table.turn+'------------>>>>'); 
			if(typeof table.pi[table.turn] == 'undefined' || table.pi[table.turn] == null){
				c('startUserTurn::::::::::::if:::::::::::>>>>>Error: "turn user not found"');
				return false;
			}

			if(table.gt == 'Bet'){
				var scaleN = config.BET_RAISE_SCALE;
				if(scaleN == 0){
					scaleN = 5;
				}
				var scale = Math.round(table.maxBet/scaleN);
				scale = scale-scale%50;
				scale = (scale == 0) ? 50 : scale;
			}
			else{
				scale = 0;
			}

			cdClass.GetUserInfo(table.pi[table.turn].uid,{_id:1,'counters.thp':1,flags:1},function(uInfo){
				var thp = 0;
				/*var showSortBtn = false;
				var firstPick = false;
				var firstSort = false;*/
				/*if(uInfo){
					thp = uInfo.counters.thp;
					if(config.ASSIST_TUT && (uInfo.counters.thp < config.SORT_BTN_SHOW_GAME_COUNT || config.SORT_BTN_SHOW)){
						showSortBtn = true;
					}


					if(config.ASSIST_TUT && config.ASSIST_FIRST_PICK && uInfo.flags._ir == 0 && typeof uInfo.flags._fPick != 'undefined' && uInfo.flags._fPick == 0){
						firstPick = true;
					}
					if(config.ASSIST_TUT && config.ASSIST_FIRST_SORT && uInfo.flags._ir == 0 && typeof uInfo.flags._fSort != 'undefined' && uInfo.flags._fSort == 0){
						firstSort = true;
					}
				}*/
				var time = config.SECONDARY_TIMER / config.MAX_TIMEOUT;
				c('startUserTurn--------1--------->>>>time: '+time);
				var t = table.pi[table.turn].secTime;
				/*if(table.pi[table.turn].secTime > time){
					t = time;
				}
				else{
					t = table.pi[table.turn].secTime;
				}*/

				commonClass.FireEventToTable(tbId, { en : 'UTS', data : {si : table.turn,uid:table.pi[table.turn].uid,scale:scale,maxBet:table.maxBet,bbv:table.bbv,rSeq:table.rSeq,thp:thp,t:t,time:table.pi[table.turn].secTime/*showSortBtn:showSortBtn,firstPick:firstPick,firstSort:firstSort*/}});
				
				c('startUserTurn----------------->>>>lastAction: '+lastAction);
				// if(lastAction){
				// 	var action = '';
					

					/*switch(lastAction){
						case 'cards_dealt':
						case 'discard':
						case 'pick_skip':
						case 'skip':
								action = 'game_play';
								break;
						case 'drop':
						case 'invalid_declare':
						case 'standup':
						case 'back_to_lobby':
						case 'ftu_bot_change':
						case 'user_score_change':
						case 'out_of_chips':
						case 'booted_out':
						case 'user_disconnected':
						case 'pool_elimination':
						case 'exit':
								action = 'game_end';
								break;
					}*/

					/*var game_id = table.game_id;
					if(table.gt == 'Deal' || table.gt == 'Pool'){
						game_id = game_id+'.'+table.sub_id;
					}*/

				// }


				if(!_.isEmpty(table.pi[table.turn]) && table.pi[table.turn]._ir == 0){  //if it is user turn
					
					
					var stt = commonClass.AddTime(config.STT+2);   //extra 2 sec
					schedule.scheduleJob(jobId,new Date(stt),function(){
						schedule.cancelJob(jobId);
						
						var jId = commonClass.GetRandomString(10);

						db.collection('playing_table').findAndModify({_id: MongoID(tbId),'pi.si':table.turn},{},{$set:{jid:jId,'pi.$.tsd':new Date(),'pi.$.sct':true}},{new:true},function(err,table1){

							if(parseInt(table.pi[table.turn].secTime) > 0){
								// var time = config.SECONDARY_TIMER / config.MAX_TIMEOUT;
								commonClass.FireEventToTable(tbId, { en : 'STS', data : {si : table.turn,uid:table.pi[table.turn].uid,t:t,time:table.pi[table.turn].secTime}});
								// var t = table.pi[table.turn].secTime;
								// if(table.pi[table.turn].secTime > time){
								// 	t = time;
								// }
								// else{
								// 	t = table.pi[table.turn].secTime;
								// }

								c('startUserTurn--------1--------->>>>t: '+t);
								var stt1 = commonClass.AddTime(t);
								
								c('startUserTurn---------2-------->>>>stt1: '+stt1);
								schedule.scheduleJob(jId,new Date(stt1),function(){
									schedule.cancelJob(jId);
									jtClass.onTurnExpire(table1.value);	
								})
							}
							else{
								c('startUserTurn----------3------->>>>stt1: '+stt1);
								jtClass.onTurnExpire(table1.value);	
							}
						})
					});
				}
				else if(!_.isEmpty(table.pi[table.turn]) && table.pi[table.turn]._ir == 1){  //if it is robot turn 
					// db.collection('robot_time').find({"rType":table.pi[table.turn].rType}).toArray(function(err, res){
					// 	var rInt = commonClass.GetRandomInt(0,100);
					// 	var bound = res[0].tout;
					// 	if(rInt <= bound)
					// 	{
					// 		c('\n[Bot timeout]-----------true--------->>>>>>>"bot will not take turn"');
					// 		var stt = commonClass.AddTime(config.STT);   //extra 2 sec
					// 		schedule.scheduleJob(jobId,new Date(stt),function(){
					// 			schedule.cancelJob(jobId);
								
					// 			var jId = commonClass.GetRandomString(10);

					// 			db.collection('playing_table').findAndModify({_id: MongoID(tbId),'pi.si':table.turn},{},{$set:{jid:jId,'pi.$.tsd':new Date(),'pi.$.sct':true}},{new:true},function(err,table1){

					// 				if(parseInt(table.pi[table.turn].secTime) > 0){

					// 					c('startUserTurn--------1--------->>>>t: '+t);
					// 					var stt1 = commonClass.AddTime(t);
					// 					c('[Bot timeout]---------2-------->>>>stt1: '+stt1);
										
					// 					commonClass.FireEventToTable(tbId, { en : 'STS', data : {si : table.turn,uid:table.pi[table.turn].uid,t:t,time:table.pi[table.turn].secTime}});
					// 					schedule.scheduleJob(jId,new Date(stt1),function(){
					// 						schedule.cancelJob(jId);
											
					// 						jtClass.onTurnExpire(table1.value);	
					// 					})
					// 				}
					// 				else{
					// 					c('[Bot timeout]----------3------->>>>stt1: '+stt1);
					// 					jtClass.onTurnExpire(table1.value);	
					// 				}
					// 			})
					// 			// jtClass.onTurnExpire(table);	
					// 		});
					// 	}
					// 	else
					// 	{
							c('\n[Bot timeout]-----------false--------->>>>>>>"bot will take turn"');
							var robotTime = commonClass.GetRandomInt(config.ROBOT_TURN_DELAY[0],config.ROBOT_TURN_DELAY[1]);
							var rtt = commonClass.AddTime(robotTime);
							schedule.scheduleJob(jobId,new Date(rtt),function(){
								schedule.cancelJob(jobId);
								robotsClass.robotTurnStarted(table._id.toString());
							});
					// 	}
					// })
					
				}
				else{
					c('startUserTurn::::::::::::else::::::::::>>>>Error: "turn user not found!!!"');
				}
			});

		});
	},
	lateUserDeclare:function(table,si){
		/* +-------------------------------------------------------------------+
            desc:function to handle late user declaration
            i/p: table = table details, si = seat index of user
        +-------------------------------------------------------------------+ */
		if(!table){
			c('lateUserDeclare:::::::::::>>>>>Error: "table not found!!!"');
			return false;
		}
		if(table.pi[si].gCards.length > 0){

			var formattedCards = cardsClass.cardsFormatter(table.pi[si].gCards,table.wildCard);
			// console.log('lateUserDeclare------>>>>analysedCards: ',analysedCards);
			var cond = false;

			if(config.ONE_SEQUENCE_POINTS){
				cond = formattedCards.pure.length > 0;
			}
			else{
				cond = (formattedCards.pure.length > 0  && (formattedCards.pure.length+formattedCards.seq.length) >1);
			}
			if(cond){   //means the grouping is valid

				var dCards = formattedCards;
				var ps = playingTableClass.cardsValidPoints(dCards,table.wildCard);
			}
			else{ //means all the cards will be considered as deadwood
				var temp = formattedCards.pure.concat(formattedCards.seq).concat(formattedCards.set).concat(formattedCards.dwd);
				temp = _.flatten(temp);
				var dCards = {pure:[],seq:[],set:[],dwd:temp};
				var ps = cardsClass.cardsSum(temp,table.wildCard);
			}

			playClass.DECL({dCards:dCards,ps : ps},{si:si,tbid:table._id.toString()},true); 
		}
		else{
			var dCards = {pure:[],seq:[],set:[],dwd:table.pi[si].cards};
			var ps = cardsClass.cardsSum(table.pi[si].cards,table.wildCard);
			playClass.DECL({dCards:dCards,ps : ps},{si:si,tbid:table._id.toString()},true); 
		}	
	},
	declareRoundWinner:function(tbId,direct){
		/* +-------------------------------------------------------------------+
            desc:function to declare round winner
            i/p: tbId = table id, direct = true/false if true then direct winner declaration
        +-------------------------------------------------------------------+ */
		cdClass.GetTbInfo(tbId,{},function(table){
			var players = playClass.getPlayingUserInRound(table.pi);
			// var winner = -1;
			

			playingTableClass.handleRoundLoser(table._id.toString(),players,table.bv,table.gt,table.fnsPlayer,direct,-1,0);


		});
	},
	declareDealWinner:function(tbId,direct){  //handles deal rummy final deal winner
		/* +-------------------------------------------------------------------+
            desc:function to declare deal rummy final winner
            i/p: tbId = table id, direct = true/false if true then direct winner declaration
        +-------------------------------------------------------------------+ */
		cdClass.GetTbInfo(tbId,{pi:1,pv:1},function(table){
			c('declareDealWinner------------->>>>table.pv:'+table.pv);
			var players = playClass.getPlayingUserInRound(table.pi);
			var winners = [];
			var total = players.length;
			var dpsArray = [];
			for(var i = 0;i < total;i++){  //prepare total points array
				if(players[i].play == 1){

					dpsArray.push(players[i].dps);
				}
			}
			c('declareDealWinner------------->>>>>>>dpsArray: ',dpsArray);
			var minDps = _.min(dpsArray); //counts the minimum total points
			// var countWinner = _.countBy(dpsArray)[minDps];  //counts the number of winners ,i.e count number of min total points
			c('declareDealWinner------------->>>>>>minDps: '+minDps);
			for(var j = 0;j < total;j++){
				if(players[j].dps == minDps && players[j].play == 1){ //means the winners
					c('declareDealWinner-------------if---------------->>>>>',players[j].uid);
					winners.push(players[j].si);
				}
				else{
					if(players[j].s == 'declare' || players[j].s == 'drop'){
						c('declareDealWinner-----------else--------------->>>>>>',players[j].uid);
						playingTableClass.handleDealLoser(table._id.toString(),players[j],table.bv,table.gt);
					}
				}
			}
			c('declareDealWinner---------------->>>>>>table.pv: '+table.pv+' type: '+typeof table.pv);
			setTimeout(function(){
				playingTableClass.handleDealWinner(table._id.toString(),winners,table.pv,direct);
			},1000);
		});
	},
	declareWinner :function(tbId){  //handle classic rummy round winner 
		/* +-------------------------------------------------------------------+
            desc:function to declare winner
            i/p: tbId = table id
        +-------------------------------------------------------------------+ */
		cdClass.GetTbInfo(tbId,{},function(table){
			var players = playClass.getPlayingUserInRound(table.pi);
			// c('declareWinner--------->>>>>>players: ',players);
			c('declareWinner--------------'+table._id+'-------------->>>>>'+table.fnsPlayer);
			
			
			playingTableClass.handleLoser(table._id.toString(),players,table.bv,table.gt,table.mode,table.fnsPlayer,-1,0);

		});
	},
	handleRoundLoser:function(tbId,players,bv,gt,fnsPlayer,direct,winner,iter){
		/* +-------------------------------------------------------------------+
            desc:function to handle round loser
            i/p: tbId = table id,players = players details,bv = boot value,gt = game type ,fnPlayer = finish player seat index,direct = true/false direct winner or not ,winner = winner player seat index,iter = iterator for recursion
        +-------------------------------------------------------------------+ */
		var total = players.length;

		if(iter < total){
			if(players[iter].si == fnsPlayer && players[iter].play == 1){ //means the winner
				c('handleRoundLoser----------if---if---------------->>>>>',players[iter].uid);
				winner = players[iter].si;
				playingTableClass.handleRoundLoser(tbId,players,bv,gt,fnsPlayer,direct,winner,iter+1);
			}
			else{
				if(players[iter].s == 'declare' || players[iter].s == 'drop'){
					c('handleRoundLoser-----if--else--if1--------------->>>>>>',players[iter].uid);
					cdClass.CountHands(players[iter].uid,'lost',gt,bv,false,function(thp,qstWin,spc){
						playClass.getUserScore(players[iter].uid,bv,gt,function(score){

							var upData = {$set:{la:new Date(),'pi.$.score':score,'pi.$.thp':thp/*,'pi.$.spc':spc*/},$addToSet:{hist:players[iter]}};

							/*if(players[iter].isSpc && spc >= config.FIRST_TIME_GAME_LIMIT){
								upData.$set['pi.$.isSpc'] = false;
								upData.$set.spcSi = -1;
								upData.$set.RobotCount = 0;
								upData.$set.HumanCount = 0;
								db.collection('game_users').updateOne({_id:MongoID(players[iter].uid)},{$set:{'flags._isSpc':0}},function(errr,res){
									if(errr){
										c('handleRoundLoser-------->>>>errr: ',errr);
									}
									c('handleRoundLoser----------->>>>>res: ',res);
								});
							}*/

							db.collection('playing_table').findAndModify({_id:MongoID(tbId),'pi.si':players[iter].si},{},upData,{new:true},function(){
								c('handleRoundLoser------if----else----if2-------->>>>>>');
								playingTableClass.handleRoundLoser(tbId,players,bv,gt,fnsPlayer,direct,winner,iter+1);
							});
						});
					});
				}
				else{
					c('handleRoundLoser------if----else-----else----->>>>>>');
					playingTableClass.handleRoundLoser(tbId,players,bv,gt,fnsPlayer,direct,winner,iter+1);
				}
			}
		}
		else{
			c('handleRoundLoser------else---------->>>>>>');
			if(gt == 'Deal'){

				playingTableClass.handleRoundWinner(tbId,winner,direct);
			}
			else if(gt == 'Pool'){

				playingTableClass.handlePoolWinner(tbId,winner,direct);
				
			}
		}
	},
	handleDealLoser:function(tbId,playerData,bv,gt){
		/* +-------------------------------------------------------------------+
            desc:function to handle deal loser
            i/p: tbId = table id,playerData = player details,bv = boot value,gt = game type 
        +-------------------------------------------------------------------+ */
		cdClass.CountHands(playerData.uid,'lost',gt,bv,false,function(thp,qstWin,spc){
			playClass.getUserScore(playerData.uid,bv,gt,function(score){

				var upData = {$set:{la:new Date(),'pi.$.score':score,'pi.$.thp':thp/*,'pi.$.spc':spc*/},$addToSet:{hist:playerData}};

				/*if(playerData.isSpc && spc >= config.FIRST_TIME_GAME_LIMIT){
					upData.$set['pi.$.isSpc'] = false;
					upData.$set.spcSi = -1;
					upData.$set.RobotCount = 0;
					upData.$set.HumanCount = 0;
					db.collection('game_users').updateOne({_id:MongoID(playerData.uid)},{$set:{'flags._isSpc':0}},function(errr,res){
						if(errr){
							c('handleDealLoser-------------->>>>>>errr: ',errr);
						}
						c('handleDealLoser---------------->>>>>res: ',res);
					});
				}*/

				db.collection('playing_table').update({_id:MongoID(tbId),'pi.si':playerData.si},upData,function(){});
			});
		});
	},
	handleLoser:function(tbId,players,bv,gt,mode,fnsPlayer,winner,iter){
		/* +-------------------------------------------------------------------+
            desc:function to handle game loser
            i/p: tbId = table id,players = players details,bv = boot value,gt = game type,fnsPlayer = finish player seat index,winner = winner player seat index,iter = iterator for recursion 
        +-------------------------------------------------------------------+ */
		c('handleLoser----------'+tbId+'--------->>>>>players: ',players,'--------------->>>>iter: '+iter);
		var total = players.length;


		if(iter < total){
			var penalty = 0;
			if(gt == 'Bet'){
				penalty = config.LATE_FINISH_PENALTY_POINTS*players[iter].bet;
			}
			else{

				penalty = config.LATE_FINISH_PENALTY_POINTS*bv;
			}
			
			if(players[iter].si == fnsPlayer){
				c('handleLoser----if----->>>>>>>iter: '+iter);
				winner = players[iter].si;
				playingTableClass.handleLoser(tbId,players,bv,gt,mode,fnsPlayer,winner,iter+1);
			}
			else{

				if(players[iter].s == 'declare'){
					c('handleLoser--------else---if------>>>>>>iter: '+iter);

					var chips = 0;
					if(gt == 'Bet'){
						chips = (players[iter].ps == 0) ? penalty : players[iter].ps*players[iter].bet; //if non winner user have 0 deadwood cards then add boot value
					}
					else{
						chips = (players[iter].ps == 0) ? penalty : players[iter].ps*bv; //if non winner user have 0 deadwood cards then add boot value
					}
					var pts = (players[iter].ps == 0) ? penalty : players[iter].ps;
					

					profileClass.ManageUserLevel('loss',players[iter].uid);
					if(mode == 'practice'){
						cdClass.UpdateUserChips(players[iter].uid,-chips,'Game Lost',function(uChips){

							cdClass.CountHands(players[iter].uid,'lost',gt,bv,false,function(thp,qstWin){

								var tempPlayerData = players[iter];
								tempPlayerData.wc = -chips;
								tempPlayerData.pts = pts;
								tempPlayerData.Chips = uChips;
								tempPlayerData.gedt = new Date();
								var upData = {$set:{la:new Date(),'pi.$.wc':-chips,'pi.$.Chips':uChips,'pi.$.pts': pts,'pi.$.thp':thp,/*'pi.$.spc':spc*/'pi.$.gedt':new Date()},$inc:{pv:chips}};
								upData['$addToSet'] = {hist:tempPlayerData};

								/*if(players[iter].isSpc && spc >= config.FIRST_TIME_GAME_LIMIT){
									// upData.$set['pi.$.isSpc'] = false;
									// upData.$set.spcSi = -1;
									upData.$set.RobotCount = 0;
									upData.$set.HumanCount = 0;
									db.collection('game_users').updateOne({_id:MongoID(players[iter].uid)},{$set:{'flags._isSpc':0}},function(errr,res){
										if(errr){
											c('handleLoser------------------>>>>>>errr: ',errr);
										}
										c('handleLoser------------->>>>>>res: ',res);
									});
								}*/

								

								playClass.getUserScore(players[iter].uid,bv,gt,function(score){
									upData['$set']['pi.$.score'] = score;
									db.collection('playing_table').findAndModify({_id:MongoID(tbId),'pi.si':players[iter].si},{},upData,{new:true},function(err,res){
										c('handleLoser------------>>>>res.value: ',res.value);
										playingTableClass.handleLoser(tbId,players,bv,gt,mode,fnsPlayer,winner,iter+1);
									});
								});
							});
						});
					}
					else if (mode == 'cash') {

						var bc = chips*config.CASH_BONUS/100;
						cdClass.UpdateUserCashforgame(players[iter].uid,-chips,bc,'Game Lost',function(uChips){

							cdClass.CountHands(players[iter].uid,'lost',gt,bv,false,function(thp,qstWin){

								var tempPlayerData = players[iter];
								tempPlayerData.wc = -chips;
								tempPlayerData.pts = pts;
								tempPlayerData.Chips = uChips;
								tempPlayerData.gedt = new Date();
								var upData = {$set:{la:new Date(),'pi.$.wc':-chips,'pi.$.Chips':uChips,'pi.$.pts': pts,'pi.$.thp':thp,/*'pi.$.spc':spc*/'pi.$.gedt':new Date()},$inc:{pv:chips}};
								upData['$addToSet'] = {hist:tempPlayerData};

								/*if(players[iter].isSpc && spc >= config.FIRST_TIME_GAME_LIMIT){
									// upData.$set['pi.$.isSpc'] = false;
									// upData.$set.spcSi = -1;
									upData.$set.RobotCount = 0;
									upData.$set.HumanCount = 0;
									db.collection('game_users').updateOne({_id:MongoID(players[iter].uid)},{$set:{'flags._isSpc':0}},function(errr,res){
										if(errr){
											c('handleLoser------------------>>>>>>errr: ',errr);
										}
										c('handleLoser------------->>>>>>res: ',res);
									});
								}*/

								

								playClass.getUserScore(players[iter].uid,bv,gt,function(score){
									upData['$set']['pi.$.score'] = score;
									db.collection('playing_table').findAndModify({_id:MongoID(tbId),'pi.si':players[iter].si},{},upData,{new:true},function(err,res){
										c('handleLoser------------>>>>res.value: ',res.value);
										playingTableClass.handleLoser(tbId,players,bv,gt,mode,fnsPlayer,winner,iter+1);
									});
								});
							});
						});
					}
				}
				else{
					c('handleLoser------------else----else------------->>>>>iter: '+iter);
					playingTableClass.handleLoser(tbId,players,bv,gt,mode,fnsPlayer,winner,iter+1);
				}
			}
		}
		else{
			// setTimeout(function(){
				c('handleLoser------else------>>>>>iter: '+iter);
				if(mode == 'practice'){

					playingTableClass.handleWinner(tbId,winner);
				}
				else if(mode == 'cash'){
					playingTableClass.handleWinnerCash(tbId,winner);
				}
			// },1000);
		}
	},
	handleRoundWinner:function(tbId,winner,direct){
		/* +-------------------------------------------------------------------+
            desc:function to handle round winner
            i/p: tbId = table id,winner = winner player index,direct = true/false direct winner
        +-------------------------------------------------------------------+ */
		cdClass.GetTbInfo(tbId,{},function(table){
			if(!table){
				c('handleRoundWinner----------->>>>>>Error:"table not found"');
				return false;
			}
			c('handleWinner-----------'+table._id+'----------->>>>>>>');
			jtClass.cancelJobOnServers(tbId,table.jid);
			// notiClass.winNoti(table.pi[winner],'FRIEND_WON',table.pv); //send notification to winner's friends
			var tempPlayerData = table.pi[winner];
			var ctth = '';
			if(direct){
				if(table.pi[winner].cards.length > 13){
					ctth = table.pi[winner].cards.pop();
					tempPlayerData.cards = table.pi[winner].cards;
				}
				tempPlayerData.dCards = {pure:[],seq:[],set:[],dwd:table.pi[winner].cards};
			}

			tempPlayerData._iw = 1;
			tempPlayerData.gedt = new Date();
			var upData = {$set:{la:new Date(),ctrlServer:SERVER_ID,'pi.$._iw':1,tst:'roundWinnerDeclared',ctt:new Date(),'pi.$.gedt':new Date()}};
			if(ctth != ''){


				if(table.pi[winner].gCards.length > 0){

					var gCards = table.pi[winner].gCards;
					c('handleRoundWinner---------->>>>>>gCards: ',gCards);
					for(var x in gCards){
						if(_.contains(gCards[x],ctth)){
							gCards[x] = _.without(gCards[x],ctth);
							break;
						}
					}
					c('handleRoundWinner------------->>>>>gCards: ',gCards);
				}
				else{
					var gCards = table.pi[winner].cards;
				}
				upData['$set']['pi.$.cards'] = table.pi[winner].cards;
				upData['$set']['pi.$.gCards'] = gCards;

				upData['$push'] = {oDeck:ctth};
			}
			upData['$addToSet'] = {hist:tempPlayerData};

			cdClass.CountHands(table.pi[winner].uid,'win',table.gt,table.bv,false,function(thp,qstWin){
				playClass.getUserScore(table.pi[winner].uid,table.bv,table.gt,function(score){
					upData['$set']['pi.$.score'] = score;
					upData['$set']['pi.$.thp'] = thp;
					// upData['$set']['pi.$.spc'] = spc;

					/*if(table.spcSi == winner && spc >= config.FIRST_TIME_GAME_LIMIT){
						upData.$set['pi.$.isSpc'] = false;
						upData.$set.spcSi = -1;
						upData.$set.RobotCount = 0;
						upData.$set.HumanCount = 0;
						db.collection('game_users').updateOne({_id:MongoID(table.pi[winner].uid)},{$set:{'flags._isSpc':0}},function(errr,res){
							if(errr){
								c('handleRoundWinner-------------->>>>errr: ',errr);
							}
							c('handleRoundWinner--------------->>>>>res: ',res);
						});
					}*/

					db.collection('playing_table').findAndModify({_id:MongoID(tbId),'pi.si':winner},{},upData,{new:true},function(err,table1){
						if(table1.value != null){

							var hist = _.clone(table1.value.hist);
							for(i = 0;i < hist.length;i++){   //sort(bubble sort) the player according to the dps  
								for(j = 0;j < hist.length-i-1;j++){
									if(hist[j].dps > hist[j+1].dps || hist[j].dps == hist[j+1].dps && hist[j]._iw < hist[j+1]._iw){
										temp = _.clone(hist[j]);
										hist[j] = _.clone(hist[j+1]);
										hist[j+1] = _.clone(temp);
									}
								}
							}


							var game_id = table1.value.game_id;
							if(table1.value.gt == 'Deal' || table1.value.gt == 'Pool'){
								game_id = game_id+'.'+table1.value.sub_id;
							}

							var rCount = 0;
							var uCount = 0;
							var rSts = 'loss';
							var uSts = 'loss';
							for(var k in hist){

								// if(hist[k]._ir == 0){
									
									// var sts = 'loss';
									if(hist[k]._iw == 1){
										// sts = 'win';

										if(hist[k]._ir == 1){
											rSts = 'win';
										}
										else{
											uSts = 'win';
										}

									}
									/*else{
										sts = 'loss';
									}*/
									if(hist[k]._ir == 1){
										rCount++;
									}
									else{
										uCount++;
									}

									/*if(hist[k].s != 'left' && hist[k].s != 'drop' && hist[k].s != 'standup'){

										//trackClass.TEA({table:'track_primary_data',category:'economy',label:table1.value.gt,option:'game_end',action:game_id,name:table1.value.rSeq,value:hist[k].wc,detail1:table1.value.ap,detail2:parseInt(k)+1,detail3:hist[k].ps,detail4:'chips',description:sts},{uid:hist[k].uid});

										if(hist[k].gst && typeof hist[k].rndCount != 'undefined' && hist[k].rndCount != null){

											var gameDuration = 0;
											var tableDuration = 0;
											gameDuration = commonClass.GetTimeDifference(hist[k].gst,new Date());
											tableDuration = commonClass.GetTimeDifference(hist[k].jt,new Date());
											trackClass.TEA({table:'track_primary_data',category:'screen',label:table1.value.gt,option:'game_end_summary',action:table1.value.ap,name:(table1.value.ap-table1.value.uCount),detail1:game_id,detail3:hist[k].rndCount,description:gameDuration,value:tableDuration},{uid:hist[k].uid});
										}

										trackClass.TEA({table:'track_primary_data',category:'economy',label:table1.value.gt,option:'game_end',action:table1.value.ap,name:parseInt(k)+1,value:hist[k].wc,detail1:game_id,detail3:hist[k].ps,detail4:'chips',description:sts},{uid:hist[k].uid});
										
									}*/
								// }
							}

							if(rCount > 0 || uCount > 0){

								db.collection('win_sts').insertOne({date:new Date(),table_id:table1.value._id.toString(),game_type:table1.value.gt,game_id:game_id,rCount:rCount,uCount:uCount,rSts:rSts,uSts:uSts});
							}

							var ldData = {$set:{
								round:table1.value.round,
								game_id:table1.value.game_id,
								sub_id:table1.value.sub_id,
								gt:table1.value.gt,
								st:table1.value.tst,
								pi:hist,
								wildCard:table1.value.wildCard,
								win:winner
							}};

							db.collection('last_deal').findAndModify({'tbid':MongoID(table1.value._id.toString())},{},ldData,{upsert:true,new:true},function(err,table1){});

							commonClass.FireEventToTable(table1.value._id.toString(),{en:'WD',data:{round:table1.value.round,game_id:table1.value.game_id,sub_id:table1.value.sub_id,gt:table1.value.gt,tst:table1.value.tst,pi:hist,win:[winner],wildCard:table1.value.wildCard}});
							


							var jobId = commonClass.GetRandomString(10);


							var uScores = [];
							for(var j in table1.pi){ 
								if(!_.isEmpty(table1.pi[j]) && table1.pi[j]._ir == 0){

					                uScores.push(table1.pi[j].score);    
					            }
					        }

					        var tScore = 0;
					        if(uScores.length  > 1){
					            tScore = commonClass.getMedian(uScores);
					        }
					        else{
					            tScore = (uScores.length == 1) ? uScores[0] : 0;
					        }

					        /*for(var k in table1.pi){
					        	if(!_.isEmpty(table1.pi[k]) && table1.pi[k]._ir == 1){
					        		trackClass.TEA({table:'track_primary_data',category:'screen',label:table1.gt,option:'game_end',action:game_id,name:'game_end',detail1:table1.pi[k].uid,detail2:table1.pi[k].un,detail3:table1.pi[k].Chips,detail4:'chips',description:table1.pi[k].rType,value:tScore},{uid:table1.pi[k].uid});
					        	}
					        }*/


							cdClass.UpdateTableData(table1.value._id.toString(),{$set:{jid:jobId}},function(table2){
								if(table2){

									var nxt = commonClass.AddTime(config.NXT);
									schedule.scheduleJob(table2.jid,new Date(nxt),function(){  
										schedule.cancelJob(table2.jid);
										playingTableClass.afterRoundFinish(table2._id.toString());
									});
								}
								else{
									c('handleRoundWinner------------>>>>>Error:"table not found"');
								}
							});
						}
						else{
							c('handleRoundWinner-------------->>>>Error:"table not found"');
						}
					});
				});
			});

		});
	},
	handleDealWinner:function(tbId,winners,pv,direct){
		/* +-------------------------------------------------------------------+
            desc:function to handle deal winner
            i/p: tbId = table id,winners = array of winner players seat index,pv = pot value,direct = true/false direct winner or nots
        +-------------------------------------------------------------------+ */
		c('handleDealWinner---------->>>>>>tbId: '+tbId+' winners'+' pv: '+pv);
		cdClass.GetTbInfo(tbId,{},function(table){
			if(!table){
				c('handleDealWinner---------->>>>>>Error:"table not found!!!"');
				return false;
			}
			jtClass.cancelJobOnServers(tbId,table.jid);
			// notiClass.winNotiDeal(winners,tbId); //send notification to winner's friends
			var msg = '';
			var prize = pv;
			if(winners.length == 1){ //means there is only one winner 
				msg = 'Game Win';
			}
			else if(winners.length > 1){  //means the game is draw
				msg = 'Game Draw';
				prize = Math.round(prize/winners.length);

			}

			var players = playClass.getPlayingUserInRound(table.pi);

			// for(var i = 0; i < players.length ;i++){

			// 	if(_.contains(winners,players[i].si)){  //means the winner

			// 		playingTableClass.giveWinChips(table._id.toString(),players[i],prize,msg,direct);
	
			// 	}
			// }

			if (table.mode == 'practice') {

				playingTableClass.giveWinChips(table._id.toString(),winners,players,0,prize,msg,table.bv,table.gt,direct);
			}
			else if (table.mode == 'cash') {
				
				playingTableClass.giveWinCash(table._id.toString(),winners,players,0,prize,msg,table.bv,table.gt,direct);
			}


			// setTimeout(function(){
			// 	cdClass.GetTbInfo(table._id.toString(),{},function(table1){
			// 		if(table1){

			// 			var hist = _.clone(table1.hist);
						
			// 			c('handleDealWinner----------->>>>>>hist: ',hist);
			// 			for(i = 0;i < hist.length;i++){   //sort(bubble sort) the player according to the dps  
			// 				for(j = 0;j < hist.length-i-1;j++){
			// 					if(hist[j].dps > hist[j+1].dps){
			// 						temp = _.clone(hist[j]);
			// 						hist[j] = _.clone(hist[j+1]);
			// 						hist[j+1] = _.clone(temp);
			// 					}
			// 				}
			// 			}
			// 			commonClass.FireEventToTable(table1._id.toString(),{en:'WD',data:{round:table1.round,gt:table1.gt,tst:table1.tst,pi:hist,win:winners,wildCard:table1.wildCard}});
			// 			playingTableClass.afterRoundFinish(table1._id.toString());
			// 		}
			// 		else{
			// 			c('handleDealWinner::::::::::::::>>>>>Error: "table not found"');
			// 		}
			// 	});
			// },2000);
		});
	},
	handlePoolWinner:function(tbId,winner,direct){
		/* +-------------------------------------------------------------------+
            desc:function to handle pool winner
            i/p: tbId = table id,winner = winner player seat index,direct = true/false direct winner or nots
        +-------------------------------------------------------------------+ */
		cdClass.GetTbInfo(tbId,{},function(table){
			if(!table){
				c('handlePoolWinner----------->>>>>>Error:"table not found"');
				return false;
			}
			c('handlePoolWinner-----------'+table._id+'----------->>>>>>>');
			jtClass.cancelJobOnServers(tbId,table.jid);

			//update table status here check if the winner is roundWinner or final Pool winner
			var players = playClass.getPlayingUserInGame(table.pi,true);
			c('handlePoolWinner-----------'+table._id+'-------------->>>>>>players: ',players);
			var remainingLoser = 0;
			for(var k in players){
				if((players[k].s == 'declare' || players[k].s == 'drop') && players[k].si != winner && players[k].dps < table.pt/*101*/){  //means all the loser having less than 101 score
					remainingLoser++;
				}
			}

			var tst = 'roundWinnerDeclared';
			if(remainingLoser == 0){
				tst = 'winnerDeclared';
			}



			// notiClass.winNoti(table.pi[winner],'FRIEND_WON',table.pv); //send notification to winner's friends
			c('handlePoolWinner---------'+table._id+'---------->>>>>tst:',tst);
			if(tst == 'winnerDeclared'){ //means give chips
				c('handlePoolWinner-----if-------->>>>>>>');
				if (table.mode == 'practice') {
					cdClass.UpdateUserChips(table.pi[winner].uid,table.pv,'Game Win',function(uChips){
						
						var tempPlayerData = table.pi[winner];
						var ctth = '';
						if(direct){
							if(table.pi[winner].cards.length > 13){
								ctth = table.pi[winner].cards.pop();
								tempPlayerData.cards = table.pi[winner].cards;
							}
							tempPlayerData.dCards = {pure:[],seq:[],set:[],dwd:table.pi[winner].cards};
						}

						tempPlayerData.wc = table.pv;
						tempPlayerData.Chips = uChips;
						tempPlayerData._iw = 1;
						tempPlayerData.gedt = new Date();
						var upData = {$set:{la:new Date(),ctrlServer:SERVER_ID,'pi.$.wc':table.pv,'pi.$.Chips':uChips,'pi.$._iw':1,tst:tst,ctt:new Date(),'pi.$.gedt':new Date()}};
						if(ctth != ''){


							if(table.pi[winner].gCards.length > 0){

								var gCards = table.pi[winner].gCards;
								// c('handlePoolWinner---------->>>>>>gCards: ',gCards);
								// for(var x in gCards){
								// 	if(_.contains(gCards[x],ctth)){
								// 		gCards[x] = _.without(gCards[x],ctth);
								// 		break;
								// 	}
								// }
								// c('handlePoolWinner------------->>>>>gCards: ',gCards);
								if(gCards.pure.length > 0){

									var pureCards = gCards.pure;
									c('handlePoolWinner---------->>>>>>gCards: ',pureCards);
									for(var x in pureCards){
										if(_.contains(pureCards[x],ctth)){
											pureCards[x] = _.without(pureCards[x],ctth);
											break;
										}
									}
									c('handlePoolWinner------------->>>>>gCards: ',gCards);
									gCards.pure = pureCards;
								}
								else if (gCards.seq.length > 0) {
									var seqCards = gCards.seq;
									c('handlePoolWinner---------->>>>>>gCards: ',seqCards);
									for(var x in seqCards){
										if(_.contains(seqCards[x],ctth)){
											seqCards[x] = _.without(seqCards[x],ctth);
											break;
										}
									}
									c('handlePoolWinner------------->>>>>gCards: ',seqCards);
									gCards.seq = seqCards;
								}
								else if (gCards.set.length > 0){
									var setCards = gCards.set;
									c('handlePoolWinner---------->>>>>>gCards: ',setCards);
									for(var x in setCards){
										if(_.contains(setCards[x],ctth)){
											setCards[x] = _.without(setCards[x],ctth);
											break;
										}
									}
									c('handlePoolWinner------------->>>>>gCards: ',setCards);
									gCards.set = setCards;
								}
								else if (gCards.dwd.length > 0){
									var dwdCards = gCards.dwd;
									c('handlePoolWinner---------->>>>>>gCards: ',dwdCards);
									for(var x in dwdCards){
										if(_.contains(dwdCards[x],ctth)){
											dwdCards[x] = _.without(dwdCards[x],ctth);
											break;
										}
									}
									c('handlePoolWinner------------->>>>>gCards: ',dwdCards);
									gCards.dwd = dwdCards;
								}
								else{
							
								}


							}
							else{
								var gCards = table.pi[winner].gCards;
								var dwdCards = table.pi[winner].cards;
								gCards.dwd = dwdCards;
							}
							upData['$set']['pi.$.cards'] = table.pi[winner].cards;
							upData['$set']['pi.$.gCards'] = gCards;
							upData['$push'] = {oDeck:ctth};
						}
						upData['$addToSet'] = {hist:tempPlayerData};

						cdClass.CountHands(table.pi[winner].uid,'win',table.gt,table.bv,true,function(thp,qstWin){
							playClass.getUserScore(table.pi[winner].uid,table.bv,table.gt,function(score){
								upData['$set']['pi.$.score'] = score;
								upData['$set']['pi.$.thp'] = thp;
								// upData['$set']['pi.$.spc'] = spc;

								/*if(table.spcSi == winner && (spc >= config.FIRST_TIME_GAME_LIMIT || uChips > config.FIRST_TIME_CHIPS_LIMIT)){
									upData.$set['pi.$.isSpc'] = false;
									upData.$set.spcSi = -1;
									upData.$set.RobotCount = 0;
									upData.$set.HumanCount = 0;
									db.collection('game_users').updateOne({_id:MongoID(table.pi[winner].uid)},{$set:{'flags._isSpc':0}},function(errr,res){
										if(errr){
											c('handlePoolWinner------------------->>>>errr: ',errr);
										}
										c('handlePoolWinner-------------------->>>>res: ',res);
									});
								}*/
								upData.$set._qstWin = qstWin;
								db.collection('playing_table').findAndModify({_id:MongoID(tbId),'pi.si':winner},{},upData,{new:true},function(err,table1){
									if(table1.value != null){

										var hist = _.clone(table1.value.hist);
										for(i = 0;i < hist.length;i++){   //sort(bubble sort) the player according to the dps  
											for(j = 0;j < hist.length-i-1;j++){
												if(hist[j].dps > hist[j+1].dps || hist[j].dps == hist[j+1].dps && hist[j]._iw < hist[j+1]._iw){
													temp = _.clone(hist[j]);
													hist[j] = _.clone(hist[j+1]);
													hist[j+1] = _.clone(temp);
												}
											}
										}

										var game_id = table1.value.game_id;
										// var deal_id = table1.value.game_id;
										if(table1.value.gt == 'Deal' || table1.value.gt == 'Pool'){
											game_id = game_id+'.'+table1.value.sub_id;
										}
										var rCount = 0;
										var uCount = 0;
										var rSts = 'loss';
										var uSts = 'loss';
										for(var k in hist){

											// if(hist[k]._ir == 0){
												
												// var sts = 'loss';
												if(hist[k]._iw == 1){
													// sts = 'win';

													if(hist[k]._ir == 1){
														rSts = 'win';
													}
													else{
														uSts = 'win';
													}

												}
												// else{
												// 	sts = 'loss';
												// }

												/*if(hist[k].s != 'left' && hist[k].s != 'drop' && hist[k].s != 'standup'){

													if(hist[k].gst && hist[k].gedt && typeof hist[k].rndCount != 'undefined' && hist[k].rndCount != null){

														var gameDuration = 0;
														var tableDuration = 0;
														gameDuration = commonClass.GetTimeDifference(hist[k].gst,hist[k].gedt);
														tableDuration = commonClass.GetTimeDifference(hist[k].jt,hist[k].gedt);
														trackClass.TEA({table:'track_primary_data',category:'screen',label:table1.value.gt,option:'game_end_summary',action:table1.value.ap,name:(table1.value.ap-table1.value.uCount),detail1:game_id,detail3:hist[k].rndCount,description:gameDuration,value:tableDuration},{uid:hist[k].uid});
													}

													if(remainingLoser == 0){

														// trackClass.TEA({table:'track_primary_data',category:'game',label:table1.value.gt,option:'deal_end',action:deal_id,name:table1.value.rSeq,value:hist[k].wc,detail1:table1.value.ap,detail2:parseInt(k)+1,detail3:hist[k].ps,detail4:'chips',description:sts},{uid:hist[k].uid});
														trackClass.TEA({table:'track_primary_data',category:'game',label:table1.value.gt,option:'deal_end',action:deal_id,name:table1.value.ap,value:hist[k].wc,detail1:parseInt(k)+1,detail3:hist[k].ps,detail4:'chips',description:sts},{uid:hist[k].uid});
														
													}
													else{
														// trackClass.TEA({table:'track_primary_data',category:'economy',label:table1.value.gt,option:'game_end',action:game_id,name:table1.value.rSeq,value:hist[k].wc,detail1:table1.value.ap,detail2:parseInt(k)+1,detail3:hist[k].ps,detail4:'chips',description:sts},{uid:hist[k].uid});
														trackClass.TEA({table:'track_primary_data',category:'economy',label:table1.value.gt,option:'game_end',action:table1.value.ap,name:parseInt(k)+1,value:hist[k].wc,detail1:game_id,detail3:hist[k].ps,detail4:'chips',description:sts},{uid:hist[k].uid});
													}
												}*/

											// }
										}
										/*if(remainingLoser == 0){
											trackClass.TEA({table:'track_primary_data',category:'economy',label:'pool_rummy',option:'winner_declaration',action:table1.value.pi[winner].uid,name:table1.value.pi[winner].un,value:table1.value.pv,detail3:'chips'},{uid:table1.value.pi[winner].uid});
										}*/


										if(rCount > 0 || uCount > 0 ){

											db.collection('win_sts').insertOne({date:new Date(),table_id:table1.value._id.toString(),game_type:table1.value.gt,game_id:game_id,rCount:rCount,uCount:uCount,rSts:rSts,uSts:uSts});
										}
										
										var ldData = {$set:{
											round:table1.value.round,
											game_id:table1.value.game_id,
											sub_id:table1.value.sub_id,
											gt:table1.value.gt,
											tst:table1.value.tst,
											pi:hist,
											wildCard:table1.value.wildCard,
											win:[winner]
										}};
										
										db.collection('last_deal').findAndModify({'tbid':table1.value._id.toString()},{},ldData,{upsert:true,new:true},function(err,table1){});

										commonClass.FireEventToTable(table1.value._id.toString(),{en:'WD',data:{
											tbid:table1.value._id.toString(),
											round:table1.value.round,
											game_id:table1.value.game_id,
											sub_id:table1.value.sub_id,
											gt:table1.value.gt,
											tst:table1.value.tst,
											pi:hist,
											win:[winner],
											wildCard:table1.value.wildCard
										}});
										


										var jobId = commonClass.GetRandomString(10);

										cdClass.UpdateTableData(table1.value._id.toString(),{$set:{jid:jobId}},function(table2){
											if(table2){
												c('handlePoolWinner------------>>>>>>>');

												/*var uScores = [];
												for(var i in table2.pi){ 
													if(!_.isEmpty(table2.pi[i]) && table2.pi[i]._ir == 0){

										                uScores.push(table2.pi[i].score);    
										            }
										        }

										        var tScore = 0;
										        if(uScores.length  > 1){
										            tScore = commonClass.getMedian(uScores);
										        }
										        else{
										            tScore = (uScores.length == 1) ? uScores[0] : 0;
										        }

										        for(var k in table2.pi){
										        	if(!_.isEmpty(table2.pi[k]) && table2.pi[k]._ir == 1){
										        		trackClass.TEA({table:'track_primary_data',category:'screen',label:table2.gt,option:'game_end',action:game_id,name:'game_end',detail1:table2.pi[k].uid,detail2:table2.pi[k].un,detail3:table2.pi[k].Chips,detail4:'chips',description:table2.pi[k].rType,value:tScore},{uid:table2.pi[k].uid});
										        	}
										        }*/


												var nxt = commonClass.AddTime(config.NXT);
												schedule.scheduleJob(table2.jid,new Date(nxt),function(){  
													schedule.cancelJob(table2.jid);
													playingTableClass.afterRoundFinish(table2._id.toString());
												});
											}
											else{
												c('handlePoolWinner------------>>>>>Error:"table not found"');
											}
										});
									}
									else{
										c('handlePoolWinner-------------->>>>Error:"table not found"');
									}
								});
							});
						});
					});
				}
				else if(table.mode == 'cash'){
					cdClass.UpdateUserCash(table.pi[winner].uid,table.pv,'Game Win',function(uChips){
						
						var tempPlayerData = table.pi[winner];
						var ctth = '';
						if(direct){
							if(table.pi[winner].cards.length > 13){
								ctth = table.pi[winner].cards.pop();
								tempPlayerData.cards = table.pi[winner].cards;
							}
							tempPlayerData.dCards = {pure:[],seq:[],set:[],dwd:table.pi[winner].cards};
						}

						tempPlayerData.wc = table.pv;
						tempPlayerData.cash = uChips;
						tempPlayerData._iw = 1;
						tempPlayerData.gedt = new Date();
						var upData = {$set:{la:new Date(),ctrlServer:SERVER_ID,'pi.$.wc':table.pv,'pi.$.cash':uChips,'pi.$._iw':1,tst:tst,ctt:new Date(),'pi.$.gedt':new Date()}};
						if(ctth != ''){


							if(table.pi[winner].gCards.length > 0){

								var gCards = table.pi[winner].gCards;
								// c('handlePoolWinner---------->>>>>>gCards: ',gCards);
								// for(var x in gCards){
								// 	if(_.contains(gCards[x],ctth)){
								// 		gCards[x] = _.without(gCards[x],ctth);
								// 		break;
								// 	}
								// }
								// c('handlePoolWinner------------->>>>>gCards: ',gCards);

								if(gCards.pure.length > 0){

									var pureCards = gCards.pure;
									c('handlePoolWinner---------->>>>>>gCards: ',pureCards);
									for(var x in pureCards){
										if(_.contains(pureCards[x],ctth)){
											pureCards[x] = _.without(pureCards[x],ctth);
											break;
										}
									}
									c('handlePoolWinner------------->>>>>gCards: ',gCards);
									gCards.pure = pureCards;
								}
								else if (gCards.seq.length > 0) {
									var seqCards = gCards.seq;
									c('handlePoolWinner---------->>>>>>gCards: ',seqCards);
									for(var x in seqCards){
										if(_.contains(seqCards[x],ctth)){
											seqCards[x] = _.without(seqCards[x],ctth);
											break;
										}
									}
									c('handlePoolWinner------------->>>>>gCards: ',seqCards);
									gCards.seq = seqCards;
								}
								else if (gCards.set.length > 0){
									var setCards = gCards.set;
									c('handlePoolWinner---------->>>>>>gCards: ',setCards);
									for(var x in setCards){
										if(_.contains(setCards[x],ctth)){
											setCards[x] = _.without(setCards[x],ctth);
											break;
										}
									}
									c('handlePoolWinner------------->>>>>gCards: ',setCards);
									gCards.set = setCards;
								}
								else if (gCards.dwd.length > 0){
									var dwdCards = gCards.dwd;
									c('handlePoolWinner---------->>>>>>gCards: ',dwdCards);
									for(var x in dwdCards){
										if(_.contains(dwdCards[x],ctth)){
											dwdCards[x] = _.without(dwdCards[x],ctth);
											break;
										}
									}
									c('handlePoolWinner------------->>>>>gCards: ',dwdCards);
									gCards.dwd = dwdCards;
								}
								else{
							
								}

							}
							else{
								var gCards = table.pi[winner].gCards;
								var dwdCards = table.pi[winner].cards;
								gCards.dwd = dwdCards;
							}
							upData['$set']['pi.$.cards'] = table.pi[winner].cards;
							upData['$set']['pi.$.gCards'] = gCards;
							upData['$push'] = {oDeck:ctth};
						}
						upData['$addToSet'] = {hist:tempPlayerData};

						cdClass.CountHands(table.pi[winner].uid,'win',table.gt,table.bv,true,function(thp,qstWin){
							playClass.getUserScore(table.pi[winner].uid,table.bv,table.gt,function(score){
								upData['$set']['pi.$.score'] = score;
								upData['$set']['pi.$.thp'] = thp;
								
								upData.$set._qstWin = qstWin;
								db.collection('playing_table').findAndModify({_id:MongoID(tbId),'pi.si':winner},{},upData,{new:true},function(err,table1){
									if(table1.value != null){

										var hist = _.clone(table1.value.hist);
										for(i = 0;i < hist.length;i++){   //sort(bubble sort) the player according to the dps  
											for(j = 0;j < hist.length-i-1;j++){
												if(hist[j].dps > hist[j+1].dps || hist[j].dps == hist[j+1].dps && hist[j]._iw < hist[j+1]._iw){
													temp = _.clone(hist[j]);
													hist[j] = _.clone(hist[j+1]);
													hist[j+1] = _.clone(temp);
												}
											}
										}

										var game_id = table1.value.game_id;
										var deal_id = table1.value.game_id;
										if(table1.value.gt == 'Deal' || table1.value.gt == 'Pool'){
											game_id = game_id+'.'+table1.value.sub_id;
										}
										var rCount = 0;
										var uCount = 0;
										var rSts = 'loss';
										var uSts = 'loss';
										for(var k in hist){

											if(hist[k]._iw == 1){

												if(hist[k]._ir == 1){
													rSts = 'win';
												}
												else{
													uSts = 'win';
												}
											}
										}

										if(rCount > 0 || uCount > 0 ){

											db.collection('win_sts').insertOne({date:new Date(),table_id:table1.value._id.toString(),game_type:table1.value.gt,game_id:game_id,rCount:rCount,uCount:uCount,rSts:rSts,uSts:uSts});
										}
										
										var ldData = {$set:{
											round:table1.value.round,
											game_id:table1.value.game_id,
											sub_id:table1.value.sub_id,
											gt:table1.value.gt,
											tst:table1.value.tst,
											pi:hist,
											wildCard:table1.value.wildCard,
											win:[winner]
										}};
										
										db.collection('last_deal').findAndModify({'tbid':table1.value._id.toString()},{},ldData,{upsert:true,new:true},function(err,table1){});

										commonClass.FireEventToTable(table1.value._id.toString(),{en:'WD',data:{
											tbid:table1.value._id.toString(),
											round:table1.value.round,
											game_id:table1.value.game_id,
											sub_id:table1.value.sub_id,
											gt:table1.value.gt,
											tst:table1.value.tst,
											pi:hist,win:[winner],
											wildCard:table1.value.wildCard
										}});
										

										var jobId = commonClass.GetRandomString(10);

										cdClass.UpdateTableData(table1.value._id.toString(),{$set:{jid:jobId}},function(table2){
											if(table2){
												c('handlePoolWinner------------>>>>>>>');

												var nxt = commonClass.AddTime(config.NXT);
												schedule.scheduleJob(table2.jid,new Date(nxt),function(){  
													schedule.cancelJob(table2.jid);
													playingTableClass.afterRoundFinish(table2._id.toString());
												});
											}
											else{
												c('handlePoolWinner------------>>>>>Error:"table not found"');
											}
										});
									}
									else{
										c('handlePoolWinner-------------->>>>Error:"table not found"');
									}
								});
							});
						});
					});
				}
			}
			else{
				c('handlePoolWinner-------else------->>>>');
				var tempPlayerData = table.pi[winner];
				var ctth = '';
				if(direct){
					if(table.pi[winner].cards.length > 13){
						ctth = table.pi[winner].cards.pop();
						tempPlayerData.cards = table.pi[winner].cards;
					}
					tempPlayerData.dCards = {pure:[],seq:[],set:[],dwd:table.pi[winner].cards};
				}

				tempPlayerData._iw = 1;
				tempPlayerData.gedt = new Date();
				var upData = {$set:{la:new Date(),ctrlServer:SERVER_ID,'pi.$._iw':1,tst:tst,ctt:new Date(),'pi.$.gedt':new Date()}};
				if(ctth != ''){


					if(table.pi[winner].gCards.length > 0){

						var gCards = table.pi[winner].gCards;
						// c('handlePoolWinner---------->>>>>>gCards: ',gCards);
						// for(var x in gCards){
						// 	if(_.contains(gCards[x],ctth)){
						// 		gCards[x] = _.without(gCards[x],ctth);
						// 		break;
						// 	}
						// }
						// c('handlePoolWinner------------->>>>>gCards: ',gCards);
						if(gCards.pure.length > 0){

							var pureCards = gCards.pure;
							c('handlePoolWinner---------->>>>>>gCards: ',pureCards);
							for(var x in pureCards){
								if(_.contains(pureCards[x],ctth)){
									pureCards[x] = _.without(pureCards[x],ctth);
									break;
								}
							}
							c('handlePoolWinner------------->>>>>gCards: ',gCards);
							gCards.pure = pureCards;
						}
						else if (gCards.seq.length > 0) {
							var seqCards = gCards.seq;
							c('handlePoolWinner---------->>>>>>gCards: ',seqCards);
							for(var x in seqCards){
								if(_.contains(seqCards[x],ctth)){
									seqCards[x] = _.without(seqCards[x],ctth);
									break;
								}
							}
							c('handlePoolWinner------------->>>>>gCards: ',seqCards);
							gCards.seq = seqCards;
						}
						else if (gCards.set.length > 0){
							var setCards = gCards.set;
							c('handlePoolWinner---------->>>>>>gCards: ',setCards);
							for(var x in setCards){
								if(_.contains(setCards[x],ctth)){
									setCards[x] = _.without(setCards[x],ctth);
									break;
								}
							}
							c('handlePoolWinner------------->>>>>gCards: ',setCards);
							gCards.seq = setCards;
						}
						else if (gCards.dwd.length > 0){
							var dwdCards = gCards.dwd;
							c('handlePoolWinner---------->>>>>>gCards: ',dwdCards);
							for(var x in dwdCards){
								if(_.contains(dwdCards[x],ctth)){
									dwdCards[x] = _.without(dwdCards[x],ctth);
									break;
								}
							}
							c('handlePoolWinner------------->>>>>gCards: ',dwdCards);
							gCards.seq = dwdCards;
						}
						else{
					
						}

					}
					else{
						var gCards = table.pi[winner].gCards;
						var dwdCards = table.pi[winner].cards;
						gCards.dwd = dwdCards;
					}
					upData['$set']['pi.$.cards'] = table.pi[winner].cards;
					upData['$set']['pi.$.gCards'] = gCards;
					upData['$push'] = {oDeck:ctth};
				}
				upData['$addToSet'] = {hist:tempPlayerData};

				cdClass.CountHands(table.pi[winner].uid,'win',table.gt,table.bv,false,function(thp,qstWin){
					playClass.getUserScore(table.pi[winner].uid,table.bv,table.gt,function(score){
						upData['$set']['pi.$.score'] = score;
						upData['$set']['pi.$.thp'] = thp;
						// upData['$set']['pi.$.spc'] = spc;

						/*if(table.spcSi == winner && spc >= config.FIRST_TIME_GAME_LIMIT){
							upData.$set['pi.$.isSpc'] = false;
							upData.$set.spcSi = -1;
							upData.$set.RobotCount = 0;
							upData.$set.HumanCount = 0;
							db.collection('game_users').updateOne({_id:MongoID(table.pi[winner].uid)},{$set:{'flags._isSpc':0}},function(errr,res){
								if(errr){
									c('handlePoolWinner------------->>>>errr: ',errr);
								}
								c('handlePoolWinner------------->>>>res: ',res);
							});
						}*/

						db.collection('playing_table').findAndModify({_id:MongoID(tbId),'pi.si':winner},{},upData,{new:true},function(err,table1){
							if(table1.value != null){

								var hist = _.clone(table1.value.hist);
								for(i = 0;i < hist.length;i++){   //sort(bubble sort) the player according to the dps  
									for(j = 0;j < hist.length-i-1;j++){
										if(hist[j].dps > hist[j+1].dps || hist[j].dps == hist[j+1].dps && hist[j]._iw < hist[j+1]._iw){
											temp = _.clone(hist[j]);
											hist[j] = _.clone(hist[j+1]);
											hist[j+1] = _.clone(temp);
										}
									}
								}



								var game_id = table1.value.game_id;
								if(table1.value.gt == 'Deal' || table1.value.gt == 'Pool'){
									game_id = game_id+'.'+table1.value.sub_id;
								}

								var rCount = 0;
								var uCount = 0;
								var rSts = 'loss';
								var uSts = 'loss';
								for(var k in hist){

									// if(hist[k]._ir == 0){
										
										// var sts = 'loss';
										if(hist[k]._iw == 1){
											// sts = 'win';

											if(hist[k]._ir == 1){
												rSts = 'win';
											}
											else{
												uSts = 'win';
											}

										}
										// else{
										// 	sts = 'loss';
										// }
										if(hist[k]._ir == 1){
											rCount++;
										}
										else{
											uCount++;
										}

										/*if(hist[k].s != 'left' && hist[k].s != 'drop' && hist[k].s != 'standup'){

											// trackClass.TEA({table:'track_primary_data',category:'economy',label:table1.value.gt,option:'game_end',action:game_id,name:table1.value.rSeq,value:hist[k].wc,detail1:table1.value.ap,detail2:parseInt(k)+1,detail3:hist[k].ps,detail4:'chips',description:sts},{uid:hist[k].uid});
											if(hist[k].gst && hist[k].gedt && typeof hist[k].rndCount != 'undefined' && hist[k].rndCount != null){

												var gameDuration = 0;
												var tableDuration = 0;
												gameDuration = commonClass.GetTimeDifference(hist[k].gst,hist[k].gedt);
												tableDuration = commonClass.GetTimeDifference(hist[k].jt,hist[k].gedt);
												trackClass.TEA({table:'track_primary_data',category:'screen',label:table1.value.gt,option:'game_end_summary',action:table1.value.ap,name:(table1.value.ap-table1.value.uCount),detail1:game_id,detail3:hist[k].rndCount,description:gameDuration,value:tableDuration},{uid:hist[k].uid});
											}
											trackClass.TEA({table:'track_primary_data',category:'economy',label:table1.value.gt,option:'game_end',action:table1.value.ap,name:parseInt(k)+1,value:hist[k].wc,detail1:game_id,detail3:hist[k].ps,detail4:'chips',description:sts},{uid:hist[k].uid});
											
										}*/
									// }
								}

								if(rCount > 0 || uCount > 0){

									db.collection('win_sts').insertOne({date:new Date(),table_id:table1.value._id.toString(),game_type:table1.value.gt,game_id:game_id,rCount:rCount,uCount:uCount,rSts:rSts,uSts:uSts});
								}
								
								var ldData = {$set:{
									tbid:table1.value._id.toString(),
									round:table1.value.round,
									game_id:table1.value.game_id,
									sub_id:table1.value.sub_id,
									gt:table1.value.gt,
									tst:table1.value.tst,
									pi:hist,
									wildCard:table1.value.wildCard,
									win:[winner]
								}};
										
								db.collection('last_deal').findAndModify({'tbid':table1.value._id.toString()},{},ldData,{upsert:true,new:true},function(err,table1){});

								commonClass.FireEventToTable(table1.value._id.toString(),{en:'WD',data:{tbid:table1.value._id.toString(),round:table1.value.round,game_id:table1.value.game_id,sub_id:table1.value.sub_id,gt:table1.value.gt,tst:table1.value.tst,pi:hist,win:[winner],wildCard:table1.value.wildCard}});
								


								var jobId = commonClass.GetRandomString(10);

								cdClass.UpdateTableData(table1.value._id.toString(),{$set:{jid:jobId}},function(table2){
									if(table2){
										c('handlePoolWinner------else-------->>>>>>next game timmer started');
										var nxt = commonClass.AddTime(config.NXT);
										schedule.scheduleJob(table2.jid,new Date(nxt),function(){  
											schedule.cancelJob(table2.jid);
											playingTableClass.afterRoundFinish(table2._id.toString());
										});
									}
									else{
										c('handlePoolWinner-------else----->>>>>Error:"table not found"');
									}
								});
							}
							else{
								c('handlePoolWinner--------else------>>>>Error:"table not found"');
							}
						});
					});
				});
			}
		});
	},
	handleWinner : function(tbId,winner/*,pv*/,direct){     //winner = winner player seat index, pv = pot value, direct = direct winner flag
		/* +-------------------------------------------------------------------+
            desc:function to handle clasic/bet winner
            i/p: tbId = table id,winner = winner player seat index,direct = true/false direct winner or nots
        +-------------------------------------------------------------------+ */
		c('handleWinner-------->>>>>winner: ',winner);
		c('handleWinner-------->>>>>tbId: ',tbId);

		// cdClass.GetTbInfo(tbId,{},function(table){
		



		// cdClass.UpdateTableData(tbId,{},function(table){
		db.collection('playing_table').findAndModify({_id:MongoID(tbId),_isWinner:0},{},{$set:{_isWinner:1,ctrlServer:SERVER_ID}},{new:true},function(err,table){
			if(err || !table || typeof table.value == 'undefined' || table.value == null){
				c('handleWinner---------->>>>>>Error: "table not found"');
				return false;
			}

			table = table.value;
			c('handleWinner-----starting--->>>>>pi: ',table.pi);
			if(_.isEmpty(table.pi[winner])){
				c('handleWinner---------->>>>>>Error: "winner is not found in pi"');
				return false;
			}
			var pv  = table.pv;
			var wid = table.pi[winner].uid.toString();
			c('handleWinner-----------tbid: '+table._id+'---------->>>>>>>uid: '+table.pi[winner].uid);
			jtClass.cancelJobOnServers(tbId,table.jid);
			profileClass.ManageUserLevel('win',table.pi[winner].uid);
			cdClass.UpdateUserChips(table.pi[winner].uid,pv,'Game Win',function(uChips){
				
				c('handleWinner-------->>>>>uChips: ',uChips);
				var tempPlayerData = table.pi[winner];
				var ctth = '';		
				if(direct){
					if(table.pi[winner].cards.length > 13){
						ctth = table.pi[winner].cards.pop();
						tempPlayerData.cards = table.pi[winner].cards;
					}
					tempPlayerData.dCards = {pure:[],seq:[],set:[],dwd:table.pi[winner].cards};
				}
				tempPlayerData.wc = pv;
				tempPlayerData.Chips = uChips;
				tempPlayerData._iw = 1;
				tempPlayerData.gedt = new Date();
				// var upData = {$set:{dealer: winner,'pi.$.wc':pv,'pi.$.Chips':uChips}};  //old logic for setting winner as dealer
				var upData = {$set:{la:new Date(),ctrlServer:SERVER_ID,'pi.$.wc':pv,'pi.$.Chips':uChips,'pi.$._iw':1,tst: 'winnerDeclared',ctt:new Date(),'pi.$.gedt':new Date()}};
				if(ctth != ''){


					if(table.pi[winner].gCards.length > 0){

						var gCards = table.pi[winner].gCards;
						// c('handleWinner---------->>>>>>gCards: ',gCards);
						// for(var x in gCards){
						// 	if(_.contains(gCards[x],ctth)){
						// 		gCards[x] = _.without(gCards[x],ctth);
						// 		break;
						// 	}
						// }
						// c('handleWinner------------->>>>>gCards: ',gCards);


						if(gCards.pure.length > 0){

							var pureCards = gCards.pure;
							c('handleWinner---------->>>>>>gCards: ',pureCards);
							for(var x in pureCards){
								if(_.contains(pureCards[x],ctth)){
									pureCards[x] = _.without(pureCards[x],ctth);
									break;
								}
							}
							c('handleWinner------------->>>>>gCards: ',gCards);
							gCards.pure = pureCards;
						}
						else if (gCards.seq.length > 0) {
							var seqCards = gCards.seq;
							c('handleWinner---------->>>>>>gCards: ',seqCards);
							for(var x in seqCards){
								if(_.contains(seqCards[x],ctth)){
									seqCards[x] = _.without(seqCards[x],ctth);
									break;
								}
							}
							c('handleWinner------------->>>>>gCards: ',seqCards);
							gCards.seq = seqCards;
						}
						else if (gCards.set.length > 0){
							var setCards = gCards.set;
							c('handleWinner---------->>>>>>gCards: ',setCards);
							for(var x in setCards){
								if(_.contains(setCards[x],ctth)){
									setCards[x] = _.without(setCards[x],ctth);
									break;
								}
							}
							c('handleWinner------------->>>>>gCards: ',setCards);
							gCards.set = setCards;
						}
						else if (gCards.dwd.length > 0){
							var dwdCards = gCards.dwd;
							c('handleWinner---------->>>>>>gCards: ',dwdCards);
							for(var x in dwdCards){
								if(_.contains(dwdCards[x],ctth)){
									dwdCards[x] = _.without(dwdCards[x],ctth);
									break;
								}
							}
							c('handleWinner------------->>>>>gCards: ',dwdCards);
							gCards.dwd = dwdCards;
						}
						else{
					
						}
					}
					else{
						var gCards = table.pi[winner].gCards;
						var dwdCards = table.pi[winner].cards;
						gCards.dwd = dwdCards;
					}


					upData['$set']['pi.$.cards'] = table.pi[winner].cards;
					upData['$set']['pi.$.gCards'] = gCards;
					upData['$push'] = {oDeck:ctth};
				}

				for(var k in table.hist){
					if(table.hist[k].uid == tempPlayerData.uid){
						upData['$removeFromSet'] = {hist:table.hist[k]}
					}					
				}
				upData['$addToSet'] = {hist:tempPlayerData};

				cdClass.CountHands(table.pi[winner].uid,'win',table.gt,table.bv,true,function(thp,qstWin){
					c('handleWinner-------->>>>>thp: ',thp);
					playClass.getUserScore(table.pi[winner].uid,table.bv,table.gt,function(score){
						c('handleWinner-------->>>>>score: ',score);
						upData['$set']['pi.$.score'] = score;
						upData['$set']['pi.$.thp'] = thp;
						// upData['$set']['pi.$.spc'] = spc;

						/*if(table.spcSi == winner && (spc >= config.FIRST_TIME_GAME_LIMIT || uChips > config.FIRST_TIME_CHIPS_LIMIT)){  //user is no longer first timer user
							upData.$set['pi.$.isSpc'] = false;
							upData.$set.spcSi = -1;
							upData.$set.RobotCount = 0;
							upData.$set.HumanCount = 0;
							db.collection('game_users').updateOne({_id:MongoID(table.pi[winner].uid)},{$set:{'flags._isSpc':0}},function(errr,res){
								if(errr){
									c('handleWinner------------>>>>>>errr: ',errr);
								}
								c('handleWinner--------------->>>>res: ',res);

							});
						}*/
						upData.$set._qstWin = qstWin;
						db.collection('playing_table').findAndModify({_id:MongoID(tbId),'pi.si':winner},{},upData,{upsert:true,new:true},function(err,table1){
							// c('history: ',table1.value.hist);
							if(table1 != null && table1.value != null){

								c('handleWinner------winner data updated-->>>>>table1');
								var hist = _.clone(table1.value.hist);
								
								for(i = 0;i < hist.length;i++){   //sort(bubble sort) the player according to the cards points
									for(j = 0;j < hist.length-i-1;j++){
										if(hist[j].wc < hist[j+1].wc){
											temp = _.clone(hist[j]);
											hist[j] = _.clone(hist[j+1]);
											hist[j+1] = _.clone(temp);
										}
									}
								}
								
								var game_id = table1.value.game_id;
								if(table1.value.gt == 'Deal' || table1.value.gt == 'Pool'){
									game_id = game_id+'.'+table1.value.sub_id;
								}


								var rCount = 0;
								var uCount = 0;
								var rSts = 'loss';
								var uSts = 'loss';
								var wl = [];
								for(var k in hist){

									// if(hist[k]._ir == 0){

										var sts = 'loss';
										if(hist[k]._iw == 1){
											sts = 'win';
											if(hist[k]._ir == 1){
												rSts = 'win';
											}
											else{
												uSts = 'win';
											}
										}
										else{
											sts = 'loss';
										}
										if(hist[k]._ir == 1){
											rCount++;
										}
										else{
											uCount++;
										}

										if(wid == hist[k].uid.toString() && hist[k]._iw != 1){
											c("dont enter in winner list");
										}
										else{
											wl.push(hist[k])
										}
										/*if(hist[k].s != 'left' && hist[k].s != 'drop' && hist[k].s != 'standup'){

											if(hist[k].gst && hist[k].gedt && typeof hist[k].rndCount != 'undefined' && hist[k].rndCount != null){

												var gameDuration = 0;
												var tableDuration = 0;
												gameDuration = commonClass.GetTimeDifference(hist[k].gst,hist[k].gedt);
												tableDuration = commonClass.GetTimeDifference(hist[k].jt,hist[k].gedt);
											}
										}*/	

									// }
								}

								c("handleWinner------winner list-->>>>>wl:",wl);
								if(rCount > 0 || uCount > 0){

									db.collection('win_sts').insertOne({date:new Date(),table_id:table1.value._id.toString(),game_type:table1.value.gt,game_id:game_id,rCount:rCount,uCount:uCount,rSts:rSts,uSts:uSts});
								}

								var ldData = {$set:{
									pi:wl,
									wildCard:table1.value.wildCard,
									win:[winner],
									round:table1.value.round,
									game_id:table1.value.game_id,
									sub_id:table1.value.sub_id,
									gt:table1.value.gt,
									tst:table1.value.tst
								}};

								db.collection('last_deal').findAndModify({'tbid':table1.value._id.toString()},{},ldData,{upsert:true,new:true},function(err,tb){});
								c('handleWinner------winner data updated-->>>>>table1.value._id.toString()',table1.value._id.toString());
								commonClass.FireEventToTable(table1.value._id.toString(),{en:'WD',data:{tbid:table1.value._id.toString(),wAnimation:true,round:table1.value.round,game_id:table1.value.game_id,sub_id:table1.value.sub_id,gt:table1.value.gt,tst:table1.value.tst,pi:wl,win:[winner],wildCard:table1.value.wildCard}});
								
								var jobId = commonClass.GetRandomString(10);

								cdClass.UpdateTableData(table1.value._id.toString(),{$set:{jid:jobId,_isWinner:0}},function(table2){
									if(table2){
										c("handleWinner----------1gf--------table2.id: ",table2._id.toString());
										var nxt = commonClass.AddTime(config.NXT);
										c("handleWinner----------2gf--------table2.jid: ",table2.jid.toString());
										schedule.scheduleJob(table2.jid,new Date(nxt),function(){  
											c("handleWinner----------1gfgf--------table2.jid: ",table2.jid.toString());	
											schedule.cancelJob(table2.jid);
											c("handleWinner----------2gfgf--------table2.id: ",table2._id.toString());
											playingTableClass.afterRoundFinish(table2._id.toString());
										});
									}
									else{
										c('handleWinner:::::::::::::::Error:"table not found"');
									}
								});	
							}
							else{
								c('handleWinner-------'+tbId+'------->>>>>>winner data not updated ');
								var upData2 = {$set:{la:new Date(),ctrlServer:SERVER_ID,tst: 'winnerDeclared',ctt:new Date()}};
								if(ctth != ''){
									upData2['$push'] = {oDeck:ctth};
								}

								for(var k in table.hist){
									if(table.hist[k].uid == tempPlayerData.uid){
										upData2['$removeFromSet'] = {hist:table.hist[k]}
									}					
								}

								upData2['$addToSet'] = {hist:tempPlayerData};
								db.collection('playing_table').findAndModify({_id:MongoID(tbId)},{},upData2,{upsert:true,new:true},function(err,table2){
									// c('history: ',table2.value.hist);
									if(table2 != null && table2.value != null){
										c('handleWinner------hist-->>>>>table2',table2.value.hist.length);
										var hist = _.clone(table2.value.hist);
										
										for(i = 0;i < hist.length;i++){   //sort(bubble sort) the player according to the cards points
											for(j = 0;j < hist.length-i-1;j++){
												if(hist[j].wc < hist[j+1].wc){
													temp = _.clone(hist[j]);
													hist[j] = _.clone(hist[j+1]);
													hist[j+1] = _.clone(temp);
												}
											}
										}
										
										var game_id = table2.value.game_id;
										if(table2.value.gt == 'Deal' || table2.value.gt == 'Pool'){
											game_id = game_id+'.'+table2.value.sub_id;
										}


										var rCount = 0;
										var uCount = 0;
										var rSts = 'loss';
										var uSts = 'loss';
										var wl = [];
										for(var k in hist){
											var sts = 'loss';
											if(hist[k]._iw == 1){
												sts = 'win';
												if(hist[k]._ir == 1){
													rSts = 'win';
												}
												else{
													uSts = 'win';
												}
											}
											else{
												sts = 'loss';
											}
											if(hist[k]._ir == 1){
												rCount++;
											}
											else{
												uCount++;
											}

											if(wid == hist[k].uid.toString() && hist[k]._iw != 1){
												c("dont enter in winner list");
											}
											else{
												c("enter in winner list"+k);
												wl.push(hist[k]);
											}
										}

										if(rCount > 0 || uCount > 0){

											db.collection('win_sts').insertOne({date:new Date(),table_id:table2.value._id.toString(),game_type:table2.value.gt,game_id:game_id,rCount:rCount,uCount:uCount,rSts:rSts,uSts:uSts});
										}

										var ldData = {$set:{
											pi:wl,
											wildCard:table2.value.wildCard,
											win:[winner],
											round:table2.value.round,
											game_id:table2.value.game_id,
											sub_id:table2.value.sub_id,
											gt:table2.value.gt,
											tst:table2.value.tst
										}};
										c("handleWinner------winner list-->>>>>wl:",wl);
										db.collection('last_deal').findAndModify({'tbid':table2.value._id.toString()},{},ldData,{upsert:true,new:true},function(err,tb){});
										c('handleWinner------winner data updated-->>>>>table2.value._id.toString()',table2.value._id.toString());
										commonClass.FireEventToTable(table2.value._id.toString(),{en:'WD',data:{tbid:table2.value._id.toString(),wAnimation:false,round:table2.value.round,game_id:table2.value.game_id,sub_id:table2.value.sub_id,gt:table2.value.gt,tst:table2.value.tst,pi:wl,win:[winner],wildCard:table2.value.wildCard}});
										
										var jobId = commonClass.GetRandomString(10);

										cdClass.UpdateTableData(table2.value._id.toString(),{$set:{jid:jobId,_isWinner:0}},function(table3){
											if(table3){
												c("handleWinner----------1--------table3.id: ",table3._id.toString());
												var nxt = commonClass.AddTime(config.NXT);
												schedule.scheduleJob(table3.jid,new Date(nxt),function(){  
													schedule.cancelJob(table3.jid);
													c("handleWinner---------2---------table3.id: ",table3._id.toString());
													playingTableClass.afterRoundFinish(table3._id.toString());
												});
											}
											else{
												c('handleWinner::::::::444444444:::::::Error:"table not found"');
											}
										});
									}
									else{
										c('handleWinner-------'+tbId+'------->>>>>>winner data not updated 1');
									}
								})
							}
						});
					});
				});
			});
		});
	},
	handleWinnerCash : function(tbId,winner,direct){
		/* +-------------------------------------------------------------------+
            desc:function to handle clasic/bet winner
            i/p: tbId = table id,winner = winner player seat index,direct = true/false direct winner or nots
        +-------------------------------------------------------------------+ */
		c('handleWinnerCash-------->>>>>winner: ',winner);
		


		db.collection('playing_table').findAndModify({_id:MongoID(tbId),_isWinner:0},{},{$set:{_isWinner:1,ctrlServer:SERVER_ID}},{new:true},function(err,table){
			if(err || !table ||typeof table.value == 'undefined' || table.value == null){
				c('handleWinnerCash---------->>>>>>Error: "table not found"');
				return false;
			}
			table = table.value;
			c('handleWinnerCash-----starting--->>>>>pi: ',table.pi);
			if(_.isEmpty(table.pi[winner])){
				c('handleWinnerCash---------->>>>>>Error: "winner is not found in pi"');
				return false;
			}
			var pv  = table.pv;
			var tds = (pv*config.TDS)/100;
			pv = pv - tds;
			c('handleWinnerCash-----------tbid: '+table._id+'---------->>>>>>>uid: '+table.pi[winner].uid);
			jtClass.cancelJobOnServers(tbId,table.jid);
			var wid = table.pi[winner].uid.toString();
			profileClass.ManageUserLevel('win',table.pi[winner].uid);
			cdClass.UpdateUserCash(table.pi[winner].uid,pv,'Game Win',function(uChips){
				
				console.log("handleWinnerCash---------------------uChips:"+uChips);
				var tempPlayerData = table.pi[winner];
				var ctth = '';
				if(direct){
					if(table.pi[winner].cards.length > 13){
						ctth = table.pi[winner].cards.pop();
						tempPlayerData.cards = table.pi[winner].cards;
					}
					tempPlayerData.dCards = {pure:[],seq:[],set:[],dwd:table.pi[winner].cards};
				}
				tempPlayerData.wc = pv;
				tempPlayerData.Chips = uChips;
				tempPlayerData._iw = 1;
				tempPlayerData.gedt = new Date();
				var upData = {$set:{la:new Date(),ctrlServer:SERVER_ID,'pi.$.wc':pv,'pi.$.Chips':uChips,'pi.$._iw':1,tst: 'winnerDeclared',ctt:new Date(),'pi.$.gedt':new Date()}};
				if(ctth != ''){


					if(table.pi[winner].gCards.length > 0){

						// var gCards = table.pi[winner].gCards;
						// c('handleWinnerCash---------->>>>>>gCards: ',gCards);
						// for(var x in gCards){
						// 	if(_.contains(gCards[x],ctth)){
						// 		gCards[x] = _.without(gCards[x],ctth);
						// 		break;
						// 	}
						// }
						// c('handleWinnerCash------------->>>>>gCards: ',gCards);

						if(gCards.pure.length > 0){

							var pureCards = gCards.pure;
							c('DSCRD---------->>>>>>gCards: ',pureCards);
							for(var x in pureCards){
								if(_.contains(pureCards[x],ctth)){
									pureCards[x] = _.without(pureCards[x],ctth);
									break;
								}
							}
							c('DSCRD------------->>>>>gCards: ',gCards);
							gCards.pure = pureCards;
						}
						else if (gCards.seq.length > 0) {
							var seqCards = gCards.seq;
							c('DSCRD---------->>>>>>gCards: ',seqCards);
							for(var x in seqCards){
								if(_.contains(seqCards[x],ctth)){
									seqCards[x] = _.without(seqCards[x],ctth);
									break;
								}
							}
							c('DSCRD------------->>>>>gCards: ',seqCards);
							gCards.seq = seqCards;
						}
						else if (gCards.set.length > 0){
							var setCards = gCards.set;
							c('DSCRD---------->>>>>>gCards: ',setCards);
							for(var x in setCards){
								if(_.contains(setCards[x],ctth)){
									setCards[x] = _.without(setCards[x],ctth);
									break;
								}
							}
							c('DSCRD------------->>>>>gCards: ',setCards);
							gCards.set = setCards;
						}
						else if (gCards.dwd.length > 0){
							var dwdCards = gCards.dwd;
							c('DSCRD---------->>>>>>gCards: ',dwdCards);
							for(var x in dwdCards){
								if(_.contains(dwdCards[x],ctth)){
									dwdCards[x] = _.without(dwdCards[x],ctth);
									break;
								}
							}
							c('DSCRD------------->>>>>gCards: ',dwdCards);
							gCards.dwd = dwdCards;
						}
						else{
					
						}
					}
					else{
						var gCards = table.pi[winner].cards;
					}
					upData['$set']['pi.$.cards'] = table.pi[winner].cards;
					upData['$set']['pi.$.gCards'] = gCards;
					upData['$push'] = {oDeck:ctth};
				}
				upData['$addToSet'] = {hist:tempPlayerData};


				cdClass.CountHands(table.pi[winner].uid,'win',table.gt,table.bv,true,function(thp,qstWin){
					playClass.getUserScore(table.pi[winner].uid,table.bv,table.gt,function(score){
						upData['$set']['pi.$.score'] = score;
						upData['$set']['pi.$.thp'] = thp;
						

						upData.$set._qstWin = qstWin;
						db.collection('playing_table').findAndModify({_id:MongoID(tbId),'pi.si':winner},{},upData,{new:true},function(err,table1){
							// c('history: ',table1.value.hist);
							if(table1.value != null){

								var hist = _.clone(table1.value.hist);
								
								for(i = 0;i < hist.length;i++){   //sort(bubble sort) the player according to the cards points
									for(j = 0;j < hist.length-i-1;j++){
										if(hist[j].wc < hist[j+1].wc){
											temp = _.clone(hist[j]);
											hist[j] = _.clone(hist[j+1]);
											hist[j+1] = _.clone(temp);
										}
									}
								}
								
								var game_id = table1.value.game_id;
								if(table1.value.gt == 'Deal' || table1.value.gt == 'Pool'){
									game_id = game_id+'.'+table1.value.sub_id;
								}


								var rCount = 0;
								var uCount = 0;
								var rSts = 'loss';
								var uSts = 'loss';
								var wl = [];
								for(var k in hist){

									if(hist[k]._iw == 1){
										if(hist[k]._ir == 1){
											rSts = 'win';
										}
										else{
											uSts = 'win';
										}
									}
									
									if(hist[k]._ir == 1){
										rCount++;
									}
									else{
										uCount++;
									}

									if(wid == hist[k].uid.toString() && hist[k]._iw != 1){
										c("dont enter in winner list");
									}
									else{
										wl.push(hist[k])
									}
								}

								if(rCount > 0 || uCount > 0){

									db.collection('win_sts').insertOne({date:new Date(),table_id:table1.value._id.toString(),game_type:table1.value.gt,game_id:game_id,rCount:rCount,uCount:uCount,rSts:rSts,uSts:uSts});
								}

								var ldData = {$set:{
									pi:wl,
									wildCard:table1.value.wildCard,
									win:[winner],
									round:table1.value.round,
									game_id:table1.value.game_id,
									sub_id:table1.value.sub_id,
									gt:table1.value.gt,
									tst:table1.value.tst
								}};

								c('handleWinnerCash------------->>>>>gCards: ',ldData);
								db.collection('last_deal').findAndModify({'tbid':table1.value._id.toString()},{},ldData,{upsert:true,new:true},function(err,table1){});
								commonClass.FireEventToTable(table1.value._id.toString(),{en:'WD',data:{tbid:table1.value._id.toString(),wAnimation:true,round:table1.value.round,game_id:table1.value.game_id,sub_id:table1.value.sub_id,gt:table1.value.gt,tst:table1.value.tst,pi:wl,win:[winner],wildCard:table1.value.wildCard}});
								
								var jobId = commonClass.GetRandomString(10);

								cdClass.UpdateTableData(table1.value._id.toString(),{$set:{jid:jobId,_isWinner:0}},function(table2){
									if(table2){

										var nxt = commonClass.AddTime(config.NXT);
										schedule.scheduleJob(table2.jid,new Date(nxt),function(){  
											schedule.cancelJob(table2.jid);
											playingTableClass.afterRoundFinish(table2._id.toString());
										});
									}
									else{
										c('handleWinnerCash:::::::::::::::Error:"table not found"');
									}
								});	
							}
							else{
								c('handleWinnerCash-------'+tbId+'------->>>>>>winner data not updated ');
								var upData2 = {$set:{la:new Date(),ctrlServer:SERVER_ID,tst: 'winnerDeclared',ctt:new Date()}};
								if(ctth != ''){
									upData2['$push'] = {oDeck:ctth};
								}
								upData2['$addToSet'] = {hist:tempPlayerData};
								db.collection('playing_table').findAndModify({_id:MongoID(tbId)},{},upData2,{upsert:true,new:true},function(err,table2){
									// c('history: ',table2.value.hist);
									if(table2 != null && table2.value != null){
										c('handleWinnerCash------winner data updated-->>>>>table2');
										var hist = _.clone(table2.value.hist);
										
										for(i = 0;i < hist.length;i++){   //sort(bubble sort) the player according to the cards points
											for(j = 0;j < hist.length-i-1;j++){
												if(hist[j].wc < hist[j+1].wc){
													temp = _.clone(hist[j]);
													hist[j] = _.clone(hist[j+1]);
													hist[j+1] = _.clone(temp);
												}
											}
										}
										
										var game_id = table2.value.game_id;
										if(table2.value.gt == 'Deal' || table2.value.gt == 'Pool'){
											game_id = game_id+'.'+table2.value.sub_id;
										}


										var rCount = 0;
										var uCount = 0;
										var rSts = 'loss';
										var uSts = 'loss';
										var wl = [];
										for(var k in hist){
											var sts = 'loss';
											if(hist[k]._iw == 1){
												sts = 'win';
												if(hist[k]._ir == 1){
													rSts = 'win';
												}
												else{
													uSts = 'win';
												}
											}
											else{
												sts = 'loss';
											}
											if(hist[k]._ir == 1){
												rCount++;
											}
											else{
												uCount++;
											}

											if(wid == hist[k].uid.toString() && hist[k]._iw != 1){
												c("dont enter in winner list");
											}
											else{
												wl.push(hist[k])
											}
										}

										if(rCount > 0 || uCount > 0){

											db.collection('win_sts').insertOne({date:new Date(),table_id:table2.value._id.toString(),game_type:table2.value.gt,game_id:game_id,rCount:rCount,uCount:uCount,rSts:rSts,uSts:uSts});
										}

										var ldData = {$set:{
											pi:wl,
											wildCard:table2.value.wildCard,
											win:[winner],
											round:table2.value.round,
											game_id:table2.value.game_id,
											sub_id:table2.value.sub_id,
											gt:table2.value.gt,
											tst:table2.value.tst
										}};

										db.collection('last_deal').findAndModify({'tbid':table2.value._id.toString()},{},ldData,{upsert:true,new:true},function(err,tb){});
										c('handleWinnerCash------winner data updated-->>>>>table2.value._id.toString()',table2.value._id.toString());
										commonClass.FireEventToTable(table2.value._id.toString(),{en:'WD',data:{tbid:table2.value._id.toString(),wAnimation:false,round:table2.value.round,game_id:table2.value.game_id,sub_id:table2.value.sub_id,gt:table2.value.gt,tst:table2.value.tst,pi:wl,win:[winner],wildCard:table2.value.wildCard}});
										
										var jobId = commonClass.GetRandomString(10);

										cdClass.UpdateTableData(table2.value._id.toString(),{$set:{jid:jobId,_isWinner:0}},function(table3){
											if(table3){
												var nxt = commonClass.AddTime(config.NXT);
												schedule.scheduleJob(table3.jid,new Date(nxt),function(){  
													schedule.cancelJob(table3.jid);
													playingTableClass.afterRoundFinish(table3._id.toString());
												});
											}
											else{
												c('handleWinnerCash:::::::::::::::Error:"table not found"');
											}
										});
									}
									else{
										c('handleWinnerCash-------'+tbId+'------->>>>>>winner data not updated 1');
									}
								})
							}
						});
					});
				});
			});
		});
	},
	giveWinChips:function(tbId,winners,px,iter,prize,msg,bv,gt,direct){  //iter = iterator for recursion
		/* +-------------------------------------------------------------------+
            desc:function to handle classic/bet winner
            i/p: tbId = table id
            	 winners = array of winners seat indices
            	 px = player details
            	 iter = iterator for recursion
            	 prize = prize amount for winners
            	 msg = message for chips track
            	 bv = boot value
            	 gt = game type
            	 direct = true/false direct winner or not
        +-------------------------------------------------------------------+ */
		c('giveWinChips------------>>>>>>>>prize: '+prize);

		
		if(iter < px.length){

			if(_.contains(winners,px[iter].si)){  //means the winner

				cdClass.UpdateUserChips(px[iter].uid,prize,msg,function(uChips){
					
					var tempPlayerData = px[iter];
					var ctth = '';
					if(direct){
						if(px[iter].cards.length > 13){
							ctth = px[iter].cards.pop();
							tempPlayerData.cards = px[iter].cards;
						}
						tempPlayerData.dCards = {pure:[],seq:[],set:[],dwd:px[iter].cards};
					}
					tempPlayerData.wc = prize;
					tempPlayerData.Chips = uChips;
					tempPlayerData._iw = 1;
					tempPlayerData.gedt = new Date();
					c('giveWinChips----------->>>>>>>>ctth: '+ctth+' direct: '+direct);
					var upData = {$set:{la:new Date(),ctrlServer:SERVER_ID,'pi.$.wc':prize,'pi.$.Chips':uChips,'pi.$._iw':1,tst:'winnerDeclared',ctt:new Date(),'pi.$.gedt':new Date()}};
					if(ctth != ''){


						if(px[iter].gCards.length > 0){

							var gCards = px[iter].gCards;
							c('giveWinChips---------->>>>>>gCards: ',gCards);
							for(var x in gCards){
								if(_.contains(gCards[x],ctth)){
									gCards[x] = _.without(gCards[x],ctth);
									break;
								}
							}
							c('giveWinChips------------->>>>>gCards: ',gCards);
						}
						else{
							var gCards = px[iter].cards;
						}

						upData['$set']['pi.$.cards'] = px[iter].cards;
						upData['$set']['pi.$.gCards'] = gCards;
						upData['$push'] = {oDeck:ctth};
					}
					upData['$addToSet'] = {hist:tempPlayerData};
					c('giveWinChips----------->>>>>upData: ',upData);
					// cdClass.CountHands(table.value.pi[px[iter].si].uid,true,function(){
					cdClass.CountHands(px[iter].uid,'win',gt,bv,true,function(thp,qstWin){
						playClass.getUserScore(px[iter].uid,bv,gt,function(score){
							upData['$set']['pi.$.score'] = score;
							upData['$set']['pi.$.thp'] = thp;
							// upData['$set']['pi.$.spc'] = spc;

							/*if(px[iter].isSpc && (spc >= config.FIRST_TIME_GAME_LIMIT || uChips > config.FIRST_TIME_CHIPS_LIMIT)){
								upData.$set['pi.$.isSpc'] = false;
								upData.$set.spcSi = -1;
								upData.$set.RobotCount = 0;
								upData.$set.HumanCount = 0;
								db.collection('game_users').updateOne({_id:MongoID(px[iter].uid)},{$set:{'flags._isSpc':0}},function(errr,res){
									if(errr){
										c('giveWinChips-------------->>>>>errr: ',errr);
									}
									c('giveWinChips------------------->>>>>res: ',res);
								});
							}*/

							if(qstWin == 1){

								upData.$set._qstWin = qstWin;
							}
							db.collection('playing_table').findAndModify({_id:MongoID(tbId),'pi.si':px[iter].si},{},upData,{new:true},function(err,table){
								if(table && table.value){
									c('giveWinChips-----------------track deal winner');
									// trackClass.TEA({table:'track_primary_data',category:'economy',label:'deal_rummy',option:'winner_declaration',action:px[iter].uid,name:px[iter].un,value:prize,detail3:'chips'},{uid:px[iter].uid}); 
									
									playingTableClass.giveWinChips(table.value._id.toString(),winners,px,iter+1,prize,msg,bv,gt,direct);
								}
								else{
									c('giveWinChips-------------->>>>>>>>>Error:"table  not found"');
								}
							});
						});
					});
				});
			}
			else{
				playingTableClass.giveWinChips(tbId,winners,px,iter+1,prize,msg,bv,gt,direct);
			}
		}
		else{
			cdClass.GetTbInfo(tbId,{},function(table1){
				if(table1){

					var hist = _.clone(table1.hist);
					
					c('giveWinChips----------->>>>>>hist: ',hist);
					for(i = 0;i < hist.length;i++){   //sort(bubble sort) the player according to the dps  
						for(j = 0;j < hist.length-i-1;j++){
							if(hist[j].dps > hist[j+1].dps  || hist[j].dps == hist[j+1].dps && hist[j]._iw < hist[j+1]._iw){ //if dps are equal then put loser after winner
								temp = _.clone(hist[j]);
								hist[j] = _.clone(hist[j+1]);
								hist[j+1] = _.clone(temp);
							}
						}
					}

					var game_id = table1.game_id;
					var deal_id = table1.game_id;
					if(table1.gt == 'Deal' || table1.gt == 'Pool'){
						game_id = game_id+'.'+table1.sub_id;
					}
					var rCount = 0;
					var uCount = 0;
					var rSts = 'loss';
					var uSts = 'loss';
					for(var k in hist){

						// if(hist[k]._ir == 0){
							
							var sts = 'loss';
							if(hist[k]._iw == 1){
								sts = 'win';
								if(hist[k]._ir == 1){
									rSts = 'win';
								}
								else{
									uSts = 'win';
								}
							}
							else{
								sts = 'loss';
							}
							if(hist[k]._ir == 1){
								rCount++;
							}
							else{
								uCount++;
							}
							c('giveWinChips-----------------track deal winner');
							if(hist[k].s != 'left' && hist[k].s != 'drop' && hist[k].s != 'standup'){

								// trackClass.TEA({table:'track_primary_data',category:'game',label:table1.gt,option:'deal_end',action:deal_id,name:table1.rSeq,value:hist[k].wc,detail1:table1.ap,detail2:parseInt(k)+1,detail3:hist[k].ps,detail4:'chips',description:sts},{uid:hist[k].uid});
								// trackClass.TEA({table:'track_primary_data',category:'game',label:table1.gt,option:'deal_end',action:deal_id,name:table1.ap,value:hist[k].wc,detail1:parseInt(k)+1,detail3:hist[k].ps,detail4:'chips',description:sts},{uid:hist[k].uid});
								var obj = { 
									gt : table1.gt ,
									ap :table1.ap ,
									rank :parseInt(k)+1 ,
									wc : hist[k].wc,
									game_id : deal_id ,
									ps :hist[k].ps ,
									sts : sts,
									type :'deal_end' ,
									tbId : table1._id.toString(),
									cat : 'game' 
								};

								if(hist[k].gst && hist[k].gedt && typeof hist[k].rndCount != 'undefined' && hist[k].rndCount != null){

				                    var gameDuration = 0;
				                    var tableDuration = 0;
				                    gameDuration = commonClass.GetTimeDifference(hist[k].gst,hist[k].gedt);
				                    tableDuration = commonClass.GetTimeDifference(hist[k].jt,hist[k].gedt);
				                    trackClass.TEA({table:'track_primary_data',category:'screen',label:table1.gt,option:'game_end_summary',action:table1.ap,name:(table1.ap-table1.uCount),detail1:deal_id,detail3:hist[k].rndCount,description:gameDuration,value:tableDuration},{uid:hist[k].uid});
				                }
								trackClass.gameEndTrack(hist[k].uid,obj);
							}
						// }
					}
					if(rCount > 0 || uCount > 0){

						db.collection('win_sts').insertOne({date: new Date(),table_id:table1._id.toString(),game_type:table1.gt,game_id:game_id,rCount:rCount,uCount:uCount,rSts:rSts,uSts:uSts});
					}
					
					var ldData = {$set:{
						round:table1.round,
						game_id:table1.game_id,
						sub_id:table1.sub_id,
						gt:table1.gt,
						tst:table1.tst,
						pi:hist,
						wildCard:table1.wildCard,
						win:winners
					}};

					db.collection('last_deal').findAndModify({'tbid':table1.value._id.toString()},{},ldData,{upsert:true,new:true},function(err,table1){});

					commonClass.FireEventToTable(table1._id.toString(),{en:'WD',data:{round:table1.round,game_id:table1.game_id,sub_id:table1.sub_id,gt:table1.gt,tst:table1.tst,pi:hist,win:winners,wildCard:table1.wildCard}});



					var jobId = commonClass.GetRandomString(10);

					cdClass.UpdateTableData(table1._id.toString(),{$set:{jid:jobId}},function(table2){
						if(table2){


							var uScores = [];
							for(var i in table2.pi){ 
								if(!_.isEmpty(table2.pi[i]) && table2.pi[i]._ir == 0){

					                uScores.push(table2.pi[i].score);    
					            }
					        }

					        var tScore = 0;
					        if(uScores.length  > 1){
					            tScore = commonClass.getMedian(uScores);
					        }
					        else{
					            tScore = (uScores.length == 1) ? uScores[0] : 0;
					        }

					        for(var k in table2.pi){
					        	if(!_.isEmpty(table2.pi[k]) && table2.pi[k]._ir == 1){
					        		c('giveWinChips-----------------track deal winner');
					        		trackClass.TEA({table:'track_primary_data',category:'screen',label:table2.gt,option:'game_end',action:game_id,name:'game_end',detail1:table2.pi[k].uid,detail2:table2.pi[k].un,detail3:table2.pi[k].Chips,detail4:'chips',description:table2.pi[k].rType,value:tScore},{uid:table2.pi[k].uid});
					        	}
					        }

							var nxt = commonClass.AddTime(config.NXT);
							schedule.scheduleJob(table2.jid,new Date(nxt),function(){  
								schedule.cancelJob(table2.jid);
								playingTableClass.afterRoundFinish(table2._id.toString());
							});
						}
						else{
							c('giveWinChips::::::::1::::>>>>>Error: "table not found"');
						}
					});
				}
				else{
					c('giveWinChips::::::::::::::>>>>>Error: "table not found"');
				}
			});
		}
	},
	giveWinCash:function(tbId,winners,px,iter,prize,msg,bv,gt,direct){
		/* +-------------------------------------------------------------------+
            desc:function to handle classic/bet winner
            i/p: tbId = table id
            	 winners = array of winners seat indices
            	 px = player details
            	 iter = iterator for recursion
            	 prize = prize amount for winners
            	 msg = message for chips track
            	 bv = boot value
            	 gt = game type
            	 direct = true/false direct winner or not
        +-------------------------------------------------------------------+ */
		c('giveWinChips------------>>>>>>>>prize: '+prize);

		
		if(iter < px.length){

			if(_.contains(winners,px[iter].si)){  //means the winner

				cdClass.UpdateUserCash(px[iter].uid,prize,msg,function(uChips){
					
					var tempPlayerData = px[iter];
					var ctth = '';
					if(direct){
						if(px[iter].cards.length > 13){
							ctth = px[iter].cards.pop();
							tempPlayerData.cards = px[iter].cards;
						}
						tempPlayerData.dCards = {pure:[],seq:[],set:[],dwd:px[iter].cards};
					}
					tempPlayerData.wc = prize;
					tempPlayerData.cash = uChips;
					tempPlayerData._iw = 1;
					tempPlayerData.gedt = new Date();
					c('giveWinChips----------->>>>>>>>ctth: '+ctth+' direct: '+direct);
					var upData = {$set:{la:new Date(),ctrlServer:SERVER_ID,'pi.$.wc':prize,'pi.$.cash':uChips,'pi.$._iw':1,tst:'winnerDeclared',ctt:new Date(),'pi.$.gedt':new Date()}};
					if(ctth != ''){


						if(px[iter].gCards.length > 0){

							var gCards = px[iter].gCards;
							c('giveWinChips---------->>>>>>gCards: ',gCards);
							for(var x in gCards){
								if(_.contains(gCards[x],ctth)){
									gCards[x] = _.without(gCards[x],ctth);
									break;
								}
							}
							c('giveWinChips------------->>>>>gCards: ',gCards);
						}
						else{
							var gCards = px[iter].cards;
						}

						upData['$set']['pi.$.cards'] = px[iter].cards;
						upData['$set']['pi.$.gCards'] = gCards;
						upData['$push'] = {oDeck:ctth};
					}
					upData['$addToSet'] = {hist:tempPlayerData};
					c('giveWinChips----------->>>>>upData: ',upData);
					// cdClass.CountHands(table.value.pi[px[iter].si].uid,true,function(){
					cdClass.CountHands(px[iter].uid,'win',gt,bv,true,function(thp,qstWin){
						playClass.getUserScore(px[iter].uid,bv,gt,function(score){
							upData['$set']['pi.$.score'] = score;
							upData['$set']['pi.$.thp'] = thp;
							// upData['$set']['pi.$.spc'] = spc;

							/*if(px[iter].isSpc && (spc >= config.FIRST_TIME_GAME_LIMIT || uChips > config.FIRST_TIME_CHIPS_LIMIT)){
								upData.$set['pi.$.isSpc'] = false;
								upData.$set.spcSi = -1;
								upData.$set.RobotCount = 0;
								upData.$set.HumanCount = 0;
								db.collection('game_users').updateOne({_id:MongoID(px[iter].uid)},{$set:{'flags._isSpc':0}},function(errr,res){
									if(errr){
										c('giveWinChips-------------->>>>>errr: ',errr);
									}
									c('giveWinChips------------------->>>>>res: ',res);
								});
							}*/

							if(qstWin == 1){

								upData.$set._qstWin = qstWin;
							}
							db.collection('playing_table').findAndModify({_id:MongoID(tbId),'pi.si':px[iter].si},{},upData,{new:true},function(err,table){
								if(table && table.value){
									c('giveWinChips-----------------track deal winner');
									// trackClass.TEA({table:'track_primary_data',category:'economy',label:'deal_rummy',option:'winner_declaration',action:px[iter].uid,name:px[iter].un,value:prize,detail3:'chips'},{uid:px[iter].uid}); 
									
									playingTableClass.giveWinCash(table.value._id.toString(),winners,px,iter+1,prize,msg,bv,gt,direct);
								}
								else{
									c('giveWinChips-------------->>>>>>>>>Error:"table  not found"');
								}
							});
						});
					});
				});
			}
			else{
				playingTableClass.giveWinCash(tbId,winners,px,iter+1,prize,msg,bv,gt,direct);
			}
		}
		else{
			cdClass.GetTbInfo(tbId,{},function(table1){
				if(table1){

					var hist = _.clone(table1.hist);
					
					c('giveWinChips----------->>>>>>hist: ',hist);
					for(i = 0;i < hist.length;i++){   //sort(bubble sort) the player according to the dps  
						for(j = 0;j < hist.length-i-1;j++){
							if(hist[j].dps > hist[j+1].dps  || hist[j].dps == hist[j+1].dps && hist[j]._iw < hist[j+1]._iw){ //if dps are equal then put loser after winner
								temp = _.clone(hist[j]);
								hist[j] = _.clone(hist[j+1]);
								hist[j+1] = _.clone(temp);
							}
						}
					}

					var game_id = table1.game_id;
					var deal_id = table1.game_id;
					if(table1.gt == 'Deal' || table1.gt == 'Pool'){
						game_id = game_id+'.'+table1.sub_id;
					}
					var rCount = 0;
					var uCount = 0;
					var rSts = 'loss';
					var uSts = 'loss';
					for(var k in hist){

						// if(hist[k]._ir == 0){
							
							// var sts = 'loss';
							if(hist[k]._iw == 1){
								// sts = 'win';
								if(hist[k]._ir == 1){
									rSts = 'win';
								}
								else{
									uSts = 'win';
								}
							}
							// else{
							// 	sts = 'loss';
							// }
							if(hist[k]._ir == 1){
								rCount++;
							}
							else{
								uCount++;
							}
							c('giveWinChips-----------------track deal winner');
							// if(hist[k].s != 'left' && hist[k].s != 'drop' && hist[k].s != 'standup'){

								// trackClass.TEA({table:'track_primary_data',category:'game',label:table1.gt,option:'deal_end',action:deal_id,name:table1.rSeq,value:hist[k].wc,detail1:table1.ap,detail2:parseInt(k)+1,detail3:hist[k].ps,detail4:'chips',description:sts},{uid:hist[k].uid});
								// trackClass.TEA({table:'track_primary_data',category:'game',label:table1.gt,option:'deal_end',action:deal_id,name:table1.ap,value:hist[k].wc,detail1:parseInt(k)+1,detail3:hist[k].ps,detail4:'chips',description:sts},{uid:hist[k].uid});
								/*var obj = { 
									gt : table1.gt ,
									ap :table1.ap ,
									rank :parseInt(k)+1 ,
									wc : hist[k].wc,
									game_id : deal_id ,
									ps :hist[k].ps ,
									sts : sts,
									type :'deal_end' ,
									tbId : table1._id.toString(),
									cat : 'game' 
								};

								trackClass.gameEndTrack(hist[k].uid,obj);*/
							// }
						// }
					}
					if(rCount > 0 || uCount > 0){

						db.collection('win_sts').insertOne({date: new Date(),table_id:table1._id.toString(),game_type:table1.gt,game_id:game_id,rCount:rCount,uCount:uCount,rSts:rSts,uSts:uSts});
					}

					var ldData = {$set:{
						round:table1.round,
						game_id:table1.game_id,
						sub_id:table1.sub_id,
						gt:table1.gt,
						tst:table1.tst,
						pi:hist,
						wildCard:table1.wildCard,
						win:winners
					}};
										
					db.collection('last_deal').findAndModify({'tbid':table1.value._id.toString()},{},ldData,{upsert:true,new:true},function(err,table1){});

					commonClass.FireEventToTable(table1._id.toString(),{en:'WD',data:{round:table1.round,game_id:table1.game_id,sub_id:table1.sub_id,gt:table1.gt,tst:table1.tst,pi:hist,win:winners,wildCard:table1.wildCard}});



					var jobId = commonClass.GetRandomString(10);

					cdClass.UpdateTableData(table1._id.toString(),{$set:{jid:jobId}},function(table2){
						if(table2){


							var uScores = [];
							for(var i in table2.pi){ 
								if(!_.isEmpty(table2.pi[i]) && table2.pi[i]._ir == 0){

					                uScores.push(table2.pi[i].score);    
					            }
					        }

					        var tScore = 0;
					        if(uScores.length  > 1){
					            tScore = commonClass.getMedian(uScores);
					        }
					        else{
					            tScore = (uScores.length == 1) ? uScores[0] : 0;
					        }

							var nxt = commonClass.AddTime(config.NXT);
							schedule.scheduleJob(table2.jid,new Date(nxt),function(){  
								schedule.cancelJob(table2.jid);
								playingTableClass.afterRoundFinish(table2._id.toString());
							});
						}
						else{
							c('giveWinChips::::::::1::::>>>>>Error: "table not found"');
						}
					});
				}
				else{
					c('giveWinChips::::::::::::::>>>>>Error: "table not found"');
				}
			});
		}
	},
	afterRoundFinish : function(tbId){
		/* +-------------------------------------------------------------------+
            desc:function to handle table after game completes
            i/p: tbId = table id
        +-------------------------------------------------------------------+ */
		c('<<<<------------afterRoundFinish-------->>>>>tbId: ',tbId);
		

		cdClass.GetTbInfo(tbId,{pi:1,bv:1,stdP:1,gt:1,ms:1,round:1,tst:1,rSeq:1,game_id:1,pt:1,nrg:1,sub_id:1,spcSi:1,mode:1},function(table){
			if(!table){
				return false;
			}
			var players = playClass.getPlayingUserInRound(table.pi);
			c('afterRoundFinish--------------'+table._id+'------->>>>>>');
			c('afterRoundFinish-------->>>>players: ',players);
			c('afterRoundFinish-------->>>>stdP: ',table.stdP);
			var rCount = 0;
			var uCount = 0;
			// var spc = 0;
			var sii = -1;
			var uidd = '';

			for(var x in players){
				if(players[x]._ir == 0){
					uCount++;
					// spc = players[x].spc;
					sii = players[x].si;
					uidd = players[x].uid;
				}
				else{
					rCount++;
				}
			}
			c('afterRoundFinish------>>>>uCount: ',uCount,' rCount: ',rCount,' table.ms: ',table.ms);
			console.log("afterRoundFinish---------->>>>>>>table.stdP.length: "+table.stdP.length)
			if(uCount == 0 && rCount >= 0 && table.stdP.length == 0){    //means there is no live user exist on table   
				c('afterRoundFinish----------->>>>not sufficient player so table delete');
				robotsClass.removeRobots(table._id.toString());
			}
			else if(table.stdP.length > 0 && table.ms == 2){
				var single = '';
				var i = 0;
				resp(i);
				function resp(i){
					if(i < table.stdP.length){
						
						playClass.LT({/*flag:"auto"*/},{leave:1,id:single,uid:table.stdP[i].uid,_ir:0,tbid : table._id.toString()},function(check){
							i++;
							resp(i);
						});
					}
					else{
						c('afterRoundFinish----------->>>player on the standup so start game after reset table');
						cdClass.UpdateTableData(table._id.toString(),{$set:{rSeq:1,maxBet :0,bbv:table.bv,_isLeave:0,tst:'',pv:0,wildCard: '',oDeck:[],declCount:0,playCount:0,cDeck: [],turn:-1,fnsPlayer:-1,hist:[],ctt:new Date()}},function(table1){
							playingTableClass.initializeGame(table._id.toString());
						});
					}
				}
			}
			else if(players.length > 0){
				c('afterRoundFinish------else if---->>>>>players: ',players);


				// recalculate table score
				var uScores = [];
				for(var i in table.pi){ 
					if(!_.isEmpty(table.pi[i]) && table.pi[i]._ir == 0){

	                    uScores.push(table.pi[i].score);    
	                }
	            }

	            var tScore = 0;
	            if(uScores.length  > 1){
	                tScore = commonClass.getMedian(uScores);
	            }
	            else{
	                tScore = (uScores.length == 1) ? uScores[0] : 0;
	            }

	            c('\n[Table score recalculated]--------------->>>>>tScore: '+tScore);
				db.collection('robot_prob').find({from:{$lte:tScore}}).sort({from:-1}).toArray(function(err,robotType){
					c('afterRoundFinish---------robot set-------->>>>>>>: ',robotType[0]);
					var rType = "Newbie";
					if(robotType && robotType.length > 0){
						var rInt = commonClass.GetRandomInt(0,100);
						c('afterRoundFinish----------->>>>>>rInt: '+rInt);  
						var bound = robotType[0].Newbie;
						if(rInt <= bound){
							
							rType = 'Newbie';
						}
						else if(rInt <= (bound += robotType[0].Amateur)){
							
							rType = 'Amateur';
						}
						else if(rInt <= (bound += robotType[0].Pro)){
							
							rType = 'Pro';
						}
						else if(rInt <= (bound += robotType[0].God)){
							
							rType = 'God';
						}
						else{
							c('God---!!!--->>>else');
							rType = 'God';
						}
					}
					c('afterRoundFinish------------>>>>>>rType: '+rType);

					/*if(typeof table.spcSi != 'undefined' && table.spcSi != -1){
						rType = 'Newbie'; //remove all robots
					}*/

					c('\n[Bot selected]------------->>>>>Robot: '+rType);
					var players1 = playClass.getPlayingUserInGame(table.pi,true);
					var game_id = table.game_id;

					if(table.gt == 'Deal' || table.gt == 'Pool'){
						game_id = table.game_id+'.'+table.sub_id;
					}
					if(table.gt == 'Deal' && table.round >= 2 || table.gt == 'Pool' || table.gt == 'Classic' || table.gt == 'Bet'){
						c('afterRoundFinish---------else if-if gt: '+table.gt+' round: '+table.round);

						/*if((uCount == 1 && typeof spc != 'undefined' && typeof sii != 'undefined' && spc == config.FIRST_TIME_GAME_LIMIT && sii != -1) || (typeof table.nrg != 'undefined' && table.nrg == 1 && spc >= config.FIRST_TIME_GAME_LIMIT)){
							var rmrb = true;
						}*/
						c("afterRoundFinish----------------***********-----------------------rCount",rCount);
						if (table.mode == 'practice'){

							playClass.removeOnLowChips(table._id.toString(),table.bv,table.gt,players,rType,table.tst,table.rSeq,game_id,rCount,table.pt,0);
						} else {

							playClass.removeOnLowCash(table._id.toString(),table.bv,table.gt,players,rType,table.tst,table.rSeq,game_id,rCount,table.pt,0);
						}
						
					}
					else{
						c('afterRoundFinish----------else if-else: ');
						cdClass.GetTbInfo(tbId,{},function(table1){
							players = playClass.getPlayingUserInRound(table1.pi);
							// var players2 = playClass.getPlayingUserInGame(table1.pi,true);  //player remaining in current pool
							c('afterRoundFinish-- else-->>>>>>>players: ',players);
							if(players.length <= 0 && table1.stdP.length == 0){
								c('afterRoundFinish-------'+table1._id+'----->>>>>>>msg:"table deleted "');
								db.collection('instant_table_invites').remove({tbid:table1._id.toString()},function(){});
								db.collection('table_invites').remove({tbid:table1._id.toString()},function(){});
								db.collection('last_deal').remove({tbid: table1._id.toString()},function(){});
								db.collection('playing_table').remove({_id: table1._id},function(){});
								// db.collection('user_notification').remove({tbid:table1._id.toString()}); //remove all table invitation for this table
								// notiClass.deleteTableNoti(table1._id.toString());
							}
							else{
								c('afterRoundFinish-----else13131313----->>>>players: ',players);
								var pi = table1.pi;
								var ap = table1.ap;
								for(var x in pi){
									if(pi[x] && !_.isEmpty(pi[x]) && typeof pi[x].si != 'undefined'){

										if(pi[x].s == 'left'){			//remove left out player data from table
											pi[x] = {};
											ap--;
										}
										else{

											pi[x].s = (pi[x].s == 'watch')? 'watch':'';
											pi[x].tCount = 0;
											pi[x].cards = [];
											// pi[x].dn = 0;
											pi[x]._iw = 0;
											pi[x].gCards = [];
											pi[x].dCards = {};
											pi[x].wc = 0;
											pi[x].pickCount = 0;
											pi[x].pts = 0;
											pi[x].ps = 0;
											pi[x].play = (table1.round < 2 && table1.gt == 'Deal' || table1.gt == 'Pool' && table1.tst == 'roundWinnerDeclared') ? pi[x].play : 0;
											pi[x].dps = (table1.round < 2 && table1.gt == 'Deal' || table1.gt == 'Pool' && table1.tst == 'roundWinnerDeclared') ? pi[x].dps : 0;  //only for deal and pool mode
											pi[x].bet = table1.bv;
											pi[x].isCollect = (table1.round < 2 && table1.gt == 'Deal' || table1.gt == 'Pool' && table1.tst == 'roundWinnerDeclared') ? pi[x].isCollect: 0; //isboot value collected or not
											pi[x].isQst = false;
											pi[x].secTime = config.SECONDARY_TIMER;
											pi[x].sct = false;
											pi[x].tsd = new Date();
											pi[x].ted = new Date();
											pi[x].sort = true;
										}
									}
								}
								// var jobId = commonClass.GetRandomString(10);
								// var nxt = commonClass.AddTime(config.NXT);
								var round = (table1.round >= 2 && table1.gt == 'Deal' || table1.gt == 'Pool' && table1.tst == 'winnerDeclared') ? 0: table1.round; 
								// var game_id = (table1.round >= 2 && table1.gt == 'Deal' || table1.gt == 'Pool' && table1.tst == 'winnerDeclared') ? Math.floor(table1.game_id):table1.game_id;
								// var pv = (table1.round == 1 && table1.gt == 'Deal') ? table1.pv : 0;
								var pv = (round == 1 && table1.gt == 'Deal' || table1.gt == 'Pool' && round > 0) ? table1.pv : 0;

								var hist = [];
								if((table1.gt == 'Deal' || table1.gt == 'Pool') && round > 0){ //if new game then only, save the data of history for left players

									hist  = table1.hist.filter(function(htData){
										if(htData.s == 'left'){
											return htData;
										}
									});
								}

								//var thp = (typeof table1.spcSi != 'undefined' && table1.spcSi != null && table1.spcSi != -1 && pi[table1.spcSi] && !_.isEmpty(pi[table1.spcSi]) && typeof pi[table1.spcSi].thp != 'undefined' && pi[table1.spcSi].thp != null) ? pi[table1.spcSi].thp : -1;
								// var spc = (typeof table1.spcSi != 'undefined' && table1.spcSi != null && table1.spcSi != -1 && pi[table1.spcSi] && !_.isEmpty(pi[table1.spcSi]) && typeof pi[table1.spcSi].spc != 'undefined' && pi[table1.spcSi].spc != null) ? pi[table1.spcSi].spc : -1;
								// if(spc == config.FIRST_TIME_GAME_LIMIT){
								// 	cdClass.updateWintrigger(pi[table1.spcSi].uid.toString(),1);
								// }
								var RobotCount = table1.RobotCount;
								var HumanCount = table1.HumanCount;
								var minS = table1.minS;
								if(table1.gt == 'Deal'){
									minS = 2
								}
								else if(table1.gt == 'Pool'){
									minS = 3;
								}
								else if(table1.gt == 'Bet'){
									minS = config.MIN_SEAT_TO_FILL_BET;
								}
								else{
									minS = config.MIN_SEAT_TO_FILL;
								}

								// var nrg = 0;
								// if(table1.spcSi == -1){
								// 	nrg = 0;
								// }
								// else{
								// 	nrg = table1.nrg;
								// }
								// db.collection('first_time_journey').findOne({gameNo:spc+1},function(errr,ftjData){
									/*if(ftjData){
										RobotCount = 0;
										HumanCount = 0;
										HumanCount = (ftjData.Human)?ftjData.Human:0;

										RobotCount += (ftjData.Newbie)?ftjData.Newbie:0;
										RobotCount += (ftjData.Amateur)?ftjData.Amateur:0;
										RobotCount += (ftjData.Pro)?ftjData.Pro:0;
										RobotCount += (ftjData.God)?ftjData.God:0;
										minS = RobotCount+1;
									}*/
									// else{
										// if(spc != -1){
											var players = playClass.getPlayingUserInRound(table1.pi);
											var rCount = 0;
											for(var x in players){
												if(players[x]._ir == 1){
													rCount++;
												}
											}

											minS = rCount+1;
										// }
									// }

									cdClass.UpdateTableData(table1._id.toString(),{$set:{rSeq:1,/*minS:minS,*//*nrg:nrg,*/maxBet :0,bbv:table1.bv,_isWinner:0,_isLeave:0,tst:'',round:round/*,jid:jobId*/,ap:ap,pi:pi,pv:pv,wildCard: '',oDeck:[],declCount:0,playCount:0/*,dNum:0*/,cDeck: [],turn:-1,fnsPlayer:-1,ctt:new Date(),hist:hist,HumanCount:HumanCount,RobotCount:RobotCount}},function(table2){
										
										
										playingTableClass.initializeGame(table1._id.toString());
									});
								// });
							}
						});
					}
				});
			}
			else if(table.stdP.length > 0 && players.length == 0){
				
				c('afterRoundFinish----------->>>player on the standup so start game after reset table');
				cdClass.UpdateTableData(table._id.toString(),{$set:{rSeq:1,maxBet :0,bbv:table.bv,_isLeave:0,tst:'',pv:0,wildCard: '',oDeck:[],declCount:0,playCount:0,cDeck: [],turn:-1,fnsPlayer:-1,hist:[],ctt:new Date()}},function(table1){
					playingTableClass.initializeGame(table._id.toString());
				});
			}
			else{
				c('afterRoundFinish:::::::::::::::::>>>>Error: "Table is empty!!!"');
			}
		});
	},
	managePlayerOnLeave : function(tbId,si,left,leaveReason){  //left is true if user actually leave the table
		/* +-------------------------------------------------------------------+
            desc:function to handle table when player leave the playing table
            i/p: tbId = table id
            	 si = seat index of leaving user
            	 left = is user left table or not
            	 leaveReason = reason to leave

        +-------------------------------------------------------------------+ */
		c('managePlayerOnLeave------>>> tbId: '+tbId+' si: '+si);
		cdClass.GetTbInfo(tbId,{},function(table){
			if(table){
				c('managePlayerOnLeave--------------->>>>>table.tst: '+table.tst+' table.pi: ',table.pi,' table.round: '+table.round+' table.gt: '+table.gt);
				
				if((table.gt == 'Deal' || table.gt == 'Pool') && (table.tst == 'RoundTimerStarted' || table.tst == 'roundWinnerDeclared')){

					var players = playClass.getPlayingUserInGame(table.pi,true);
				}
				else{

					var players = playClass.getPlayingUserInRound(table.pi,true);
				}
				
				// c('managePlayerOnLeave------->>>>players: ',players,' table.tst: ',table.tst);
				if(players.length == 1 && (table.tst == "StartDealingCard" || table.tst == "CardsDealt" || table.tst == "RoundStarted" || (table.tst == 'RoundTimerStarted' && table.gt =='Deal' && table.round == 1 || table.tst == 'roundWinnerDeclared' && table.gt =='Deal') || (table.tst == 'RoundTimerStarted' && table.gt =='Pool' && table.round > 0))){  //if player leave inbetween game and only one player remains
					// var dCards = {pure:[],seq:[],set:[],dwd:table.pi[players[0].si].cards}
					// c('managePlayerOnLeave----------->>>>dCards: ',dCards);
					// db.collection('playing_table').findAndModify({_id:MongoID(tbId),'pi.si':players[0].si},{},{$set:{'pi.$.dCards':dCards}},{new:true},function(err,table1){
						// c('managePlayerOnLeave-------->>>>>>>table1: ',table1);
						// playingTableClass.handleWinner(table1.value._id.toString(),players[0].si,table1.value.pv);
					c('managePlayerOnLeave-------->>>>>>>table: ',table);

					if(table.gt == 'Deal'){
						//deal rummy leave logic here
						var players1 = playClass.getPlayingUserInGame(table.pi,true);
						c('managePlayerOnLeave----deal----->>>>>>players: ',players);
						c('managePlayerOnLeave-----deal---->>>>>>players1: ',players1);

						if(players1.length == 1){  //means there is only one player left on table which was in deal so direct winner
							c('managePlayerOnLeave---play 1------deal--->>>>>')
							cdClass.UpdateTableData(table._id.toString(),{$set:{round:2}},function(table1){

								playingTableClass.handleDealWinner(table._id.toString(),[players[0].si],table.pv,true);
							});
						}
						else{
							c('managePlayerOnLeave------play > 1------->>>>');
							//if the deal players are more than 1 and then check if the round is 1 then declare round winner or else decalre final winner
							if(table.round == 1){  
								c('managePlayerOnLeave-----------play > 1 ----round 1------>>>>>');

								cdClass.UpdateTableData(table._id.toString(),{$set:{fnsPlayer:players[0].si}},function(table1){

									playingTableClass.declareRoundWinner(table._id.toString(),true);
								});
								// playingTableClass.handleRoundWinner(table._id.toString(),players[0].si,true)
							}
							else{
								c('managePlayerOnLeave-----------play > 1 -----round 2----------->>>>>');
								cdClass.UpdateTableData(table._id.toString(),{$set:{round:2}},function(table1){
									playingTableClass.declareDealWinner(table._id.toString(),true);
								});
							}
						}

					}
					else if(table.gt == 'Pool'){
						var players1 = playClass.getPlayingUserInGame(table.pi,true);
						c('managePlayerOnLeave----pool----->>>>>>players: ',players);
						c('managePlayerOnLeave-----pool---->>>>>>players1: ',players1);
						if(players1.length == 1){ //means there is only one player left on which was in pool so direct winner
							c('managePlayerOnLeave--------play 1----pool------>>>>>');
							//logic to handle direct pool winner 
							playingTableClass.handlePoolWinner(table._id.toString(),players1[0].si,true);
						}
						else{
							c('managePlayerOnLeave------play > 1------->>>>');

							//direct winner logic here
							cdClass.UpdateTableData(table._id.toString(),{$set:{fnsPlayer:players[0].si}},function(table1){
								playingTableClass.declareRoundWinner(table._id.toString(),true);
							});
						}
					}
					else{

						if(table.mode == 'practice'){
							
							playingTableClass.handleWinner(table._id.toString(),players[0].si/*,table.pv*/,true);
						} else {
							
							playingTableClass.handleWinnerCash(table._id.toString(),players[0].si/*,table.pv*/,true);
						}
					}

					// });
				}
				else{
					players = playClass.getPlayingUserInRound(table.pi);
					var rCount = 0;
					var uCount = 0;

					for(x in players){
						if(players[x]._ir == 0){
							uCount++;
						}
						else{
							rCount++;
						}
					}
					c('managePlayerOnLeave------else-->>>uCount: ',uCount,' rCount: ',rCount,' turn: ',table.turn,' ap: ',table.ap);
					if(uCount == 0 && rCount >= 0 && left && table.stdP.length == 0){   //if player leaves and only robot remains then delete the table   
						robotsClass.removeRobots(table._id.toString());
					}
					else{  
						var minS = (table.minS)?table.minS:config.MIN_SEAT_TO_FILL;
						var minSb = (table.minS)?table.minS:config.MIN_SEAT_TO_FILL_BET;
						var MIN_SEAT_TO_FILL = (table._ip == 1)?2:minS;
						var MIN_SEAT_TO_FILL_BET = (table._ip == 1)?2:minSb;
						var MIN_SEAT_TO_FILL_DEAL = 2;
						var MIN_SEAT_TO_FILL_POOL = 3;
						/*if(table._ip != 1 && typeof table.spcSi  != 'undefined' && table.spcSi != -1){  //means setup for special user
							var RobotCount = table.RobotCount?table.RobotCount:0;
							var HumanCount = table.HumanCount?table.HumanCount:0;
							RobotCount += HumanCount;

							
							if(MIN_SEAT_TO_FILL < RobotCount+1 && RobotCount+1 <= table.ms){
								MIN_SEAT_TO_FILL = RobotCount+1;
							}
							else if(MIN_SEAT_TO_FILL < RobotCount+1 && RobotCount+1 > table.ms){
								MIN_SEAT_TO_FILL = table.ms;
							}

							if(MIN_SEAT_TO_FILL_BET < RobotCount+1 && RobotCount+1 <= table.ms){
								MIN_SEAT_TO_FILL_BET = RobotCount+1;
							}
							else if(MIN_SEAT_TO_FILL_BET < RobotCount+1 && RobotCount+1 > table.ms){
								MIN_SEAT_TO_FILL_BET = table.ms;
							}

							if(MIN_SEAT_TO_FILL_DEAL < RobotCount+1 && RobotCount+1 <= table.ms){
								MIN_SEAT_TO_FILL_DEAL = RobotCount+1;
							}
							else if(MIN_SEAT_TO_FILL_DEAL < RobotCount+1 && RobotCount+1 > table.ms){
								MIN_SEAT_TO_FILL_DEAL = table.ms;
							}

							if(MIN_SEAT_TO_FILL_POOL < RobotCount+1 && RobotCount+1 <= table.ms){
								MIN_SEAT_TO_FILL_POOL = RobotCount+1;
							}
							else if(MIN_SEAT_TO_FILL_POOL < RobotCount+1 && RobotCount+1 > table.ms){
								MIN_SEAT_TO_FILL_POOL = table.ms;
							}
						}*/

						if(table.tst == "RoundTimerStarted" && table.ap < table.ms && (table.ap < MIN_SEAT_TO_FILL && table.gt == 'Classic' || table.ap < MIN_SEAT_TO_FILL_BET && table.gt == 'Bet')){ //special condition if user standup or leave table after round timer started
							c('managePlayerOnLeave-------RoundTimerStarted------>>>>>>>insufficient players');
							jtClass.cancelJobOnServers(table._id.toString(),table.jid);
							cdClass.UpdateTableData(table._id.toString(),{$set:{rSeq:1,maxBet :0,bbv:table.bv,_isLeave:0,tst:'',pv:0,wildCard: '',oDeck:[],declCount:0,playCount:0,cDeck: [],turn:-1,fnsPlayer:-1,hist:[],ctt:new Date()}},function(table1){
								playingTableClass.initializeGame(table._id.toString());
							});
						}
						else if(table.tst == "RoundTimerStarted" && table.ap < table.ms && table.ap < MIN_SEAT_TO_FILL_DEAL && table.gt == 'Deal'){ //special condition if user standup or leave table after round timer started
							c('managePlayerOnLeave-------RoundTimerStarted------>>>>>>>insufficient players');
							jtClass.cancelJobOnServers(table._id.toString(),table.jid);
							cdClass.UpdateTableData(table._id.toString(),{$set:{rSeq:1,_isLeave:0,tst:'',pv:0,wildCard: '',oDeck:[],declCount:0,playCount:0,cDeck: [],turn:-1,fnsPlayer:-1,hist:[],ctt:new Date()}},function(table1){
								playingTableClass.initializeGame(table._id.toString());
							});
						}
						else if(table.tst == "RoundTimerStarted" && table.ap < table.ms && table.ap < MIN_SEAT_TO_FILL_POOL && table.gt == 'Pool'){ //special condition if user standup or leave table after round timer started
							c('managePlayerOnLeave-------RoundTimerStarted------>>>>>>>insufficient players');
							jtClass.cancelJobOnServers(table._id.toString(),table.jid);
							cdClass.UpdateTableData(table._id.toString(),{$set:{rSeq:1,_isLeave:0,tst:'',pv:0,wildCard: '',oDeck:[],declCount:0,playCount:0,cDeck: [],turn:-1,fnsPlayer:-1,hist:[],ctt:new Date()}},function(table1){
								playingTableClass.initializeGame(table._id.toString());
							});
						}
						else if(table.tst == "winnerDeclared" && table.ap == 0 && table.stdP.length > 0){ //special condition if  all user standup or leave table on winnerDeclared timer started
							c('managePlayerOnLeave-----winnerDeclared-------->>>>>>>insufficient players');
							// jtClass.cancelJobOnServers(table._id.toString(),table.jid);
							// cdClass.UpdateTableData(table._id.toString(),{$set:{rSeq:1,maxBet :0,bbv:table.bv,_isLeave:0,/*tst:'',*/pv:0,wildCard: '',oDeck:[],declCount:0,playCount:0,cDeck: [],turn:-1/*,fnsPlayer:-1,hist:[]*/,ctt:new Date()}},function(table1){
							// 	playingTableClass.initializeGame(table._id.toString());
							// });
						}
						else if(table.tst == "RoundStarted" && players.length == 0){ //special condition to handle all standup and rounstarted table status of table
							c('managePlayerOnLeave----->>>>RoundStarted--------->>>>>ap: '+table.ap);
							// jtClass.cancelJobOnServers(table._id.toString(),table.jid);
							// cdClass.UpdateTableData(table._id.toString(),{$set:{rSeq:1,maxBet :0,bbv:table.bv,_isLeave:0,/*tst:'',*/pv:0,wildCard: '',oDeck:[],declCount:0,playCount:0,cDeck: [],turn:-1,/*fnsPlayer:-1,hist:[],*/ctt:new Date()}},function(table1){
							// 	playingTableClass.initializeGame(table._id.toString());
							// });
						}
						else if((/*table.tst == "StartDealingCard" || */table.tst == "RoundStarted") && table.turn == si){  //means turn user leaves table
							c('managePlayerOnLeave---------------->>>>>>RoundStarted');
							
							if(table.gt == 'Bet'){

								var players1 = playClass.getPlayingUserInRound(table.pi,true);
								var chipsArray = [];
								for(var i in players1){
									chipsArray.push(players1[i].Chips);
								}
								c('managePlayerOnLeave------------>>>>chipsArray: ',chipsArray);
								var minChips = _.min(chipsArray);
								c('managePlayerOnLeave------------>>>>minChips: '+minChips);
								var maxBet = Math.round(minChips/160);
								c('managePlayerOnLeave-----1--------->>>>>maxBet: '+maxBet+' table.bbv: '+table.bbv);
								// if(config.BET_RAISE_SCALE > 0){ //to round the max bet value
								// 	maxBet = maxBet-maxBet%config.BET_RAISE_SCALE;
								// 	maxBet = (maxBet <= table.bbv) ? table.bbv : maxBet;
								// }
								maxBet = maxBet-maxBet%50;  //rounding maxbet
								maxBet = (maxBet <= table.bbv) ? table.bbv : maxBet;
								c('managePlayerOnLeave-----2--------->>>>>maxBet: '+maxBet);
								cdClass.UpdateTableData(table._id.toString(),{$set:{maxBet:maxBet}},function(table1){
									if(table1){

										jtClass.cancelJobOnServers(table1._id.toString(),table1.jid);


										playingTableClass.changeTableTurn(table1._id.toString(),leaveReason);
									}
									else{

										c('managePlayerOnLeave------------->>>>>Error:"table not found"');
									}
								});
							}
							else{

								jtClass.cancelJobOnServers(table._id.toString(),table.jid);
								playingTableClass.changeTableTurn(table._id.toString(),leaveReason);
							}
						}
						else if((/*table.tst == "StartDealingCard" || */table.tst == "RoundStarted") && table.ap > 0 && (typeof table.turn =='undefined' || table.turn == null)){ //special condition to handle simultaneous leave,switch, standup
							c('managePlayerOnLeave------1------>>>>>>table.turn: ',table.turn);
							var pi = playClass.getPlayingUserInRound(table.pi,true);

							var upData = {$set:{rSeq:1,maxBet :0,bbv:table.bv,_isLeave:0,declCount:0,playCount:0,tst:'',pv:0,hist:[],cDeck:[],oDeck:[],fnsPlayer:-1,wildCard:'',turn:-1,dealer:-1,ctt:new Date()}};
							if(table.gt == 'Deal' || table.gt == 'Pool'){
								upData['$set'].round = 0;
							}
							
							if(pi.length == 0){
								cdClass.UpdateTableData(table._id.toString(),upData,function(table1){
									if(table1){

										playingTableClass.initializeGame(table1._id.toString());
									}
									else{
										c('managePlayerOnLeave---------->>>>>>Error:"table not found"');
									}
								});
							}
						}
						else if((/*table.tst == "StartDealingCard" || */table.tst == "RoundStarted") && table.ap == 0 && table.stdP.length > 0){ //means there is no user on table but someone is standup
							c('managePlayerOnLeave-------2--------->>>>table.ap: ',table.ap);
							// jtClass.cancelJobOnServers(table._id.toString(),table.jid);
							// var upData = {$set:{rSeq:1,maxBet :0,bbv:table.bv,_isLeave:0,declCount:0,playCount:0,pv:0,tst:'',hist:[],cDeck:[],oDeck:[],tScore:0,fnsPlayer:-1,wildCard:'',turn:-1,dealer:-1,ctt:new Date()}};
							// if(table.gt == 'Deal' || table.gt == 'Pool'){
							// 	upData['$set'].round = 0;
							// }
							// cdClass.UpdateTableData(table._id.toString(),upData,function(table1){
							// 	if(table1){

							// 		playingTableClass.initializeGame(table1._id.toString());
							// 	}
							// 	else{
							// 		c('managePlayerOnLeave------------->>>>>Error:"table not found"');
							// 	}
							// });
						}
						else if(table.tst == "RoundStarted" && table.turn != si && table.gt == 'Bet'){ //
							c('managePlayerOnLeave----------->>>>>>turn != si && bet');
							var players1 = playClass.getPlayingUserInRound(table.pi,true);
							var chipsArray = [];
							for(var i in players1){
								chipsArray.push(players1[i].Chips);
							}
							c('managePlayerOnLeave------------>>>>chipsArray: ',chipsArray);
							var minChips = _.min(chipsArray);
							c('managePlayerOnLeave------------>>>>minChips: '+minChips);
							var maxBet = Math.round(minChips/160);
							c('managePlayerOnLeave-----1--------->>>>>maxBet: '+maxBet+' table.bbv: '+table.bbv);
							
							maxBet = maxBet-maxBet%50;  //rounding maxbet
							maxBet = (maxBet <= table.bbv) ? table.bbv : maxBet;
							c('managePlayerOnLeave-----2--------->>>>>maxBet: '+maxBet);
							cdClass.UpdateTableData(table._id.toString(),{$set:{maxBet:maxBet}},function(table1){});
						}
					}   
				}
			}

		});
	}
}