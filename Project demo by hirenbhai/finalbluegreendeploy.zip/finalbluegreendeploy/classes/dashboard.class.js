var requestURL = require('request');
module.exports = {
	AUCI : function(data, client){ //Add User Connection Id
		/* +-------------------------------------------------------------------+
            desc:this function is used to assign user variable to socket object
            i/p: data = user details
        +-------------------------------------------------------------------+ */
		if( !data || !client.sck){
            c('AUCI:::::::::::>>>>Error: "data not found!!!"');
			return false;
		}
		
		client.uid = data._id.toString();
		client.det = data.det;
			
		//c(data.uid);
       

		//update socket of the user

        var lc = data.lc;
        
        //if the user comes after one days then reset the counter 
        db.collection('game_users').findAndModify({_id:data._id},{},{$set:{lc:lc,sck:client.sck,'flags._io':1,'flags._ftp':0}},{new:true},function(err,resp){
            var res = resp.value;
            //c(data.uid);
            c('AUCI---------->>>>>data.sck: ',data.sck,' client.sck: ',client.sck);
            if( data.sck && data.sck != '' && data.sck != client.sck){
                commonClass.SendDirect(data.sck, { en : 'NCC', data : {sck:data.sck}});
            }
    		
    		var pUser = { uid: client.uid, un : res.un, lc : res.lc, _isup : res.flags._isup, _ir : res.flags._ir, pp : res.pp, 
    					 fid : res.fid, sck : client.sck };
    					
    		client.un = res.un;
    		client.lc = res.lc;
    		client._isup = res.flags._isup;
    		client._ir = res.flags._ir;
    		client.pp = res.pp;
    		client.ult = res.ult;

    		if(res.prms){
    			client.pubact = commonClass.InArray('publish_actions', res.prms);
    		}
    		else{
    			client.pubact = true;
    		}
    			
    		if(res.det == 'ios' && res.iv){
    			// client.v = parseFloat(res.iv);
                client.v = res.iv;
                client.vc = res.ivc;
    		}
    		else if(res.det == 'android' && res.av){
                // client.v = parseFloat(res.av);
    			client.v = res.av;
                client.vc = res.avc;
    		}
    		else{
    			client.v = 2;	
    		}
    		
            
            res.flags._ftp = data.flags._ftp;

            var dtdiff1 = commonClass.GetTimeDifference(new Date(), new Date(config.MMSD));
            var dtdiff2 = commonClass.GetTimeDifference(new Date(), new Date(config.MMED));
            
            dtdiff1=dtdiff1<0?0:dtdiff1;
            dtdiff2=dtdiff2<0?0:dtdiff2;
            dtdiff2 = dtdiff2-dtdiff1;
            if(commonClass.InMaintenanceMode()){
                
                config.MM=true;
            }
            else{
                config.MM=false;
            }
           

            if(config.MM == true && config.MMSFLAG == true && dtdiff2 > 0){
                              
                res.StartAfter = 0;
                res.RemoveAfter = dtdiff2;   
            }
            else{
               
                res.StartAfter = dtdiff1;
                res.RemoveAfter = dtdiff2;
            }
            res.MM = config.MM;
            res.MMSFLAG = config.MMSFLAG;

            res.CLASSIC_BTN = CLASSIC_BTN;
            res.DEAL_BTN = DEAL_BTN;
            res.POOL_BTN = POOL_BTN;
            res.BET_BTN = BET_BTN;
            
            trackClass.dauMau(pUser.uid, res.det);
            var remtime = commonClass.GetTimeDifference(new Date(),new Date(res.lasts.ldbt));
            // var dayDiff = commonClass.GetTimeDifference(new Date(res.lasts.ldbt),new Date(),'day');
            if(remtime <= 0) {    
                res.freeBonus = true;
            }
            else{
                res.freeBonus = true;
            }
            c('AUCI------------>>>>data.rejoin: '+data.rejoin+' data.tbid: '+data.tbid);
            res.inviteTbid = '';

            rClient.get("onlinePlayers", function (err, counter) {
                c("onlinePlayers------------------cPlayers:",counter);
                
                res.op = counter;
                c("AUCI------------------freeBonus:",res.freeBonus);
                bonusClass.CFSB({},client)
                // leaderBoardClass.LB({Filter:'global'},client);

                dashboardClass.filterData(res,client);
            });
        });
	},
    LOGOUT:function(data,client){
        /* +-------------------------------------------------------------------+
            desc:this function is used to handle user that has disconnect 
            i/p: data = {}
        +-------------------------------------------------------------------+ */
        if(!client.sck){
            c('LOGOUT::::::::::::::>>>>>>>>Error: "socket not found!!!"');
            return false;
        }
        if(client._ir == 0){
            cdClass.GetUserInfo(client.uid,{sck:1,tbid:1,rejoinID:1,rejoin:1,cbTbid:1},function(userData){
                c('LOGOUT----->>>>>userData: ',userData,' client.sck: ',client.sck);
                if(userData && userData.sck == client.sck){
                    cdClass.UpdateUserData(client.uid,{$set:{'flags._io':0,sck:'','lasts.llgt':new Date()}},function(userInfo){
                        c('LOGOUT--------------------->>>>>userInfo: ',userInfo);
                        if(userInfo.tbid && userInfo.tbid != ''){
                            var rejoinPID = "REJOINP" + commonClass.GetRandomInt(1, 99999);
                            var si = client.si;
                            var id = client.id;

                            if(userInfo.rejoin == 0){

                                cdClass.UpdateUserData(userInfo._id.toString(),{$set:{rejoinID:rejoinPID,rejoin:1/*,sck:'','flags._io':0*/}},function(upData){
                                    var playRejoinTime = commonClass.AddTime(config.REJOIN_PLAY_TIME);
                                    schedule.scheduleJob(rejoinPID,new Date(playRejoinTime),function(){
                                        schedule.cancelJob(rejoinPID);
                                        //standup logic here
                                        cdClass.GetUserInfo(userInfo._id.toString(),{},function(userInfo1){
                                            c('LOGOUT------------->>>>>userInfo1: ',userInfo1);
                                            if(userInfo1 && userInfo1.rejoin != 0){

                                                c('LOGOUT------ '+userInfo1.un+' ------->>>>>Msg: "user 1 min time out hence standup"');
                                                


                                                cdClass.GetTbInfo(userInfo1.tbid,{gt:1,_ip:1},function(table){

                                                    if(table){

                                                        if(table.gt == 'Deal'){
                                                            
                                                            c('LOGOUT--------->>>>userInfo1.flags._ir: ',userInfo1.flags._ir,' si: ',si,' userInfo1.tbid: ',userInfo1.tbid);
                                                            playClass.LT({flag:"disc"},{id:id,uid:userInfo1._id.toString(),_ir:userInfo1.flags._ir,si : si,tbid : userInfo1.tbid});
                                                           
                                                        }
                                                        else if(table.gt == 'Pool'){
                                                            c('LOGOUT--------------->>>>>userInfo1.flags._ir: '+userInfo1.flags._ir+' si: '+si+' userInfo1.tbid: '+userInfo1.tbid);
                                                            if(table._ip == 1){
                                                                playClass.LT({flag:"disc"},{id:id,uid:userInfo1._id.toString(),_ir:userInfo1.flags._ir,si : si,tbid : userInfo1.tbid});
                                                            }
                                                            else{

                                                                playClass.DRC({},{tbid:table._id.toString(),si:si});
                                                            }
                                                        }
                                                        else{

                                                            /*playClass.STNDUP({flag:'auto'},{id:id,uid:userInfo1._id.toString(),tbid:userInfo1.tbid,si:si,_ir:userInfo1.flags._ir},function(check){
                                                                if(check){*/

                                                                    // var rejoinTID = "REJOINT" + commonClass.GetRandomInt(1, 99999);
                                                                    // cdClass.UpdateUserData(userInfo1._id.toString(),{$set:{rejoinID:rejoinTID,rejoin:2}},function(upData1){
                                                                        /*var tableRejoinTime = commonClass.AddTime(config.REJOIN_TABLE_TIME);
                                                                        schedule.scheduleJob(rejoinTID,new Date(tableRejoinTime),function(){
                                                                            schedule.cancelJob(rejoinTID);
                                                                            //table leave logic here
                                                                            cdClass.GetUserInfo(userInfo1._id.toString(),{},function(userInfo2){
                                                                                c('LOGOUT----------->>>>userInfo2: ',userInfo2);
                                                                                if(userInfo2 && userInfo2.rejoin != 0){*/

                                                                                    // c('LOGOUT-------- '+upData1.un+' ------->>>>>Msg: "user 4 min time out hence removed from table"')
                                                                                    cdClass.UpdateUserData(userInfo1._id.toString(),{$set:{rejoinID:'',rejoin:0}},function(upData2){
                                                                                        c('LOGOUT--------->>>>upData2.flags._ir: ',upData2.flags._ir,' si: ',si,' upData2: ',upData2.tbid);
                                                                                        playClass.LT({flag:"disc"},{id:id,uid:upData2._id.toString(),_ir:upData2.flags._ir,si : si,tbid : upData2.tbid});
                                                                                    });
                                                                                /*}
                                                                                else{
                                                                                    c('LOGOUT------->>>>leave table fail');
                                                                                }
                                                                            });
                                                                        });*/
                                                                    // });
                                                                /*}
                                                                else{
                                                                    console.log('LOGOUT::::::::::::::::::Error: "standup not possible" '+new Date());
                                                                }
                                                            });*/
                                                        }
                                                    }
                                                    else{
                                                        c('LOGOUT---------->>>>msg:"table not found"');
                                                    }
                                                });
                                            }
                                            else{
                                                c('LOGOUT----->>>standup fail');
                                            }
                                        });
                                    });
                                });
                            }
                            else{
                                c('LOGOUT---------------------------->>>>>"post logout process cancelled"');
                            }
                        }
                    });
                }
                else{
                    c('LOGOUT::::::::::::::::>>>>>Error:"user not found or already rejoin!!!"');
                }
            });
        }
    },
    RJT:function(data,client){  //Rejoin table; data = {}
        /* +-------------------------------------------------------------------+
            desc:this event is used to handle rejoin state
            i/p: data = {}
        +-------------------------------------------------------------------+ */
        c('RJT----------->>>>>>client.uid:  ',client.uid);
        if(!client.uid || client.uid.length < 24){
            return false;
        }
        cdClass.GetUserInfo(client.uid,{},function(userInfo){
            c('RJT---------->>>>>userInfo: ',userInfo);
            if(!userInfo){
                c('RJT------------>>>>>"user not found"');
                return false;
            }
            if(userInfo.rejoinID && userInfo.rejoinID != ''){
                jtClass.cancelRejoinJobs(userInfo.rejoinID);
                c('RJT------------->>>>>Msg: "rejoin timer canceled"');
            }

            if(userInfo.tbid && userInfo.tbid != '' && userInfo.tbid.length == 24){
                cdClass.GetTbInfo(userInfo.tbid,{},function(table){
                    if(table){ // table found
                        db.collection('playing_table').findOne({_id:table._id,'pi.uid':client.uid},{fields:{"pi.$":1}},function(err,pTable){
                            var tbId = table._id.toString();
                            var uId = userInfo._id.toString();
                            

                            var rCount = 0;

                            for(k in table.pi){
                                if(!_.isEmpty(table.pi[k]) && typeof table.pi[k]._ir != 'undefined' && table.pi[k]._ir == 1){
                                    rCount++;
                                }
                            }

                            var game_id = table.game_id;
                            var sub_id = table.sub_id;

                            if(_.contains(['','RoundTimerStarted','CollectingBootValue','StartDealingCard'],table.tst)){
                                game_id = game_id+1;
                                sub_id = sub_id+1;
                            }
                            
                            if(table.gt == 'Deal' || table.gt == 'Pool'){ 


                                if(table.round == 0){
                                    game_id = game_id+'.1';
                                    
                                }
                                else{
                                    game_id = game_id+'.'+sub_id;

                                }
                                
                            }

                            if(pTable){  //means the player is playing in table
                                c('RJT----------if---------->>>>>Msg: "join to seat"')
                                var Seat = pTable.pi[0].si;
                                cdClass.UpdateUserData(uId,{$set:{rejoin:0,rejoinID:''}},function(upData){
                                    var single = upData.sck.replace(SERVER_ID + ".", "");
                                    c('RJT--------->>>>>>>single: ',single);
                                    if (io.sockets.connected[single]){
                                        c('RJT--------->>>>>if io  tbId: ',tbId);
                                        io.sockets.connected[single].join(tbId);
                                    }
                                    client.tbid = tbId;
                                    client.si = Seat;
                                    client.gt = table.gt;
                                    playingTableClass.GTI({"tbid": tbId,_isHelp:0,"rejoin":1}, client);
                                });
                            }
                            else{  //player is standup
                                c('RJT----else--->>>>Msg: "user is join in standup mode"');
                                cdClass.UpdateUserData(uId,{$set:{rejoin:0,rejoinID:''}},function(upData){
                                    var single = upData.sck.replace(SERVER_ID + ".", "");
                                    if (io.sockets.connected[single]){
                                        c('joinSeat-----before----->>>>connected sockets: ',io.sockets.adapter.rooms[tbId]);
                                        c('RJT-----------else------------>>>>tbId: ',tbId);
                                        io.sockets.connected[single].join(tbId);
                                        c('joinSeat-----before----->>>>connected sockets: ',io.sockets.adapter.rooms[tbId]);

                                    }
                                    client.tbid = tbId;
                                    client.gt = table.gt;
                                    playingTableClass.GTI({"tbid": tbId,_isHelp:0,"rejoin":1}, client);
                                });   
                            }
                        });
                    }
                    else{   // if table not found
                        cdClass.UpdateUserData(client.uid, {$set: {tbid:'',rejoin:0,rejoinID:''}}, function () {
                            c('RJT------------->>>>>>Msg:"table not found"');
                            commonClass.SendData(client, 'PUP', {flag:'tnf',uid:client.uid}, 'error:1023');  //table not found
                        });
                    }
                });
            }
            else{

                c('RJT-------3333----->>>>"no table found"');
            }
        });
    },
	LogoutProcess: function (client) {
		c('LOGOUTPROCESS-------->>>>');
        cdClass.GetUserInfo(client.uid, {
            sck: 1,
            tbid: 1,
            un: 1
        }, function (uInfo) {
            if (client.uid && uInfo.sck != "" && (!uInfo.sck || uInfo.sck == client.sck )) {
                c('LOGOUTPROCESS-----if1----->>>>>');
                db.collection('game_users').update({
                    _id: MongoID(client.uid),
                    sck: client.sck
                }, {
                    $set: {
                        "flags._io": 0,
                        sck: "",
                        tbid: "",
                        rejoinID: ""
                    }
                }, function () {});
            }
           	if(uInfo.sck && uInfo.sck != "" && (uInfo.sck == client.sck || !uInfo.sck)) {
                c('LOGOUTPROCESS-----if2------>>>>>');
                
                if (client.tbid && uInfo.tbid != '') {
                    c('LOGOUTPROCESS-----if2-----if--->>>>');
                    playClass.LT({si:client.si}, client); 
                }
               
            }
        });
    },
    filterData:function(userData,client){
        // c('filterData--------------->>>>>>>userData: ',userData,' client.uid: '+client.uid);

        if(userData){
            
            delete userData.lasts;
            delete userData.osType;
            delete userData.osVer;
            delete userData.devBrnd;
            delete userData.devMdl;
            delete userData.sck;
            delete userData.rand;
            delete userData.ds;
            delete userData.counters.hw;
            delete userData.counters.hl;
            delete userData.counters.hd;
            delete userData.counters.cw;
            delete userData.counters.cl;
            delete userData.counters.cdr;
            delete userData.counters.hcl;
            delete userData.counters.tap;
            delete userData.counters.tpp;    
            delete userData.counters.opc;
            delete userData.sn;
            // delete userData.sessId;
            c('filterData----------------->>>>>: userData: ',userData);
            commonClass.SendData(client,'SP',userData);
        }
        else{
            c('filterData----------------->>>>>>"data not found"');
        }
    }
}