module.exports = {
	onTurnExpire: function(table){  //performs the after task when the player's timeout
		/* +-------------------------------------------------------------------+
            desc:function to handle process after player's turn time expires
            i/p: table =  {_id = table id, turn = seat index of turn user}
        +-------------------------------------------------------------------+ */
        if(!table || !table._id){
        	console.log('onTurnExpire:::::::::::::::::::>>>>>Error: "table not found"'+new Date());
        	return false;
        }


        cdClass.GetTbInfo(table._id.toString(),{},function(tbInfo){
        	if(tbInfo){
        		c('onTurnExpire---------------->>>>>>table.turn: '+table.turn+' tbInfo.turn: '+tbInfo.turn);
        		if(tbInfo.turn == table.turn){ //means only turn user turn get expired
        			// var time = config.SECONDARY_TIMER / config.MAX_TIMEOUT;
        			var time = 0;
					db.collection('playing_table').findAndModify({_id: table._id,'pi.si':table.turn},{},{$set:{la:new Date(),ctrlServer:SERVER_ID/*,'pi.$.secTime':0*/,'pi.$.sct':false,'pi.$._uur':1,'pi.$.secTime':time},$inc:{'pi.$.tCount':1}},{new:true},function(err,table1){
						if(!table1 || !table1.value){
							c('onTurnExpire:::::::::::::::::::>>>>Error: "table not found!!!"');
							return false;
						}

						if(table1.value.turn == -1 || typeof table1.value.pi[table1.value.turn] == 'undefined'){
							c('onTurnExpire:::::::::::::::::::>>>>Error: "table turn not found!!!"',table1.value.turn);
							return false;
						}
						if(typeof table1.value.pi[table1.value.turn].cards == 'undefined'){
							c('onTurnExpire::::::::::::::::::>>>>>Error: "turn user cards not found"');
							return false;
						}
						// if user exceeds max time limit
						var ctth = '';
						if(table1.value.pi[table1.value.turn].cards.length > 13){   //card to throw when user have picked the card and timeout happens
							ctth = table1.value.pi[table1.value.turn].cards.pop();   
							c('onTurnExpire-------->>>>ctth: ',ctth);

							if(table1.value.pi[table1.value.turn].gCards.length > 0){

								var gCards = table1.value.pi[table1.value.turn].gCards;
								// c('onTurnExpire---------->>>>>>gCards: ',gCards);
								// for(var x in gCards){
								// 	if(_.contains(gCards[x],ctth)){
								// 		gCards[x] = _.without(gCards[x],ctth);
								// 		break;
								// 	}
								// }
								// c('onTurnExpire------------->>>>>gCards: ',gCards);

								if(gCards.pure.length > 0){

									var pureCards = gCards.pure;
									c('onTurnExpire---------->>>>>>gCards: ',pureCards);
									for(var x in pureCards){
										if(_.contains(pureCards[x],ctth)){
											pureCards[x] = _.without(pureCards[x],ctth);
											break;
										}
									}
									c('onTurnExpire------------->>>>>gCards: ',gCards);
									gCards.pure = pureCards;
								}
								else if (gCards.seq.length > 0) {
									var seqCards = gCards.seq;
									c('onTurnExpire---------->>>>>>gCards: ',seqCards);
									for(var x in seqCards){
										if(_.contains(seqCards[x],ctth)){
											seqCards[x] = _.without(seqCards[x],ctth);
											break;
										}
									}
									c('onTurnExpire------------->>>>>gCards: ',seqCards);
									gCards.seq = seqCards;
								}
								else if (gCards.set.length > 0){
									var setCards = gCards.set;
									c('onTurnExpire---------->>>>>>gCards: ',setCards);
									for(var x in setCards){
										if(_.contains(setCards[x],ctth)){
											setCards[x] = _.without(setCards[x],ctth);
											break;
										}
									}
									c('onTurnExpire------------->>>>>gCards: ',setCards);
									gCards.set = setCards;
								}
								else if (gCards.dwd.length > 0){
									var dwdCards = gCards.dwd;
									c('onTurnExpire---------->>>>>>gCards: ',dwdCards);
									for(var x in dwdCards){
										if(_.contains(dwdCards[x],ctth)){
											dwdCards[x] = _.without(dwdCards[x],ctth);
											break;
										}
									}
									c('onTurnExpire------------->>>>>gCards: ',dwdCards);
									gCards.dwd = dwdCards;
								}
								else{
							
								}
							
							}
							else{
								var gCards = table1.value.pi[table1.value.turn].gCards;
								var dwdCards = table1.value.pi[table1.value.turn].cards;
								gCards.dwd = dwdCards;
							}
							db.collection('playing_table').findAndModify({_id:table1.value._id,'pi.si':table1.value.turn},{},{$set:{la:new Date(),ctrlServer:SERVER_ID,'pi.$.cards':table1.value.pi[table1.value.turn].cards,'pi.$.gCards':gCards},$push:{oDeck:ctth}},function(err,table2){

								if(table2 && table2.value){

									commonClass.FireEventToTable(table2.value._id.toString(),{en:'TUT',data:{si:table2.value.turn,uid:table2.value.pi[table2.value.turn].uid,ctth:ctth}});			//TUT : turned user time out
									cdClass.GetUserInfo(table2.value.pi[table2.value.turn].uid,{sck:1},function(uSck){

										// if(table2.value.pi[table2.value.turn].tCount >= config.MAX_TIMEOUT){  
										if(table2.value.pi[table2.value.turn].secTime <= 0){
											//user leave logic here    auto :1 for LT
											if(uSck && typeof uSck.sck == 'string' && uSck.sck != ''){

												var single = uSck.sck.replace(/s\d*_\d*./i,'');
											}
											else{
												var single = '';	
											}
											setTimeout(function(){
												playClass.LT({flag:"auto"},{leave:1,id:single,uid:table2.value.pi[table2.value.turn].uid,_ir:table2.value.pi[table2.value.turn]._ir,si : table2.value.turn,tbid : table2.value._id.toString()});
											},450);
											return false;
										}
										else{

											// setTimeout(function(){   //latency

											playingTableClass.changeTableTurn(table2.value._id.toString(),'pick_skip');
											// },1000);
										}
									});
								}
								else{
									c('onTurnExpire::::::::::::::::::::::::::>>>>"table data not found"');
								}
							});
						}
						else{
							commonClass.FireEventToTable(table1.value._id.toString(),{en:'TUT',data:{si:table1.value.turn,uid:table1.value.pi[table1.value.turn].uid,ctth:ctth}});
							cdClass.GetUserInfo(table1.value.pi[table1.value.turn].uid,{sck:1},function(uSck){

								if(table1.value.pi[table1.value.turn].secTime <= 0){
								// if(table1.value.pi[table1.value.turn].tCount >= config.MAX_TIMEOUT){  
									//user leave logic here   auto : 1 for LT
									if(uSck && typeof uSck.sck == 'string' && uSck.sck != ''){

										var single = uSck.sck.replace(/s\d*_\d*./i,'');
									}
									else{
										var single = '';	
									}
									setTimeout(function(){   //latency
										playClass.LT({flag:"auto"},{leave:1,id:single,uid:table1.value.pi[table1.value.turn].uid,_ir:table1.value.pi[table1.value.turn]._ir ,si : table1.value.turn,tbid : table1.value._id.toString()});
									},450);
									return false;
								}
								else{

									// setTimeout(function(){   //latency

									playingTableClass.changeTableTurn(table1.value._id.toString(),'skip');
									//},1000);
								}
							});
						}
						/*var game_id = table1.value.game_id;
						if(table1.value.gt == 'Deal' || table1.value.gt == 'Pool'){
							game_id = game_id+'.'+table1.value.sub_id;
						}*/
					});
        		}
        		else{
        			c('onTurnExpire----------'+tbInfo._id.toString()+'---------->>>>>turn mismatch!!!! table.turn: '+table.turn+' != tbInfo.turn: '+tbInfo.turn+' '+new Date());
        		}
        	}
        	else{
        		c('onTurnExpire---------------->>>>>table not found!!!');
        	}
        });
	},
	cancelJobOnServers:function(tbId,jId){ //cancel job on multiple server 
		/* +-------------------------------------------------------------------+
            desc:function to cancel schedule job on servers
            i/p: table =  {tbId = _id of table, jId = jobid of user}
        +-------------------------------------------------------------------+ */
		c('cancelJobOnServers----------->>>>>'+tbId+' jId: '+jId+' '+new Date());
		tbId = tbId.toString();
		var sData = {en: 'CTJ', data: {jid: jId}};

        playExchange.publish('job.' + tbId, sData);
	},
	cancelRejoinJobs:function(rejoinID){
		/* +-------------------------------------------------------------------+
            desc:function to cancel schedule job of rejoin
            i/p: table =  {rejoinID = job id for rejoin}
        +-------------------------------------------------------------------+ */
		playExchange.publish('rejoin.'+rejoinID,{});
	}
}