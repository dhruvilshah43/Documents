module.exports = {
    FM: function(data, client) { //feedback message; data = {reportTo,text}
        /* +-------------------------------------------------------------------+
            desc:this event is use to send feedback message
            i/p: data = {reportTo = _id of user that to whom the current user has reported for
                           text = feedback message
                        }, client = socket object
        +-------------------------------------------------------------------+ */
        cdClass.GetUserInfo(client.uid, {_id: 1,unique_id: 1,det:1,ue:1,un:1,pp:1,flag:1,iv:1,av:1,counters:1}, function(uInfo) {
            if (uInfo) {
                if (uInfo.det == 'android') {
                    var version = uInfo.av;
                }
                else if(uInfo.det == 'ios') {
                    var version = uInfo.iv;
                }
                else {
                    var version = '';
                }

                var insertObj = {
                    cd: new Date(),
                    from: client.uid,
                    fromName: uInfo.un,
                    fromPP : uInfo.pp,
                    to : '5a9a5b54bc118d16442dc36f', //admin static 
                    toPP : '',
                    toName: 'GAME ADMIN',
                    message: data.text,
                    det: uInfo.det,
                    ue: (typeof uInfo.ue == "undefined") ? "" : uInfo.ue,
                    version: version
                };

                if (typeof data.reportTo != 'undefined'){
                    insertObj.reportTo = data.reportTo;
                }
                db.collection('feedback').insertOne(insertObj, function (err, res) {});
                insertObj.lastSent = commonClass.getDuration(new Date,new Date(),client.lc);
                
                commonClass.SendData(client, 'FM',insertObj);

                // playExchange.publish("admin", insertObj);
            } 
            else {
                c('FM------------------------->>>>>"user not found!!!"');
            }
        });
    },
    RAP: function(data, client) { //feedback message; data = {reportTo,text}
        /* +-------------------------------------------------------------------+
            desc:this event is use to send feedback message
            i/p: data = {reportTo = _id of user that to whom the current user has reported for
                           text = feedback message
                        }, client = socket object
        +-------------------------------------------------------------------+ */
        if(data.category == "Select Issue"){
            commonClass.SendData(client,'PUP', {},'error:1052');
            return false;
        }

        cdClass.GetUserInfo(client.uid, {_id: 1,unique_id: 1,det:1,ue:1,un:1,pp:1,flag:1,iv:1,av:1,counters:1}, function(uInfo) {
            if (uInfo) {
                if (uInfo.det == 'android') {
                    var version = uInfo.av;
                }
                else if(uInfo.det == 'ios') {
                    var version = uInfo.iv;
                }
                else {
                    var version = '';
                }

                cdClass.GetTbInfo(data.tbid,{ms:1,tjid:1},function(tbInfo){

                    if(tbInfo.ms == 2){
                        var tn = 'TwoPlayer_' + tbInfo.tjid;
                    }
                    else if(tbInfo.ms == 4){
                        var tn = 'FourPlayer_' + tbInfo.tjid;
                    }
                    else if(tbInfo.ms == 6){
                        var tn = 'SixPlayer_' + tbInfo.tjid;
                    }


                    var insertObj = {
                        cd: new Date(),
                        from: client.uid,
                        fromName: uInfo.un,
                        fromPP : uInfo.pp,
                        to : '5a9a5b54bc118d16442dc36f', //admin static 
                        toPP : '',
                        toName: 'GAME ADMIN',
                        category: data.category,
                        message: data.text,
                        table_name: tn,
                        gid: tbInfo.tjid,
                        det: uInfo.det,
                        ue: (typeof uInfo.ue == "undefined") ? "" : uInfo.ue,
                        version: version
                    };

                    db.collection('feedback').insertOne(insertObj, function (err, res) {});
                    insertObj.lastSent = commonClass.getDuration(new Date,new Date(),client.lc);
                    
                    commonClass.SendData(client, 'RAP',{});
                });
            } 
            else {
                c('FM------------------------->>>>>"user not found!!!"');
            }
        });
    },
    RPD: function(data, client) { //feedback message; data = {reportTo,text}
        /* +-------------------------------------------------------------------+
            desc:this event is use to send feedback message
            i/p: data = {reportTo = _id of user that to whom the current user has reported for
                           text = feedback message
                        }, client = socket object
        +-------------------------------------------------------------------+ */
        cdClass.GetTbInfo(data.tbid,{ms:1,tjid:1},function(tbInfo){

            if(tbInfo.ms == 2){
                var tn = 'TwoPlayer_' + tbInfo.tjid;
            }
            else if(tbInfo.ms == 4){
                var tn = 'FourPlayer_' + tbInfo.tjid;
            }
            else if(tbInfo.ms == 6){
                var tn = 'SixPlayer_' + tbInfo.tjid;
            }


            var insertObj = {
                table_name: tn,
                gid: tbInfo.tjid,
                category: config.FEEDBACK_CATEGORY
            };
            // category:["Score not update Properly","Winning not Credited","Others"]
            
            commonClass.SendData(client, 'RPD',insertObj);
        });
    },
    GFM: function(data, client) { //get feedback message
        /* +-------------------------------------------------------------------+
            desc:this event is use to get all feedback message
            i/p: data = {},client = socket object
            o/p: GFM event: object = {
                                msg : feedback message details
                                _io : 1/0, is admin online or not
                                lastOnline : last online time screen
                            }
        +-------------------------------------------------------------------+ */
        c('GFM------------->>>>uid: '+client.uid);

        db.collection('admin').findOne({_id:MongoID('5a9a5b54bc118d16442dc36f')},function(err,adminInfo){
            var _io = 0;
            var lastOnline = '';
            // if(adminInfo){
            //     if(adminInfo.scks.length > 0){
            //         _io = 1;
            //         lastOnline = 'Active Now';
            //     }
            //     else{
            //         lastOnline = moment(adminInfo.cd).fromNow();
            //     }
            // }
            if(adminInfo){
                if(adminInfo.scks.length > 0){
                    _io = 1;
                }
                lastOnline = commonClass.getDuration(adminInfo.cd,new Date(),client.lc,true);
            }
            

            db.collection('feedback').find({$or:[{from:client.uid,to:'5a9a5b54bc118d16442dc36f'},{from:'5a9a5b54bc118d16442dc36f',to:client.uid}]}).sort({cd:1}).toArray(function(err,feedback){
                if(feedback && feedback.length > 0){

                    // for(var i in feedback){
                    //     feedback[i].lastSent = moment(feedback[i].cd).fromNow();
                    // }
                    for(var i in feedback){
                        feedback[i].lastSent = commonClass.getDuration(feedback[i].cd,new Date(),client.lc);
                    }

                    commonClass.SendData(client, 'GFM', {msg:feedback,_io:_io,lastOnline:lastOnline});
                }
                else{
                    commonClass.SendData(client, 'GFM', {msg:[],_io:_io,lastOnline:lastOnline});
                }
                db.collection('feedback').update({to:client.uid,isRead:0},{$set:{isRead:1}},{multi :true},function(){});
            });
        });
    },    
    GFNC :function(data,client){ //Get feedback notification counter; data = {close: 1/0}
        /* +-------------------------------------------------------------------+
            desc:event to get feedback notification counter
            i/p: data = {close : 1/0 if event is called after closing feedback screen},client = socket object
            o/p: GFNC event: data = {count = notification counter}
        +-------------------------------------------------------------------+ */
        c('GFNC------------------>>>>>>data: ',data,' client.uid: '+client.uid);

        if(data.close == 1){ //means called when closing feeedback screen
            db.collection('feedback').update({to:client.uid,isRead:0},{$set:{isRead:1}},{multi:true},function(){
                commonClass.SendDirect(client.uid,{en:'GFNC',data:{count:0}},true);
            });
        }
        else{

            db.collection('feedback').find({to:client.uid,isRead:0}).count(function(err,count){
                if(count){
                    commonClass.SendDirect(client.uid,{en:'GFNC',data:{count:count}},true);
                }
                else{
                    commonClass.SendDirect(client.uid,{en:'GFNC',data:{count:0}},true);
                }
            });
        }
    },
    updateSystemMessage: function(obj) {
        /* +-------------------------------------------------------------------+
            desc:function to set admin reply to user
            i/p: obj = {uid : _id of user, msg: reply of admin }
            o/p: GFNC event: data = {count = notification counter}
        +-------------------------------------------------------------------+ */
        uid = obj.uid;
        msg = obj.msg;

        cdClass.GetUserInfo(uid,{pp:1,un:1,sck:1,lc:1},function(userInfo){
            if(userInfo){
                var setData = {
                    cd: new Date(),
                    from: "5a9a5b54bc118d16442dc36f",
                    fromName: "GAME ADMIN",
                    fromPP: "",
                    to: uid,
                    toPP : userInfo.pp,
                    toName: userInfo.un,
                    message : msg,
                    det: 'PC',
                    ue : '',
                    isRead: 0
                }

                db.collection('feedback').save(setData,function(err,res){

                    db.collection('feedback').find({to:uid}).sort({cd:-1}).toArray(function(err1,resp){
                        if(resp && resp.length > 0){
                            if(userInfo.sck != ''){
                               
                                resp[0].lastSent = commonClass.getDuration(new Date,new Date(),userInfo.lc);
                                commonClass.SendDirect(userInfo.sck,{en:'FM',data:resp[0]});
                                fbClass.GFNC({},{uid:uid});
                            }
                        }  
                        else{
                            c('updateSystemMessage----------------->>>>"not message to send"');
                        }
                    });
                });
            }
            else{
                c('updateSystemMessage----------------->>>>>>"user not found"');
            }
        });
    }   
}