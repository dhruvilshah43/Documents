module.exports = {
	
	LN: function(data,client){ //Language
		/* +-------------------------------------------------------------------+
            desc:event to get multi language text for game
            i/p: data =  {location = location of the text in which it need to be show}, client = socket object
            o/p: data = {location = location of the text, msg = text details}
        +-------------------------------------------------------------------+ */
		//c('LN ------->>>>>data',data);
		var location = data.location;
		var code = client.lc;
		var arr = [];
		db.collection('multi_language').find({"location":location,"LC":code}).project({"_id":0,"mid":1,"text":1}).toArray(function(err,resp){
			if(resp){
				//c('LN ------->>>>>languagecode',resp);
				commonClass.SendData(client,'LN',{location: location,msg: resp}); 
			}
		});
	}
}