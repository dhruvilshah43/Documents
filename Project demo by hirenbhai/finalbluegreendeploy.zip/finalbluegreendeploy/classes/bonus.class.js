module.exports = {
	CFSB : function(data,client){ //Check For spin Bonus
		/* +-------------------------------------------------------------------+
			desc:this event is use for checking is the current user is elegible for daily bonus
			i/p: - data = {}, client = socket object
		+-------------------------------------------------------------------+ */
		c('CFSB--------------------->>>>>>"client.uid:"'+client.uid);
		cdClass.GetUserInfo(client.uid,{lasts:1,det:1},function(userInfo){
			if(userInfo){
				// var lsctt = new Date(commonClass.AddTimeD(userInfo.lasts.lsct,86400)); 
				// var diff = commonClass.GetTimeDifference(lsctt,new Date());
				
				var diff = commonClass.GetTimeDifference(new Date(userInfo.lasts.lsct),new Date(),'day');
				c('CFSB--------------------->>>>>>"diff:"'+diff);
				if(diff >= 1){
					bonusClass.GSD({uid:userInfo._id.toString()},client);
				}
				else{
					commonClass.SendData(client,'CFSB',{sts:false});
				}
			}
			else{
				c('CFSB--------------------->>>>>>"user not found"');
			}
		});
	},
	GSD : function(data,client){ //get spinner data
		
		c('GSD--------------------->>>>>>"data.uid:"'+data.uid);
		cdClass.GetUserInfo(data.uid,{},function(userInfo){
			if(userInfo){
				db.collection('daily_spinner').find({Active:1}).sort({cd:-1}).toArray(function(err,spinner){
					if(spinner && spinner.length > 0){

						spin = spinner[0];
						var rn = commonClass.GetRandomInt(1, 100);
                        var bound = spin.spinnerData[0].prob;
                        for (var i = 0; i < spin.spinnerData.length; i++) {
	                        if(rn <= bound){
                                c("spin Data paid >>>", spin.spinnerData[i].prob);
	                            spin.result = i //spin.spinnerData[i].id;
                                break;
                            } 
                            else{
                                bound = bound+parseInt(spin.spinnerData[i+1].prob);
                            }
	                    }

	                    db.collection('lucky_spin_extra').find({}).sort({invC: 1}).toArray(function(err,extraInfo){
	                    	
	                    	var invFndC = 0;
							var invFndRwd = 0;
							c('GSD--------------------->>>>>>"extraInfo:"'+extraInfo);
	                    	if(extraInfo && extraInfo.length > 0){
	                    		var invCount = userInfo.counters.invC;
								var daysCount = userInfo.counters.spinDays;
								var invBonus = 0;
								var dsBonus = 0;

	                    		invArray = _.clone(extraInfo); //array of invite counter
	                    		invFndC = invArray[0].invC;
								invFndRwd = invArray[0].invReward;

								for(var k = invArray.length-1 ;k >= 0  ; k--){
									if(invArray[k].invC <= invCount){
										invBonus = invArray[k].invReward;
										break;
									}
								}

								dayArray = _.clone(extraInfo);
								var i,j;
								for(i = 0;i < dayArray.length;i++){   //sort(bubble sort) the invC 
									for(j = 0;j < dayArray.length-i-1;j++){
										if(dayArray[j].dayStreak > dayArray[j+1].dayStreak ){ 
											temp = _.clone(dayArray[j]);
											dayArray[j] = _.clone(dayArray[j+1]);
											dayArray[j+1] = _.clone(temp);
										}
									}
								}

								for(var l = dayArray.length-1; l >= 0 ;l--){
									if(dayArray[l].dayStreak <= daysCount){
										dsBonus = dayArray[l].dReward;
										break;
									}
								}

								var daily_streak = [];
								var invite_bonus = [];
								for(var t in invArray){
									daily_streak.push(invArray[t].dReward);
									invite_bonus.push(invArray[t].invReward);
								}

								c('GSD--------------------->>>>>>"invBonus:"'+invBonus);
								spin.invBonus = invBonus;
								spin.dsBonus = dsBonus;
								spin.invArray = invite_bonus;
								spin.dayArray = daily_streak;
	                    		commonClass.SendData(client, 'GSD', spin);
	                    	}
	                    	else{
	                    		commonClass.SendData(client, 'GSD', spin);
	                    	}
	                    })
					}
				});
			}
		});
	},
	GSR : function(data,client){ //get spinner rewards

		cdClass.GetUserInfo(client.uid,{},function(userInfo){
			if(userInfo){
				db.collection('daily_spinner').find({Active:1}).sort({cd:-1}).toArray(function(err,spinner){
					if(spinner && spinner.length > 0){

						spin = spinner[0];
						
						reward = spin.spinnerData[parseInt(data.result)].extras;

						db.collection('lucky_spin_extra').find({}).sort({dayStreak:1}).toArray(function(err,extraInfo){
							var invReward = 0;
							var dayReward = 0;

							var crtTime = new Date();
							var daysCount = userInfo.counters.spinDays;

							if(extraInfo && extraInfo.length > 0){  //reward type is percent
								var invCount = userInfo.counters.invC;
								var temp = '';
								var invArray = _.clone(extraInfo); //array of invite counter
								var i,j;
								for(i = 0;i < invArray.length;i++){   //sort(bubble sort) the invC 
									for(j = 0;j < invArray.length-i-1;j++){
										if(invArray[j].invC < invArray[j+1].invC ){ 
											temp = _.clone(invArray[j]);
											invArray[j] = _.clone(invArray[j+1]);
											invArray[j+1] = _.clone(temp);
										}
									}
								}

								c('giveRewards----------->>>>>>invArray: ',invArray);

								
								for(var k in invArray){
									if(invArray[k].invC <= userInfo.counters.invC){
										invReward = invArray[k].invReward;
										break;
									}
								}

								var dayArray = _.clone(extraInfo);
								for(i = 0;i < dayArray.length;i++){   //sort(bubble sort) the dayStreak 
									for(j = 0;j < dayArray.length-i-1;j++){
										if(dayArray[j].dayStreak < dayArray[j+1].dayStreak ){ 
											temp = _.clone(dayArray[j]);
											dayArray[j] = _.clone(dayArray[j+1]);
											dayArray[j+1] = _.clone(temp);
										}
									}
								}

								for(var k in dayArray){
									if(dayArray[k].dayStreak <= daysCount){
										dayReward = dayArray[k].dReward;
										break;
									}
								}
							}

							var dsBonus = Math.round(reward*dayReward/100);
							var invBonus = Math.round(reward*invReward/100);

							var lsct = userInfo.lasts.lsct;
							var diffCount = commonClass.GetTimeDifference(lsct,crtTime,'day');
							if(diffCount == 1){ //if days count == 1 then set new date and increment days count
								lsct = new Date();
								daysCount ++;
							}
							else if(diffCount > 1){ //if days count >  1 then set new Date and reset days count
								lsct = new Date();
								daysCount = 0;
							}
							else{ //if days count < 1 then do nothing
								c('giveRewards-------->>>>');
							}

							var df = commonClass.GetTimeDifference(lsct,new Date());
			                df = df<0 ? 0:df;
			                var dstime = 86400 - df; //timer for collect daily spin collect

			                var amount = reward + invBonus + dsBonus;

							cdClass.UpdateUserChips(client.uid, amount, "Spinner Rewarded Chips", function(fChips) {
								
								var upData = {$set:{"lasts.lsct":new Date(),"counters.spinDays":daysCount}};
								cdClass.UpdateUserData(client.uid,upData,function(userInfo){

		                    		commonClass.SendData(client, 'GSR', {Chips: fChips});
								})
							})
						})
					}
				});
			}
		});
	},
	CFDB : function(data,client){ //check daily bonus
		c("CFDB------------:client.uid",client.uid);
		
		cdClass.GetUserInfo(client.uid,{},function(userInfo){
			if(userInfo){
				c("CFDB------------data:",userInfo.lasts.ldbt);
				// var upData = {$set : {"lasts.ll" : new Date()}};
				var freeBonus = {dbc : 0};
				// var dayDiff = Math.floor(commonClass.GetTimeDifference(data.lasts.ldbt, new Date())/86400);
				var dayDiff = commonClass.GetTimeDifference(new Date(userInfo.lasts.ldbt),new Date(),'day');
				
				if(dayDiff >= 1){
					freeBonus.daily_bonus = true;
					freeBonus.dbc = (dayDiff == 1) ? (userInfo.counters.dbc + 1) : 1;
				}
				else{
					freeBonus.daily_bonus = false;
					freeBonus.dbc = userInfo.counters.dbc;
				}

				if(freeBonus.dbc > 7){
					freeBonus.dbc = 7;
				}

				// upData.$set["counters.dbc"] = freeBonus.dbc;
				var chipsarray = config.DAILYBONUS;
				freeBonus.chips_array = chipsarray;
				freeBonus.chips = chipsarray[parseInt(freeBonus.dbc) - 1];
				c("CFDB------------:",freeBonus);

				commonClass.SendData(client, 'CFDB', freeBonus);
			}
		});
	},
	CDB : function(data,client){
		cdClass.GetUserInfo(client.uid,{},function(userInfo){
			if(userInfo){
				
				var ldbt = new Date(userInfo.lasts.ldbt);
                // ldbt.setSeconds(ldbt.getSeconds() + Number(86400));
                var remtime = commonClass.GetTimeDifference(new Date(),ldbt);
                if(remtime <= 0) {
                    // bonusClass.CFDB(userInfo,client,86400-remtime);
                    // return false;
	                var daysCount = userInfo.counters.dbc;
	                var crtTime = new Date();
					var diffCount = commonClass.GetTimeDifference(new Date(userInfo.lasts.ldbt),crtTime,'day');
					if(diffCount == 1){ //if days count == 1 then set new date and increment days count
						ldbt = new Date();
						daysCount ++;
					}
					else if(diffCount > 1){ //if days count >  1 then set new Date and reset days count
						ldbt = new Date();
						daysCount = 1;
					}
					else{ //if days count < 1 then do nothing
						c('giveRewards-------->>>>');
					}

					if(daysCount > 7){
						daysCount = 7;
					}

					var chipsarray = config.DAILYBONUS;
	             	var bonus = chipsarray[parseInt(userInfo.counters.dbc)];
					cdClass.UpdateUserChips(client.uid,bonus,'collect daily bonus',function(uChips){
						cdClass.UpdateUserData(client.uid,{$set:{'lasts.ldbt':ldbt,'counters.dbc':daysCount}},function(upData){
							commonClass.SendData(client, 'CDB', {Chips: uChips,daily_bonus: false});
						})
					})
                }
                else{
                	commonClass.SendData(client, 'CDB', {daily_bonus: false,msg:"you are not elegible"});
                }

			}	
		});
	}
}