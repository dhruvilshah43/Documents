module.exports = {
	GBL:function(data,client){ // Get Buddy List
		/* +-------------------------------------------------------------------+
			desc:Event to get buddy list
			i/p: data = {},client = socket object
		+-------------------------------------------------------------------+ */
		var fIds = [];
		var fList = [];
		db.collection('user_friends').findOne({uid:MongoID(data.uid)},{fields:{friends:1}},function(err,userFnd){
			if(userFnd){
				fIds = userFnd.friends;
				if(fIds.length > 0){

					db.collection('game_users').find({_id:{$in:fIds}}).project({_id:1,un:1,pp:1,"flags._io":1,tbid:1}).toArray(function(err1,userInfo){
						if(userInfo && userInfo.length > 0){
							fList = userInfo;
						}
						commonClass.SendData(client,'GBL',{list: fList});
						// commonClass.SendData(client,'GBL',{fIds:fIds});
					});
				}
				else{
					commonClass.SendData(client,'GBL',{list: fList});
				}
			}
		});
	},
	SINV :function(data,client){  //Send Invite request; data = {recvIds: [,....]}
		/* +-------------------------------------------------------------------+
			desc:Event to send table invitation
			i/p: data = {recvIds = array of _id of receiver users,isFromPWF= true/false},client = socket object
		+-------------------------------------------------------------------+ */
		c('SINV---------->>>>>>tbid: '+client.tbid);
		if(typeof client.tbid == 'undefined'){
			c('SINV------------>>>>>"table Id not found!!!"');
			return false;
		}
		cdClass.GetUserInfo(client.uid,{},function(sendInfo){
			if(sendInfo){
	
				for(var i in data.recvIds){
					buddiesClass.sendInvites(data.recvIds[i].toString(),{un:sendInfo.un,pp:sendInfo.pp,isFromPWF:data.isFromPWF},client);
				}

			}
			else{
				c('SINV------------->>>>>>"user not found"');
			}
		});
	},
	ACINV:function(data,client){ //Accept friend request; data = {notiId}
		/* +-------------------------------------------------------------------+
			desc:Event to accept table invitation
			i/p: data = {notiId = _id of invite notification},client = socket object
		+-------------------------------------------------------------------+ */
		c('ACINV--------->>>>>data.notiId: '+data.notiId);
		if(data.notiId && data.notiId != ''){
			
			db.collection('user_notification').findOne({_id:MongoID(data.notiId.toString()),sub:'INVITEREQUEST'},function(err,notiInfo){
				if(notiInfo){
					if(!notiInfo.tbid || notiInfo.tbid == ''){
						c('ACINV------1------>>>>>>"invite notification tbid not found"');
						db.collection('user_notification').remove({ $or:[{_id:MongoID(data.notiId.toString())},{sendId:notiInfo.sendId,recvId:notiInfo.recvId,tbid:notiInfo.tbid.toString()}]},function(){ //deleteng the notification
							notiClass.NRC({uid:client.uid});
						});  
						return;
					}

					cdClass.GetUserInfo(client.uid,{},function(userInfo){
						if(userInfo){
							//check if the user is playing in any table or not 
							if(notiInfo.tbid == userInfo.tbid){ //means user is in same table
								c('ACINV------------>>>>"user is already on that table "');
								commonClass.SendData(client,'PUP',{flag:'alPlay'},'error:1025'); //already playing on the same table
								db.collection('user_notification').remove({$or:[{_id:MongoID(data.notiId.toString())},{sendId:notiInfo.sendId,recvId:notiInfo.recvId,tbid:notiInfo.tbid.toString()}]},function(){ //deleteng the notification
									 notiClass.NRC({uid:client.uid});
								}); 
								return;
							}

							db.collection('playing_table').findOne({_id:MongoID(notiInfo.tbid),$where:'this.ap < this.ms'},{},function(err1,tbInfo){
								if(tbInfo){
									var cond = true;
									if(tbInfo.gt == 'Deal'){
										cond = _.contains(['','RoundTimerStarted','RoundStarted'],tbInfo.tst) && tbInfo.round == 0;
										if(userInfo.Chips < tbInfo.bv){
											var reqChips = tbInfo.bv;
											commonClass.SendData(client,'PUP', {flag:'noChips',reqChips:reqChips},'error:1020'); //no sufficient chips
											// strClass.outOfChipsPop(client,{flag:'noChips',reqChips:reqChips});
											db.collection('user_notification').remove({$or:[{_id:MongoID(data.notiId.toString())},{sendId:notiInfo.sendId,recvId:notiInfo.recvId,tbid:notiInfo.tbid.toString()}]},function(){ //deleteng the notification
												notiClass.NRC({uid:client.uid});
											});
											return;
										}
									}
									else if(tbInfo.gt == 'Pool'){
										cond = _.contains(["","RoundTimerStarted"],tbInfo.tst) && tbInfo.round == 0;
										if(userInfo.Chips < tbInfo.bv){
											var reqChips = tbInfo.bv;
											commonClass.SendData(client,'PUP', {flag:'noChips',reqChips:reqChips},'error:1020'); //no sufficient chips
											// strClass.outOfChipsPop(client,{flag:'noChips',reqChips:reqChips});
											db.collection('user_notification').remove({$or:[{_id:MongoID(data.notiId.toString())},{sendId:notiInfo.sendId,recvId:notiInfo.recvId,tbid:notiInfo.tbid.toString()}]},function(){ //deleteng the notification
												notiClass.NRC({uid:client.uid});
											});
											return;
										}
									}
									else if(tbInfo.gt == 'Bet'){
										cond = !_.contains(['StartDealingCard','CardsDealt','winnerDeclared'],tbInfo.tst);
										if(userInfo.Chips < tbInfo.bv*config.MAX_DEADWOOD_PTS){
											var reqChips = tbInfo.bv*config.MAX_DEADWOOD_PTS;
											commonClass.SendData(client,'PUP', {flag:'noChips',reqChips:reqChips},'error:1020'); //no sufficient chips
											// strClass.outOfChipsPop(client,{flag:'noChips',reqChips:reqChips});
											db.collection('user_notification').remove({$or:[{_id:MongoID(data.notiId.toString())},{sendId:notiInfo.sendId,recvId:notiInfo.recvId,tbid:notiInfo.tbid.toString()}]},function(){ //deleteng the notification
												notiClass.NRC({uid:client.uid});
											});
											return;
										}
									}
									else{ //default condition for classic rummy
										cond = !_.contains(['StartDealingCard','CardsDealt','winnerDeclared'],tbInfo.tst);
										if(userInfo.Chips < tbInfo.bv*config.MAX_DEADWOOD_PTS){
											var reqChips = tbInfo.bv*config.MAX_DEADWOOD_PTS;
											commonClass.SendData(client,'PUP', {flag:'noChips',reqChips:reqChips},'error:1020'); //no sufficient chips
											// strClass.outOfChipsPop(client,{flag:'noChips',reqChips:reqChips});
											db.collection('user_notification').remove({$or:[{_id:MongoID(data.notiId.toString())},{sendId:notiInfo.sendId,recvId:notiInfo.recvId,tbid:notiInfo.tbid.toString()}]},function(){ //deleteng the notification
												notiClass.NRC({uid:client.uid});
											});
											return;
										}

									}

									if(cond){ //means table is ready to join
										//find the seat and join logic here
										c('ACINV------------>>>>>>"table join"');
										if(userInfo.tbid == ''){ //means user is not playing in table
											c('ACINV---------------->>>>>"user is not playing in any table"');
											client.isInvite = true;
											playingTableClass.joinSeat(tbInfo._id.toString(),client);
										}
										else{ //means user is playing some table so remove from table first
											c('ACINV------------>>>>"user is playing in table"');
											playingTableClass.findTableExistence(client,true,function(check){
												if(check == 1){
													c('ACINV------------>>>>>"join table"');
													client.isInvite = true;
													playingTableClass.joinSeat(tbInfo._id.toString(),client);
												}
												else{
													c('ACINV------------>>>>>"unable to join table"');
												}
											});
										}
										db.collection('user_notification').remove({$or:[{_id:MongoID(data.notiId.toString())},{sendId:notiInfo.sendId,recvId:notiInfo.recvId,tbid:notiInfo.tbid.toString()}]},function(){ //deleteng the notification
											notiClass.NRC({uid:client.uid});
										});  
									}
									else{
										c('ACINV------------>>>>>"game is running can\'t join the table"');
										commonClass.SendData(client,'PUP',{flag:'alRun'},'error:1027'); //game is running so can't join the table
										db.collection('user_notification').remove({$or:[{_id:MongoID(data.notiId.toString())},{sendId:notiInfo.sendId,recvId:notiInfo.recvId,tbid:notiInfo.tbid.toString()}]},function(){ //deleteng the notification
											 notiClass.NRC({uid:client.uid});
										});  
									}
								}
								else{
									c('ACINV------------>>>>>"table not found or no seat are there to seat"');
									commonClass.SendData(client,'PUP',{flag: 'noSeat'},'error:1029'); //no empty seat available
									db.collection('user_notification').remove({$or:[{_id:MongoID(data.notiId.toString())},{sendId:notiInfo.sendId,recvId:notiInfo.recvId,tbid:notiInfo.tbid.toString()}]},function(){ //deleteng the notification
										notiClass.NRC({uid:client.uid});
									});  
								}
							});
						}
						else{
							c('ACINV------------->>>>>"user not found"');
							db.collection('user_notification').remove({$or:[{_id:MongoID(data.notiId.toString())},{sendId:notiInfo.sendId,recvId:notiInfo.recvId,tbid:notiInfo.tbid.toString()}]},function(){  //deleteng the notification
								notiClass.NRC({uid:client.uid});
							}); 
						}
					});
				}
				else{
					c('ACINV-----2------->>>>>"invite notification not found"');
					commonClass.SendData(client, 'PUP', {flag:'noTable'}, 'error:1048');  //table not found
				}
			});
		}
		else{
			c('ACINV------------>>>>>"invalid id"');
		}
	},
	JTFL:function(data,client){ //join table from shared link; data = {notiId}
		/* +-------------------------------------------------------------------+
			desc:Event to accept table invitation
			i/p: data = {notiId = _id of invite notification},client = socket object
		+-------------------------------------------------------------------+ */
		c('JTFL--------->>>>>data.notiId: '+data.tbid);
		if(data.tbid && data.tbid != ''){

			cdClass.GetUserInfo(client.uid,{},function(userInfo){
				if(userInfo){
					//check if the user is playing in any table or not 
					if(data.tbid == userInfo.tbid){ //means user is in same table
						c('JTFL------------>>>>"user is already on that table "');
						commonClass.SendData(client,'PUP',{flag:'alPlay'},'error:1025'); //already playing on the same table
						return;
					}

					db.collection('playing_table').findOne({_id:MongoID(data.tbid),$where:'this.ap < this.ms'},{},function(err1,tbInfo){
						if(tbInfo){
							var cond = true;
							if(tbInfo.gt == 'Deal'){
								cond = _.contains(['','RoundTimerStarted','RoundStarted'],tbInfo.tst) && tbInfo.round == 0;
								if(userInfo.Chips < tbInfo.bv){
									var reqChips = tbInfo.bv;
									commonClass.SendData(client,'PUP', {flag:'noChips',reqChips:reqChips},'error:1020'); //no sufficient chips
									// strClass.outOfChipsPop(client,{flag:'noChips',reqChips:reqChips});
									return;
								}
							}
							else if(tbInfo.gt == 'Pool'){
								cond = _.contains(["","RoundTimerStarted"],tbInfo.tst) && tbInfo.round == 0;
								if(userInfo.Chips < tbInfo.bv){
									var reqChips = tbInfo.bv;
									commonClass.SendData(client,'PUP', {flag:'noChips',reqChips:reqChips},'error:1020'); //no sufficient chips
									// strClass.outOfChipsPop(client,{flag:'noChips',reqChips:reqChips});
									return;
								}
							}
							else if(tbInfo.gt == 'Bet'){
								cond = !_.contains(['StartDealingCard','CardsDealt','winnerDeclared'],tbInfo.tst);
								if(userInfo.Chips < tbInfo.bv*config.MAX_DEADWOOD_PTS){
									var reqChips = tbInfo.bv*config.MAX_DEADWOOD_PTS;
									commonClass.SendData(client,'PUP', {flag:'noChips',reqChips:reqChips},'error:1020'); //no sufficient chips
									// strClass.outOfChipsPop(client,{flag:'noChips',reqChips:reqChips});
									return;
								}
							}
							else{ //default condition for classic rummy
								cond = !_.contains(['StartDealingCard','CardsDealt','winnerDeclared'],tbInfo.tst);
								if(userInfo.Chips < tbInfo.bv*config.MAX_DEADWOOD_PTS){
									var reqChips = tbInfo.bv*config.MAX_DEADWOOD_PTS;
									commonClass.SendData(client,'PUP', {flag:'noChips',reqChips:reqChips},'error:1020'); //no sufficient chips
									// strClass.outOfChipsPop(client,{flag:'noChips',reqChips:reqChips});
									return;
								}

							}

							if(cond){ //means table is ready to join
								//find the seat and join logic here
								c('JTFL------------>>>>>>"table join"');
								if(userInfo.tbid == ''){ //means user is not playing in table
									c('JTFL---------------->>>>>"user is not playing in any table"');
									client.isInvite = true;
									playingTableClass.joinSeat(tbInfo._id.toString(),client);
								}
								else{ //means user is playing some table so remove from table first
									c('JTFL------------>>>>"user is playing in table"');
									playingTableClass.findTableExistence(client,true,function(check){
										if(check == 1){
											c('JTFL------------>>>>>"join table"');
											client.isInvite = true;
											playingTableClass.joinSeat(tbInfo._id.toString(),client);
										}
										else{
											c('JTFL------------>>>>>"unable to join table"');
										}
									});
								}
							}
							else{
								c('JTFL------------>>>>>"game is running can\'t join the table"');
								commonClass.SendData(client,'PUP',{flag:'alRun'},'error:1027'); //game is running so can't join the table
							}
						}
						else{
							c('JTFL------------>>>>>"table not found or no seat are there to seat"');
							commonClass.SendData(client,'PUP',{flag: 'noSeat'},'error:1029'); //no empty seat available 
						}
					});
				}
				else{
					c('JTFL------------->>>>>"user not found"');
				}
			});
		}
		else{
			c('JTFL------------>>>>>"invalid id"');
		}
	},
	SaveFriendList:function (data){	
		/* +-------------------------------------------------------------------+
			desc:function to save fb friends
			i/p: data = {}, client = socket object
		+-------------------------------------------------------------------+ */
		//getting all facebook friends from user.
		c('SaveFriendList------------->>>>>>>data.un: '+data.un+' data.fid: '+data.fid+' data.fat: '+data.fat);
		FB.setAccessToken(data.fat);
		FB.api('/'+config.FB_API_V+'/me/friends', function (response) {
			
			c('SaveFriendList--------------->>>>>>>response: ',response);
			if(!response || response.error || typeof response == 'undefined' || typeof response.data == 'undefined'){
				c('SaveFriendList--------------->>>>>>>data.fat: '+data.fat);
				c('Save Friend List >> '+data.un +">>"+data.fid);
			}
			else{
			  
				var FriendArray = [];

				//preparing friends array who are playing with me
				for(var i in response.data){
					FriendArray.push(response.data[i].id);
				}
				
				c('SaveFriendList----------->>>>>>FriendArray: ',FriendArray);


				//first we have to find _id for registered users.
				
				db.collection("game_users").distinct("_id",{ fid : { $in : FriendArray }}, function(err, fndInfo){ 

					c('SaveFriendList------------->>>>>fndInfo: ',fndInfo);

					db.collection("user_friends").update({_id : data._id},{$set:{uid:data._id},$addToSet : {friends:{$each:fndInfo}}},{upsert:true,multi:true},function(){});
					db.collection("user_friends").update({ _id : { $in : fndInfo}}, { $addToSet : { friends : data._id }},{upsert:true,multi: true}, function(){ });

				});			  
			}
		});
	},
	sendInvites:function(recvId,sendInfo,client){
		/* +-------------------------------------------------------------------+
			desc:function to handle table invitation
			i/p: recvId = receivers _id, sendInfo = sender _id,isFromPWF = is from private table, client = socket object
		+-------------------------------------------------------------------+ */
		var tbid = client.tbid;
		var uid = client.uid;
		cdClass.GetUserInfo(recvId,{tbid:1,lasts:1,det:1},function(recvInfo){

			if(recvInfo && tbid){

				if(tbid == recvInfo.tbid){  //receiver is already on same table
					return;
				}

				cdClass.GetTbInfo(tbid,{_id:1,gt:1},function(tbInfo){

					if(tbInfo){

						var obj = {
							cd: new Date(), 
							sub: 'INVITEREQUEST',
							tbid: tbid,
							sendId : uid,
							sName : sendInfo.un,
							sProfile : sendInfo.pp,
							recvId : recvId.toString(),
							gt : tbInfo.gt,
							msg : "has challenged you!",
							pupTimer:config.NOTI_TIMER,
							isRead: 0,
							isFromPWF: sendInfo.isFromPWF?true:false 
						}

						db.collection('user_notification').save(obj,function(err,newNoti){

							commonClass.SendDirect(recvId.toString(),{en:'SINV',data:newNoti.ops[0]}, true);
							notiClass.NRC({uid:recvId.toString()});
						});
					}
				});   
			}
		});
	}
}