module.exports = {
	MP:function(data,client){ //My Profile; data = {uid}
		/* +-------------------------------------------------------------------+
			desc:event to open user profile details
			i/p: data = {uid : user details}, client = socket object
			o/p: MP event : uid = user id
							un = user name 
							pp = profile picture
							unique_id = unique id
							Chips = chips 
							Coins = coins
							tGames = total games played
							tWon = total hands won
							mcw = most chips won
							win_loss = win/loss ratio
							fndCount = friends count
							btn = buddy button
							blkBtn = block button
		+-------------------------------------------------------------------+ */
		c('MP-------->>>client.uid: ',client.uid);
		
		cdClass.GetUserInfo(data.uid,{un:1,unique_id:1,pp:1,Chips:1,Coins:1,counters:1,tbid:1},function(userInfo){ //get the current userInfo
			if(userInfo){
                c('MP----------->>>>userInfo.un: ',userInfo.un);

				var obj = {
					uid:userInfo._id.toString(),
					un:userInfo.un,
					pp:userInfo.pp,
					unique_id:userInfo.unique_id,
					Chips:userInfo.Chips,
					Coins:userInfo.Coins,
					tGames:userInfo.counters.thp,
					tWon:userInfo.counters.hw,
                    tloss:parseInt(userInfo.counters.hl) + parseInt(userInfo.counters.hd),
				};
				commonClass.SendData(client,'MP',obj);	
			}
			else{
				c('MP--------------------->>>>>>"user not found"');
			}
		});	
	},
	UUN : function(data,client){ //update user name ; data = {un}
		/* +-------------------------------------------------------------------+
			desc:event to update user name
			i/p: data = {un = username}, client = socket object
			o/p: UUN event : data = {un = username}
		+-------------------------------------------------------------------+ */
		c("UUN --------->>>>>change user name----",data.un);
		c("UUN --------->>>>>client id ----",client.uid);
		cdClass.UpdateUserData(client.uid,{$set: {"un": data.un}},function(udata){
			if(udata){
				commonClass.SendDirect(udata._id, {en:'UUN',data:{un:udata.un}}, true);
			}
		}); 
	},
    CGS:function(data,client){ //Change Game Settings  data = {flag}
        /* +-------------------------------------------------------------------+
            desc:event to change game settings 
            i/p: data = {flag = sound/vibrate}
            o/p: CGS event : data = {flag = sound/vibrate, sts = 1/0}
        +-------------------------------------------------------------------+ */
        c('CGS----------------->>>>data: ',data);

        if(!data.flag){
            c('CGS---------------->>>>"flag not found"');
            return;
        }
        cdClass.GetUserInfo(client.uid,{flags:1},function(userInfo){
            var check = false;
            var sts = 1;
            if(userInfo){
                var upData = {};
                if(data.flag == 'sound'){
                    if(userInfo.flags._snd == 1){
                        upData = {$set:{'flags._snd':0}};
                        sts = 0;
                    }
                    else{
                        upData = {$set:{'flags._snd':1}};   
                        sts = 1;
                    }
                    check = true;
                }
                else if(data.flag == 'vibrate'){
                    if(userInfo.flags._vib == 1){
                        upData = {$set:{'flags._vib':0}};
                        sts = 0;
                    }
                    else{
                        upData = {$set:{'flags._vib':1}};
                        sts = 1;
                    }
                    check = true;
                }

                if(!check){
                    c('CGS---------------->>>>>"check fails"');
                    return;
                }

                cdClass.UpdateUserData(client.uid,upData,function(upInfo){
                    if(upData){
                        commonClass.SendData(client,'CGS',{flag:data.flag,sts:sts});
                    }
                });
            }
            else{
                c('CGS---------------->>>>"user not found!!!"');
            }
        });
    },
    GS: function (data,client){
        c('GS-------->>>client.uid: ',client.uid);
        
        cdClass.GetUserInfo(data.uid,{counters:1,flags:1},function(userInfo){ //get the current userInfo
            if(userInfo){

                var obj = {
                    vib : userInfo.flags._vib,
                    snd : userInfo.flags._snd
                };
                commonClass.SendData(client,'GS',obj);  
            }
            else{
                c('GS--------------------->>>>>>"user not found"');
            }
        }); 
    },
	ManageUserLevel: function (en, data, client) {
        var xp = 0;
        switch (en) {
            case 'dailyBonus':
             	xp : 10;
             	break;

            case 'win':
                xp = 15;
                break;

            case 'play':
                xp = 2;
                break;

            case 'loss':
            	xp = 2;
            	break;
        }

        //if user eligible for increase the level progress
        if (xp > 0) {
            data = (data != null && typeof data != 'undefined') ? data.toString() : '';
            var uid = (typeof client == 'undefined') ? data.toString() : client.uid;

            //first we have to collect userinformation to complete the level.
            cdClass.GetUserInfo(uid, {
                counters: 1,
                sck: 1,
                flags: 1,
                Chips: 1,
                fid: 1
            }, function (ui) {
                if (ui.length == 0)
                    return false;

                var levelPoint = 100;
                // var levelPoint = ((ui.counters.lvc * 50) + 20); //generate point range according to level
                var np = parseInt(ui.counters.ppo) + xp; //prepare new point after summation
                var lc = (levelPoint <= np) ? ui.counters.lvc + 1 : ui.counters.lvc; //if level point smaller or equal then change the level
                np = (levelPoint <= np) ? np - levelPoint : np; //if level point smaller or equal then change the level
                // levelPoint = (ui.counters.lvc < lc) ? ((lc * 50) + 20) : levelPoint;
                levelPoint = (ui.counters.lvc < lc) ? 100 : levelPoint;
                
                //percentage for level completed
                var pp = Math.round((100 * np) / levelPoint);

                db.collection('game_users').update({
                    _id: MongoID(uid)
                }, {
                    $set: {
                        "counters.lvc": lc,
                        "counters.pper": pp,
                        "counters.ppo": np
                    }
                },function () {
                	profileClass.ManageUserClub(data)
                });

                var dt = {
                    lvc: lc,
                    pper: pp,
                    xp:xp
                };

                commonClass.SendDirect(ui.sck, {
                    en: 'PRGU',
                    data: dt
                });
            });
        }
    },
    ManageUserClub: function (uid){
    	
    	if(typeof uid == 'undefined' || uid.toString().length < 24) {
            return false;
        }
        
        cdClass.GetUserInfo(uid.toString(), {
            "sck": 1,
            "flags": 1,
            "un": 1,
            "det": 1,
            "club": 1,
    		"counters": 1
        }, function (uinfo) {
            
            if (typeof uinfo._id != 'undefined') { 
            	db.collection('level_points').find({}).sort({slvl:1}).toArray(function(err,resp){
            		if(resp.length > 0){
            			var club = resp;
            			var vip_club = uinfo.club;
            			for(var i = 0; i < club.length; i++) {
            				if (uinfo.counters.lvc >= club[i].slvl && uinfo.counters.lvc <= club[i].elvl) {
            					vip_club = club[i].name;
            					break;
            				}
            			}

            			db.collection('game_users').update({_id : MongoID(uinfo._id)},{ $set : { "club" : vip_club}},function () {
		                	var dt = {
			                    lvc: uinfo.counters.lvc,
			                    ppo: uinfo.counters.ppo,
			                    club: vip_club,
			                    pper: uinfo.counters.pper
			                };

			                commonClass.SendDirect(uinfo.sck, {
			                    en: 'PRGU',
			                    data: dt
			                });
		                });
            		}
            	});
            }
        });
    }
}