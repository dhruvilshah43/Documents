var path = require('path');
module.exports = {
	CreateQueues: function(){ //binds the queues with exchanges
		/* +-------------------------------------------------------------------+
			desc:this function binds the queue with respective exchanges.
		+-------------------------------------------------------------------+ */
		c('CreateQueues----------->>>>SERVER_ID: '+SERVER_ID);

		rabbitConn.queue('emitter_'+SERVER_ID, function (q) {
			q.bind(playExchange, "room.*");
			q.bind(playExchange, "single."+SERVER_ID+".*");
			q.bind(playExchange, "job.*");
			q.bind(playExchange, "rejoin.*");
			q.bind(playExchange, "admin");
			  
			q.subscribe(function(message, headers, deliveryInfo, messageObject) {
				// c('amqp--------------------',message,'----',deliveryInfo);
				if ( !message) {
				  console.log('CreateQueues::::::::::>>>>>Error: "message not found!!!"');

				  return false;
				}
				
				if (deliveryInfo.routingKey.indexOf("room.") != -1) {
					//first we have to get table id from routing key.
					
					var room = deliveryInfo.routingKey.replace('room.', '');
					
					//room must be exists in routing key.
					if (!room) {
						console.log('CreateQueues::::::::::::::::>>>>>>Error: "room not found!!!"');

						return false;
					}
					// c('CreateQueues------room---->>>en: ',message.en);

					// var wData = message;
					// console.log("message:",message);
					var wData = commonClass.enc_web(message);
					var eData = commonClass.Enc(message);
					// console.log("wData:",wData);
					
					// c('CreateQueues--------->>>>>wData: ',wData);

					io.to(room).emit('res', {data:eData});
					io.to(room).emit('resw', {data:wData});

					//playExchange.publish('t.'+room, eData);

					if (message.en == 'LT' && message.data.leave == 1) {
						try {
							var client = io.sockets.connected[message.data.id];

							if (client && typeof client._ir != 'undefined' && client._ir != null && client._ir == 0) {
								c('CreateQueues--------- LT------------>>>>>>client._ir: ', client._ir);
								c('CreateQueues--------- LT -------------------->>>>>Msg:"try to remove socket from table"');
								c('CreateQueues--------- LT-----before----->>>>connected sockets: ', io.sockets.adapter.rooms[message.data.tbid]);

								io.sockets.connected[client.id].leave(message.data.tbid); 
								c('CreateQueues--------- LT-----after----->>>>connected sockets: ', io.sockets.adapter.rooms[message.data.tbid]);

								delete io.sockets.connected[client.id].tbid;
								delete io.sockets.connected[client.id].si;
								delete io.sockets.connected[client.id].gt;
								c('CreateQueues--------- LT ------------------>>>>>Msg: "socket removed from table"');

								if (message.data.flag == 'auto') {
									commonClass.SendData(client, 'PUP', {flag: 'tut', gt: message.data.gt}, 'success:1043');
								} else if (message.data.flag == 'noChips') {
									commonClass.SendData(client,'PUP', {flag:'noChips',gt:message.data.gt,reqChips:message.data.reqChips},'error:1020'); 
									// strClass.outOfChipsPop(client, {flag: 'noChips', gt: message.data.gt, reqChips: message.data.reqChips});
								} else if (message.data.flag == 'lostPool') {
									commonClass.SendData(client, 'PUP', {flag: 'lostPool',pt:message.data.pt}, 'success:1044',true); 
								}

								if (message.data.flag != 'switch' && message.data.flag != 'fns' && !message.data.onInvite) {   //if not leave from switch

									if (message.data.winc > 0) { //win chips
										var winc = commonClass.getWebShortCurrency(message.data.winc);
										var showRate = message.data.showRate;
										// showRate = true;  below code temp comment
										// commonClass.SendData(client, 'PUP', {flag: 'lastPlay', winc: winc, showRate: showRate}, 'success:1006', true);
									}
									else if (message.data.winc < 0) { //chips lost
										var winc = commonClass.getWebShortCurrency( Math.abs(message.data.winc) );
										// commonClass.SendData(client, 'PUP', {flag: 'lastPlay', winc: winc, showRate: false}, 'success:1007', true);
									}
								}
							}
						} catch (e) {
							c('CreateQueues--------- LT::::::::else if::::>>>>>>Error: "client not leave!!!"', e);
						}
					} else if (message.en == 'STNDUP') {

						try {
							var client = io.sockets.connected[message.data.id];
							// c('STNDUP----1----->>>>>');
							if (typeof client._ir != 'undefined' && client._ir != null && client._ir == 0) {
								c('CreateQueues---------  STNDUP ----------->>>>>Msg: "try to delete si from socket"');

								delete io.sockets.connected[client.id].si;
								c('CreateQueues---------  STNDUP------------>>>Msg: "si removed from socket"');
							}
							// delete client.si; 
						} catch(e) {
							// c('STNDUP::::::::::::>>>>>>Error: "client not standup!!!"');
						}
					}
				}
				else if (deliveryInfo.routingKey.indexOf("single.") != -1) {
					// c('CreateQueues-----single----->>>>>en: ',message.en);
					var single = deliveryInfo.routingKey.replace('single.'+SERVER_ID+'.', '');
					var clientObj = io.sockets.connected[single];

					if (clientObj) {
					   c('CreateQueues----->>>>single: ');

					   var eData = commonClass.Enc(message);
					   var wData = commonClass.enc_web(message);
					   c('CreateQueues--single-111-->>>>>'+clientObj.det);

					   clientObj.emit('res', {data:eData});
					   clientObj.emit('resw', {data:wData});

						if (message.en == 'LT' && message.data.leave == 1) {
							try {
								var client = io.sockets.connected[single];
								c('CreateQueues------- LT -------------------->>>>>Msg:"try to remove socket from table"');
								c('CreateQueues------- LT-----before----->>>>connected sockets: ', io.sockets.adapter.rooms[message.data.tbid]);

								io.sockets.connected[single].leave(message.data.tbid);
								c('CreateQueues------- LT-----after----->>>>connected sockets: ', io.sockets.adapter.rooms[message.data.tbid]);

								delete io.sockets.connected[single].tbid;
								delete io.sockets.connected[single].si;
								delete io.sockets.connected[single].gt;
								c('CreateQueues------- LT ------------------>>>>>Msg: "socket removed from table"');
								c('CreateQueues------- LT--------->>>>tbid deleted');


								if (message.data.flag == 'auto') {
									commonClass.SendData(client, 'PUP', {flag: 'tut', gt: message.data.gt}, 'success:1043');
								} else if (message.data.flag == 'noChips') {
									strClass.outOfChipsPop(client,{flag: 'noChips', gt: message.data.gt, reqChips: message.data.reqChips});
								} else if (message.data.flag == 'lostPool') {
									commonClass.SendData(client, 'PUP', {flag: 'lostPool',pt: message.data.pt}, 'success:1044',true); 
								}

								if (message.data.flag != 'switch' && message.data.flag != 'fns' && !message.data.onInvite) {

									if (message.data.winc > 0) { //losses chips
										var winc = commonClass.getWebShortCurrency(message.data.winc);
										var showRate = message.data.showRate;
										//showRate = true;
										// commonClass.SendData(client, 'PUP', {flag: 'lastPlay', winc: winc, showRate: showRate}, 'success:1006', true);
									} else if (message.data.winc < 0) { //chips lost
										var winc = commonClass.getWebShortCurrency( Math.abs(message.data.winc) );

										// commonClass.SendData(client, 'PUP', {flag: 'lastPlay', winc: winc, showRate: false}, 'success:1007', true);
									}
								}
							} catch (e) {
								c('CreateQueues----- LT:::::::if::::::>>>>>>Error: "client not leave!!!"', e);
							}
						} else if (message.en == 'NCC' && message.data.sck) {

							if (typeof message.data.sck == 'string' && message.data.sck != '') {

								var single = message.data.sck.replace(/s\d*_\d*./i,'');
							} else{
								var single = '';    
							}

							c('CreateQueues------------ NCC---------->>>>single: ', single);

							try {
								c('CreateQueues------------ NCC------------>>>>>>before disconnect');

								io.sockets.connected[single].disconnect();
								c('CreateQueues------------ NCC---------->>>>>>>after disconnect');
							} catch(e) {
								c('CreateQueues------------ NCC::::::::::::::::>>>>Error: "socket not disconnected"');
							}
						} 
					}   
				} else if (deliveryInfo.routingKey.indexOf("job.") != -1) {
					if (message.en == 'CTJ') {
						// c('CTJ--------message.data.jid: '+ message.data.jid+' '+new Date());

						if (message.data.jid) {
							// c('CTJ----if---->>>>message.data.jid: ',message.data.jid+' '+new Date());

							schedule.cancelJob(message.data.jid);
						} else {
							
							//TODO: WHEN PROBLEM CAME TAKE LOOK HERE.
						}
						return false;
					}
				} else if (deliveryInfo.routingKey.indexOf("rejoin.") != -1) {
					var rejoinID = deliveryInfo.routingKey.replace('rejoin.', '');

					schedule.cancelJob(rejoinID);
				} else if (deliveryInfo.routingKey.indexOf("admin") != -1) {
					c('CreateQueues------------->>>>>admin: ', message);

					io.sockets.emit('resA', message);
				}
			});
		}); 
		
		//this queue will helpful for cancel job, change config, & change error messages on live server.
		rabbitConn.queue(SERVER_ID, function (q) {
			
			q.bind(jobExchange, SERVER_ID+".*");
			q.bind(jobExchange, "other");
						
			q.subscribe(function(message, headers, deliveryInfo, messageObject) {
				if (!message) {
					return false;
				}
				
				if (message.en == 'RDC') { //Refresh Data Codes
					cdClass.PrepareDataCodes();
				} else if (message.en == 'SBM') { //Set Bot Maker
					cdClass.PrepareScoreData();
				} else if (message.en == 'SBD') { //Set Bot Drop data
					cdClass.PrepareDropData();
				} else if (message.en == 'SBC') { //Set Bot Cards
					cdClass.PrepareRCData();
				} else if (message.en == 'PFC') { //Prepare Feature Data
					cdClass.PrepareFeatureData();
					c('CreateQueues------------->>>>PFC changed message.data: ', message.data);
				}
				else if (message.en == 'SCNF') { //Save config to server
					c('CreateQueues--------------in save config to server=======SCNF======SCNF');

					var prePrefix = config.SERVER;
					config = message.data;
					var postPrefix = config.SERVER;

					//writing file on 2 server for each node on specific server.
					var sArr = SERVER_ID.split('_');
					c('CreateQueues--------->>>>>>prePrefix: '+prePrefix+' postPrefix: '+postPrefix+' sArr: ', sArr);

					if (prePrefix != postPrefix && sArr[0] != postPrefix.split('_')[0]) {
						c('CreateQueues------if---------->>>>>>>>FSC');
						var eData = commonClass.Enc({en: 'FSC', data: {}}); //force server change
						io.sockets.emit('res', eData);
					}

					if (parseInt(sArr[1]) == 1) {
						fs.writeFile("./config.json", JSON.stringify(message.data), function(err) {});
					}
						
					//now we have to broadcase event to all user that server will go in maintenance mode
					if (config.MMSFLAG == true) {
						notiClass.SendMMNotification(); 
					}
				}   
			});
		});
	}
}