var rs = require('randomstring');
var encKey = 'DFK8s58uWFCF4Vs8NCrgTxfMLwjL9WUy';
var sEncKey = 'uWR2YR6xefvCRad7AaME7KTTTnrA78vC'; //server encryption key.
var webKey = '6087819419583180';
var days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
var months = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
cryptos = module.exports = require('crypto-js');

module.exports = {
	
	getIpad:function(client){ 
		/* +-------------------------------------------------------------------+
			desc:this function gives the ip address of the player from socket id.
			i/p:socket object
			o/p:client ip address
		+-------------------------------------------------------------------+ */

      var ipad=  (client.handshake && client.handshake.address) ? client.handshake.address.split(":")[3] : '';       
      return  ipad;
    },
    getIpadFromUrl: function(client) {
    	/* +-------------------------------------------------------------------+
			desc:this function gives the ip address of the player from express req object.
			i/p:client = express req object
			o/p:client ip address
		+-------------------------------------------------------------------+ */
        try{
            var ipad = '';
            //req.connection.remoteAddress
            if(typeof client.connection != 'undefined' && client.connection != null && typeof client.connection.remoteAddress != 'undefined' && client.connection.remoteAddress != null) {
                ipad = client.connection.remoteAddress;
            }
            var ipad1 = ipad.split(":");
            if(typeof ipad1[3] != 'undefined' && ipad1[3] != null && ipad1[3] != '') {
                return ipad1[3];
            } else {
                return ipad;
            }
        } catch(e){
            console.log("getIpadFromUrl : Exception : ", e);
        }


        // var ipad = (typeof client.handshake != 'undefined' && typeof client.handshake.address != 'undefined') ? client.handshake.address.split(":")[3] : '';
        // return ipad;
    },

    GetLanguageCode : function(lc){  
    	/* +-------------------------------------------------------------------+
			desc:this function give the language code of player if outside of this then en default.
			i/p:user languagecode
			o/p:language code
		+-------------------------------------------------------------------+ */

		var langArr = ['en','hi','te'];

		//if undefined from device or flash
		if(!lc){
			return (config.DEFAULT_LANGUAGE && this.InArray(config.DEFAULT_LANGUAGE, langArr))?config.DEFAULT_LANGUAGE:'en';
		}
		else if(!this.InArray(lc.toLowerCase(), langArr)){ // we have only 3 languages, if outside of this then default
			return 'en';
		}
		else{
			return lc;
		}
	},
	GetRandomInt:function (min, max) {  
		/* +-------------------------------------------------------------------+
			desc:this function generates random integer between min and max.
			i/p:min->lower bound,max->upper bound
			o/p:random int 
		+-------------------------------------------------------------------+ */

	    	var rnd = Math.floor(Math.random() * (parseInt(max) - parseInt(min) + 1)) + parseInt(min);
			return Number(rnd);	
	},
	GetRandomString : function(len){ 
	  	/* +-------------------------------------------------------------------+
		desc:this function genrate the random string of particular leangth given as input.
		i/p:leangth
		o/p:string
		+-------------------------------------------------------------------+ */

		if(len)
		{
			if(len == 10){
				return SERVER_ID+"."+rs.generate(len)
			}
			else{
				return rs.generate(len);
			}
		}
		else{
			return rs.generate(32);
		}
	},
    DetectDevice: function(req){
    	/* +-------------------------------------------------------------------+
			desc:this function detect the device type wich is ipod,iphone,ipad or androide.
			i/p:request
			o/p:device type
		+-------------------------------------------------------------------+ */

		var ua = req.headers['user-agent'];
		var obj = {Mobile : false};
		
		if (/mobile/i.test(ua)){
			obj.Mobile = true;
		}
				
		if (/like Mac OS X/.test(ua)) {
			obj.iPod = /iPod/.test(ua);
			obj.iPhone = /iPhone/.test(ua);
			obj.iPad = /iPad/.test(ua);
		}
		
		if (/Android/.test(ua)){
			var t = /Android ([0-9\.]+)[\);]/.exec(ua);
			if(!t)
				return obj;
			obj.Android = t[1];
		}
		
		console.log("DetectDevice---------------obj: ",obj);
		return obj;	
	},
	GetFormatedDateShort: function(d) {
		/* +-------------------------------------------------------------------+
			desc:this function is used to format date in particular format (093344)
			i/p: d = date
			o/p:date in particular format
		+-------------------------------------------------------------------+ */
        var today = new Date(d);
        var dd = today.getDate();
        var mm = today.getMonth() + 1; //January is 0!
        var yyyy = today.getFullYear();
        var hh = today.getHours();
        var m = today.getMinutes();
        var ss = today.getSeconds();

        if (dd < 10) {
            dd = '0' + dd
        }
        if (mm < 10) {
            mm = '0' + mm
        }

        var today = yyyy.toString() + mm.toString() + dd.toString();
        return today;
    },
	getCurrentWeekRange : function(){  
		/* +-------------------------------------------------------------------+
			desc: this function gives the date range of the current week
			i/p: -
			o/p: week start & end date
		+-------------------------------------------------------------------+ */

		var dt = new Object(); //creating new object for return with start date and end date
		var curr = new Date; // get current date
		
		var WeekStartDay = new Date(curr.setDate(curr.getDate() - curr.getDay()));//.toISOString();
		dt.wsd = new Date(WeekStartDay.getFullYear(),WeekStartDay.getMonth(),WeekStartDay.getDate(),0,0,0);
		
		dt.wed = new Date(new Date().getFullYear(),new Date().getMonth(),new Date().getDate(),0,0,0);
		return dt;
	},
	formatDate : function(date){
		/* +-------------------------------------------------------------------+
			desc: this function is used to format date
			i/p: date = date to format
			o/p: formatted date
		+-------------------------------------------------------------------+ */
		if(typeof date == 'undefined' || date == null || date == ""){
			return "";
		}
		else{
			date = new Date(date);
			var dt = date.getDate();

			var suffix = 'th';

			if(dt%10 == 1){
				suffix = 'st';
			}
			else if(dt%10 == 2){
				suffix = 'nd';
			}
			else if(dt%10 == 3){
				suffix =  'rd';
			}
			else{
				suffix = 'th';
			}

			var mnt = date.toLocaleString("en-us", { month: "short" })


			var s = dt+suffix+' '+mnt;
			s = s.toUpperCase();


			return s;

		}
	},
	getDayBetweenTwoDates: function (odate){  
		/* +-------------------------------------------------------------------+
			desc:this function give the number of dates btween two dates
			i/p: secondDate
			o/p: days
		+-------------------------------------------------------------------+ */

		var oneDay = 24 * 60 * 60 * 1000; // hours*minutes*seconds*milliseconds
		var firstDate = new Date();
		var secondDate = new Date(odate);

		var diffDays = Math.round(Math.abs((firstDate.getTime() - secondDate.getTime()) / (oneDay)));
		return diffDays
 	},
 	GetDayRange : function(){  //give the current date time range
 		/* +-------------------------------------------------------------------+
			desc: this function give the current date time range
			i/p: - 
			o/p:
		+-------------------------------------------------------------------+ */
		var start = new Date();
		start.setHours(0,0,0,0);
		
		var end = new Date();
		end.setHours(23,59,59,999);
		
		return {StartTime : new Date(start), EndTime : new Date(end)}; 
	},
	GetFormatedDate : function(d){  //gives current date in formatted way
		/* +-------------------------------------------------------------------+
			desc: this function change the formate of date in 'mm/dd/yyyy' format.
			i/p: date
			o/p: formated date
		+-------------------------------------------------------------------+ */

		var today = new Date(d);
		var dd = today.getDate();
		var mm = today.getMonth()+1; //January is 0!	
		var yyyy = today.getFullYear();
		
		if(dd<10){dd='0'+dd} 
		if(mm<10){mm='0'+mm} 
		

		var today = mm+'/'+dd+'/'+yyyy;
		return today;
	},
	GetFormatedDate1 : function(d){  //gives current date in formatted way
		/* +-------------------------------------------------------------------+
			desc: this function change the formate of date in 'yyyy-mm-dd' format.
			i/p: date
			o/p: formated date
		+-------------------------------------------------------------------+ */

		var today = new Date(d);
		var dd = today.getDate();
		var mm = today.getMonth()+1; //January is 0!	
		var yyyy = today.getFullYear();
		
		if(dd<10){dd='0'+dd} 
		if(mm<10){mm='0'+mm} 
		
		var today = yyyy+'-'+mm+'-'+dd;
		return today;
	},
	GetFormatedDate2 : function(dt){
		var d = new Date();
		var day = days[d.getDay()];
		var hr = d.getHours();
		var date = d.getDate();
		var month = months[d.getMonth()];
		var year = d.getFullYear();

		var dday = day + " " + date + " " + month + " " + year;
		return dday;
	},
	GetTimefor : function(dt){  //gives current date in formatted way
		/* +-------------------------------------------------------------------+
			desc: this function change the formate of date in 'yyyy-mm-dd' format.
			i/p: date
			o/p: formated date
		+-------------------------------------------------------------------+ */
		var d = new Date(dt);
		var hr = d.getHours();
		var min = d.getMinutes();
		if (min < 10) {
		    min = "0" + min;
		}
		var ampm = "am";
		if( hr > 12 ) {
		    hr -= 12;
		    ampm = "pm";
		}

		var dday = hr + ":" + min + ampm
		return dday;
	},
	GetFormatedDateTime: function(d) {
		/* +-------------------------------------------------------------------+
			desc: this function change the formate of date in 'yyyy-mm-dd hh:mm:ss' format.
			i/p: date
			o/p: formated date
		+-------------------------------------------------------------------+ */
        var today = new Date(d);
        var dd = today.getDate();
        var mm = today.getMonth() + 1; //January is 0!
        var yyyy = today.getFullYear();
        var hh = today.getHours();
        var m = today.getMinutes();
        var ss = today.getSeconds();

        if (dd < 10) {
            dd = '0' + dd
        }
        if (mm < 10) {
            mm = '0' + mm
        }

        if (hh < 10) {
            hh = '0' + hh
        }
        if (m < 10) {
            m = '0' + m
        }
        if (ss < 10) {
            ss = '0' + ss
        }

        var today = yyyy + '-' + mm + '-' + dd + ' ' + hh + ':' + m + ':' + ss;
        return today;
    },
	RoundInt : function(n,d){
		/* +-------------------------------------------------------------------+
			desc: this function is used to round the decimal number 
			i/p: n = number ,d = digits required after decimal places
			o/p: formatted date
		+-------------------------------------------------------------------+ */
		n = Math.round(n*Math.pow(10,d));

		n = n/(Math.pow(10,d));
		return n;
	},
	SendData:function(client, en, dt, msgDefination, parseFlag){  
		/* +-------------------------------------------------------------------+
			desc: this function send data to server by socket.
			i/p:
				client : Using this object instance we can emit the message & data
				en : Which event we have to update.
				dt : Object or array of data which we need to send.
				msgDefination : Defination of message which type of message we have to emit. E.X : error:1001
				parseFlag : Any message need to parse with sent data or not. if true i will parse the message.
			o/p: send data
		+-------------------------------------------------------------------+ */

		c('\n[ SendData ]----------------------------((( '+en+' ))))-------ooooooooooooooooooooooooooooo   Time: '+new Date().getHours()+':'+new Date().getMinutes()+':'+new Date().getSeconds()+':'+new Date().getMilliseconds());
		
		if(client && typeof client == 'object'){
			if(dt){
			 	//we have split message type and message content from here.


				if(!msgDefination){
					var def = 'success:0000';
					var msgDefination = (client.lc) ? client.lc+":"+def  : 'en:'+def ;
				}
				else{

					var msgDefination = (client.lc) ?  client.lc+":"+msgDefination :'en:'+msgDefination ;
				}
			 	c('SendData--------1-------->>>>>msgDefination: ',msgDefination,' lc: '+client.lc+' client.vc: '+client.vc+' client.isOppo: '+client.isOppo);

			 	
			 	if(client.det == 'flash' || client.det == 'html' || client.det == 'android' && typeof client.vc != 'undefined' && (typeof client.isOppo != 'undefined' && client.isOppo == 1 && parseInt(client.vc) > 4 || 15 < parseInt(client.vc)) || client.det == 'ios' && typeof client.v != 'undefined' && commonClass.checkVer("1.6",client.v.toString())){

				 	var lc = msgDefination.split(':')[0];
				 	var type = msgDefination.split(':')[1];
				 	var code = msgDefination.split(':')[2];

				 	if(code == '9006'){
				 		 code = '9800';
				 	}
				 	else if(code == '1019'){
				 		code = '9801';
				 	}
				 	else if(code == '8002'){
				 		code = '9802';
				 	}
				 	else if(code == '7002'){
				 		code = '9803';
				 	}
				 	else if(code == '3003' && type == 'coins'){
				 		code = '9804';
				 	}
				 	else if(code == '3009'){
				 		code = '9805';
				 	}
				 	else{

				 	}

				 	msgDefination = lc+':'+type+':'+code;
			 	}

			 	c('sendData--------1.5--------->>>>>msgDefination: '+msgDefination);



				if(!dataCodesArr[msgDefination]){
					msgDefination = 'en:'+msgDefination.split(':')[1]+':'+msgDefination.split(':')[2];
				}

			 	c('SendData--------2-------->>>>>msgDefination: ',msgDefination,' lc: '+client.lc);
				var msgArr = (msgDefination).split(':');
			}
			else{
				var msgArr = ['en','error', '1111'];
			}
			// console.log('SendData: ',dataCodesArr[msgDefination]);
		 	//we have to prepare message from defined message for success, notification and error
			var data  = { flag : (msgArr[1] == 'error') ? false : true, errorCode : msgArr[2],title: dataCodesArr[msgDefination].Title,lc:dataCodesArr[msgDefination].Lc,
		 			   msg : (dataCodesArr[msgDefination]) ? dataCodesArr[msgDefination].Message : 'Unknown Error!!!',  
					   en : en, data : dt };
					   			   
			//if any message need to parsing the data then we have parse it manually
			if(parseFlag && dt){
				data.msg = this.KeywordReplacer(dt, data.msg);
			} 
		

			c('data = ',data,'\n');
			// var eData = commonClass.Enc(data);
			// var eData = data;
			
			// if(client.frm == 'io'){
				
			// 	var single = client.sck.replace(SERVER_ID+".","");
			// 	if(io.sockets.connected[single]){
			// 		io.sockets.connected[single].emit('res', eData);
			// 	}
			// }
			// else{
				c("\n\n\nsendData -- en ---->"+en)
				c("sendData -- dt ---->",dt)
				playExchange.publish("single."+client.sck, data);
			// }
		}
		else{
			c('SendData---------->>>>>>Msg"socket not found"');
		}
	},
	SendDirect: function(qid, data, flag){ // send data direct to player; flag = true for qid = uid OR false for qid = client.sck
		/* +-------------------------------------------------------------------+
			desc: this function send data direct to player from userid.
			i/p:
				qid = uid,
				data = data to send to user
				flag = true
			o/p: send data
		+-------------------------------------------------------------------+ */

		c('\n[ SendDirect ]----------------------------((( '+data.en+' )))--------ooooooooooooooooooooooooooooo   Time: '+new Date().getHours()+':'+new Date().getMinutes()+':'+new Date().getSeconds()+':'+new Date().getMilliseconds());
		c('data = ',data.data,'\n');
		if( !qid || qid == ''){
			c('SendDirect:::::::::::::Error:  "qid not found!!!"');
			return false;
		}

		if(flag == true){

			cdClass.GetUserInfo(qid, { sck : 1, "flags._io" : 1, "flags._ir" : 1},function(rcu){
				// c('SendDirect--------->>>>>>rcu: ',rcu);
				if(rcu && rcu.flags && rcu.flags._io == 1 && rcu.flags._ir == 0 && rcu.sck != ''){
					// c('SendDirect-----if---->>>>>>rcu: ',rcu);
					playExchange.publish("single."+rcu.sck, data);
				}
				else{
					c('SendDirect::::::::::::::::::::::::>>>>>>Error: "table not found"');
				}
			}) 
		}
		else{
			// c('SendDirect--------->>>>>>qid: ',qid);
			playExchange.publish("single."+qid, data);
		}
	},
	FireEventToTable: function(tbId, dataToSend, msgNoti){  //send data to the table 
		/* +-------------------------------------------------------------------+
			desc: this function send data to table from table_id.
			i/p: tableid,data to send
			o/p: send data 
		+-------------------------------------------------------------------+ */
		
		c('\n[ FireEventToTable ]--------<<<tbId: '+tbId+'>>>--------((( '+dataToSend.en+' )))------ooooooooooooooooooooooooo   Time: '+new Date().getHours()+':'+new Date().getMinutes()+':'+new Date().getSeconds()+':'+new Date().getMilliseconds());
		c('data = ',dataToSend.data,'\n');
		if(!tbId){
			c('FireEventToTable::::::::::::>>>>>Error: "tbId not found!!!"');
			return false;
		}
		//include Stand for that if we have to include current socket id or not.
		
		
		if(typeof tbId == 'string' && tbId.length > 23)
		{
			
			if(msgNoti)
			{
				dataToSend.data.msg = "";
				dataToSend.data.key = msgNoti;
			}
		
			// playExchange.publish('t.'+tbId, commonClass.Enc(dataToSend));
			c("\n\n\nsend -- en ---->"+dataToSend.en)
			c("send -- data ---->",dataToSend.data)
			playExchange.publish("room."+tbId, dataToSend);
		}
	},
	KeywordReplacer:function(dt, str){  
		/* +-------------------------------------------------------------------+
			desc: this function replace the keyword(string) in array. 
			i/p:
				dt : total subset of array keyword.
				str : in which string you want to replace keyword.
			o/p: updated string
		+-------------------------------------------------------------------+ */

		for(var y in dt){  
			eval("str = str.replace(/\\[\\["+y+"]\\]/g, dt."+y+");"); 
		}
		for(var z in config){  
			eval("str = str.replace(/\\[\\["+z+"]\\]/g, config."+z+");"); 
		}
		
		return str;
	},
	checkVer:function(oldVer,newVers){	

		/* +-------------------------------------------------------------------+
			desc: this function is used to check whether the version of app is older or not 
			i/p:
				oldVer : older version of app
				str : newer version of app
			o/p: true/false
		+-------------------------------------------------------------------+ */
	    if(typeof oldVer == 'undefined' || oldVer == null){
	        oldVer = '0';
	    }
	    if(typeof newVers == 'undefined' || newVers == null){
	        newVers = '0';
	    }

	    var version = oldVer.split('.');
	    var newVersion = newVers.split('.');




	    if(newVersion.length == 2){
	        newVersion.push(0);
	    }
	    else if(newVersion.length == 1){
	        newVersion.push(0);
	        newVersion.push(0);
	    }
	    else{

	    }
	    if(version.length == 2){
	        version.push(0);
	    }
	    else if(version.length == 1){
	        version.push(0);
	        version.push(0);
	    }
	    else{

	    }

	    if(version[0] < newVersion[0]){

	        return true;
	        
	    }
	    else if(version[0] == newVersion[0]){
	        if(version[1] < newVersion[1]){
	            return true;
	        }
	        else if(version[1] == newVersion[1]){
	            if(version[2] < newVersion[2]){
	                return true;
	            }
	            else{
	                return false;
	            }
	        }
	        else{
	            return false;
	        }
	    }
	    else{
	        
	        return false;
	    }
	},
	enc_web:function(s){
		var ENCKEY = "DFK8s58uWFCF4Vs8NCrgTxfMLwjL9WUy";
		var ciphertext = cryptos.Rabbit.encrypt(JSON.stringify(s), ENCKEY).toString();
  		return ciphertext;
  		// return s;
	},
	dnc_web:function(s){
		var ENCKEY = "DFK8s58uWFCF4Vs8NCrgTxfMLwjL9WUy";
		var decryptedData = JSON.parse(cryptos.Rabbit.decrypt(s,ENCKEY).toString(cryptos.enc.Utf8));
        return decryptedData;
	},
	enc_dec:function(s) {
		/* +-------------------------------------------------------------------+
			desc:this function encrypt and decrypt the data.
			i/p: data
			o/p: encrypted/decrypted data
		+-------------------------------------------------------------------+ */
		if(typeof s != 'string'){

	    	s=JSON.stringify(s);
		}
	    var k = webKey;
	    var enc = "";
	    var str = "";
	    // make sure that input is string
	    // str = s.toString();
	    for (var i = 0; i < s.length; i++) {
	        // create block
	        var a = s.charCodeAt(i);
	        // bitwise XOR
	        var b = a ^ k;
	        enc = enc + String.fromCharCode(b);
	    }
	    return enc;
	},
	Encbs: function(pt){
		var data = JSON.stringify(pt);
		console.log("data:",data);
		let buff = new Buffer.from(data);
		let stringToDecode = buff.toString('base64');

		var strings = '';
		var nxtPos = 10;
        var index = 0;
        while (index < stringToDecode.length) {

        	strings += 'A'+stringToDecode.slice(index, Math.min(index + nxtPos, stringToDecode.length));
            index += nxtPos;
        }

        console.log("strings:",strings);
        return strings; 
	},
	Enc: function(toCrypt, private){
		/* +-------------------------------------------------------------------+
			desc: this function encrypt the data.
			i/p: plain data
			o/p: encrypted data
		+-------------------------------------------------------------------+ */

		// keyBuf = new Buffer(Array(32));
		keyBuf = Buffer.from(Array(32));

		var ek = (private) ? sEncKey : encKey;

		keyBuf.write(ek, 'utf8');
		ivBuf = Buffer.from(Array(16));
		// ivBuf = new Buffer(Array(16));

		var cipher = crypto.createCipheriv('aes256', keyBuf, ivBuf);
				
		output = cipher.update(JSON.stringify(toCrypt), 'utf-8', 'base64') + cipher.final('base64');
		return output; 
	},
	Dec: function(request,private){
		/* +-------------------------------------------------------------------+
			desc: this function decrypt the data.
			i/p: encrypted data
			o/p: decrypted data
		+-------------------------------------------------------------------+ */

		// keyBuf = new Buffer(Array(32));
		keyBuf = Buffer.from(Array(32));
		// Copy the key into this buffer
		var ek = (private) ? sEncKey : encKey;

		keyBuf.write(ek, 'utf8');

		// Create the 16-byte zero-filled IV buffer
		// ivBuf = new Buffer(Array(16));
		ivBuf = Buffer.from(Array(16));
		var deCipher = crypto.createDecipheriv('aes256', keyBuf, ivBuf);

		try{ 

			decrypted = deCipher.update(request,'base64','utf8') + deCipher.final('utf8');
			return JSON.parse(decrypted);
		}
		catch(e){

			c(request);
			c(e);
			return null;
		}
	},
	GetTimeDifference : function(startDate, endDate, type){
		/* +-------------------------------------------------------------------+
			desc: this function return time difference between two dates.
			i/p: start_date,end_date
			o/p: timedifference
		+-------------------------------------------------------------------+ */
		// c("GetTimeDifference-----------date1",startDate,"--------date2",endDate);
	  	var date1 = new Date(startDate);
		var date2 = new Date(endDate);
		var diffMs = (date2 - date1); // milliseconds between now & Christmas
		// c("GetTimeDifference-----------date1",date1,"--------date2",date2);
		if(type == 'day'){

			var date1 = new Date(startDate.getFullYear(), startDate.getMonth(), startDate.getDate(),0,0,0);
			var date2 = new Date(endDate.getFullYear(), endDate.getMonth(), endDate.getDate(),0,0,0);
			var timeDiff = Math.abs(date2.getTime() - date1.getTime());
			var diffDays = Math.ceil(timeDiff / (1000 * 3600 * 24)); 
			return diffDays;
		}
		else if(type == 'hour'){

			return Math.round((diffMs % 86400000) / 3600000); 
		}
		else if(type == 'minute'){

			return Math.round(((diffMs % 86400000) % 3600000) / 60000);
		}	
		else{

		 	return Math.round((diffMs / 1000));	
		}
	},
	getDuration: function (startDate,endDate,lc,admin){ //give time duration with unit
		/* +-------------------------------------------------------------------+
			desc:this function returns time difference string
			i/p: startDate = start date
				 endDate = end date
				 lc = language code
				 admin = true/false sts for admin
			o/p: msg = message
		+-------------------------------------------------------------------+ */
		var diff = endDate.getTime()-startDate.getTime();
		diff = Math.round(diff/1000);

		var obj = {msg:'',value:''};
		if((r = Math.floor(diff/31536000)) > 1){  //years ago
			
			obj = {msg:'9901',value:r};
		}
		else if((r = Math.floor(diff/31536000)) == 1){ //year ago
			
			obj = {msg:'9902',value:r};
		}
		else if((r=Math.floor(diff/2592000)) > 1){ //months ago
			
			obj = {msg:'9903',value:r};
		}
		else if((r=Math.floor(diff/2592000)) == 1){ //month ago
			
			obj = {msg:'9904',value:r};
		}
		else if((r=Math.floor(diff/86400)) > 1){ //days ago
			
			obj = {msg:'9905',value:r};
		}
		else if((r=Math.floor(diff/86400)) == 1){ //day ago
			
			obj = {msg:'9906',value:r};
		}
		else if((r=Math.floor(diff/3600)) > 1){ //hours ago
			
			obj = {msg:'9907',value:r};
		}
		else if((r=Math.floor(diff/3600)) == 1){ //hour ago
			
			obj = {msg:'9908',value:r};
		}
		else if((r=Math.floor(diff/60)) > 1){ //minutes
			
			obj = {msg:'9909',value:r};
		}
		else if((r=Math.floor(diff/60)) == 1){
			
			obj = {msg:'9910',value:r};
		}
		else{
			
			if(admin){
				obj = {msg:'9911',value:''};
			}
			else{

				obj = {msg:'9912',value:''};
			}
		}

		var type = lc+":time:"+obj.msg;
		if(!dataCodesArr[type]){
			type = 'en:time:'+obj.msg;
		}
		c('getDuration------------>>>>>>>type: '+type+' obj.value: '+obj.value+' dataCodesArr[type]: ',dataCodesArr[type]);
		var msg = commonClass.KeywordReplacer({v:obj.value},dataCodesArr[type].Message);
		return msg;
	},
	chipsFormat:function(chips){ //fomat the chips in 'cr' and 'l'
		/* +-------------------------------------------------------------------+
			desc:this function is used to format chips
			i/p: chips = chips
			o/p: chips
			//npm abbreviate,numeral
		+-------------------------------------------------------------------+ */
		var iteration = '';
		var d;
		if (chips >= 10000000) {
            d = chips / 10000000;
            iteration = "CR";
        } else if (chips >= 100000) {
            d = chips / 100000;
            iteration = "L";
        } else {
            d = chips;
        }
      	//d = Math.round(d);
      	//chips = commonClass.RoundInt(d,2);
      	// c("chipsFormat------------------chips",chips);
        chips = commonClass.RoundInt(d,2);
        chips = chips + "" + iteration;
		// c("chipsFormat------------------chips",chips);
        return chips;
	},
	getNumberRang:function(no){
		
        var t = 0;
        var f = 0;
        for(var i=no-1;i>=no-50;i--){

            if(i%50 == 0){
                t = i+1; 
                break;
            }
        }
        for(var j=no;j<=no+50;j++){

            if(j%50 == 0){
                f = j;
                break;
            }
        }
        return t+"-"+f;
    },
    AddTime: function(t){
		//t will be in second how many second you want to add in time.
		/* +-------------------------------------------------------------------+
			desc: this function add the time(seconds) in time.
			i/p: seconds
			o/p: addedseconds
		+-------------------------------------------------------------------+ */

		var ut = new Date();
		ut.setSeconds(ut.getSeconds() + Number(t));
		return ut;
	},
	AddTimeD: function(sdate,t){
		/* +-------------------------------------------------------------------+
			desc: this function add the time(seconds) by adding sDate in time.
			i/p: sDate = start date , t = seconds to add
			o/p: new time after adding date
		+-------------------------------------------------------------------+ */
		//c("sdate",typeof sdate);
		//c("new date",typeof new Date());
		var ut = new Date(sdate);
		ut.setSeconds(ut.getSeconds() + Number(t));
		return ut;
	},
	subTime: function(t) {
        var ut = new Date();
        ut.setSeconds(ut.getSeconds() - Number(t));
        return ut;
    },
    subTimeD: function(sdate,t){
    	var ut = new Date(sdate);
		ut.setSeconds(ut.getSeconds() - Number(t));
		return ut;
    },
	PrepareId : function(sPrefix, id){
		/* +-------------------------------------------------------------------+
			desc: this function is used to create socket id
			i/p: sPrefix = server id, id = socket id
			o/p: formatted socket id
		+-------------------------------------------------------------------+ */
		return sPrefix+"."+id;
	},
	uenc : function(str){
		/* +-------------------------------------------------------------------+
			desc: this function is used to encode url
			i/p: str = url string
			o/p: encoded url string
		+-------------------------------------------------------------------+ */
		return encodeURIComponent(str).replace(/'/g,"%27").replace(/"/g,"%22");
	},
	GetGameConfig: function(){
    	/* +-------------------------------------------------------------------+
			desc: this function is used to get game config
			o/p: config details
		+-------------------------------------------------------------------+ */
		var dt = {};

		var ro = [
			"INITIAL_CHIPS",
			"FB_CHIPS",
			"PAYMENT_FAIL_PUP",
			"BU",
			"FB_API_V",
			"FB_INSTANT_APP_SECRET",
			"RABU",
			"GAME_NAME",
			"MAX_DEADWOOD_PTS",
			"MIN_SEAT_TO_FILL",
			"MIN_SEAT_TO_FILL_BET",
			"MM",
			"FIRST_DROP",
			"FIRST_DROP",
			"HOURLY_BONUS_TIME",
			"HOURLY_BONUS_CHIPS",
			"MIDDLE_DROP",
			"DEAL_PLAYER_SELECTOR",
			"REPICK",
			"REPICK_TIME",
			"DST",
			"NXT",
			"RST",
			"STT",
			"FNS",
			"FBAI",
			"FBAN",
			"CB_STT",
			"SHOW_INTRO_VIDEO",
			"INTRO_VIDEO_LINK",
			"PRIVACY_LINK",
			"TERMS_LINK",
			"ARTRULES_LINK",
			"SHOW_GOLD_SPIN",
			"AUTO_GUEST_LOGIN",
			"ONE_SEQUENCE_POINTS",
			"LINKS",
			"FPS_BTN",
			"FPS_TIME",
			"ASSIST_TUT",
			"SORT_BTN_SHOW_GAME_COUNT",
			"CONTACT_NO",
			"SORT_BTN_SHOW",
			"DECL_BTN_ON_CENTRE",
			"ADD_HERE_BTN",
			"BWIDTH_TIME",
			"DAILYBONUS",
			"PING_INTERVAL",
 			"PONG_TIMER"
		];


		for (var k in config) {

			if ( ro.indexOf(k) != -1) {
				dt[k] = config[k];
			}
		}

		return dt;
	},
	arrayUnique : function(a) {
	    return a.reduce(function(p, c) {
    	    if (p.indexOf(c) < 0) p.push(c);
        	return p;
	    }, []);
	},
	LoadBalancer: function(callback){
		/* +-------------------------------------------------------------------+
			desc: this function is used to distribute server among players
			i/p: callback = callback function
			o/p: returns allocated server details
		+-------------------------------------------------------------------+ */
		rClient.zscan('servers',0,'MATCH',config.SERVER,function (err, servers) { 
			c('LoadBalancer--------->>>>>servers: ',servers);
            rClient.hgetall(servers[1][0], function (err, finalServer) {
                return callback(finalServer);
            });
        });
	},
	delete2dArrRow:function (arr, row) {
	   	
	   arr = arr.slice(0); // make copy
	   arr.splice(row, 1);
	   return arr;
	},
	sendMail :function(data,cb){
   		/* +-------------------------------------------------------------------+
			desc: function to send mail
			i/p: data = {to: receivers mail id,subject = subject, html = html body}
			o/p: returns error if any
			//sendgrid
		+-------------------------------------------------------------------+ */
		var transport = nodemailer.createTransport(ses({
				   AWSAccessKeyID: "",
				   AWSSecretKey: ""
		}));
		// Message object
		transport.sendMail({
		   from : 'Team11 Rummy <no-reply@new-dev.artoon.in.com>',
		   to : data.to,
		   subject : data.subject,
		   html:data.html
		},function(error){
			if(error){

				c('sendMail::::::::::::>>>>error: '+error);
			}
			else{
				c('sendMail------------>>>>>>Msg: "mail sent"');
			}
            if(typeof cb =='function'){
                return cb(error);
            }else{
                return error;
            }
        });
    },
    DifferArray: function(a1, a2) {
		var a = [], diff = [];
		for (var i = 0; i < a1.length; i++) {
			a[a1[i]] = true;
		}
		for (var i = 0; i < a2.length; i++) {
			if (a[a2[i]]) {
			   delete a[a2[i]];
			} 
			else {
			   a[a2[i]] = true;
			}
		}
		for (var k in a) {
			diff.push(k);
		}
		return diff;
   	},
	InArray: function(needle, haystack) {
		/* +-------------------------------------------------------------------+
			desc: check if the element is in array
			i/p: needle = element to find, haystack = array
			o/p: true/false 
		+-------------------------------------------------------------------+ */
	 	if(!haystack || !needle){
			return false;
	 	}
			
	    var length = haystack.length;
	    for(var i = 0; i < length; i++){
	        if(haystack[i] && haystack[i].toString() == needle.toString()){
				return true;
	        }
	    }
	    return false;
	},
	shuffleArray: function(a){  //shuffle the array elements
		/* +-------------------------------------------------------------------+
			desc: shuffle array elements
			i/p: a = array
			o/p: shuffled array
		+-------------------------------------------------------------------+ */
		var temp = _.clone(a);
		var shuffle = [];
		while(temp.length > 0){ 
			rt = Math.floor(Math.random()*temp.length);
			shuffle.push(temp[rt]);
			temp.splice(rt,1);
		}
		return shuffle;
	},
	getMedian: function(score){   //score = array of numbers
		/* +-------------------------------------------------------------------+
			desc: this function is used to get median
			i/p: score = array of integers
			o/p: return median
		+-------------------------------------------------------------------+ */
		if(score.length > 0 ){

			score.sort();
			

			var half = Math.floor(score.length / 2);
			

			if(score.length%2 == 1){  //odd no. of scores
				return score[half];
			}
			else{   //even number of score
				return Math.round((score[half-1] + score[half])/2);
			}	
		}
		else{
			return 0;
		}
	},
	getShortCurrency: function(amount) {
		/* +-------------------------------------------------------------------+
			desc: format the currency
			i/p: amount = amount
			o/p: returns formatted currency 
		+-------------------------------------------------------------------+ */
        return (Number(amount) > 9999999) ? (amount / 10000000) + 'Cr' : (Number(amount) > 99999) ? (amount / 100000) + 'L' : amount;
    },
    getWebShortCurrency: function(amount) {
    	/* +-------------------------------------------------------------------+
			desc: format the currency
			i/p: amount = amount
			o/p: returns formatted currency 
		+-------------------------------------------------------------------+ */
        return (Number(amount) > 9999999) ? Math.round(amount / 10000000) + 'Cr' : (Number(amount) > 99999) ? Math.round(amount / 100000) + 'L' : amount;
    },
    InMaintenanceMode: function(){
        /* +-------------------------------------------------------------------+
            desc:function to check if the server is in maintenance mode or not 
            o/p: true/false
        +-------------------------------------------------------------------+ */
        var nd = new Date();
        if(config.MMSFLAG == true){

            if(nd >= new Date(config.MMSD) && nd <= new Date(config.MMED)){
                c('InMaintenanceMode--------------->>>>>"in maintenance mode"');
            	// config.MM = true; //assigning true to main flag for display maintenance screen 
            	return true;
            }
            else if (nd > new Date(config.MMED)){
                c('InMaintenanceMode--------------->>>>>>"maintenance mode end"');
            	// config.MMSFLAG = false; //got to live mode
            	// config.MM = false; //got to live mode
            	return false; 
            }
            else{
                c('InMaintenanceMode--------------->>>>>"anonymous case"');
            	return false;
            }
        }
        else{
            c('InMaintenanceMode----------------->>>>"switch off"');
            // config.MM = false; //got to live mode
        	return false;
        }
	},
    formatCurrency:function(amount){
    	/* +-------------------------------------------------------------------+
			desc: format the currency
			i/p: amount = amount
			o/p: returns formatted currency 
		+-------------------------------------------------------------------+ */


		
        var returnVal = '';

        var d = 0;
        var  iteration = '';
        if (amount >= 10000000) {
            d = amount / 10000000;
            iteration = "CR";
        } else if (amount >= 100000) {
            d = amount / 100000;
            iteration = "L";
        } else if (amount >= 10000) {
            d = amount / 1000;
            iteration = "K";
        } else {
            return commaNumber(amount);
        }

       isRound = (d * 10) % 10 == 0;
        if (isRound) {
            returnVal = d * 10 / 10 + "";
        } 
        else {
            returnVal = commonClass.RoundInt(d,2)+'';
        }

       
        var s = returnVal.split(".");
        if (s.length >= 2 && s[1] == 0) {
            returnVal = s[0];
        }
        
        returnVal = commaNumber(returnVal) + " " + iteration;
        return returnVal;
    }
    
}