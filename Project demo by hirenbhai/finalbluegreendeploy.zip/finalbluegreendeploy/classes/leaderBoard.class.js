module.exports = {
    LB: function (data, client) { //leaderboard
        cdClass.GetUserInfo(client.uid, {
            av: 1,
            iv: 1,
            det: 1
        }, function (uInfo) {
            if (data.Filter == 'global') {
                db.collection('game_users').find({"flags._ir":0}).project({
                    _id: 1,
                    un: 1,
                    pp: 1,
                    Chips: 1,
                    totalcash: 1,
                    "counters.lvc": 1,
                    "counters.ppo": 1,
                    club: 1,
                    fid: 1,
                    det: 1
                }).sort({
                    "counters.lvc":-1,
                    "counters.ppo":-1
                }).limit(50).toArray(function (err, resp) {

                    // fetching user id  from friends facebook id
                    var final = {
                        resp: resp,
                        type:"global"
                    };
                    commonClass.SendData(client, 'LB', final);                        
                });
            } else if (data.Filter == 'friend') {
                // fetching user id  from friends facebook id
                db.collection('game_users').find({"flags._ir":0}).project({
                    _id: 1,
                    un: 1,
                    pp: 1,
                    Chips: 1,
                    totalcash: 1,
                    "counters.lvc": 1,
                    "counters.ppo": 1,
                    club: 1,
                    fid: 1,
                    det: 1
                }).sort({
                    "counters.lvc":-1,
                    "counters.ppo":-1
                }).limit(50).toArray(function (err, resp) {

                    // fetching user id  from friends facebook id
                    var final = {
                        resp: resp,
                        type:"friend"
                    };
                    commonClass.SendData(client, 'LB', final);                        
                });
               /* var fIds = [];
                db.collection('user_friends').findOne({uid:MongoID(client.uid)},{fields:{friends:1}},function(err,userFnd){
                    if(userFnd){
                        fIds = userFnd.friends;
                        var wher = {
                            $or:{
                                "_id":{$in:fIds},
                                "_id":MongoID(client.uid)
                            }
                        }
                        // db.collection('game_users').find({_id:{$in:fIds}}).project({
                        db.collection('game_users').find(wher).project({
                            _id:1,
                            un:1,
                            pp:1,
                            Chips: 1,
                            totalcash: 1,
                            "counters.lvc": 1,
                            "counters.ppo": 1,
                            club: 1,
                            det: 1,
                            tbid:1
                        }).sort({
                            "counters.lvc":-1,
                            "counters.ppo":-1
                        }).toArray(function(err1, userInfo){
                            
                            for(var i in userInfo){
                                if(userInfo._id.toString() == client.uid){
                                    
                                }
                            }
                            
                            var final = {
                                resp: userInfo,
                                type:"friend"
                            };
                            commonClass.SendData(client,'LB',final);
                        });
                    }
                });*/
            }
        });
    }
}