module.exports = {
	init: function(){ 
	  	/* +-------------------------------------------------------------------+
            desc: function to initialize socket server
        +-------------------------------------------------------------------+ */
	    //decrement online players from redis.
		rClient.zscore("servers", SERVER_ID, function(err, cPlayers){ 
		
			if(parseInt(cPlayers) > 0){
				rClient.decrby("onlinePlayers", cPlayers); //decrements the players which are connected to this
			}
			
			rClient.hmset(SERVER_ID, "host", SERVICE_HOST, "port", SERVER_PORT, "proto" , SERVER_PROTO); //saving server information to SERVER_ID hash
			rClient.zadd('servers',0,SERVER_ID);
			
			
		});
		cdClass.PrepareDataCodes(function(){ //Generate global array for data code [Error, success]
			cdClass.PrepareFeatureData(function(){ //Generate global arrays to set game feature
				cdClass.PrepareScoreData(function(){//Generate global arrays to initialize user score data
					cdClass.PrepareRCData(function(){
						cdClass.PreparePlayData(function(){
							cdClass.PrepareDropData(function(){
								c('init-------1---->>>>>>>');
						
								// robotsClass.robotTurnStarted_new();
								io.sockets.on("connection", function (socket) {
						            c("conncrion ");
						            
						            rClient.zincrby('servers', 1, SERVER_ID);
						            rClient.incr('onlinePlayers');
						            // var wData = commonClass.Enc({en:'DONE',data:{}});
						            // socket.emit('resw', wData);
						            socket.sck = commonClass.PrepareId(SERVER_ID, socket.id);
						            commonClass.SendDirect(socket.sck, {en: "DONE",data: {}});
						            ecClass.BindSocketToEvent(socket);
						        });


								/*io.sockets.on("connection",  function(socket){
									c('socket connected ',socket.id);

									rClient.zincrby('servers', 1, SERVER_ID);
									rClient.incr('onlinePlayers');

									setTimeout(function(){
										var wData = commonClass.enc_dec({en:'DONE',data:{}});
									    // io.sockets.connected[socket.id].emit('resw', wData);
									    socket.emit('res', wData);
										c('init------------>>>>"DONE sent"');
									},1000);



									ecClass.BindSocketToEvent(socket);
								});*/
							});
						});
					});
				}); 
			});
		});
	},
	eventHub:function(request,socket){
		/* +-------------------------------------------------------------------+
            desc: function to handle all event processes
            i/p: request = {en = event name,data = data for event},socket = socket object
        +-------------------------------------------------------------------+ */
				
		if(typeof request == 'string'){
			console.log("eventHub:--------->>>>>>>>>>>>>request:"+request);
			request = JSON.parse(request);
		}
		if(!request){

			return false;
		}

		var en = request.en;
		if(en != 'HB'){
			c('\n\n\n----------------------------((( '+en+' )))--------iiiiiiiiiiiiiiiiiiiiiiiiiiii   Time: '+new Date().getHours()+':'+new Date().getMinutes()+':'+new Date().getSeconds()+':'+new Date().getMilliseconds());
			c('data = ',request.data,'\n');
		}
		switch(en){	
				case 'FTAJ': // Find Table And Join point rummy
				case 'FTAJC': //find table and join cash mode point rummy
				case 'FTAJDM': //Find Table And Join Deal Mode 
				case 'FTAJDMC': //find table and join cash mode deal rummy
				case 'FTAJPM'://Find Table And Join Pool Mode
				case 'FTAJPMC'://Find table and join pool cash mode 
				case 'FTAJBM': //Find Table And Join Bet Mode
				case 'FTAJBMC'://find table and join cash mode Bet rummy
				case 'JFT': //join friend table
				case 'GTI' : //Get Table Info
				case 'PFQ':// Play For Quest
				case 'GPT': //Get Private Table
				case 'CPT':// Create Private Table
				case 'PFGP':// Play From Generic Popup
				case 'GPTCL'://get pool playing cat
				case 'GPTC'://get point rummy category
				case 'LASTDEAL': //get last deal data
				case 'GPTI': //get game information
				case 'REFRESH': //refresh game
					playingTableClass[en](request.data, socket);
					break;
					
				case 'MP': //My Profile
				case 'UUN': //update user name
				case 'CGS': //change game settings
				case 'GS': //get game settings
					profileClass[en](request.data,socket);
					break;

				case 'SP': // sign up 
				case 'GGC'://GetGameConfig.
					signupClass[en](request.data,socket);
					break;
				
				case 'LOGOUT': //logout
				case 'RJT':  //Rejoin Table
					dashboardClass[en](request.data,socket);
					break;
					
				case 'SCD' : //save cards	
				case 'SMC':  //See My Cards
				case 'PFCD':  //Pick From Close Deck
				case 'PFOD': //Pick From Open Deck
				case 'DSCRD': //Discard card
				case 'LT': //Leave Table
				case 'DRCA': //Drop Cards
				case 'DRC': //Drop Cards
				case 'FNS': //Finish
				case 'DECL': //Declare
				case 'STNDUP': // standup
				case 'JNBK': // join back
				case 'SWTL': // switch table
				case 'SWINF': //information before switch table
				case 'DC': // discarded cards
				case 'SORT': // sort cards
					playClass[en](request.data,socket);
					break; 

				case 'GBL': //get buddi list
				case 'SINV': //Send Invite request
				case 'ACINV': //Accept friend request
				case 'JTFL': //join table from shared link
					buddiesClass[en](request.data,socket);
					break;

				case 'LB':
					leaderBoardClass[en](request.data,socket);
					break;
					
				case 'FM': //Feedback Message
				case 'RAP': //report a problem
				case 'RPD': //report problem data
				case 'GFM': // Get Feedback Messages
				case 'GFNC': // Get Feedback Notification Counter
					fbClass[en](request.data,socket);
					break;

				case 'LN': //Language code
					langClass[en](request.data,socket);
					break;

				case 'CFSB':
				case 'GSD':
				case 'GSR':
				case 'CFDB':
				case 'CDB':
					bonusClass[en](request.data,socket);
					break;
					
				case 'TEA': //Track Event Analytics
				case 'FPS': // FPS count track event
					trackClass[en](request.data,socket);
					break;

				case 'HB': // heart beat
					console.log("HB:----------------data:",request.data);
					commonClass.SendDirect(socket.sck, {en: "HB",data: {id:request.data.id}});
					// socket.emit('resw', commonClass.Enc({en:"HB",data : request.data}));	
					// socket.emit('res', commonClass.Enc({en:"HB",data : request.data}));
			}
	},
	BindSocketToEvent : function(socket){
		/* +-------------------------------------------------------------------+
            desc: function to bind socket with socket
            i/p: = socket = socket object
        +-------------------------------------------------------------------+ */
		if(!socket){
		 	return false;
		}
		socket.sck = commonClass.PrepareId(SERVER_ID, socket.id);

		if(SERVICE_HOST == 'game.artoon.in'){  //condition to set default static ip for dev server
			socket.ipad = '27.54.182.197';
		}
		else{

			socket.ipad = commonClass.getIpad(socket);
		}
		
		socket.on('req', function(request){  //android,ios,flash event handler 
			c("event----------->>>>>>request",request);
			if(!request.en){    //temporary code for testing else compulsury deciper
		    	request = commonClass.Dec(request.data);	   
			}

		    socket.removeListener('req', function(){});
			ecClass.eventHub(request,socket);		 
		});
		socket.on('reqw', function(request){  //android,ios,flash event handler 
			c("event------data to decrypt----->>>>>>request",request);
			if(!request.en){    //temporary code for testing else compulsury deciper
		    	request = commonClass.dnc_web(request);	   
				c("event------data after decrypt----->>>>>>request",request);
			}
		    socket.removeListener('reqw', function(){});
			ecClass.eventHub(request,socket);		 
		});
		socket.on('reqA',function(request){
			c('reqA------------>>>>>>request: ',request);

			if(request.en == 'ADMIN' && request.data && request.data.UserId && request.data.UserId.toString() == "5a9a5b54bc118d16442dc36f"){

				db.collection('admin').updateOne({_id:MongoID("5a9a5b54bc118d16442dc36f")},{$set:{cd:new Date()},$addToSet:{scks:socket.sck}},function(){});
			}
			else{
				c('reqA------------->>>>>"unauthorised access"');
			}
		});
		socket.on('write',function(request){
			c('write------------->>>>>>>request: ',request);
			if(request){
				c('write---------------->>>>if');
				// db.collection('DTS_data').save(request);
			}
			else{
				c('write---------------->>>>else');
			}

		});
		socket.on('error', function (exc) {
			 c("ignoring exception: " + exc);
		});
		
		//deleting socket id from player Array on connection close from device.
		socket.on('hb',  function(request){
			// console.log('-_-_-_-_-_-_-_hb_-_-_-_-_-_-_-');
			socket.emit('res', commonClass.Enc({en : "hb", data : {}}));	
			// socket.emit('res',{en : "hb", data : {}});	
			socket.removeListener('hb', function(){});
		});
		//deleting socket id from player Array on connection close from device.
		socket.on('disconnect',  function(disc){
			rClient.decr('onlinePlayers');
			rClient.zincrby('servers', -1, SERVER_ID);
			var data = {un:socket.un,_ir:socket._ir,uid:socket.uid,sck:socket.sck,tbid:socket.tbid,mTbid:socket.mTbid,si:socket.si};
			c('disconnect------------>>>data: ',data);
			//db.collection('admin').updateOne({_id:MongoID("5a9a5b54bc118d16442dc36f")},{$set:{cd:new Date()},$pull:{scks:socket.sck}},function(){});
			
			dashboardClass.LOGOUT({}, socket);
		
		});	
	}
}