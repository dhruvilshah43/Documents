module.exports = {
	
	getCardsForCheatGame :function(pi,pObj){ //cheater gets better cards from here; cheater = cheater sequence number
		/* +-------------------------------------------------------------------+
			desc:this function is used to generate cards for the user considering robot level
			i/p: pi = array of player details on table,pObj = {pure,seq,joker,cSeq,cSet}
			o/p : object = {
					sCards = 2D array of cards for players 
					wildCard = wildCard
					cDeck = array of cards for close deck
					tCard = top card for open deck
				  }
		+-------------------------------------------------------------------+ */
		var cards = ['f-1-0','f-2-0','f-3-0','f-4-0','f-5-0','f-6-0','f-7-0','f-8-0','f-9-0','f-10-0','f-11-0','f-12-0','f-13-0',
				'l-1-0','l-2-0','l-3-0','l-4-0','l-5-0','l-6-0','l-7-0','l-8-0','l-9-0','l-10-0','l-11-0','l-12-0','l-13-0',
				'k-1-0','k-2-0','k-3-0','k-4-0','k-5-0','k-6-0','k-7-0','k-8-0','k-9-0','k-10-0','k-11-0','k-12-0','k-13-0',
				'c-1-0','c-2-0','c-3-0','c-4-0','c-5-0','c-6-0','c-7-0','c-8-0','c-9-0','c-10-0','c-11-0','c-12-0','c-13-0',
				'f-1-1','f-2-1','f-3-1','f-4-1','f-5-1','f-6-1','f-7-1','f-8-1','f-9-1','f-10-1','f-11-1','f-12-1','f-13-1',
				'l-1-1','l-2-1','l-3-1','l-4-1','l-5-1','l-6-1','l-7-1','l-8-1','l-9-1','l-10-1','l-11-1','l-12-1','l-13-1',
				'k-1-1','k-2-1','k-3-1','k-4-1','k-5-1','k-6-1','k-7-1','k-8-1','k-9-1','k-10-1','k-11-1','k-12-1','k-13-1',
				'c-1-1','c-2-1','c-3-1','c-4-1','c-5-1','c-6-1','c-7-1','c-8-1','c-9-1','c-10-1','c-11-1','c-12-1','c-13-1',
				'j-1-0','j-2-0','j-3-0','j-4-0'];



		var shuffle = cardsClass.shuffleCards(cards);

		//selecting wildCards
		//if joker comes in wildCard then card shifting takes place until we get card that is not joker
		while(shuffle[0] && shuffle[0].split('-')[0] == 'j'){
			shuffle.push(shuffle[0]);
    		shuffle.splice(0,1);
		}
		var wildCard  = shuffle.splice(0,1)[0];
		cards = _.without(cards,wildCard);
		// console.log('getCardsForCheatGame---------->>>>cards: ',cards.length);
		var sCards;
		if(pi.length == 2){

			sCards = [[],[]];
		}
		else if(pi.length == 3){
			sCards = [[],[],[]];
		}
		else if(pi.length == 4){
			sCards = [[],[],[],[]];
		}
		else{
			sCards = [[],[],[],[],[]];
		}
		//cards distribution logic here
		c('getCardsForCheatGame----------->>>>>pi: ',pi);



		for(var i in pi){
			// console.log('getCardsForCheatGame-------->>>>>>pi: ',pi[i]);
			if(!_.isEmpty(pi[i]) && typeof pi[i].si != 'undefined' && pi[i].si != null && pi[i].s == 'playing' && pi[i]._ir == 1){
				var rCards = [];
				var obj = {};
				obj = cheatClass.getPures(cards,pi[i].rType,(13 - rCards.length),wildCard);   //give pure seqs to robot
				c('\n[BotCards]-------->>>>pures: ',obj.pures);
				rCards = rCards.concat(obj.pures);		
				obj = cheatClass.getSeqs(obj.cards,pi[i].rType,(13 - rCards.length),wildCard);	//give impure seq to robot
				c('\n[BotCards]-------->>>>seqs: ',obj.seqs);
				rCards = rCards.concat(obj.seqs);
				obj = cheatClass.getSets(obj.cards,pi[i].rType,(13 - rCards.length),wildCard);	//give set to robot
				c('\n[BotCards]-------->>>>sets: ',obj.sets);
				rCards = rCards.concat(obj.sets);
				obj = cheatClass.getJWS(obj.cards,pi[i].rType,(13 - rCards.length),wildCard);   //give joker or hukam to robot
				c('\n[BotCards]-------->>>>jws: ',obj.jws);
				rCards = rCards.concat(obj.jws);
				obj = cheatClass.getCSeqs(obj.cards,pi[i].rType,(13 - rCards.length),wildCard);	//give close seqs to robot
				c('\n[BotCards]-------->>>>cSeqs: ',obj.cSeqs);
				rCards = rCards.concat(obj.cSeqs);
				obj = cheatClass.getCSets(obj.cards,pi[i].rType,(13 - rCards.length),wildCard);	//give close set to robot
				c('\n[BotCards]-------->>>>cSets: ',obj.cSets);
				rCards = rCards.concat(obj.cSets);
				// console.log('getCardsForCheatGame-----1--->>>>rCards: ',rCards);
				shuffle = cardsClass.shuffleCards(obj.cards);
				sCards[i] = rCards.concat(shuffle.splice(0,13 - rCards.length));
				// console.log('getCardsForCheatGame----2---->>>>sCards[i]: ',sCards[i]);
				c('\n[BotCards]------seat Index('+pi[i].si+')----------->>>>>cards: ',sCards[i]);
				cards = _.difference(obj.cards,sCards[i]);
			}
			else if(!_.isEmpty(pi[i]) && typeof pi[i].si != 'undefined' && pi[i].si != null && pi[i].s == 'playing' && pi[i]._ir == 0 && pi[i].isSpc && pObj){
				
				var uCards = [];
				var obj = {cards:cards};
				c("getCardsForCheatGame---------------------pObj:",pObj);
				if(pObj.pure > 0){

					obj = cheatClass.getPures(cards,'Newbie',(13 - uCards.length),wildCard,pObj.pure);   //give pure seqs to user
					c('\n[uCards]-------->>>>pures: ',obj.pures);
					uCards = uCards.concat(obj.pures);		
				}
				if(pObj.seq > 0){

					obj = cheatClass.getSeqs(obj.cards,'Newbie',(13 - uCards.length),wildCard,pObj.seq);	//give impure seq to user
					c('\n[uCards]-------->>>>seqs: ',obj.seqs);
					uCards = uCards.concat(obj.seqs);
				}
				if(pObj.set > 0){

					obj = cheatClass.getSets(obj.cards,'Newbie',(13 - uCards.length),wildCard,pObj.set);	//give set to user
					c('\n[uCards]-------->>>>sets: ',obj.sets);
					uCards = uCards.concat(obj.sets);
				}
				if(pObj.joker > 0){

					obj = cheatClass.getJS(obj.cards,'Newbie',(13 - uCards.length),wildCard,pObj.joker);   //give joker to user
					c('\n[uCards]-------->>>>jws: ',obj.jws);
					uCards = uCards.concat(obj.jws);
				}
				if(pObj.wildcard > 0){

					obj = cheatClass.getWS(obj.cards,'Newbie',(13 - uCards.length),wildCard,pObj.wildcard);   //give wildCard to user
					c('\n[uCards]-------->>>>jws: ',obj.jws);
					uCards = uCards.concat(obj.jws);
				}
				if(pObj.cSeq > 0){

					obj = cheatClass.getCSeqs(obj.cards,'Newbie',(13 - uCards.length),wildCard,pObj.cSeq);	//give close seqs to user
					c('\n[uCards]-------->>>>cSeqs: ',obj.cSeqs);
					uCards = uCards.concat(obj.cSeqs);
				}
				if(pObj.cSet > 0){

					obj = cheatClass.getCSets(obj.cards,'Newbie',(13 - uCards.length),wildCard,pObj.cSet);	//give close set to user
					c('\n[uCards]-------->>>>cSets: ',obj.cSets);
					uCards = uCards.concat(obj.cSets);
				}
				// console.log('getCardsForCheatGame-----1--->>>>uCards: ',uCards);
				var pcd = cardsClass.getCardsWithoutJW(obj.cards,wildCard);
				var pcdsh = cardsClass.shuffleCards(pcd);
				var concard = pcdsh.splice(0,13 - uCards.length);
				sCards[i] = uCards.concat(concard);
				shuffle = cardsClass.shuffleCards(obj.cards);
				for(var k in concard){
					c("getCardsForCheatGame---------------------k:",concard[k]);
					shuffle.splice(shuffle.indexOf(concard[k]),1);
				}
				// console.log('getCardsForCheatGame----2---->>>>sCards[i]: ',sCards[i]);
				c('\n[uCards]------seat Index('+pi[i].si+')----------->>>>>cards: ',sCards[i]);
				cards = _.difference(obj.cards,sCards[i]);
			}
		}

		shuffle = cardsClass.shuffleCards(cards);
		var temp = [];
		for(var j in pi){
			if(!_.isEmpty(pi[j]) && typeof pi[j].si != 'undefined' && pi[j].si != null && pi[j].s == 'playing' && pi[j]._ir == 0 && (!pi[j].isSpc || pi[j].isSpc && !pObj)){
				sCards[j] = shuffle.splice(0,13);
			}
		}
		c('getCardsForCheatGame------------->>>>>>sCards',sCards,' cards: ',shuffle.length);


		var cDeck = [];
		var tCard = shuffle.splice(0,1)[0]; //first cards to show

		var final = {sCards: sCards,wildCard: wildCard,cDeck: shuffle,tCard: tCard};
		// console.log('getCardsForCheatGame------------>>>>>>>final: ',final);
		return final;
	},
	getPures:function(cards,rType,rmLen,wildCard,Nos){  //cards = main deck ,rType = robot type, rmLen = robot remainin cards to get, wildCard = wildCard
		/* +-------------------------------------------------------------------+
			desc:this function generates pure sequence for robot
			i/p: cards = array of remaining cards  from main deck
				 rType = type of robot
				 rmLen = number of cards required to make 13 cards 
				 wildCard = wildcard
				 Nos = number of pure
			o/p : object = {
					cards = remaining cards from deck
					pures = array containing pure sequence
		   		  }
		+-------------------------------------------------------------------+ */

		
		if(rmLen >= 3){
			var nos = 0;

			if(typeof Nos == 'undefined' || Nos == null){
				var p = commonClass.GetRandomInt(0,100);
				eval('var nos0 = RCARDS.'+rType+'.PURE.nos0');
				eval('var nos1 = RCARDS.'+rType+'.PURE.nos1');
				eval('var nos2 = RCARDS.'+rType+'.PURE.nos2');
				eval('var nos3 = RCARDS.'+rType+'.PURE.nos3');
				var bound = nos0;

				if(p <= bound){
					//no pure sequence
					c(rType+' PURE0');
					return {cards: cards,pures: []};
				}
				else if(p <= (bound += nos1)){
					//give one pure sequence
					c(rType+' PURE1');

					nos = 1;
				}
				else if(p <= (bound += nos2)){
					//give two impure sequence
					c(rType+' PURE2');
					if(rmLen >= 6){
						nos = 2;
					}
					else{
						nos = 1;
					}
				}
				else if(p <= (bound += nos3)){
					//give three pure sequence 
					c(rType+' PURE3');
					if(rmLen >= 9){

						nos = 3;
					}
					else if(rmLen >= 6){
						 nos = 2;
					}
					else{
						nos = 1;
					}
				}
				else{
					c(rType+' PURE null');

					return {cards: cards,pures: []};
				}
			}
			else{
				nos = Nos;
			}
			c('getPures--------->>>>>nos: '+nos);

			var tempC = _.clone(cards);
			tempC = _.difference(tempC,['j-1-0','j-2-0','j-3-0','j-4-0']);
			
			var r = commonClass.GetRandomInt(0,tempC.length-1);   
			// c('getPures------------>>>>>r: '+r+' tempC: '+tempC);
			var pures = [];
			var tmp = [];
			var cdLen = tempC.length;
			for(var i = 0 ;i < cdLen ;i++){
				// c('getPures---------->>>>>>i: '+i+' tmp: ',tmp);
				if(tmp.length == 0){
					tmp.push(tempC[r]);
					// c('getPures-------->>>>>tmp.length: ',tmp.length);
				}			
				else{
					// c('getPures-------->>>>else');
					var lastCard = tmp[tmp.length-1];
					var newCard = tempC[r];
					// c('lastCard: '+lastCard+' newCard: '+newCard);
					var matchSuit = (lastCard.split('-')[0] == newCard.split('-')[0])? true :false;
					var diff = parseInt(newCard.split('-')[1]) - parseInt(lastCard.split('-')[1])


					if(matchSuit){  //two cards with same suit 
						if(diff == 0){
							//ignore
						}
						else if(diff == 1){
							tmp.push(newCard);
						}	
						else{

							if(tmp.length == 3){
								tempC = _.difference(tempC,tmp);
								pures.push(tmp);
								if(pures.length == nos){
									break;
								}
							}
							tmp = [];
							// tmp.push(newCard);
						}
					}
					else{
						if(tmp.length == 3){
							tempC = _.difference(tempC,tmp);
							pures.push(tmp);
							if(pures.length == nos){
								break;
							}
						}
						tmp = [];
						// tmp.push(newCard);
					}
				}
				if(tmp.length == 3){
					tempC = _.difference(tempC,tmp);
					pures.push(tmp);
					tmp = [];
					if(pures.length == nos){
						break;
					}
				}
				r = (r+1)%tempC.length;
			}

			c('getPures------------>>>>>pures: ',pures);
			pures = _.flatten(pures);
			cards = _.difference(cards,pures);
			return {cards: cards,pures:pures};
		}
		else{
			return {cards: cards,pures: []};	
		}
	},
	getSeqs:function(cards,rType,rmLen,wildCard,Nos){ //get premade sequence
		/* +-------------------------------------------------------------------+
			desc:this function generates impure sequence for robot
			i/p: cards = array of remaining cards  from main deck
				 rType = type of robot
				 rmLen = number of cards required to make 13 cards 
				 wildCard = wildcard
				 Nos = number of seq
			o/p : object = {
					cards = remaining cards from deck
					seqs = array containing impure sequence
		   		  }
		+-------------------------------------------------------------------+ */

		
		if(rmLen >= 3){
			var nos = 0;

			if(typeof Nos == 'undefined' || Nos == null){
				var p = commonClass.GetRandomInt(0,100);
				eval('var nos0 = RCARDS.'+rType+'.SEQS.nos0');
				eval('var nos1 = RCARDS.'+rType+'.SEQS.nos1');
				eval('var nos2 = RCARDS.'+rType+'.SEQS.nos2');
				eval('var nos3 = RCARDS.'+rType+'.SEQS.nos3');
				
				var bound = nos0;

				if(p <= bound){
					//no pure sequence
					c(rType+' SEQS0');
					return {cards: cards,seqs: []};
				}
				else if(p <= (bound += nos1)){
					//give one pure sequence
					c(rType+' SEQS1');

					nos = 1;
				}
				else if(p <= (bound += nos2)){
					//give two impure sequence
					c(rType+' SEQS2');
					if(rmLen >= 6){

						nos = 2;
					}
					else{
						nos = 1;
					}
				}
				else if(p <= (bound += nos3)){
					//give three pure sequence
					c(rType+' SEQS3');
					if(rmLen >= 9){

						nos = 3;
					}
					else if(rmLen >= 6){
						nos = 2;
					}
					else{
						nos =1;
					}
				}
				else{
					c(rType+' SEQS null');
					return {cards: cards,seqs: []};
				}
			}
			else{
				nos = Nos;
			}
			c('getSeqs---------->>>>>nos: '+nos);
			var tempC = _.clone(cards);
			var jwArray = cardsClass.getJWcards(tempC,wildCard);
			if(jwArray.length == 0){  //there is no joker to make a impure sequence
				return {cards: cards,seqs: []};
			}
			tempC = _.difference(tempC,jwArray);


			var r = commonClass.GetRandomInt(0,tempC.length-1);   
			// c('getPures------------>>>>>r: '+r+' tempC: '+tempC);
			var seqs = [];
			var tmp = [];
			var cdLen = tempC.length;
			for(var i = 0 ;i < cdLen ;i++){
				// c('getPures---------->>>>>>i: '+i+' tmp: ',tmp);
				if(tmp.length == 0){
					tmp.push(tempC[r]);
					// c('getPures-------->>>>>tmp.length: ',tmp.length);
				}			
				else{
					// c('getPures-------->>>>else');
					var lastCard = tmp[tmp.length-1];
					var newCard = tempC[r];
					// c('lastCard: '+lastCard+' newCard: '+newCard);
					var matchSuit = (lastCard.split('-')[0] == newCard.split('-')[0])? true :false;
					var diff = parseInt(newCard.split('-')[1]) - parseInt(lastCard.split('-')[1])


					if(matchSuit){  //two cards with same suit 
						if(diff == 0){
							//ignore
						}
						else if(diff == 1){
							tmp.push(newCard);
						}	
						else if(diff == 2){
							//add joker or wildcards logic here
							if(tmp.length == 1 && jwArray.length > 0){    //means one old cards one joker/wildcards and one newcard
								tmp.push(jwArray.splice(0,1)[0]);
								tmp.push(newCard);
								tempC = _.difference(tempC,tmp);
								seqs.push(tmp);
								if(seqs.length == nos || jwArray.length == 0){
									break;
								}
							}
							tmp = [];
							// tmp.push(newCard);
						}
						else{

							if(tmp.length == 2 && jwArray.length > 0){
								tmp.push(jwArray.splice(0,1)[0]);
								tempC = _.difference(tempC,tmp);
								seqs.push(tmp);
								if(seqs.length == nos || jwArray.length == 0){
									break;
								}
							}
							tmp = [];
							// tmp.push(newCard);
						}
					}
					else{
						if(tmp.length == 2 && jwArray.length > 0){
							tmp.push(jwArray.splice(0,1)[0]);
							tempC = _.difference(tempC,tmp);
							seqs.push(tmp);
							if(seqs.length == nos || jwArray.length == 0){
								break;
							}
						}
						tmp = [];
						// tmp.push(newCard);
					}
				}
				if(tmp.length == 2 && jwArray.length > 0){
					tmp.push(jwArray.splice(0,1)[0]);
					tempC = _.difference(tempC,tmp);
					seqs.push(tmp);
					tmp = [];
					if(seqs.length == nos || jwArray.length == 0){
						break;
					}
				}
				r = (r+1)%tempC.length;
			}

			// c('getSeqs------------>>>>>seqs: ',seqs);
			seqs = _.flatten(seqs);
			cards = _.difference(cards,seqs);
			c('getSeqs-------->>>>seqs: ',seqs);

			return {cards: cards,seqs: seqs};

		}
		else{
			return {cards: cards,seqs: []};	
		}
	},
	getSets:function(cards,rType,rmLen,wildCard,Nos){ //returns premade sets array
		/* +-------------------------------------------------------------------+
			desc:this function generates sets for robot
			i/p: cards = array of remaining cards  from main deck
				 rType = type of robot
				 rmLen = number of cards required to make 13 cards 
				 wildCard = wildcard
				 Nos = number of sets
			o/p : object = {
					cards = remaining cards from deck
					sets = array containing sets
		   		  }
		+-------------------------------------------------------------------+ */
		c('getSets------->>>rmLen: '+rmLen);

		
		
		if(rmLen >= 3){
			var nos = 0;

			if(typeof Nos == 'undefined' || Nos == null){
				var p = commonClass.GetRandomInt(0,100);
				eval('var nos0 = RCARDS.'+rType+'.SETS.nos0');
				eval('var nos1 = RCARDS.'+rType+'.SETS.nos1');
				eval('var nos2 = RCARDS.'+rType+'.SETS.nos2');
				eval('var nos3 = RCARDS.'+rType+'.SETS.nos3');
				var bound = nos0;

				if(p <= bound){
					//no pure sequence
					c(rType+' SETS0');

					return {cards:cards,sets:[]};
				}
				else if(p <= (bound += nos1)){
					//give one pure sequence
					c(rType+' SETS1');
					nos = 1;
				}
				else if(p <= (bound += nos2)){
					//give two impure sequence
					c(rType+' SETS2');
					if(rmLen >= 6){

						nos = 2;
					}
					else{
						nos = 1;
					}
				}
				else if(p <= (bound += nos3)){
					//give three pure sequence 
					c(rType+' SETS3');
					if(rmLen >= 9){

						nos = 3;
					}
					else if(rmLen >= 6){
						nos = 2;
					}
					else{
						nos = 1; 
					}
				}
				else{
					c(rType+' SETS null');
					return {cards:cards,sets:[]};
				}
			}
			else{
				nos = Nos;
			}
			c('getSets----------->>>>>>nos: '+nos);
			
			var tempC = _.clone(cards);
			tempC = _.difference(tempC,['j-1-0','j-2-0','j-3-0','j-4-0']);
		

			tempC = tempC.toString();
			var r = commonClass.GetRandomInt(0,12)+1;   
			var re = new RegExp('[flkc]-'+r+'-[01]', 'g');
			var srCards =  (tempC.match(re) != null ) ? cardsClass.removeDuplicates(tempC.match(re)) : [];   //find the array of cards having same rank bu different suits
			var sets = [];
			tempC = tempC.split(',');
			for(var i = 0; i < 13 ;i++){
				if(srCards.length >= 3){   //check if the same rank cards have sufficient cards to form a sets
					var tmp = srCards.splice(0,3);
					tempC = _.difference(tempC,tmp);
					sets.push(tmp);
					if(sets.length == nos){
						break;
					}
				}
				r = r%13+1;
				tempC = tempC.toString();
				re = new RegExp('[flkc]-'+r+'-[01]', 'g');
				srCards = (tempC.match(re) != null) ? cardsClass.removeDuplicates(tempC.match(re)) : [];
				
				tempC = tempC.split(',');
			}
			c('getSets---------->>>>>>sets: ',sets);
			sets = _.flatten(sets);
			cards = _.difference(cards,sets);
			return {cards: cards,sets: sets};
		}
		else{
			return {cards:cards,sets:[]};
		}
	},
	getJWS:function(cards,rType,rmLen,wildCard,Nos){
		/* +-------------------------------------------------------------------+
			desc:this function gives jokers/wildCards for robot
			i/p: cards = array of remaining cards  from main deck
				 rType = type of robot
				 rmLen = number of cards required to make 13 cards 
				 wildCard = wildcard
				 Nos = number of joker or wildcards
			o/p : object = {
					cards = remaining cards from deck
					jws = array containing jokers
		   		  }
		+-------------------------------------------------------------------+ */
		var nos = 0;
		if(rmLen >= 1){  ///check if there is vacancy for atleast one card
			
			if(typeof Nos == 'undefined' || Nos == null){

				var p = commonClass.GetRandomInt(0,100);
				eval('var nos0 = RCARDS.'+rType+'.JW.nos0');
				eval('var nos1 = RCARDS.'+rType+'.JW.nos1');
				eval('var nos2 = RCARDS.'+rType+'.JW.nos2');
				eval('var nos3 = RCARDS.'+rType+'.JW.nos3');
				
				var bound = nos0;

				if(p <= bound){
					//no pure sequence
					c(rType+' JW0');
					return {cards: cards,jws: []};
				}
				else if(p <= (bound += nos1)){
					//give one pure sequence
					c(rType+' JW1');

					nos = 1;
				}
				else if(p <= (bound += nos2)){
					//give two impure sequence
					c(rType+' JW2');
					if(rmLen >= 2){    //check if there is the vacancy for two joker/wildCard

						nos = 2;
					}
					else{
						nos = 1;
					}
				}
				else if(p <= (bound += nos3)){
					//give three pure sequence 
					c(rType+' JW3');
					if(rmLen >= 3){  //check if there is the vacancy for three joker/wildCard

						nos = 3;
					}
					else if(rmLen >= 2){  //check if there is the vacancy for two joker/wildCard
						nos = 2;
					}
					else{
						nos = 1;
					}
				}
				else{
					c(rType+' JW null');
					return {cards: cards,jws: []};
				}
			}
			else{
				nos = Nos;
			}
		}
		c('getJWS----------->>>>>nos: '+nos);
		var jwArray = cardsClass.getJWcards(cards,wildCard);
		// var final jwArray
		var finalJW = [];
		if(jwArray.length > 0){   //check if there is atleast one joker/wildCard
			if(nos == 3){
				if(jwArray.length >= 3){  //check if there are atleast three joker/wildCard
					finalJW = jwArray.splice(0,3);
				}
				else if(jwArray.length == 2){ //check if there are atleast two joker/wildCard
					finalJW = jwArray.splice(0,2);
					
				}
				else{
					finalJW = jwArray.splice(0,1);
				}
			}
			else if(nos == 2){
				if(jwArray.length >= 2){   //check if there are atleast two joker/wildCard
					finalJW = jwArray.splice(0,2);
					
				}
				else{
					finalJW = jwArray.splice(0,1);
				}
			}
			else{
				finalJW = jwArray.splice(0,1);
			}
			c('getJWS----------->>>>>>>finalJW: ',finalJW);
			cards = _.difference(cards,finalJW);
			return {cards: cards,jws: finalJW};
		}
		else{
			return {cards: cards,jws: []};
		}
	},
	getJS:function(cards,rType,rmLen,wildCard,Nos){
		/* +-------------------------------------------------------------------+
			desc:this function gives jokers/wildCards for robot
			i/p: cards = array of remaining cards  from main deck
				 rType = type of robot
				 rmLen = number of cards required to make 13 cards 
				 wildCard = wildcard
				 Nos = number of joker or wildcards
			o/p : object = {
					cards = remaining cards from deck
					jws = array containing jokers
		   		  }
		+-------------------------------------------------------------------+ */
		var nos = 0;
		if(rmLen >= 1){  ///check if there is vacancy for atleast one card
			
			if(typeof Nos == 'undefined' || Nos == null){

				var p = commonClass.GetRandomInt(0,100);
				eval('var nos0 = RCARDS.'+rType+'.JW.nos0');
				eval('var nos1 = RCARDS.'+rType+'.JW.nos1');
				eval('var nos2 = RCARDS.'+rType+'.JW.nos2');
				eval('var nos3 = RCARDS.'+rType+'.JW.nos3');
				
				var bound = nos0;

				if(p <= bound){
					//no pure sequence
					c(rType+' JW0');
					return {cards: cards,jws: []};
				}
				else if(p <= (bound += nos1)){
					//give one pure sequence
					c(rType+' JW1');

					nos = 1;
				}
				else if(p <= (bound += nos2)){
					//give two impure sequence
					c(rType+' JW2');
					if(rmLen >= 2){    //check if there is the vacancy for two joker/wildCard

						nos = 2;
					}
					else{
						nos = 1;
					}
				}
				else if(p <= (bound += nos3)){
					//give three pure sequence 
					c(rType+' JW3');
					if(rmLen >= 3){  //check if there is the vacancy for three joker/wildCard

						nos = 3;
					}
					else if(rmLen >= 2){  //check if there is the vacancy for two joker/wildCard
						nos = 2;
					}
					else{
						nos = 1;
					}
				}
				else{
					c(rType+' JW null');
					return {cards: cards,jws: []};
				}
			}
			else{
				nos = Nos;
			}
		}
		c('getJWS----------->>>>>nos: '+nos);
		var jwArray = cardsClass.getJCards(cards);
		// var final jwArray
		var finalJW = [];
		if(jwArray.length > 0){   //check if there is atleast one joker/wildCard
			if(nos == 3){
				if(jwArray.length >= 3){  //check if there are atleast three joker/wildCard
					finalJW = jwArray.splice(0,3);
				}
				else if(jwArray.length == 2){ //check if there are atleast two joker/wildCard
					finalJW = jwArray.splice(0,2);
					
				}
				else{
					finalJW = jwArray.splice(0,1);
				}
			}
			else if(nos == 2){
				if(jwArray.length >= 2){   //check if there are atleast two joker/wildCard
					finalJW = jwArray.splice(0,2);
					
				}
				else{
					finalJW = jwArray.splice(0,1);
				}
			}
			else{
				finalJW = jwArray.splice(0,1);
			}
			c('getJWS----------->>>>>>>finalJW: ',finalJW);
			cards = _.difference(cards,finalJW);
			return {cards: cards,jws: finalJW};
		}
		else{
			return {cards: cards,jws: []};
		}
	},
	getWS:function(cards,rType,rmLen,wildCard,Nos){
		/* +-------------------------------------------------------------------+
			desc:this function gives jokers/wildCards for robot
			i/p: cards = array of remaining cards  from main deck
				 rType = type of robot
				 rmLen = number of cards required to make 13 cards 
				 wildCard = wildcard
				 Nos = number of joker or wildcards
			o/p : object = {
					cards = remaining cards from deck
					jws = array containing jokers
		   		  }
		+-------------------------------------------------------------------+ */
		var nos = 0;
		if(rmLen >= 1){  ///check if there is vacancy for atleast one card
			
			if(typeof Nos == 'undefined' || Nos == null){

				var p = commonClass.GetRandomInt(0,100);
				eval('var nos0 = RCARDS.'+rType+'.JW.nos0');
				eval('var nos1 = RCARDS.'+rType+'.JW.nos1');
				eval('var nos2 = RCARDS.'+rType+'.JW.nos2');
				eval('var nos3 = RCARDS.'+rType+'.JW.nos3');
				
				var bound = nos0;

				if(p <= bound){
					//no pure sequence
					c(rType+' JW0');
					return {cards: cards,jws: []};
				}
				else if(p <= (bound += nos1)){
					//give one pure sequence
					c(rType+' JW1');

					nos = 1;
				}
				else if(p <= (bound += nos2)){
					//give two impure sequence
					c(rType+' JW2');
					if(rmLen >= 2){    //check if there is the vacancy for two joker/wildCard

						nos = 2;
					}
					else{
						nos = 1;
					}
				}
				else if(p <= (bound += nos3)){
					//give three pure sequence 
					c(rType+' JW3');
					if(rmLen >= 3){  //check if there is the vacancy for three joker/wildCard

						nos = 3;
					}
					else if(rmLen >= 2){  //check if there is the vacancy for two joker/wildCard
						nos = 2;
					}
					else{
						nos = 1;
					}
				}
				else{
					c(rType+' JW null');
					return {cards: cards,jws: []};
				}
			}
			else{
				nos = Nos;
			}
		}
		c('getJWS----------->>>>>nos: '+nos);
		var jwArray = cardsClass.getWCards(cards,wildCard);
		// var final jwArray
		var finalJW = [];
		if(jwArray.length > 0){   //check if there is atleast one joker/wildCard
			if(nos == 3){
				if(jwArray.length >= 3){  //check if there are atleast three joker/wildCard
					finalJW = jwArray.splice(0,3);
				}
				else if(jwArray.length == 2){ //check if there are atleast two joker/wildCard
					finalJW = jwArray.splice(0,2);
					
				}
				else{
					finalJW = jwArray.splice(0,1);
				}
			}
			else if(nos == 2){
				if(jwArray.length >= 2){   //check if there are atleast two joker/wildCard
					finalJW = jwArray.splice(0,2);
					
				}
				else{
					finalJW = jwArray.splice(0,1);
				}
			}
			else{
				finalJW = jwArray.splice(0,1);
			}
			c('getJWS----------->>>>>>>finalJW: ',finalJW);
			cards = _.difference(cards,finalJW);
			return {cards: cards,jws: finalJW};
		}
		else{
			return {cards: cards,jws: []};
		}
	},
	getCSeqs:function(cards,rType,rmLen,wildCard,Nos){
		/* +-------------------------------------------------------------------+
			desc:this function gives close sequence for robot
			i/p: cards = array of remaining cards  from main deck
				 rType = type of robot
				 rmLen = number of cards required to make 13 cards 
				 wildCard = wildcard
				 Nos = numbe of cSeqs
			o/p : object = {
					cards = remaining cards from deck
					cSeqs = array containing close sequence
		   		  }
		+-------------------------------------------------------------------+ */
		if(rmLen >= 2){

			var nos = 0;


			if(typeof Nos == 'undefined' || Nos == null){

				var p = commonClass.GetRandomInt(0,100);
				eval('var nos0 = RCARDS.'+rType+'.CSEQS.nos0');
				eval('var nos1 = RCARDS.'+rType+'.CSEQS.nos1');
				eval('var nos2 = RCARDS.'+rType+'.CSEQS.nos2');
				eval('var nos3 = RCARDS.'+rType+'.CSEQS.nos3');
				var bound = nos0;
				if(p <= bound){
					//no pure sequence
					c(rType+' CSEQS0');
					return {cards: cards,cSeqs: []};
				}
				else if(p <= (bound += nos1)){
					//give one pure sequence
					c(rType+' CSEQS1');

					nos = 1;
				}
				else if(p <= (bound += nos2)){
					//give two impure sequence
					c(rType+' CSEQS2');
					if(rmLen >= 4){

						nos = 2;
					}
					else{
						nos = 1;
					}
				}
				else if(p <= (bound += nos3)){
					//give three pure sequence 
					c(rType+' CSEQS3');
					if(rmLen >= 6){

						nos = 3;
					}
					else if(rmLen >= 4){
						nos = 2;
					}
					else{
						nos = 1;
					}
				}
				else{
					c(rType+' CSEQS null');

					return {cards: cards,cSeqs: []};
				}
			}
			else{
				nos = Nos;
			}
			c('getCSeqs----------->>>>>nos: '+nos);

			var tempC = _.clone(cards);
			tempC = _.difference(tempC,['j-1-0','j-2-0','j-3-0','j-4-0']);
			
			var r = commonClass.GetRandomInt(0,tempC.length-1);   
			// c('getPures------------>>>>>r: '+r+' tempC: '+tempC);
			var cSeqs = [];
			var tmp = [];
			var cdLen = tempC.length;
			for(var i = 0 ;i < cdLen ;i++){
				// c('getCSeqs---------->>>>>>i: '+i+' tmp: ',tmp);
				if(tmp.length == 0){
					tmp.push(tempC[r]);
					// c('getCSeqs-------->>>>>tmp.length: ',tmp.length);
				}			
				else{
					// c('getCSeqs-------->>>>else');
					var lastCard = tmp[tmp.length-1];
					var newCard = tempC[r];
					// c('lastCard: '+lastCard+' newCard: '+newCard);
					var matchSuit = (lastCard.split('-')[0] == newCard.split('-')[0])? true :false;
					var diff = parseInt(newCard.split('-')[1]) - parseInt(lastCard.split('-')[1])


					if(matchSuit){  //two cards with same suit 
						if(diff == 0){
							//ignore
						}
						else if(diff == 1 || diff == 2){
							tmp.push(newCard);
						}	
						else{

							if(tmp.length == 2){
								tempC = _.difference(tempC,tmp);
								cSeqs.push(tmp);
								if(cSeqs.length == nos){
									break;
								}
							}
							tmp = [];
							// tmp.push(newCard);
						}
					}
					else{
						if(tmp.length == 2){
							tempC = _.difference(tempC,tmp);
							cSeqs.push(tmp);
							if(cSeqs.length == nos){
								break;
							}
						}
						tmp = [];
						// tmp.push(newCard);
					}
				}
				if(tmp.length == 2){
					tempC = _.difference(tempC,tmp);
					cSeqs.push(tmp);
					tmp = [];
					if(cSeqs.length == nos){
						break;
					}
				}
				r = (r+1)%tempC.length;
			}

			c('getCSeqs------------>>>>>cSeqs: ',cSeqs);
			cards = _.difference(cards,_.flatten(cSeqs));
			return {cards: cards,cSeqs: _.flatten(cSeqs)};
		}
		else{
			return {cards: cards,cSeqs: []};
		}
	},
	getCSets:function(cards,rType,rmLen,wildCard,Nos){
		/* +-------------------------------------------------------------------+
			desc:this function gives close set for robot
			i/p: cards = array of remaining cards  from main deck
				 rType = type of robot
				 rmLen = number of cards required to make 13 cards 
				 wildCard = wildcard
				 Nos = number of cSets
			o/p : object = {
					cards = remaining cards from deck
					cSets = array containing close sets
		   		  }
		+-------------------------------------------------------------------+ */
		if(rmLen >= 2){
			var nos = 0;


			if(typeof Nos == 'undefined' || Nos == null){

				var p = commonClass.GetRandomInt(0,100);
				eval('var nos0 = RCARDS.'+rType+'.CSETS.nos0');
				eval('var nos1 = RCARDS.'+rType+'.CSETS.nos1');
				eval('var nos2 = RCARDS.'+rType+'.CSETS.nos2');
				eval('var nos3 = RCARDS.'+rType+'.CSETS.nos3');
				var bound = nos0;
				if(p <= bound){
					//no pure sequence
					c(rType+' CSETS0');
					return {cards: cards,cSets: []};
				}
				else if(p <= (bound += nos1)){
					//give one pure sequence
					c(rType+' CSETS1');

					nos = 1;
				}
				else if(p <= (bound += nos2)){
					//give two impure sequence
					c(rType+' CSETS2');
					if(rmLen >= 4){

						nos = 2;
					}
					else{
						nos = 1;
					}
				}
				else if(p <= (bound += nos3)){
					//give three pure sequence 
					c(rType+' CSETS3');
					if(rmLen >= 6){

						nos = 3;
					}
					else if(rmLen >= 4){
						nos = 2;
					}
					else{
						nos = 1;
					}
				}
				else{
					c(rType+' CSETS null');

					return {cards: cards,cSets: []};
				}
			}
			else{
				nos = Nos;
			}
			c('getCSets-------------->>>>>nos: '+nos);

			var tempC = _.clone(cards);
			tempC = _.difference(tempC,['j-1-0','j-2-0','j-3-0','j-4-0']);
		

			tempC = tempC.toString();
			var r = commonClass.GetRandomInt(0,12)+1;   
			var re = new RegExp('[flkc]-'+r+'-[01]', 'g');

			var srCards = (tempC.match(re) != null) ? cardsClass.removeDuplicates(tempC.match(re)):[];
			

			// var srCards = cardsClass.removeDuplicates(tempC.match(re));   //find the array of cards having same rank bu different suits
			var cSets = [];
			tempC = tempC.split(',');
			for(var i = 0; i < 13 ;i++){
				if(srCards.length >= 2){   //check if the same rank cards have sufficient cards to form a close cSets
					var tmp = srCards.splice(0,2);
					tempC = _.difference(tempC,tmp);
					cSets.push(tmp);
					if(cSets.length == nos){
						break;
					}
				}
				r = r%13+1;
				tempC = tempC.toString();
				re = new RegExp('[flkc]-'+r+'-[01]', 'g');   //find all cards with rank r
				srCards = (tempC.match(re) != null)? cardsClass.removeDuplicates(tempC.match(re)):[];
				
				tempC = tempC.split(',');
			}
			cSets = _.flatten(cSets);
			c('getCSets---------->>>>>>cSets: ',cSets);
			cards = _.difference(cards,cSets);
			return {cards: cards,cSets: cSets};
		}
		else{

			return {cards: cards,cSets: []};
		}
	},
	getPure : function (cards,wildCard,len){  //len = length of the pure sequence
  		c('getPure-------->>>>');
	    cards = cards.splice(0,52);     //take only first 52 cards from deck
	    var rd = commonClass.GetRandomInt(0,3); //0 = f,1 = l, 2 = k, 3 = c
	    cards = cards.splice(rd*13,13); // choosing random suit for pure sequence
	    cards = cardsClass.shuffleCards(cards);
	    var pure = [];
		var comb = cardsClass.combinations(cards,len,len,true);
		for(var i in comb){
			if(cardsClass.isPure(comb[i])){
				if(_.contains(comb[i],wildCard)){
					pure = _.without(comb[i],wildCard);
					pure.push(wildCard.split('-')[0]+'-'+wildCard.split('-')[1]+'-1');
				}
				else{
					pure = comb[i];
				}

				break;
			}
		}
		return pure;
	},
	getSet:function(cards,wildCard){  //returns 3 cards with same rank and different suit
		c('getSet--------->>>>');
		var set = [];
		var rank = commonClass.GetRandomInt(1,13);
		var suit = ['f','l','k','c'];
		var st;
		var t;
		for(var i = 0;i < 3;i++){
			st = commonClass.GetRandomInt(0,suit.length-1);
			t = suit[st]+'-'+rank+'-0';
			if(t == wildCard){
				t = suit[st]+'-'+rank+'-1';
			}
			set.push(t);
			suit = _.without(suit,suit[st]);
		}
		return set;
	},
	getJW:function(wildCard){  //return three cards as joker or wildCard
		var jw = ['j-1-0','j-2-0','j-3-0','j-4-0','f-'+wildCard.split('-')[1]+'-0','l-'+wildCard.split('-')[1]+'-0','k-'+wildCard.split('-')[1]+'-0','c-'+wildCard.split('-')[1]+'-0'];
		var rd;
		var t;
		var final = [];
		for(var i = 0;i < 3;i++){
			rd = commonClass.GetRandomInt(0,jw.length-1);
			if(jw[rd] == wildCard){
				t = wildCard.split('-')[0]+'-'+wildCard.split('-')[1]+'-1';
			}
			else{
				t = jw[rd];
			}
			final.push(t);
			jw = _.without(jw,t);
		}
		return final;
	}
}