module.exports = {
	SMC: function(data,client){
		/* +-------------------------------------------------------------------+
            desc:event to send cards to players
            i/p: data = {},client = socket object
            o/p: SMC event : data = cards array for player
        +-------------------------------------------------------------------+ */
		c('SMC----------->>>>>client.tbid: '+client.tbid+' client.uid: '+client.uid);
		if(client.tbid && typeof client.si != 'undefined' && client.si != null){
			cdClass.GetTbInfo(client.tbid,{},function(table){	
				if(table){
					db.collection('playing_table').findOne({_id:MongoID(client.tbid),'pi.uid':client.uid},{fields:{'pi.$':1}},function(resp){
						c('SMC----------->>>>>resp: ',resp)
						if(resp){
							commonClass.SendData(client,'SMC',resp.pi[0].cards); 
						}
						else{
							c('SMC::::::::::::Error:"player not found!!!"');
						}
					});
				}
				else{
					c('SMC:::::::::::::::Error:"table not found!!!"');
				}
			});
		}
	},

	SCD_old : function(data,client){   //save cards; data = {gCards: [[],[],......]}
		/* +-------------------------------------------------------------------+
            desc:event to store grouped cards to server
            i/p: data = {gCards = 2D array of grouped cards},client = socket object
        +-------------------------------------------------------------------+ */
		c('SCD---------->>>>>client.tbid: '+client.tbid+' client.si '+client.si+' client.uid: '+client.uid);
		c('SCD--------------->>>>>>data.gCards: ',data.gCards);
		if(data.gCards && data.gCards.length > 0){

			var temp = _.flatten(data.gCards);
			c('SCD--------------->>>>>>temp: ',temp);
			if(temp.length == 13 || temp.length == 14){

				db.collection('playing_table').findAndModify({_id:MongoID(client.tbid),tst:'RoundStarted','pi.si': client.si},{},{$set:{la:new Date(),'pi.$.gCards':data.gCards}},{new:true},function(err,table){
					// c('SCD----------->>>>>table: ',table.value);
					if(table && table.value){
						c('SCD-------'+client.tbid+'-------->>>>>>Msg: "cards updated!!!"');
					}
					else{
						c('SCD------'+client.tbid+'------->>>>Msg:"cards not updated!!!"');
					}
				});
			}
			else{
				db.collection('playing_table').findOne({_id:MongoID(client.tbid),'pi.si':client.si},{fields:{'pi.$':1}},function(err,tbInfo){
					if(tbInfo && tbInfo.pi && tbInfo.pi.length > 0){
						c('SCD-------------->>>>>tbInfo: ',tbInfo);
						var gCards = (tbInfo.pi[0] && tbInfo.pi[0].gCards && tbInfo.pi[0].gCards.length > 0)?tbInfo.pi[0].gCards:[tbInfo.pi[0].cards];
						commonClass.SendData(client,'SCD', {gCards:gCards});
					}
					else{
						c('SCD----------------'+client.tbid+'------------------>>>>>"cards error"');
					}
				});
			}
		}
	},
	SCD : function(data,client){   //save cards; data = {gCards: [[],[],......]}
		/* +-------------------------------------------------------------------+
            desc:event to store grouped cards to server
            i/p: data = {gCards = 2D array of grouped cards},client = socket object
        +-------------------------------------------------------------------+ */
		c('SCD---------->>>>>client.tbid: '+client.tbid+' client.si '+client.si+' client.uid: '+client.uid);

		if(data.gCards){

			var temppure = _.flatten(data.gCards.pure);
			var tempseq = _.flatten(data.gCards.seq);
			var tempset = _.flatten(data.gCards.set);
			var tempdwd = _.flatten(data.gCards.dwd);

			var temp = temppure.length + tempseq.length + tempset.length + tempdwd.length;
			c('SCD--------------->>>>>>temp: ',temp);
			if(temp == 13 || temp == 14){
				data.gCards = {pure : data.gCards.pure, seq : data.gCards.seq, set : data.gCards.set, dwd : data.gCards.dwd};
				db.collection('playing_table').findAndModify({_id:MongoID(client.tbid),/*tst:'RoundStarted',*/'pi.si': client.si},{},{$set:{la:new Date(),'pi.$.gCards':data.gCards}},{new:true},function(err,table){
					// c('SCD----------->>>>>table: ',table.value);
					if(table && table.value){
						c('SCD-------'+client.tbid+'-------->>>>>>Msg: "cards updated!!!"');
					}
					else{
						c('SCD------'+client.tbid+'------->>>>Msg:"cards not updated!!!"');
					}
				});
			}
			else{
				db.collection('playing_table').findOne({_id:MongoID(client.tbid),'pi.si':client.si},{fields:{'pi.$':1}},function(err,tbInfo){
					if(tbInfo && tbInfo.pi && tbInfo.pi.length > 0){
						c('SCD-------------->>>>>tbInfo: ',tbInfo);
						var gCards = (tbInfo.pi[0] && tbInfo.pi[0].gCards)?tbInfo.pi[0].gCards:[tbInfo.pi[0].cards];
						commonClass.SendData(client,'SCD', {gCards:gCards});
					}
					else{
						c('SCD----------------'+client.tbid+'------------------>>>>>"cards error"');
					}
				});
			}
		}
	},
	PFCD : function(data,client,callback){   //Pick From Close Deck  : data = {}, client = {si,tbid}
		/* +-------------------------------------------------------------------+
            desc:event to pick card from close deck
            i/p: data = {},client = socket object,callback = callback function
            o/p: PFCD event : data = {si = seat index of user, card = picked up card , bet = current bet}
        +-------------------------------------------------------------------+ */
		c('PFCD---------->>>>>tbid: '+client.tbid+' si: '+client.si);
		c('PFCD------>>>data: ',data);
		var pfcdCard = '';
		// var repick = (typeof data.repick != 'undefined' && data.repick) ? data.repick : false;
		cdClass.GetTbInfo(client.tbid,{cDeck:1,oDeck:1,spcSi:1,stdP:1,wildCard:1,turn:1,bbv:1,game_id:1,sub_id:1,gt:1,pi:1,rSeq:1},function(table){
			if(table){
				
				c('PFCD------------->>>>>client.si: '+client.si+' ==  table.turn: '+table.turn);

				if(client.si == table.turn){

				
					if(table.pi && table.pi[table.turn] && !_.isEmpty(table.pi[table.turn]) && typeof table.pi[table.turn].cards != 'undefined' && table.pi[table.turn].cards.length == 13){

						//playClass.isFirstTimeUser(table.pi[table.turn].uid.toString(),function(isSpc,RobotCount,HumanCount){
							var rCount = 0,uCount = 0;
							for(x in table.pi){
								if(table.pi[x]._ir == 1){
									rCount++;
								}
								else if(table.pi[x]._ir == 0){
									uCount++;
								}
							}

							if(table.cDeck.length <= 0){ //if cDeck is empty then shuffle thrown cards and create new cDeck
								var remainder = table.oDeck.pop();  // last card of open deck
								var newCDeck = cardsClass.shuffleCards(table.oDeck);
								pfcdCard = newCDeck[0];

								/*if(client.si == table.spcSi){
									var rin = commonClass.GetRandomInt(0,100);
									if(rin <= config.SMRTPICK || (repick && table.pi[table.turn].thp == 0)){
										pfcdCard = cardsClass.setCloseDeckCard(newCDeck,table.pi[table.turn].cards,table.wildCard);
									} else {
										pfcdCard = newCDeck[0];
									}
								}*/
								var rin = commonClass.GetRandomInt(0,100);
								if(rin <= config.SMRTPICK && uCount == 0 && table.stdP.length > 0){
									pfcdCard = cardsClass.setCloseDeckCard(newCDeck,table.pi[table.turn].cards,table.wildCard);
								}

								c('PFCD------->>>>pfcdCard: ',pfcdCard);
								newCDeck = _.without(newCDeck,pfcdCard);

								var upData = {$push:{'pi.$.cards':pfcdCard},$set:{la:new Date(),'pi.$.lpc':pfcdCard,ctrlServer:SERVER_ID,'pi.$.tCount':0,cDeck:newCDeck,oDeck:[remainder],'pi.$.bet':table.bbv},$inc:{'pi.$.pickCount':1}};

								if(table.pi[table.turn]._ir == 0){

									var gCards = table.pi[table.turn].gCards;
									// var temp = _.flatten(gCards.dwd);
									gCards.dwd.push([pfcdCard]);
									// if(temp.length > 0 && temp.length == 13){
									// 	gCards.push([pfcdCard]);
									upData.$set['pi.$.gCards'] = gCards;
									// }
									// else if(temp.length == 0){
									// 	gCards = table.pi[table.turn].cards;
									// 	gCards.push(pfcdCard);
									// 	upData.$set['pi.$.gCards'] = [gCards];
									// }
									// else{
									// 	//do nothing
									// }
								}

								db.collection('playing_table').findAndModify({_id:MongoID(client.tbid),'pi.si':table.turn},{},upData,{new:true},function(err,resp){
									var res = resp.value;
									if(res && res.pi && res.pi[res.turn]){
										/*var cardHint = false;
										var firstDiscard = false;
										var firstActions = false;
										if(config.ASSIST_TUT && res.pi[res.turn] && res.pi[res.turn]._ir == 0 && typeof res.pi[res.turn].thp  != 'undefined' && res.pi[res.turn].thp != null && config.DISCARD_HINT_GAME_COUNT &&  res.pi[res.turn].thp < config.DISCARD_HINT_GAME_COUNT){ //means user has reached beyond hint level
											cardHint = true;
										}*/

										/*cdClass.GetUserInfo(res.pi[res.turn].uid,{},function(userInfo){
											if(userInfo){

												if(config.ASSIST_TUT && config.ASSIST_FIRST_DISCARD && res.pi[res.turn] && res.pi[res.turn]._ir == 0 && typeof userInfo.flags._fDiscard != 'undefined' && userInfo.flags._fDiscard == 0){
													firstDiscard = true;
												}
												if(config.ASSIST_TUT && config.ASSIST_FIRST_ACTIONS && res.pi[res.turn] && res.pi[res.turn]._ir == 0 && typeof userInfo.flags._fActions != 'undefined' && userInfo.flags._fActions == 0){
													firstActions = true;	
												}
											}*/
											if(res.pi[res.turn].uid && res.pi[res.turn].uid != ''){

												db.collection('game_users').updateOne({_id:MongoID(res.pi[res.turn].uid)},{$set:{'flags._fPick':1}},function(err1,resSts){
													if(err1){

														c('PFCD---------------->>>>>>>>err1: ',err1);
													}
													c('PFCD------------------->>>>>first pick completed');
												});
											}
											commonClass.FireEventToTable(table._id.toString(),{en:'PFCD',data:{si:res.turn,uid:res.pi[res.turn].uid,card : pfcdCard,bet:table.bbv}});
											if(typeof callback == 'function'){
												callback(res);
											}
										// });
									}
									else{
										console.log('PFCD::::::::::::1::::::Error: "card pick failed" client.uid: '+client.uid+' client.tbid: '+client.tbid+' client.si: '+client.si+' '+new Date());
									}
								});
							}
							else{
								pfcdCard = table.cDeck[0];
								/*if(client.si == table.spcSi){
									var rin = commonClass.GetRandomInt(0,100);
									if(rin <= config.SMRTPICK || (repick && table.pi[table.turn].thp == 0)){
										pfcdCard = cardsClass.setCloseDeckCard(table.cDeck,table.pi[table.turn].cards,table.wildCard);
									} else {
										pfcdCard = table.cDeck[0];
									}
								}*/
								var rin = commonClass.GetRandomInt(0,100);
								if(rin <= config.SMRTPICK && uCount == 0 && table.stdP.length > 0){
									pfcdCard = cardsClass.setCloseDeckCard(table.cDeck,table.pi[table.turn].cards,table.wildCard);
								}
								
								var remainingCards = _.without(table.cDeck,pfcdCard);
								var upData = {$push:{'pi.$.cards':pfcdCard},$set:{la:new Date(),cDeck:remainingCards,'pi.$.lpc':pfcdCard,ctrlServer:SERVER_ID,'pi.$.tCount':0,'pi.$.bet':table.bbv},$inc:{'pi.$.pickCount':1}};

								if(table.pi[table.turn]._ir == 0){

									var gCards = table.pi[table.turn].gCards;
									// var temp = _.flatten(gCards);
									gCards.dwd.push([pfcdCard]);
									// if(temp.length > 0 && temp.length == 13){
									// 	gCards.push([pfcdCard]);
									upData.$set['pi.$.gCards'] = gCards;
									// }
									// else if(temp.length == 0){
									// 	gCards = table.pi[table.turn].cards;
									// 	gCards.push(pfcdCard);
									// 	upData.$set['pi.$.gCards'] = [gCards];
									// }
									// else{
									// 	//do nothing
									// }
								}
								
								
								db.collection('playing_table').findAndModify({_id:MongoID(client.tbid),'pi.si':table.turn},{},upData,{new:true},function(err,resp){
									var res = resp.value;
									if(res && res.pi && res.pi[res.turn]){
										/*var cardHint = false;
										var firstDiscard = false;
										var firstActions = false;
										if(config.ASSIST_TUT && res.pi[res.turn] && res.pi[res.turn]._ir == 0 && typeof res.pi[res.turn].thp  != 'undefined' && res.pi[res.turn].thp != null && config.DISCARD_HINT_GAME_COUNT &&  res.pi[res.turn].thp < config.DISCARD_HINT_GAME_COUNT){ //means user has reached beyond hint level
											cardHint = true;
										}*/


										/*cdClass.GetUserInfo(res.pi[res.turn].uid,{},function(userInfo){
											if(userInfo){

												if(config.ASSIST_TUT && config.ASSIST_FIRST_DISCARD && res.pi[res.turn] && res.pi[res.turn]._ir == 0 && typeof userInfo.flags._fDiscard != 'undefined' && userInfo.flags._fDiscard == 0){
													firstDiscard = true;
												}
												if(config.ASSIST_TUT && config.ASSIST_FIRST_ACTIONS && res.pi[res.turn] && res.pi[res.turn]._ir == 0 && typeof userInfo.flags._fActions != 'undefined' && userInfo.flags._fActions == 0){
													firstActions = true;	
												}
											}*/
											if(res.pi[res.turn].uid && res.pi[res.turn].uid != ''){

												db.collection('game_users').updateOne({_id:MongoID(res.pi[res.turn].uid)},{$set:{'flags._fPick':1}},function(err1,resSts){
													if(err1){

														c('PFCD---------------->>>>>>>>err1: ',err1);
													}
													c('PFCD------------------->>>>>first pick completed');
												});

											}
											commonClass.FireEventToTable(res._id.toString(),{en:'PFCD',data:{si:res.turn,uid:res.pi[res.turn].uid,card : pfcdCard,bet:table.bbv}});
											if(typeof callback == 'function'){
												callback(res);
											}
										// });
									}
									else{
										console.log('PFCD::::::::::2::::::::::Error: "card pick failed" client.tbid: '+client.tbid+' client.si: '+client.si+' client.uid: '+client.uid+' '+new Date());
									}
								});
							}
						//})
					}
					else{
						c('PFCD:::::::::'+client.tbid+':::::::::>>>>>Error: "not valid no. of cards"');
					}
				}
				else{
					c('PFCD::::::::'+table._id+':::::>>>>Error:"false action"');
				}
			}
			else{
				c('PFCD::::::::::::::::>>>>Error: "table not found!!!"');
			}
		});
	},
	PFOD : function(data,client,callback){  //Pick From Thrown Cards  : data = {}, client = {si,tbid}
		/* +-------------------------------------------------------------------+
            desc:event to pick card from open deck
            i/p: data = {},client = socket object,callback = callback function
            o/p: PFOD event : data = {si = seat index of user, card = picked up card , bet = current bet}
        +-------------------------------------------------------------------+ */
		c('PFOD---------->>>>>tbid: '+client.tbid+' si: '+client.si);
		c('PFOD-------->>>>data: ',data);
		cdClass.GetTbInfo(client.tbid,{oDeck:1,turn:1,wildCard:1,bbv:1,pi:1,rSeq:1,gt:1,game_id:1,sub_id:1,thp:1},function(table){
			if(table){
				c('PFOD------------->>>>>client.si: '+client.si+'==  table.turn: '+table.turn);
				if(client.si == table.turn){

					var pfodCard = table.oDeck.pop();

					c('PFOD-------->>>>pfodCard: ',pfodCard);

					if(typeof pfodCard == 'undefined' || pfodCard == null || pfodCard == '' || _.isEmpty(table.pi[table.turn]) || typeof table.pi[table.turn].cards == 'undefined' || table.pi[table.turn].cards.length != 13){
						console.log('PFOD::::::::::'+client.tbid+':::::::::>>>>Error: "open deck is empty or cards length is not valid!!!" '+new Date());
						return false;
					}


					/*if(typeof table.oDeck[0] != 'undefined'){
						var odc = table.oDeck[0];
						var DCScards = cardsClass.DifferCardSuit(odc);
						var DCSwildCard = cardsClass.DifferCardSuit(table.wildCard);
						if(DCScards.rank == DCSwildCard.rank || DCScards.suit == 'j'){
							console.log("PFOD-------->>>>you can not pick wildcard or joker from open deck");
							return false;
						}
					}*/


					var game_id = table.game_id;
					if(table.gt == 'Deal' || table.gt == 'Pool'){
						game_id = game_id+'.'+table.sub_id;
					}

					var upData = {$set:{la:new Date(),'pi.$.lpc':pfodCard,ctrlServer:SERVER_ID,'pi.$.occ':1,'pi.$.tCount':0,'pi.$.bet':table.bbv},$push:{'pi.$.cards' :pfodCard},$pop:{oDeck:1},$inc:{'pi.$.pickCount':1}};
					
					if(table.pi[table.turn]._ir == 0){
						
						var gCards = table.pi[table.turn].gCards;
						// var temp = _.flatten(gCards);
						// if(temp.length > 0 && temp.length == 13){
						gCards.dwd.push([pfodCard]);
						// 	gCards.push([pfodCard]);
						upData.$set['pi.$.gCards'] = gCards;
						// }
						// else if(temp.length == 0){
						// 	gCards = table.pi[table.turn].cards;
						// 	gCards.push(pfodCard);	
						// 	upData.$set['pi.$.gCards'] = [gCards];
						// }
						// else{
						// 	//do nothing
						// }
					}



					db.collection('playing_table').findAndModify({_id:table._id,'pi.si':table.turn},{},upData,{new:true},function(err,resp){
						var res = resp.value;
						if(res && res.pi && res.pi[res.turn]){
							
							/*var cardHint = false;
							var firstDiscard = false;
							var firstActions = false;
							if(config.ASSIST_TUT && res.pi[res.turn]._ir == 0 && typeof res.pi[res.turn].thp  != 'undefined' && res.pi[res.turn].thp != null && config.DISCARD_HINT_GAME_COUNT &&  res.pi[res.turn].thp < config.DISCARD_HINT_GAME_COUNT){ //means user has reached beyond hint level
								cardHint = true;
							}*/


							/*cdClass.GetUserInfo(res.pi[res.turn].uid,{},function(userInfo){
								if(userInfo){

									if(config.ASSIST_TUT && config.ASSIST_FIRST_DISCARD && res.pi[res.turn]._ir == 0 && typeof userInfo.flags._fDiscard != 'undefined' && userInfo.flags._fDiscard == 0){
										firstDiscard = true;
									}
									if(config.ASSIST_TUT && config.ASSIST_FIRST_ACTIONS && res.pi[res.turn]._ir == 0 && typeof userInfo.flags._fActions != 'undefined' && userInfo.flags._fActions == 0){
										firstActions = true;
									}
								}*/
								if(res.pi[res.turn].uid && res.pi[res.turn].uid != ''){

									db.collection('game_users').updateOne({_id:MongoID(res.pi[res.turn].uid)},{$set:{'flags._fPick':1}},function(err1,resSts){
										if(err1){

											c('PFOD---------------->>>>>>>>err1: ',err1);
										}
										c('PFOD------------------->>>>>first pick completed');
									});
								}
								commonClass.FireEventToTable(res._id.toString(),{en:'PFOD',data:{si:res.turn,uid:res.pi[res.turn].uid,card:pfodCard,thp:res.pi[res.turn].thp,bet:table.bbv}});
								playClass.DC({},{tbid : res._id.toString()});
								if(typeof callback == 'function'){
									callback(res);
								}
							// });
						}
						else{
							console.log('PFOD::::::::::::::::::Error: "invalid pick event" client.si: '+client.si+' res: ',res,' '+new Date());
						}
					});
				}
				else{
					c('PFOD::::::::'+table._id+':::::>>>>Error:"false action"');
				}
			}
			else{
				c('PFOD:::::::::::::::>>>>Error:" table not found!!!"');
			}
		});
	},
	DSCRD : function(data,client){  //Throw Card On Desk	 : data = {card,bet}, client = {si,tbid}
		/* +-------------------------------------------------------------------+
            desc:event to discard card 
            i/p: data = {card = card to throw,bet = bet set by player},client = socket object
            o/p: DSCRD event : data = {si = seat index of user, card = picked up card , bet = current bet,bbv = current bet,isRaise = 1/0 if the bet has raised or not}
        +-------------------------------------------------------------------+ */
		c('DSCRD---------->>>>>tbid: '+client.tbid+' si: '+client.si);
		c('DSCRD-------->>>>data: ',data);
		var si = client.si;
		cdClass.GetTbInfo(client.tbid,{},function(table){
			if(!table){
				c('DSCRD:::::::::::::::>>>Error: "table not found!!!"');
				return false;
			}
			c('DSCRD--------->>>>table.turn: '+table.turn);
			if(table.turn == -1){ //added to handle table stuck issue
				c('DSCRD------------>>>>>>>Error:"turn user lost"');
				return false;
			}
			if(!table.pi){
				c('DSCRD:::::::::::::::>>>Error: "table players not found!!!"');
				return false;
			}
			if(!table.pi[si]){
				c('DSCRD:::::::::::::>>>>>>Error: "discard user not found"');
				return false;
			}
			c('DSCRD------------->>>>>si : '+si+' == table.turn: '+table.turn);
			if(si == table.turn){
				var bet = (table.gt == 'Bet' && typeof data.bet != 'undefined' && data.bet >= table.bbv && data.bet <= table.maxBet)? data.bet : table.pi[si].bet;

				c('DSCRD----------->>>>>table.pi[si].cards: '+table.pi[si].cards+' data.card: '+data.card);
				var remainingCards = _.without(table.pi[si].cards,data.card);

				if(remainingCards.length == 13){

					jtClass.cancelJobOnServers(table._id.toString(),table.jid);
					c('DSCRD-------------'+table._id+'---------si: '+si+'--------'+table.turn+'------------->>>remainingCards.length: (13): ',remainingCards.length);   //13 cards
					var upData = {$set:{la: new Date(),ctrlServer:SERVER_ID,'pi.$.cards':remainingCards,'pi.$.bet':bet,bbv:bet,'pi.$.lpc':'','pi.$.occ':0,'pi.$._uur':1},$push:{oDeck:data.card}/*,$inc:{'pi.$.secTime':0}*/};
					
					if(table.pi[si].sct == true && typeof data.secTime == 'undefined'){
						var diff = commonClass.GetTimeDifference(new Date(table.pi[si].tst),new Date());
						var scc = table.pi[si].secTime - diff;
						upData.$set['pi.$.secTime'] = parseInt(scc);
						upData.$set['pi.$.sct'] = false;
					}
					else if (typeof data.secTime != 'undefined' && table.pi[si].sct == true) {
						upData.$set['pi.$.secTime'] = parseInt(data.secTime);
						upData.$set['pi.$.sct'] = false;
					}

					///////////new logic start//////////


					// if(table.pi[si]._ir == 0 && table.pi[si].gCards){
						
					// 	if(table.pi[si].gCards.length > 0){

					// 		var gCards = table.pi[table.turn].gCards;
					// 		c('DSCRD---------->>>>>>gCards: ',gCards);
					// 		for(var x in gCards){
					// 			if(_.contains(gCards[x],data.card)){
					// 				gCards[x] = _.without(gCards[x],data.card);
					// 				break;
					// 			}
					// 		}
					// 		c('DSCRD------------->>>>>gCards: ',gCards);
					// 		upData.$set['pi.$.gCards'] = gCards;
					// 	}
					// 	else{
					// 		var gCards = remainingCards;
					// 		upData.$set['pi.$.gCards'] = [gCards];
					// 	}
					// }

					if(table.pi[si]._ir == 0 && table.pi[si].gCards){
						
						if(table.pi[si].gCards.pure.length > 0){

							var gCards = table.pi[table.turn].gCards.pure;
							c('DSCRD---------->>>>>>gCards: ',gCards);
							for(var x in gCards){
								if(_.contains(gCards[x],data.card)){
									gCards[x] = _.without(gCards[x],data.card);
									break;
								}
							}
							c('DSCRD------------->>>>>gCards: ',gCards);
							upData.$set['pi.$.gCards.pure'] = gCards;
						}
						else if (table.pi[si].gCards.seq.length > 0){
							var gCards = table.pi[table.turn].gCards.seq;
							c('DSCRD---------->>>>>>gCards: ',gCards);
							for(var x in gCards){
								if(_.contains(gCards[x],data.card)){
									gCards[x] = _.without(gCards[x],data.card);
									break;
								}
							}
							c('DSCRD------------->>>>>gCards: ',gCards);
							upData.$set['pi.$.gCards.seq'] = gCards;
						}
						else if (table.pi[si].gCards.set.length > 0){
							var gCards = table.pi[table.turn].gCards.set;
							c('DSCRD---------->>>>>>gCards: ',gCards);
							for(var x in gCards){
								if(_.contains(gCards[x],data.card)){
									gCards[x] = _.without(gCards[x],data.card);
									break;
								}
							}
							c('DSCRD------------->>>>>gCards: ',gCards);
							upData.$set['pi.$.gCards.set'] = gCards;
						}
						else if (table.pi[si].gCards.dwd.length > 0){
							var gCards = table.pi[table.turn].gCards.dwd;
							c('DSCRD---------->>>>>>gCards: ',gCards);
							for(var x in gCards){
								if(_.contains(gCards[x],data.card)){
									gCards[x] = _.without(gCards[x],data.card);
									break;
								}
							}
							c('DSCRD------------->>>>>gCards: ',gCards);
							upData.$set['pi.$.gCards.dwd'] = gCards;
						}
						else{
							var gCards = remainingCards;
							upData.$set['pi.$.gCards.dwd'] = [gCards];
						}
					}

					///////////new logic end/////////




					db.collection('playing_table').findAndModify({_id:MongoID(table._id),'pi.si':si},{},upData,{new:true},function(err,resp){
						var res = resp.value;
						
						if(res && res.pi && res.pi[si]){

							if(res.pi[si].uid && res.pi[si].uid != ''){

								db.collection('game_users').updateOne({_id:MongoID(res.pi[si].uid)},{$set:{'flags._fDiscard':1}},function(err1,resSts){
									if(err1){

										c('DSCRD---------------->>>>>>>>err1: ',err1);
									}
									c('DSCRD------------------->>>>>first discard completed');
								});
							}

							var isRaise = (res.gt == 'Bet' && table.bbv < res.bbv) ? 1 : 0; //raise in bet

							/*var game_id = table.game_id;
							if(table.gt == 'Deal' || table.gt == 'Pool'){
								game_id = game_id+'.'+table.sub_id;
							}*/

							commonClass.FireEventToTable(res._id.toString(),{en:'DSCRD',data:{si:si,uid:res.pi[si].uid,card:data.card,finish:false,bbv:res.bbv,time:res.pi[si].secTime,cdd:false,isRaise:isRaise}});
							playClass.DC({},{tbid : res._id.toString()});
							// setTimeout(function(){   //latency
								c('DSCRD-------------->>>>>"turn going to change"');
								playingTableClass.changeTableTurn(res._id.toString(),'discard');
							// },1000);
						}
						else{
							c('DSCRD::::::::::::::::::::::::::::::>>>>>"false action user is not present on table"');
							return false;
						}
					});
				}
				else{
					c('DSCRD::::::::'+table._id+':::::>>>>Error:"false action not enough card"');
					commonClass.SendData(client,'REV',{card: data.card});
				}
			}
			else{
				c('DSCRD::::::::'+table._id+':::::>>>>Error:"false action"');
				commonClass.SendData(client,'REV',{card: data.card});
			}
		});
	},
	FNS_old:function(data,client,callback){ //finish   data = {card}
		/* +-------------------------------------------------------------------+
            desc:event to finish game 
            i/p: data = {card = card to throw},client = socket object, callback = callback function
            o/p: FNS event : data = {si = seat index of user,t = finish timer,asi = array of index of active users}
        +-------------------------------------------------------------------+ */
		c('FNS---------->>>>>tbid: '+client.tbid+' si: '+client.si);
		c('FNS---------->>>>>data: '+data);
		var si = client.si;
		cdClass.GetTbInfo(client.tbid,{},function(table){
			if(!table){
				c('FNS:::::::::::::>>>>>>Error: "table not found!!!"');
				return false;
			}
			if(!table.pi){
				c('FNS:::::::::::::::>>>Error: "table players not found!!!"');
				return false;
			}
			if(!table.pi[si]){
				c('FNS::::::::::::::>>>>Error: "player not found"');
				return false;
			}
			var remainingCards = _.without(table.pi[si].cards,data.card);

			var gCards = table.pi[si].gCards;
			c('FNS--------1212---->>>>>>gCards: ',gCards);
			// for(var x in gCards){
			// 	if(_.contains(gCards[x],data.card)){
			// 		gCards[x] = _.without(gCards[x],data.card);
			// 		break;
			// 	}
			// }

			if(table.pi[si]._ir == 0 && table.pi[si].gCards){
						
				if(table.pi[si].gCards.pure.length > 0){

					var pureCards = table.pi[table.turn].gCards.pure;
					c('FNS---------->>>>>>gCards: ',pureCards);
					for(var x in pureCards){
						if(_.contains(pureCards[x],data.card)){
							pureCards[x] = _.without(pureCards[x],data.card);
							break;
						}
					}
					c('FNS------------->>>>>gCards: ',gCards);
					gCards.pure = pureCards;
					// upData.$set['pi.$.gCards.pure'] = gCards;
				}
				else if (table.pi[si].gCards.seq.length > 0){
					var seqCards = table.pi[table.turn].gCards.seq;
					c('FNS---------->>>>>>gCards: ',seqCards);
					for(var x in seqCards){
						if(_.contains(seqCards[x],data.card)){
							seqCards[x] = _.without(seqCards[x],data.card);
							break;
						}
					}
					c('FNS------------->>>>>gCards: ',seqCards);
					gCards.seq = seqCards;
					// upData.$set['pi.$.gCards.seq'] = seqCards;
				}
				else if (table.pi[si].gCards.set.length > 0){
					var setCards = table.pi[table.turn].gCards.set;
					c('FNS---------->>>>>>gCards: ',setCards);
					for(var x in setCards){
						if(_.contains(setCards[x],data.card)){
							setCards[x] = _.without(setCards[x],data.card);
							break;
						}
					}
					c('FNS------------->>>>>gCards: ',setCards);
					gCards.seq = setCards;
					// upData.$set['pi.$.gCards.set'] = gCards;
				}
				else if (table.pi[si].gCards.dwd.length > 0){
					var dwdCards = table.pi[table.turn].gCards.dwd;
					c('FNS---------->>>>>>gCards: ',dwdCards);
					for(var x in dwdCards){
						if(_.contains(dwdCards[x],data.card)){
							dwdCards[x] = _.without(dwdCards[x],data.card);
							break;
						}
					}
					c('FNS------------->>>>>gCards: ',dwdCards);
					gCards.seq = dwdCards;
					// upData.$set['pi.$.gCards.dwd'] = gCards;
				}
				else{
					// var gCards = remainingCards;
					gCards.dwd = remainingCards;
					// upData.$set['pi.$.gCards.dwd'] = [gCards];
				}
			}


			c('FNS-----'+table._id+'------->>>>>tst: '+table.tst+' pi: ',table.pi);
			if(remainingCards.length == 13 && data.card && table.ap > 1 && table._isLeave == 0 && table.tst == "RoundStarted"){
				jtClass.cancelJobOnServers(table._id.toString(),table.jid);

				var jobId = commonClass.GetRandomString(10);
				var upData = {$set:{la:new Date(),ctrlServer:SERVER_ID,'pi.$.cards':remainingCards,'pi.$.gCards':gCards,'pi.$.s':'finish',jid:jobId,'pi.$.lpc':'','pi.$._uur':1,tst:'Finished',ctt:new Date(),fnsPlayer:si}/*,$inc:{'pi.$.secTime':0}*/,$push:{oDeck:data.card}};
				
				/*if(table.pi[si].sct == true && typeof data.secTime == 'undefined'){
					var diff = commonClass.GetTimeDifference(new Date(table.pi[si].tst),new Date());
					var scc = table.pi[si].secTime - diff;
					upData.$set['pi.$.secTime'] = parseInt(scc);
					upData.$set['pi.$.sct'] = false;
				}
				else if (typeof data.secTime != 'undefined' && table.pi[si].sct == true) {
					upData.$set['pi.$.secTime'] = parseInt(data.secTime);
					upData.$set['pi.$.sct'] = false;
				}*/

				var finishTimer = config.FNS;

				db.collection('playing_table').findAndModify({_id:table._id,'pi.si':si},{},upData,{new:true},function(err,resp){
					resp = resp.value;
					if(resp && resp.pi && resp.pi[si]){

						if(resp.pi[si].uid && resp.pi[si].uid != ''){

							db.collection('game_users').updateOne({_id:MongoID(resp.pi[si].uid)},{$set:{'flags._fActions':1}},function(err1,resSts){
								if(err1){

									c('FNS---------------->>>>>>>>err1: ',err1);
								}
								else{
									c('FNS------------------->>>>>firstActions completed');
								}
							});
						}

						var pi = resp.pi;
						var aSi = [];
						c('FNS--------'+resp._id+'-------->>>>>pi: ',pi);
						for(var k in pi){
							if(!_.isEmpty(pi[k]) && typeof pi[k].si != 'undefined' && (pi[k].s == 'playing' || pi[k].s == 'finish')){
								aSi.push(pi[k].si);
							}
						}


						// setTimeout(function(){
						commonClass.FireEventToTable(resp._id.toString(),{en:'DSCRD',data:{si:si,uid:pi[si].uid,time:resp.pi[si].secTime,card:data.card,bbv:resp.bbv,finish:true,isRaise:0}});
						commonClass.FireEventToTable(resp._id.toString(),{en:'FNS',data:{si:si,uid:pi[si].uid,t:finishTimer,asi:aSi,card:data.card}});
						// playClass.DC({},{tbid : resp._id.toString()});

						var players = playClass.getPlayingUserInRound(resp.pi);

						for(var i = 0;i < players.length ;i++){
							if(players[i].s == 'playing' && players[i]._ir == 1){
								// var robotTime = commonClass.GetRandomInt(config.ROBOT_TURN_DELAY[0],config.ROBOT_TURN_DELAY[1]);
								c('FNS-------->>>players[i]: ',players[i]);
								

								robotsClass.lateRobotDeclare(resp,players[i].si);
							}
						}


						var fns = commonClass.AddTime(finishTimer);
						schedule.scheduleJob(resp.jid,new Date(fns),function(){
							schedule.cancelJob(resp.jid);
							cdClass.GetTbInfo(resp._id.toString(),{pi:1},function(table1){
								if(table1){

									var players1 = playClass.getPlayingUserInRound(table1.pi);
									c('FNS--------------->>>>>>>msg: "finish timer completed"');
									for(var j = 0;j < players1.length ;j++){
										if(players1[j].s == 'playing'&& players1[j]._ir == 0){
											c('FNS--------------->>>>>>>msg: "finish timer playing"');
											//need to replace with the new logic by checking sequence
											var dCards = {pure : [],seq : [],set : [],dwd : players1[j].cards};
											// var ps = config.MAX_DEADWOOD_PTS;
											c('FNS------------->>>>>>dCards: ',dCards,' players1[j].s: ',players1[j].s,' players1[j].si: ',players1[j].si);
											var ps = cardsClass.cardsSum(players1[j].cards,resp.wildCard);
											playClass.DECL({dCards:dCards,ps : ps},{si:players1[j].si,tbid:table1._id.toString()}); 

											//new logic enable after cards storing done from client side
											// playingTableClass.lateUserDeclare(resp,players1[j].si);
										}
										else if (players1[j].s == 'finish' && players1[j]._ir == 0){

											c('FNS--------------->>>>>>>msg: "finish timer finish"');
											var godanalysedCards = gbClass.GetSortedCard(players1[j].cards,resp.wildCard);
											var analysedCards = cardsClass.cardsAnalyser(players1[j].cards,resp.wildCard);
											if(godanalysedCards.cardSum <= analysedCards.cardSum){
												analysedCards = godanalysedCards;
											}
											var ps = 0;
											if(analysedCards.pure.length > 0 && (analysedCards.pure.length+analysedCards.seq.length) > 1){   //means the grouping is valid

												var dCards = {pure : analysedCards.pure, seq : analysedCards.seq, set : analysedCards.set, dwd : analysedCards.dwd};
												ps = analysedCards.cardSum;
											}
											else{ //means all the cards will be considered as deadwood
												var temp = analysedCards.pure.concat(analysedCards.seq).concat(analysedCards.set).concat(analysedCards.dwd);
												temp = _.flatten(temp);
												var dCards = {pure:[[dvfd,fg,gfg],[fsdfsd,ffd,fdfg]],seq:[],set:[],dwd:temp};
												ps = cardsClass.cardsSum(temp,table.wildCard);
											}

											c('FNS--------------->>>>>>>dCards:',dCards);
											playClass.DECL({dCards:dCards,ps : ps},{si:players1[j].si,tbid:table1._id.toString()}); 
										}
									}	
								}
								else{
									c('FNS-------------->>>>>>>.msg: "table not found"');
								}
							});	
						});
						// },2000);

						if(typeof callback == 'function'){
							callback();
						}
					}
					else{
						c('FNS-------------->>>>>>Error : "user not found on table"');
					}
				});
			}
			else{

				console.log('FNS-----'+table._id+'-------remainingCards: ',remainingCards,'---data.card: '+data.card+'---table.ap: '+table.ap+'----table._isLeave: '+table._isLeave+'----table.tst: '+table.tst+'-->>>>Error: "invalid number of cards"'+new Date());
				// commonClass.SendData(client,'PUP',{},'error:1031');    //invalid number of cards to finish
			}

		});
	},
	FNS:function(data,client,callback){ //finish   data = {card}
		/* +-------------------------------------------------------------------+
            desc:event to finish game 
            i/p: data = {card = card to throw},client = socket object, callback = callback function
            o/p: FNS event : data = {si = seat index of user,t = finish timer,asi = array of index of active users}
        +-------------------------------------------------------------------+ */
		c('FNS---------->>>>>tbid: '+client.tbid+' si: '+client.si);
		c('FNS---------->>>>>data: '+data);
		var si = client.si;
		cdClass.GetTbInfo(client.tbid,{},function(table){
			if(!table){
				c('FNS:::::::::::::>>>>>>Error: "table not found!!!"');
				return false;
			}
			if(!table.pi){
				c('FNS:::::::::::::::>>>Error: "table players not found!!!"');
				return false;
			}
			if(!table.pi[si]){
				c('FNS::::::::::::::>>>>Error: "player not found"');
				return false;
			}
			var remainingCards = _.without(table.pi[si].cards,data.card);

			var gCards = table.pi[si].gCards;
			c('FNS--------1212---->>>>>>gCards: ',gCards);
			// for(var x in gCards){
			// 	if(_.contains(gCards[x],data.card)){
			// 		gCards[x] = _.without(gCards[x],data.card);
			// 		break;
			// 	}
			// }

			if(table.pi[si]._ir == 0 && table.pi[si].gCards){
						
				if(table.pi[si].gCards.pure.length > 0){

					var pureCards = table.pi[table.turn].gCards.pure;
					c('FNS---------->>>>>>gCards: ',pureCards);
					for(var x in pureCards){
						if(_.contains(pureCards[x],data.card)){
							pureCards[x] = _.without(pureCards[x],data.card);
							break;
						}
					}
					c('FNS------------->>>>>gCards: ',gCards);
					gCards.pure = pureCards;
					// upData.$set['pi.$.gCards.pure'] = gCards;
				}
				else if (table.pi[si].gCards.seq.length > 0){
					var seqCards = table.pi[table.turn].gCards.seq;
					c('FNS---------->>>>>>gCards: ',seqCards);
					for(var x in seqCards){
						if(_.contains(seqCards[x],data.card)){
							seqCards[x] = _.without(seqCards[x],data.card);
							break;
						}
					}
					c('FNS------------->>>>>gCards: ',seqCards);
					gCards.seq = seqCards;
					// upData.$set['pi.$.gCards.seq'] = seqCards;
				}
				else if (table.pi[si].gCards.set.length > 0){
					var setCards = table.pi[table.turn].gCards.set;
					c('FNS---------->>>>>>gCards: ',setCards);
					for(var x in setCards){
						if(_.contains(setCards[x],data.card)){
							setCards[x] = _.without(setCards[x],data.card);
							break;
						}
					}
					c('FNS------------->>>>>gCards: ',setCards);
					gCards.set = setCards;
					// upData.$set['pi.$.gCards.set'] = gCards;
				}
				else if (table.pi[si].gCards.dwd.length > 0){
					var dwdCards = table.pi[table.turn].gCards.dwd;
					c('FNS---------->>>>>>gCards: ',dwdCards);
					for(var x in dwdCards){
						if(_.contains(dwdCards[x],data.card)){
							dwdCards[x] = _.without(dwdCards[x],data.card);
							break;
						}
					}
					c('FNS------------->>>>>gCards: ',dwdCards);
					gCards.dwd = dwdCards;
					// upData.$set['pi.$.gCards.dwd'] = gCards;
				}
				else{
					// var gCards = remainingCards;
					gCards.dwd = remainingCards;
					// upData.$set['pi.$.gCards.dwd'] = [gCards];
				}
			}


			c('FNS-----'+table._id+'------->>>>>tst: '+table.tst+' pi: ',table.pi);
			if(remainingCards.length == 13 && data.card && table.ap > 1 && table._isLeave == 0 && table.tst == "RoundStarted"){
				jtClass.cancelJobOnServers(table._id.toString(),table.jid);

				var jobId = commonClass.GetRandomString(10);
				var upData = {$set:{la:new Date(),ctrlServer:SERVER_ID,'pi.$.cards':remainingCards,'pi.$.gCards':gCards,'pi.$.s':'finish',jid:jobId,'pi.$.lpc':'','pi.$._uur':1,tst:'Finished',ctt:new Date(),fnsPlayer:si}/*,$inc:{'pi.$.secTime':0}*/,$push:{oDeck:data.card}};
				
				/*if(table.pi[si].sct == true && typeof data.secTime == 'undefined'){
					var diff = commonClass.GetTimeDifference(new Date(table.pi[si].tst),new Date());
					var scc = table.pi[si].secTime - diff;
					upData.$set['pi.$.secTime'] = parseInt(scc);
					upData.$set['pi.$.sct'] = false;
				}
				else if (typeof data.secTime != 'undefined' && table.pi[si].sct == true) {
					upData.$set['pi.$.secTime'] = parseInt(data.secTime);
					upData.$set['pi.$.sct'] = false;
				}*/

				var finishTimer = config.FNS;

				db.collection('playing_table').findAndModify({_id:table._id,'pi.si':si},{},upData,{new:true},function(err,resp){
					resp = resp.value;
					if(resp && resp.pi && resp.pi[si]){

						if(resp.pi[si].uid && resp.pi[si].uid != ''){

							db.collection('game_users').updateOne({_id:MongoID(resp.pi[si].uid)},{$set:{'flags._fActions':1}},function(err1,resSts){
								if(err1){

									c('FNS---------------->>>>>>>>err1: ',err1);
								}
								else{
									c('FNS------------------->>>>>firstActions completed');
								}
							});
						}

						var pi = resp.pi;
						var aSi = [];
						c('FNS--------'+resp._id+'-------->>>>>pi: ',pi);
						for(var k in pi){
							if(!_.isEmpty(pi[k]) && typeof pi[k].si != 'undefined' && (pi[k].s == 'playing' || pi[k].s == 'finish')){
								aSi.push(pi[k].si);
							}
						}


						// setTimeout(function(){
						commonClass.FireEventToTable(resp._id.toString(),{en:'DSCRD',data:{si:si,uid:pi[si].uid,time:resp.pi[si].secTime,card:data.card,bbv:resp.bbv,finish:true,cdd:false,isRaise:0}});
						commonClass.FireEventToTable(resp._id.toString(),{en:'FNS',data:{si:si,uid:pi[si].uid,t:finishTimer,asi:aSi,card:data.card}});
						playClass.DC({},{tbid : resp._id.toString()});

						var players = playClass.getPlayingUserInRound(resp.pi);

						for(var i = 0;i < players.length ;i++){
							if(players[i].s == 'playing' && players[i]._ir == 1){
								// var robotTime = commonClass.GetRandomInt(config.ROBOT_TURN_DELAY[0],config.ROBOT_TURN_DELAY[1]);
								c('FNS-------->>>players[i]: ',players[i]);
								

								robotsClass.lateRobotDeclare(resp,players[i].si);
							}
						}


						var fns = commonClass.AddTime(finishTimer);
						schedule.scheduleJob(resp.jid,new Date(fns),function(){
							schedule.cancelJob(resp.jid);
							cdClass.GetTbInfo(resp._id.toString(),{pi:1},function(table1){
								if(table1){

									var players1 = playClass.getPlayingUserInRound(table1.pi);
									c('FNS--------------->>>>>>>msg: "finish timer completed"');
									for(var j = 0;j < players1.length ;j++){
										if(players1[j].s == 'playing'&& players1[j]._ir == 0){
											c('FNS--------------->>>>>>>msg: "finish timer playing"');
											//need to replace with the new logic by checking sequence
											var dCards = {pure : [],seq : [],set : [],dwd : players1[j].cards};
											// var ps = config.MAX_DEADWOOD_PTS;
											c('FNS------------->>>>>>dCards: ',dCards,' players1[j].s: ',players1[j].s,' players1[j].si: ',players1[j].si);
											var ps = cardsClass.cardsSum(players1[j].cards,resp.wildCard);
											playClass.DECL({dCards:dCards,ps : ps},{si:players1[j].si,tbid:table1._id.toString()}); 

											//new logic enable after cards storing done from client side
											// playingTableClass.lateUserDeclare(resp,players1[j].si);
										}
										else if (players1[j].s == 'finish' && players1[j]._ir == 0){

											c('FNS--------------->>>>>>>msg: "finish timer finish"');
											var ps = 0;
											var dCards = {pure : players1[j].gCards.pure, seq : players1[j].gCards.seq, set : players1[j].gCards.set, dwd : players1[j].gCards.dwd};
											temp = _.flatten(players1[j].gCards.dwd);
											ps = cardsClass.cardsSum(temp,table.wildCard);
											c('FNS--------------->>>>>>>dCards:',dCards);
											playClass.DECL({dCards:dCards,ps : ps},{si:players1[j].si,tbid:table1._id.toString()}); 
										}
									}	
								}
								else{
									c('FNS-------------->>>>>>>.msg: "table not found"');
								}
							});	
						});
						// },2000);

						if(typeof callback == 'function'){
							callback();
						}
					}
					else{
						c('FNS-------------->>>>>>Error : "user not found on table"');
					}
				});
			}
			else{

				console.log('FNS-----'+table._id+'-------remainingCards: ',remainingCards,'---data.card: '+data.card+'---table.ap: '+table.ap+'----table._isLeave: '+table._isLeave+'----table.tst: '+table.tst+'-->>>>Error: "invalid number of cards"'+new Date());
				// commonClass.SendData(client,'PUP',{},'error:1031');    //invalid number of cards to finish
			}

		});
	},
	DECL:function(data,client,hide){  // Declare : data = {dCards,ps}; dCards = {pure : [[],[]],seq : [[],[]],set : [[],[]],dwd : []}; hide = flag for hiding declaration
		/* +-------------------------------------------------------------------+
            desc:event to declare game 
            i/p: data = {dCards = object of formatted cards,ps = points of cards},client = socket object
        +-------------------------------------------------------------------+ */
		c('DECL--------->>>>client.tbid: '+client.tbid+' client.si: '+client.si+' data: ',data);

		var si = client.si;
		cdClass.GetTbInfo(client.tbid,{},function(table){
			if(!table){
				c('DECL::::::::::>>>>Error: "table not found!!!"');
				return false;
			}
			if(table.pi && table.pi[si] && typeof table.pi[si].s !='undefined' && table.fnsPlayer != -1 && (table.pi[si].s == 'finish' || table.pi[si].s == 'playing')){

				data.dCards.dwd = _.flatten(data.dCards.dwd);
				c('DECL------111----->>>>>>data.dCards: ',data.dCards);


				if(table.pi[si]._ir == 0){  //special condition to validate live player cards
					var cond = false;

					if(config.ONE_SEQUENCE_POINTS){
						cond = data.dCards.pure.length > 0;
					}
					else{
						cond = (data.dCards.pure.length > 0 && (data.dCards.pure.length+data.dCards.seq.length) >1);
					}
					if(cond){   //means the grouping is valid

						data.dCards = {pure : data.dCards.pure, seq : data.dCards.seq, set : data.dCards.set, dwd : data.dCards.dwd};
						data.ps = cardsClass.cardsValidPoints(data.dCards,table.wildCard);
					}
					else{ //means all the cards will be considered as deadwood
						var temp = data.dCards.pure.concat(data.dCards.seq).concat(data.dCards.set).concat(data.dCards.dwd);
						temp = _.flatten(temp);
						data.dCards = {pure:[],seq:[],set:[],dwd:temp};
						data.ps = cardsClass.cardsSum(temp,table.wildCard);
					}
				}

				c('DECL-----------222------->>>>>>>>data.ps: '+data.ps+' data.dCards: ',data.dCards);
				var udps = (table.gt == 'Deal' || table.gt == 'Pool') ? data.ps : 0;
				db.collection('playing_table').findAndModify({_id:table._id,'pi.si':si},{},{$set:{la:new Date(),'pi.$.s':'declare','pi.$.dCards':data.dCards,'pi.$.ps':data.ps},$inc:{declCount:1,'pi.$.dps':udps}},{new:true},function(err,table1){
					var res = table1.value;
					c('DECL---------->>>>>>>res: ',res);
					if(err){
						console.log('DECL::::::::::'+table._id+'::::::::si: '+si+' ---data.dCards: ',data.dCards,' data.ps: '+data.ps+' udps: '+udps+':::::::Error: ',err,' '+new Date());
					}

					if(!res){
						console.log('DECL::::::::::'+table._id+'::::::::si: '+si+' ---data.dCards: ',data.dCards,' data.ps: '+data.ps+' udps: '+udps+' '+new Date());
						return false;
					}
					if(!hide){
						commonClass.FireEventToTable(res._id.toString(),{en:'DECL',data:{si:si,uid:table.pi[si].uid}});
					}
					c('DECL------->>>>>declCount: '+res.declCount+' playCount: '+res.playCount);

					var playCount = 0;

					for(var i in res.pi){
						if(res.pi[i] && !_.isEmpty(res.pi[i]) && typeof res.pi[i].s != 'undefined' && _.contains(['playing','finish','declare'],res.pi[i].s)){
							playCount++;
						}
					}
					c('DECL------------->>>>playCount: '+playCount);
					if(res.declCount >= playCount){  
						jtClass.cancelJobOnServers(res._id.toString(),res.jid);
						//logic of all declaration here 
						c('DECL----------->>>>>>: finish player: '+res.fnsPlayer+' res.pi: ',res.pi);
						if(_.isEmpty(res.pi[res.fnsPlayer]) || typeof res.pi[res.fnsPlayer].dCards == 'undefined' || res.pi[res.fnsPlayer].dCards == null || _.isEmpty(res.pi[res.fnsPlayer].dCards)){
							//means finish user left the table so resume the game



							var pi = res.pi;
							var asi = [];
							var shortBtn = [];

							for(var k in pi){
								if(!_.isEmpty(pi[k]) && typeof pi[k].si != 'undefined' && (pi[k].s == 'playing' || pi[k].s == 'declare' || pi[k].s == 'finish')){
									asi.push(pi[k].si);
									shortBtn.push({uid:pi[k].uid,sort:pi[k].sort})
								}
							}
							asi = _.without(asi,res.fnsPlayer);



							commonClass.FireEventToTable(res._id.toString(),{en:'INDECL',data:{si:res.fnsPlayer,ocard:res.oDeck[res.oDeck.length-1],sort:shortBtn,asi:asi}});
							for(var i in pi){
								if(!_.isEmpty(pi[i]) && typeof pi[i].s != 'undefined' && pi[i].s != null && pi[i].s == 'declare'){
									pi[i].s = 'playing';
									pi[i].dps = (res.gt == 'Deal' || res.gt == 'Pool') ? pi[i].dps-pi[i].ps : 0; //unsetting dps
									pi[i].ps = 0;
									pi[i].wc = 0;
									pi[i].dCards = {};
								}
							}
							
							cdClass.UpdateTableData(res._id.toString(),{$set:{tst:'RoundStarted',fnsPlayer:-1,declCount:0,pi:pi,ctt:new Date()}},function(upData){
								if(upData){

									playingTableClass.changeTableTurn(upData._id.toString(),'invalid_declare');
								}
								else{
									c('DECL--------1------->>>>>>Error:"table not found"');
								}
							});
						}
						else{
							//finish user has valid rummy hence declare winner 
							var fnsPlayerPoints =  cardsClass.cardsValidPoints(res.pi[res.fnsPlayer].dCards,res.wildCard);
							var fnsPureCount = res.pi[res.fnsPlayer].dCards.pure.length;
							var fnsSeqCount = res.pi[res.fnsPlayer].dCards.seq.length;
							if(fnsPlayerPoints == 0 && fnsPureCount > 0 && (fnsPureCount + fnsSeqCount) > 1 /* && res.pi[res.fnsPlayer].dCards.dwd.length == 0*/){
								//declare winner logic here
								if(res.gt == 'Deal'){
									if(res.round == 1){
										//deal 1st round winner logic here
										playingTableClass.declareRoundWinner(res._id.toString());
									}
									else{
										//deal final winner logic here 
										playingTableClass.declareDealWinner(res._id.toString());

									}
								}
								else if(res.gt == 'Pool'){
									var players = playClass.getPlayingUserInGame(res.pi,true);

									if(players.length > 1){	//means more than one player so declare round winner
										playingTableClass.declareRoundWinner(res._id.toString());
									}
									// else if(players.length == 1){ //means only one player so declare final winner
									// 	// playingTableClass.declarePoolWinner(res._id.toString());
									// 	playingTableClass.handlePoolWinner(res._id.toString(),players[0].si);
									// }
									else{
										c('DECL-----------'+res._id+'------------->>>>>Error:"table is empty or foul"');
									}

								}
								else{

									playingTableClass.declareWinner(res._id.toString());
								}
							}
							else{

								//drop finish player and resume the game logic here
								var pi = res.pi;
								var asi = [];
								var shortBtn = [];
								for(var k in pi){
									if(!_.isEmpty(pi[k]) && typeof pi[k].si != 'undefined' && (pi[k].s == 'playing' || pi[k].s == 'declare' || pi[k].s == 'finish')){
										asi.push(pi[k].si);
										shortBtn.push({uid:pi[k].uid,sort:pi[k].sort})
									}
								}
								asi = _.without(asi,res.fnsPlayer);

								commonClass.FireEventToTable(res._id.toString(),{en:'INDECL',data:{si:res.fnsPlayer,ocard:res.oDeck[res.oDeck.length-1],sort:shortBtn,asi:asi}});
								for(var i in pi){
									if(!_.isEmpty(pi[i]) && typeof pi[i].s != 'undefined' && pi[i].s != null && pi[i].s == 'declare'){
										pi[i].s = 'playing';
										pi[i].dps = (res.gt == 'Deal' || res.gt == 'Pool') ? pi[i].dps-pi[i].ps : 0; //unsetting dps
										pi[i].ps = 0;
										pi[i].wc = 0;
										pi[i].dCards = {};
									}
								}
								// var fnsPlayer = res.fnsPlayer;
								cdClass.UpdateTableData(res._id.toString(),{$set:{tst:'RoundStarted',fnsPlayer:-1,declCount:0,pi:pi,ctt:new Date()}},function(upData){
									if(upData){

										playClass.DRC({},{tbid:upData._id.toString(),si:res.fnsPlayer},true);
									}
									else{
										c('DECL-------2----->>>>>>Error: "table not found"');
									}
								});

							}
						}
					}
				});
			}
			else{
				c('DECL:::::::::::::::>>>>Error:"false declare action"');
			}
		});
	},
	DRCA:function(data,client){  //Drop cards approval

		c('DRCA---------->>>>>tbid: '+client.tbid+' si: '+client.si);
		cdClass.GetTbInfo(client.tbid,{},function(table){
			if(!table){
				c('DRCA:::::::::::::Error:"table not found!!!" ');
				return false;
			}
			if(table.pi[client.si].pickCount == 0){
				var Chips = config.MAX_DEADWOOD_PTS*table.bv*0.25;    //25% will be deducted if drop without picking any cards i.e First Drop
				commonClass.SendData(client,'DRCA',{Chips:Chips});
			}
			else{
				var Chips = config.MAX_DEADWOOD_PTS*table.bv*0.5;    //50% will be deducted if drop after picking any cards i.e Middle Drop
				commonClass.SendData(client,'DRCA',{Chips:Chips});
			}

		});
	},
	DRC:function(data,client,full){
		/* +-------------------------------------------------------------------+
            desc:event to drop cards 
            i/p: data = {},client = socket object, full = true/false check to cut full chips or not 
        +-------------------------------------------------------------------+ */
		c('DRC--------->>>>data: ',data,' client.tbid: '+client.tbid+' client.si: '+client.si);
		cdClass.GetTbInfo(client.tbid,{},function(table){
			var si = client.si;
			if(!table || typeof si == 'undefined' || si == -1 || !table.pi || !table.pi[si]){
				c('DRC:::::::::::::::>>>Error: "table not found or seat not found!!!"');
				return false;
			}
			c('DRC------------>>>>>start Drop');
			if(table.tst == 'RoundStarted' && table.pi[si].s != 'drop' && si == table.turn){
				jtClass.cancelJobOnServers(table._id.toString(),table.jid);
				c('DRC----------if-------->>>>>');
				if(table.gt == 'Deal'){
					cdClass.CountHands(table.pi[si].uid,'drop',table.gt,table.bv,false,function(thp,qstWin){

						c('DRC----->>>>table._id: ',table._id,' type of id: ',typeof table._id,' si: ',si,' typeof si: ',typeof si);
						var tempPlayerData = table.pi[si];
						// tempPlayerData.gCards = [table.pi[si].cards];
						tempPlayerData.gCards = {pure:[],seq:[],set:[],dwd:table.pi[si].cards};
						tempPlayerData.dCards = {pure:[],seq:[],set:[],dwd:table.pi[si].cards};
						tempPlayerData.ps = config.MAX_DEADWOOD_PTS;//cardsClass.cardsSum(table.pi[si].cards,table.wildCard);
						tempPlayerData.dps = table.pi[si].dps + tempPlayerData.ps;
						tempPlayerData.gedt = new Date();

						var upData = {$set:{la: new Date(),ctrlServer:SERVER_ID,'pi.$.thp':thp,/*'pi.$.spc':spc,*/'pi.$.s':'drop','pi.$.dCards':tempPlayerData.dCards,'pi.$.ps':tempPlayerData.ps,'pi.$.dps':tempPlayerData.dps,'pi.$.gedt':new Date()},$inc:{playCount:-1}};
						// upData['$addToSet'] = {hist:tempPlayerData};
						/*if(spc >= config.FIRST_TIME_GAME_LIMIT && table.spcSi == si){  //user has crossed the limit for the first time journey game play
							upData.$set['pi.$.isSpc'] = false;
							upData.$set.spcSi = -1;
							upData.$set.RobotCount = 0;
							upData.$set.HumanCount = 0;

							db.collection('game_users').updateOne({_id:MongoID(table.pi[si].uid)},{$set:{'flags._isSpc':0}},function(errr,res){
								if(errr){
									c('DRC------------>>>>>>errr: ',errr);
								}
								c('DRC------------->>>>res: ',res);
							});
						}*/
						

						playClass.getUserScore(table.pi[si].uid,table.bv,table.gt,function(score){
							upData['$set']['pi.$.score'] = score;
							db.collection('playing_table').findAndModify({_id:table._id,'pi.si':si},{},upData,{new:true},function(err,table1){
								
								if(!table1 || !table1.value){
									console.log('DRC:::::::::::::::::::::Error: ',err);
									return false;
								}

								var players = playClass.getPlayingUserInRound(table1.value.pi,true);
								var asi = [];
								for(var i = 0;i < players.length;i++){
									asi.push(players[i].si);
								}

								commonClass.FireEventToTable(table1.value._id.toString(),{en:'DRC',data:{uid:table.pi[si].uid,si:si,pts:0,asi:asi,dps:tempPlayerData.dps}});
								
								var game_id = table1.value.game_id+'.'+table1.value.sub_id;

								var sts = 'drop';
								if(full){
									sts = 'invalid_declare';
								}


								/*if(table1.value.pi[si] && table1.value.pi[si].gst && table1.value.pi[si].gedt && typeof table1.value.pi[si].rndCount != 'undefined' && table1.value.pi[si].rndCount != null){

									var gameDuration = 0;
									var tableDuration = 0;
									gameDuration = commonClass.GetTimeDifference(table1.value.pi[si].gst,table1.value.pi[si].gedt);
									tableDuration = commonClass.GetTimeDifference(table1.value.pi[si].jt,table1.value.pi[si].gedt);
									trackClass.TEA({table:'track_primary_data',category:'screen',label:table1.value.gt,option:'game_end_summary',action:table1.value.ap,name:(table1.value.ap-table1.value.uCount),detail1:game_id,detail3:table.pi[si].rndCount,description:gameDuration,value:tableDuration},{uid:table1.value.pi[si].uid});
								}*/



								if(players.length == 1 && table1.value.tst == "RoundStarted"){
									if(table1.value.round == 1){
										cdClass.UpdateTableData(table1.value._id.toString(),{$set:{fnsPlayer:players[0].si}},function(table2){
											if(table2){

												playingTableClass.declareRoundWinner(table2._id.toString(),true);
											}
											else{
												c('DRC------1------>>>>>>Error:"table not found"');
											}
										});
										// playingTableClass.handleRoundWinner(table1.value._id.toString(),players[0].si,true)
									}
									else{
										playingTableClass.declareDealWinner(table1.value._id.toString(),true);
										// playingTableClass.handleDealWinner(table1.value._id.toString(),[players[0].si],table1.value.pv,true)
									}
								}
								else{
									if(table1.value.tst == "RoundStarted"){
										

										// if(full){
										// 	setTimeout(function(){  //delay to handle animation
										// 		playingTableClass.changeTableTurn(table1.value._id.toString());
										// 	},1000);
										// }
										// else{
											playingTableClass.changeTableTurn(table1.value._id.toString(),'drop');

										// }
										
									}
								}
							});
						});
					});
				}
				else if(table.gt == 'Pool'){
					cdClass.CountHands(table.pi[si].uid,'drop',table.gt,table.bv,false,function(thp,qstWin){
						var ps = 0;
						if(full){
							ps = config.MAX_DEADWOOD_PTS;    //100% will be deducted if finish with invalid declaration
						}
						else{
							if(table.pi[si].pickCount == 0){
								ps = config.MAX_DEADWOOD_PTS*config.FIRST_DROP;    //25% will be deducted if drop without picking any cards i.e First Drop
							}
							else{
								ps = config.MAX_DEADWOOD_PTS*config.MIDDLE_DROP;    //50% will be deducted if drop after picking any cards i.e Middle Drop
							}
						}


						c('DRC----->>>>table._id: ',table._id,' type of id: ',typeof table._id,' si: ',si,' typeof si: ',typeof si);
						var tempPlayerData = table.pi[si];
						// tempPlayerData.gCards = [table.pi[si].cards];
						tempPlayerData.gCards = {pure:[],seq:[],set:[],dwd:table.pi[si].cards};
						tempPlayerData.dCards = {pure:[],seq:[],set:[],dwd:table.pi[si].cards};
						tempPlayerData.ps = ps;//cardsClass.cardsSum(table.pi[si].cards,table.wildCard);
						tempPlayerData.dps = table.pi[si].dps + tempPlayerData.ps;
						tempPlayerData.gedt = new Date();
						var upData = {$set:{la: new Date(),ctrlServer:SERVER_ID,'pi.$.thp':thp/*,'pi.$.spc':spc*/,'pi.$.s':'drop','pi.$.dCards':tempPlayerData.dCards,'pi.$.ps':tempPlayerData.ps,'pi.$.dps':tempPlayerData.dps,'pi.$.gedt':new Date()},$inc:{playCount:-1}};
						// upData['$addToSet'] = {hist:tempPlayerData};
						/*if(spc >= config.FIRST_TIME_GAME_LIMIT && table.spcSi == si){  //user has crossed the limit for the first time journey game play
							upData.$set['pi.$.isSpc'] = false;
							upData.$set.spcSi = -1;
							upData.$set.RobotCount = 0;
							upData.$set.HumanCount = 0;
							db.collection('game_users').updateOne({_id:MongoID(table.pi[si].uid)},{$set:{'flags._isSpc':0}},function(errr,res){
								if(errr){
									c('DRC------------>>>>>>errr: ',errr);
								}
								c('DRC------------->>>>res: ',res);
							});
						}*/
						playClass.getUserScore(table.pi[si].uid,table.bv,table.gt,function(score){
							upData['$set']['pi.$.score'] = score;
							db.collection('playing_table').findAndModify({_id:table._id,'pi.si':si},{},upData,{new:true},function(err,table1){
								
								if(!table1 || !table1.value || !table1.value.pi || !table1.value.pi[si]){
									console.log('DRC::::::::::::::::::::err: ',err);
									return false;
								}

								var players = playClass.getPlayingUserInRound(table1.value.pi,true);
								var asi = [];
								for(var i = 0;i < players.length;i++){
									asi.push(players[i].si);
								}

								commonClass.FireEventToTable(table1.value._id.toString(),{en:'DRC',data:{uid:table.pi[si].uid,si:si,pts:0,asi:asi,dps:tempPlayerData.dps}});
								
								var game_id = table1.value.game_id+'.'+table1.value.sub_id;
								var sts = 'drop';
								if(full){
									sts = 'invalid_declare';
								}
								/*if(table1.value.pi[si] && table1.value.pi[si].gst && table1.value.pi[si].gedt && typeof table1.value.pi[si].rndCount != 'undefined' && table1.value.pi[si].rndCount != null){

									var gameDuration = 0;
									var tableDuration = 0;
									gameDuration = commonClass.GetTimeDifference(table1.value.pi[si].gst,table1.value.pi[si].gedt);
									tableDuration = commonClass.GetTimeDifference(table1.value.pi[si].jt,table1.value.pi[si].gedt);
									trackClass.TEA({table:'track_primary_data',category:'screen',label:table1.value.gt,option:'game_end_summary',action:table1.value.ap,name:(table1.value.ap-table1.value.uCount),detail1:game_id,detail3:table.pi[si].rndCount,description:gameDuration,value:tableDuration},{uid:table1.value.pi[si].uid});
								}*/

								//leave logic here
								if(table1.value.pi[si].dps >= table1.pt/*101*/){ //incase player points go beyond 101 then leave that player

									cdClass.GetUserInfo(table1.value.pi[si].uid,{sck:1},function(userInfo){
										if(userInfo && typeof userInfo.sck == 'string' && userInfo.sck != ''){

											var single = userInfo.sck.replace(/s\d*_\d*./i,'');
										}
										else{
											var single = '';	
										}

										var game_id = table1.value.game_id+'.'+table1.value.sub_id;

										playClass.LT({flag:"lostPool"},{leave:1,id:single,uid:table1.value.pi[si].uid,_ir:table1.value.pi[si]._ir,si : si,tbid : table1.value._id.toString()});
									});
								}
								else{

									if(players.length == 1 && table1.value.tst == "RoundStarted"){
										var players1 = playClass.getPlayingUserInGame(table1.value.pi,true);
										if(players1.length > 1){  //if more than one playing user in running pool then only round winner will be declared
											cdClass.UpdateTableData(table1.value._id.toString(),{$set:{fnsPlayer:players[0].si}},function(table2){
												if(table2){

													// round winner logic here 
													playingTableClass.declareRoundWinner(table2._id.toString(),true);
												}
												else{
													c('DRC--------------->>>>>Error:"table not found"');
												}
											});
											
										}
										else if(players1.length == 1){  //if only one playing user in running game then declare him final winner
											// pool winner declare
											// playingTableClass.declareDealWinner(table1.value._id.toString(),true);
											playingTableClass.handlePoolWinner(table2._id.toString(),players1[0].si,true);
										}
										else{
											c('DRC---------->>>>>>table is empty');
										}
									}
									else{
										if(table1.value.tst == "RoundStarted"){
										
											playingTableClass.changeTableTurn(table1.value._id.toString(),'drop');										
										}
									}
								}
							});
						});
					});
				}
				else{
					
					var cutChips = 0;
					var pts = 0;
					if(table.gt == 'Bet'){ //chips cutting based on player's bet
						
						if(full){
							cutChips = config.MAX_DEADWOOD_PTS*table.pi[si].bet;    //100% will be deducted if finish with invalid declaration
							pts = config.MAX_DEADWOOD_PTS;
						}
						else{
							if(table.pi[si].pickCount == 0){
								cutChips = config.MAX_DEADWOOD_PTS*table.pi[si].bet*config.FIRST_DROP;    //25% will be deducted if drop without picking any cards i.e First Drop
								pts = config.MAX_DEADWOOD_PTS*config.FIRST_DROP;
							}
							else{
								cutChips = config.MAX_DEADWOOD_PTS*table.pi[si].bet*config.MIDDLE_DROP;    //50% will be deducted if drop after picking any cards i.e Middle Drop
								pts = config.MAX_DEADWOOD_PTS*config.MIDDLE_DROP;
							}
						}
					}
					else{
						if(full){
							cutChips = config.MAX_DEADWOOD_PTS*table.bv;    //100% will be deducted if finish with invalid declaration
							pts = config.MAX_DEADWOOD_PTS;
						}
						else{
							if(table.pi[si].pickCount == 0){
								cutChips = config.MAX_DEADWOOD_PTS*table.bv*config.FIRST_DROP;    //25% will be deducted if drop without picking any cards i.e First Drop
								pts = config.MAX_DEADWOOD_PTS*config.FIRST_DROP;
							}
							else{
								cutChips = config.MAX_DEADWOOD_PTS*table.bv*config.MIDDLE_DROP;    //50% will be deducted if drop after picking any cards i.e Middle Drop
								pts = config.MAX_DEADWOOD_PTS*config.MIDDLE_DROP;
							}
						}
					}



					c('DRC-------->>>cutChips: ',cutChips);
					if(!table.pi[si]){
						console.log('DRC::::::::::::::::table._id: '+table._id+' si: '+si+' table.pi: ',table.pi+' ::::::>>>'+new Date());
						return false;
					}

					if (table.mode == 'practice') {

						cdClass.UpdateUserChips(table.pi[si].uid,-cutChips,'Card Drop Deduction',function(uChips){

							cdClass.CountHands(table.pi[si].uid,'drop',table.gt,table.bv,false,function(thp,qstWin){

								c('DRC----->>>>table._id: ',table._id,' type of id: ',typeof table._id,' si: ',si,' typeof si: ',typeof si);
								var tempPlayerData = table.pi[si];
								tempPlayerData.s = 'drop';
								tempPlayerData.Chips = uChips;
								tempPlayerData.wc = -cutChips;
								tempPlayerData.pts = pts;

								// tempPlayerData.gCards = [table.pi[si].cards];
								tempPlayerData.gCards = {pure:[],seq:[],set:[],dwd:table.pi[si].cards};
								tempPlayerData.dCards = {pure:[],seq:[],set:[],dwd:table.pi[si].cards};
								// tempPlayerData.ps = config.MAX_DEADWOOD_PTS;
								tempPlayerData.ps = pts;//cardsClass.cardsSum(table.pi[si].cards,table.wildCard);
								tempPlayerData.dps = pts;
								tempPlayerData.gedt = new Date();
								var upData = {$set:{la: new Date(),ctrlServer:SERVER_ID,'pi.$.thp':thp,/*'pi.$.spc':spc,*/'pi.$.s':'drop','pi.$.Chips':uChips,'pi.$.wc':-cutChips,'pi.$.dCards':{pure:[],seq:[],set:[],dwd:table.pi[si].cards},'pi.$.ps':tempPlayerData.ps,'pi.$.pts':pts,'pi.$.gedt':new Date()},$inc:{pv:cutChips,playCount:-1}};
								var players = playClass.getPlayingUserInRound(table.pi,true);
								c("DRC---------------->>>>>>>>>>>>>>>players.length:",players.length);
								if(players.length > 0){
									upData['$addToSet'] = {hist:tempPlayerData};
								}
								else{
									c("DRC---------------->>>>>>>>>>>>>>>do nothing")
								}
								// upData['$addToSet'] = {hist:tempPlayerData};

								/*if(spc >= config.FIRST_TIME_GAME_LIMIT && table.spcSi == si){  //user has crossed the limit for the first time journey game play
									upData.$set['pi.$.isSpc'] = false;
									upData.$set.spcSi = -1;
									upData.$set.RobotCount = 0;
									upData.$set.HumanCount = 0;
									db.collection('game_users').updateOne({_id:MongoID(table.pi[si].uid)},{$set:{'flags._isSpc':0}},function(errr,res){
										if(errr){
											c('DRC------------>>>>>>errr: ',errr);
										}
										c('DRC------------->>>>res: ',res);
									});
								}*/


								playClass.getUserScore(table.pi[si].uid,table.bv,table.gt,function(score){
									upData['$set']['pi.$.score'] = score;
									db.collection('playing_table').findAndModify({_id:table._id,'pi.si':si},{},upData,{new:true},function(err,table1){
										
										if(!table1 || !table1.value){
											c('DRC::::::::::::::::::::err: ',err);
											return false;
										}

										var players = playClass.getPlayingUserInRound(table1.value.pi,true);
										var asi = [];
										var chipsArray = [];
										for(var i = 0;i < players.length;i++){
											asi.push(players[i].si);
											chipsArray.push(players[i].Chips);
										}

										commonClass.FireEventToTable(table1.value._id.toString(),{en:'DRC',data:{uid:table.pi[si].uid,si:si,pts:pts,wc:-cutChips,asi:asi,bet:table.pi[si].bet}});
										
										var game_id = table1.value.game_id;
										var sts = 'drop';
										if(full){
											sts = 'invalid_declare';
										}

										/*if(table1.value.pi[si] && table1.value.pi[si].gst && table1.value.pi[si].gedt && typeof table1.value.pi[si].rndCount != 'undefined' && table1.value.pi[si].rndCount != null){

											var gameDuration = 0;
											var tableDuration = 0;
											gameDuration = commonClass.GetTimeDifference(table1.value.pi[si].gst,table1.value.pi[si].gedt);
											tableDuration = commonClass.GetTimeDifference(table1.value.pi[si].jt,table1.value.pi[si].gedt);
										}*/

										if(players.length == 1 && table1.value.tst == "RoundStarted"){
											playingTableClass.handleWinner(table1.value._id.toString(),players[0].si/*,table1.value.pv*/,true)
										}
										else{
											if(table1.value.tst == "RoundStarted"){
												
													
													if(table1.value.gt == 'Bet'){

														var minChips = _.min(chipsArray);
														var maxBet = Math.round(minChips/160);
														// if(config.BET_RAISE_SCALE > 0){ //to round the max bet value
														// 	maxBet = maxBet-maxBet%config.BET_RAISE_SCALE;
														// 	maxBet = (maxBet <= table1.value.bbv) ? table1.value.bbv : maxBet;
														// }
														maxBet = maxBet-maxBet%50;  //rounding maxbet
														maxBet = (maxBet <= table1.value.bbv) ? table1.value.bbv : maxBet;
														

														cdClass.UpdateTableData(table1.value._id.toString(),{$set:{maxBet:maxBet}},function(table2){
															if(table2){

																playingTableClass.changeTableTurn(table2._id.toString(),'drop');													
															}
															else{
																c('DRC------------->>>>>>Error:"table not found"');
															}
														});
													}
													else{

														playingTableClass.changeTableTurn(table1.value._id.toString(),'drop');
													}
												// }
											}
										}
									});
								});
							});
						});
					}
					else if (table.mode == 'cash') {
						
						var bc = cutChips*config.CASH_BONUS/100;
						cdClass.UpdateUserCashforgame(table.pi[si].uid,-cutChips,bc,'Card Drop Deduction',function(uChips){

							cdClass.CountHands(table.pi[si].uid,'drop',table.gt,table.bv,false,function(thp,qstWin){

								c('DRC----->>>>table._id: ',table._id,' type of id: ',typeof table._id,' si: ',si,' typeof si: ',typeof si);
								var tempPlayerData = table.pi[si];
								tempPlayerData.s = 'drop';
								tempPlayerData.cash = uChips;
								tempPlayerData.wc = -cutChips;
								tempPlayerData.pts = pts;

								// tempPlayerData.gCards = [table.pi[si].cards];
								tempPlayerData.gCards = {pure:[],seq:[],set:[],dwd:table.pi[si].cards};
								tempPlayerData.dCards = {pure:[],seq:[],set:[],dwd:table.pi[si].cards};
								// tempPlayerData.ps = config.MAX_DEADWOOD_PTS;
								tempPlayerData.ps = pts;//cardsClass.cardsSum(table.pi[si].cards,table.wildCard);
								tempPlayerData.dps = pts;
								tempPlayerData.gedt = new Date();
								var upData = {$set:{la: new Date(),ctrlServer:SERVER_ID,'pi.$.thp':thp,/*'pi.$.spc':spc,*/'pi.$.s':'drop','pi.$.Chips':uChips,'pi.$.wc':-cutChips,'pi.$.dCards':{pure:[],seq:[],set:[],dwd:table.pi[si].cards},'pi.$.ps':tempPlayerData.ps,'pi.$.pts':pts,'pi.$.gedt':new Date()},$inc:{pv:cutChips,playCount:-1}};
								var players = playClass.getPlayingUserInRound(table.pi,true);
								c("DRC---------------->>>>>>>>>>>>>>>players.length:",players.length);
								if(players.length > 0){
									upData['$addToSet'] = {hist:tempPlayerData};
								}
								else{
									c("DRC---------------->>>>>>>>>>>>>>>do nothing")
								}
								// upData['$addToSet'] = {hist:tempPlayerData};

								/*if(spc >= config.FIRST_TIME_GAME_LIMIT && table.spcSi == si){  //user has crossed the limit for the first time journey game play
									upData.$set['pi.$.isSpc'] = false;
									upData.$set.spcSi = -1;
									upData.$set.RobotCount = 0;
									upData.$set.HumanCount = 0;
									db.collection('game_users').updateOne({_id:MongoID(table.pi[si].uid)},{$set:{'flags._isSpc':0}},function(errr,res){
										if(errr){
											c('DRC------------>>>>>>errr: ',errr);
										}
										c('DRC------------->>>>res: ',res);
									});
								}*/


								playClass.getUserScore(table.pi[si].uid,table.bv,table.gt,function(score){
									upData['$set']['pi.$.score'] = score;
									db.collection('playing_table').findAndModify({_id:table._id,'pi.si':si},{},upData,{new:true},function(err,table1){
										
										if(!table1 || !table1.value){
											c('DRC::::::::::::::::::::err: ',err);
											return false;
										}

										var players = playClass.getPlayingUserInRound(table1.value.pi,true);
										var asi = [];
										var chipsArray = [];
										for(var i = 0;i < players.length;i++){
											asi.push(players[i].si);
											chipsArray.push(players[i].cash);
										}

										commonClass.FireEventToTable(table1.value._id.toString(),{en:'DRC',data:{uid:table.pi[si].uid,si:si,pts:pts,wc:-cutChips,asi:asi,bet:table.pi[si].bet}});
										
										var game_id = table1.value.game_id;
										var sts = 'drop';
										if(full){
											sts = 'invalid_declare';
										}

										/*if(table1.value.pi[si] && table1.value.pi[si].gst && table1.value.pi[si].gedt && typeof table1.value.pi[si].rndCount != 'undefined' && table1.value.pi[si].rndCount != null){

											var gameDuration = 0;
											var tableDuration = 0;
											gameDuration = commonClass.GetTimeDifference(table1.value.pi[si].gst,table1.value.pi[si].gedt);
											tableDuration = commonClass.GetTimeDifference(table1.value.pi[si].jt,table1.value.pi[si].gedt);
										}*/

										if(players.length == 1 && table1.value.tst == "RoundStarted"){
											playingTableClass.handleWinnerCash(table1.value._id.toString(),players[0].si/*,table1.value.pv*/,true)
										}
										else{
											if(table1.value.tst == "RoundStarted"){
												
													
													if(table1.value.gt == 'Bet'){

														var minChips = _.min(chipsArray);
														var maxBet = Math.round(minChips/160);
														// if(config.BET_RAISE_SCALE > 0){ //to round the max bet value
														// 	maxBet = maxBet-maxBet%config.BET_RAISE_SCALE;
														// 	maxBet = (maxBet <= table1.value.bbv) ? table1.value.bbv : maxBet;
														// }
														maxBet = maxBet-maxBet%50;  //rounding maxbet
														maxBet = (maxBet <= table1.value.bbv) ? table1.value.bbv : maxBet;
														

														cdClass.UpdateTableData(table1.value._id.toString(),{$set:{maxBet:maxBet}},function(table2){
															if(table2){

																playingTableClass.changeTableTurn(table2._id.toString(),'drop');													
															}
															else{
																c('DRC------------->>>>>>Error:"table not found"');
															}
														});
													}
													else{

														playingTableClass.changeTableTurn(table1.value._id.toString(),'drop');
													}
												// }
											}
										}
									});
								});
							});
						});
					}
				}
			}
			else{
				c('DRC------------->>>>>>table: '+table._id.toString()+' table.tst : '+table.tst+' si: '+si);
			}
		});
	},
	STNDUP:function(data,client,callback){  //standup
		/* +-------------------------------------------------------------------+
            desc:event to standup from table 
            i/p: data = {flag : 'auto'}/{},client = socket object
            o/p: STNDUP event: data = {id = socket id,si = seat index,uid = _id of user ,ap : number of active players on table }
        +-------------------------------------------------------------------+ */
		c('STNDUP-------->>>>data: ',data,' client.tbid: '+client.tbid+' client.si: '+client.si+' client._ir: '+client._ir+' client.id: '+client.id+' client.uid: '+client.uid);
		var freeSts = ["","RoundTimerStarted","winnerDeclared","roundWinnerDeclared"/*,"dealWinnerDeclared"*/];
		cdClass.GetTbInfo(client.tbid,{},function(table){
			if(table){
				var si = client.si;

				if(typeof si != 'undefined' && si != null && client.uid && table.pi[si] && table.pi[si].uid != client.uid){
					console.log('STNDUP:::::::::::::::::::::::>>>>>>>Error: "false event" table.pi[si].uid: '+table.pi[si].uid+' != client.uid: '+client.uid+' '+new Date());
					return false;
				}

				var playr = playClass.getPlayingUserInRound(table.pi,true);
				console.log("STNDUP--------*--------"+client.tbid+">>>>>>>>>>>>>>>playr.length:",playr.length);
				console.log("STNDUP--------*--------"+client.tbid+">>>>>>>>>>>>>>>table.tst:",table.tst);
				if(typeof client.si == 'undefined' || client.si == null || !table.pi[si]){
					c('STNDUP::::::::::::::>>>>>>Error: "user already standup"');
					if(typeof callback == 'function'){
						return callback(true);
					}
					// return false;
				}
				else if(table.tst == "CollectingBootValue"){
					c('STNDUP----'+table._id+'------>>>>>>Msg: "player cannot standup table on cards boot value collection phase"');
					commonClass.SendData(client, 'PUP', {}, 'error:1040');  //player can't leave table at cards dealing phase
				}
				else if(table.tst == 'StartDealingCard' || table.tst == 'CardsDealt'){
					c('STNDUP---------'+table._id+'------------->>>>>Msg: "player cannot standup at cards dealing phase"');
					commonClass.SendData(client, 'PUP', {}, 'error:1035');  //player can't standup at cards dealing phase
				}
				else if(table.tst == 'RoundStarted' && playr.length == 1){
					c('STNDUP---------'+table._id+'------------->>>>>Msg: "player cannot standup if no user left and winner is goin to declare"');
					commonClass.SendData(client, 'PUP', {}, 'error:1051');
				}
				else if(_.contains(freeSts,table.tst) || table.pi[si].s == '' || table.pi[si].s == 'watch' || table.pi[si].s == 'drop'){  //simply remove player if player leaves after drop cards as chips already cut during drop cards process
					
					c('STNDUP----->>>>table._id: ',table._id,' type of id: ',typeof table._id,' si: ',si);
					var upData = {$set:{'pi.$':{},la:new Date(),ctrlServer:SERVER_ID},$inc:{ap:-1,uCount:-1}};

					/*if(table.spcSi == si && si != -1){
						upData.$set.spcSi = -1;
						upData.$set.RobotCount = 0;
						upData.$set.HumanCount = 0;
					}*/

					upData['$addToSet'] = {stdP: {uid:table.pi[si].uid,un:table.pi[si].un,si:si,theme:table.pi[si].theme/*,dealerImg:table.pi[si].dealerImg,dealerId:table.pi[si].dealerId*/}};
					c('STNDUP--------->>>>>upData: ',upData,' table._id: ',table._id,' si: ',si);
					db.collection('playing_table').findAndModify({_id:table._id,'pi.si':si},{},upData,{new:true},function(err,table1){
						c('STNDUP-------->>>>>table1: ',table1.value);
						if(table1 && table1.value && table1.value.pi && table1.value.pi[si]){

							commonClass.FireEventToTable(table1.value._id.toString(),{en:'STNDUP',data:{id:client.id,si : si,uid:table.pi[si].uid,ap:table1.value.ap}});
							// setTimeout(function(){
							// 	if(typeof client._ir != 'undefined' && client._ir != null && client._ir == 0){
							// 		try{
							// 			c('STNDUP ----------->>>>>Msg: "try to delete si from socket"');
							// 			delete io.sockets.connected[client.id].si;
							// 			c('STNDUP------------>>>Msg: "si removed from socket"');

							// 		}
							// 		catch(e){
							// 			console.log('STNDUP::::::::::::>>>>>>Error: "client not standup!!!"');
							// 		}
							delete client.si; 
							// 	}
							playingTableClass.managePlayerOnLeave(table1.value._id.toString(),si,false,'standup');
							if(typeof callback == 'function'){
								return callback(true);
							}
							// },100);
						}
						else{
							c('STNDUP----------->>>>>>Error:"table not found!!!"');
						}
					});
				}
				else if(table.tst == 'Finished'){  
					c('STNDUP------------>>>>>Msg: "player cannot standup at cards dealing phase"');
					commonClass.SendData(client, 'PUP', {}, 'error:1039');  //player can't standup at cards dealing phase
				}
				else if(table.gt == 'Deal'){ //not required
					c('STNDUP--------'+table._id+'--------->>>>table status: ',table.tst,' standing user: ',table.pi[si].un, 'si : ',si);
					
					c('STNDUP---------'+table._id+'------------>>>>on running game');
					cdClass.CountHands(table.pi[si].uid,'lost');

					var upData = {$set:{la:new Date(),'pi.$':{},ctrlServer:SERVER_ID},$inc:{ap:-1,uCount:-1}};

					/*if(table.spcSi == si && si != -1){
						upData.$set.spcSi = -1;
						upData.$set.RobotCount = 0;
						upData.$set.HumanCount = 0;
					}*/

					if(table.pi[si].s == 'playing'){
						upData['$inc'].playCount = -1;

					}
					var tempPlayerData = table.pi[si];
					tempPlayerData.s = 'standup';

					var ctth = '';
					if(table.pi[si].cards.length > 13){  //user has more than 13 cards means he has picked a card
						ctth = table.pi[si].cards.pop();
						upData['$push'] = {oDeck: ctth};
					}
					tempPlayerData.cards = table.pi[si].cards;
					// tempPlayerData.gCards = [table.pi[si].cards];
					tempPlayerData.gCards = {pure:[],seq:[],set:[],dwd:table.pi[si].cards};
					tempPlayerData.dCards = {pure:[],seq:[],set:[],dwd:table.pi[si].cards};
					tempPlayerData.ps = config.MAX_DEADWOOD_PTS;
					tempPlayerData.dps = config.MAX_DEADWOOD_PTS*2;  //full two round points
					tempPlayerData.gedt = new Date();
					upData['$addToSet'] = {hist:tempPlayerData,stdP: {uid:table.pi[si].uid,un:table.pi[si].un,si:si,theme:table.pi[si].theme/*,dealerImg:table.pi[si].dealerImg,dealerId:table.pi[si].dealerId*/}};
					c('STNDUP---------->>>>>si: '+si,' table._id: ',table._id,' upData: ',upData);
					db.collection('playing_table').findAndModify({_id:table._id,'pi.si':si},{},upData,{new:true},function(err,table1){
						if(!table1 || !table1.value){
							c('STNDUP------------------------->>>>>>Error:"table not found!!!!"');
							return false;
						}
						var game_id = table1.value.game_id+'.'+table1.value.sub_id;
						var reason = (data.flag && data.flag == 'auto')?'auto_standup':'standup';

						/*if(table.pi[si] && table.pi[si].gst && typeof table.pi[si].rndCount != 'undefined' && table.pi[si].rndCount != null){

							var gameDuration = 0;
							var tableDuration = 0;
							gameDuration = commonClass.GetTimeDifference(table.pi[si].gst,new Date());
							tableDuration = commonClass.GetTimeDifference(table.pi[si].jt,new Date());
							trackClass.TEA({table:'track_primary_data',category:'screen',label:table.gt,option:'game_end_summary',action:table.ap,name:(table.ap-table.uCount),detail1:game_id,detail3:table.pi[si].rndCount,description:gameDuration,value:tableDuration},{uid:table.pi[si].uid});
						}*/


						if(ctth != ''){

							commonClass.FireEventToTable(table1.value._id.toString(),{en:'DSCRD',data:{si:si,uid:table.pi[si].uid,card:ctth,bbv:table1.value.bbv,finish:false,cdd:true,isRaise:0}});
							playClass.DC({},{tbid : table1.value._id.toString()});
						}
						commonClass.FireEventToTable(table1.value._id.toString(),{en:'STNDUP',data:{id:client.id,si : si,uid:table.pi[si].uid,wc:cutChips,pts:pts,ap:table1.value.ap}});
						
						delete client.si; 
						
						playingTableClass.managePlayerOnLeave(table1.value._id.toString(),si,false,'standup');
						if(typeof callback == 'function'){
							return callback(true);
						}
					});
				}
				else{
					c('STNDUP--------'+table._id+'--------->>>>table status: ',table.tst,' standing user: ',table.pi[si].un, ' si : ',si);
					
					c('STNDUP---------'+table._id+'------------>>>>on running game');
					
					var cutChips = 0;  
					var pts = 0; 

					if(table.gt == 'Bet'){ //chips cut based on player's bet
						if(table.pi[si].pickCount == 0){
							cutChips = config.MAX_DEADWOOD_PTS*table.pi[si].bet*config.FIRST_DROP;    //25% will be deducted if leave without picking any cards i.e First Leave
							pts = config.MAX_DEADWOOD_PTS*config.FIRST_DROP;
						}
						else{
							cutChips = config.MAX_DEADWOOD_PTS*table.pi[si].bet*config.MIDDLE_DROP;    //50% will be deducted if leave after picking any cards i.e Middle Leave
							pts = config.MAX_DEADWOOD_PTS*config.MIDDLE_DROP;
						}
					}
					else{

						if(table.pi[si].pickCount == 0){
							cutChips = config.MAX_DEADWOOD_PTS*table.bv*config.FIRST_DROP;    //25% will be deducted if leave without picking any cards i.e First Leave
							pts = config.MAX_DEADWOOD_PTS*config.FIRST_DROP;
						}
						else{
							cutChips = config.MAX_DEADWOOD_PTS*table.bv*config.MIDDLE_DROP;    //50% will be deducted if leave after picking any cards i.e Middle Leave
							pts = config.MAX_DEADWOOD_PTS*config.MIDDLE_DROP;
						}
					}

					c('STNDUP--------'+table._id+'-------->>>cutChips: ',cutChips);
					
					if (table.mode == 'practice') {

						cdClass.UpdateUserChips(table.pi[si].uid,-cutChips,'Table Leave Deduction',function(uChips){

							cdClass.CountHands(table.pi[si].uid,'lost',table.gt,table.bv,false,function(thp,qstWin){

								// if(table.pi[si]._ir == 1){
								// 	cdClass.UpdateUserData(table.pi[si].uid,{$set:{tbid:"",s:"free"}});
								// }
								// else{
								// 	cdClass.UpdateUserData(table.pi[si].uid,{$set:{tbid:""}});
								// }
								var upData = {$set:{la:new Date(),'pi.$':{},ctrlServer:SERVER_ID},$inc:{pv:cutChips,ap:-1,uCount:-1}};

								/*if(table.spcSi == si && si != -1){
									upData.$set.spcSi = -1;
									upData.$set.RobotCount = 0;
									upData.$set.HumanCount = 0;
									if(spc >= config.FIRST_TIME_GAME_LIMIT){
										db.collection('game_users').updateOne({_id:MongoID(table.pi[si].uid)},{$set:{'flags._isSpc':0}},function(errr,res){
											if(errr){
												c('DRC------------>>>>>>errr: ',errr);
											}
											c('DRC------------->>>>res: ',res);
										});
									}
								}*/
								if(table.pi[si].s == 'playing'){
									upData['$inc'].playCount = -1;

								}
								var tempPlayerData = table.pi[si];
								tempPlayerData.s = 'standup';
								tempPlayerData.Chips = uChips;
								tempPlayerData.wc = -cutChips;
								tempPlayerData.pts = pts;

								var ctth = '';
								if(table.pi[si].cards.length > 13){  //user has more than 13 cards means he has picked a card
									ctth = table.pi[si].cards.pop();
									upData['$push'] = {oDeck: ctth};
								}

								tempPlayerData.cards = table.pi[si].cards;
								// tempPlayerData.gCards = [table.pi[si].cards];
								tempPlayerData.gCards = {pure:[],seq:[],set:[],dwd:table.pi[si].cards};
								tempPlayerData.dCards = {pure:[],seq:[],set:[],dwd:table.pi[si].cards};
								// tempPlayerData.ps = config.MAX_DEADWOOD_PTS;
								// tempPlayerData.ps = cardsClass.cardsSum(table.pi[si].cards,table.wildCard);
								tempPlayerData.ps = pts;
								tempPlayerData.dps = pts;
								tempPlayerData.gedt = new Date();
								var players = playClass.getPlayingUserInRound(table.pi,true);
								console.log("STNDUP---------------->>>>>>>>>>>>>>>players.length:",players.length);
								if(players.length > 0){
									upData['$addToSet'] = {hist:tempPlayerData,stdP: {uid:table.pi[si].uid,un:table.pi[si].un,si:si,theme:table.pi[si].theme/*,dealerImg:table.pi[si].dealerImg,dealerId:table.pi[si].dealerId*/}};
								}
								else{
									upData['$addToSet'] = {/*hist:tempPlayerData,*/stdP: {uid:table.pi[si].uid,un:table.pi[si].un,si:si,theme:table.pi[si].theme/*,dealerImg:table.pi[si].dealerImg,dealerId:table.pi[si].dealerId*/}};
								}

								db.collection('playing_table').findAndModify({_id:table._id,'pi.si':si},{},upData,{new:true},function(err,table1){
									if(!table1 || !table1.value){
										c('STNDUP------------------------->>>>>>Error:"table not found!!!!"');
										return false;
									}
									var game_id = table1.value.game_id;

									var reason = (data.flag && data.flag == 'auto')?'auto_standup':'standup';

									/*if(table.pi[si] && table.pi[si].gst && typeof table.pi[si].rndCount != 'undefined' && table.pi[si].rndCount != null){

										var gameDuration = 0;
										var tableDuration = 0;
										gameDuration = commonClass.GetTimeDifference(table.pi[si].gst,new Date());
										tableDuration = commonClass.GetTimeDifference(table.pi[si].jt,new Date());
										trackClass.TEA({table:'track_primary_data',category:'screen',label:table.gt,option:'game_end_summary',action:table.ap,name:(table.ap-table.uCount),detail1:game_id,detail3:table.pi[si].rndCount,description:gameDuration,value:tableDuration},{uid:table.pi[si].uid});
									}*/

									if(ctth != ''){

										commonClass.FireEventToTable(table1.value._id.toString(),{en:'DSCRD',data:{si:si,uid:table.pi[si].uid,card:ctth,bbv:table1.value.bbv,finish:false,cdd:true,isRaise:0}});
										playClass.DC({},{tbid : table1.value._id.toString()});
									}
									commonClass.FireEventToTable(table1.value._id.toString(),{en:'STNDUP',data:{id:client.id,si : si,uid:table.pi[si].uid,wc:cutChips,pts:pts,ap:table1.value.ap}});
									
									delete client.si; 
									
									playingTableClass.managePlayerOnLeave(table1.value._id.toString(),si,false,'standup');
									if(typeof callback == 'function'){
										return callback(true);
									}
								});
							});
					
						});
					}
					else if (table.mode == 'cash') {
						
						var bc = cutChips*config.CASH_BONUS/100;
						cdClass.UpdateUserCashforgame(table.pi[si].uid,-cutChips,bc,'Table Leave Deduction',function(uChips){

							cdClass.CountHands(table.pi[si].uid,'lost',table.gt,table.bv,false,function(thp,qstWin){

								// if(table.pi[si]._ir == 1){
								// 	cdClass.UpdateUserData(table.pi[si].uid,{$set:{tbid:"",s:"free"}});
								// }
								// else{
								// 	cdClass.UpdateUserData(table.pi[si].uid,{$set:{tbid:""}});
								// }
								var upData = {$set:{la:new Date(),'pi.$':{},ctrlServer:SERVER_ID},$inc:{pv:cutChips,ap:-1,uCount:-1}};

								/*if(table.spcSi == si && si != -1){
									upData.$set.spcSi = -1;
									upData.$set.RobotCount = 0;
									upData.$set.HumanCount = 0;
									if(spc >= config.FIRST_TIME_GAME_LIMIT){
										db.collection('game_users').updateOne({_id:MongoID(table.pi[si].uid)},{$set:{'flags._isSpc':0}},function(errr,res){
											if(errr){
												c('DRC------------>>>>>>errr: ',errr);
											}
											c('DRC------------->>>>res: ',res);
										});
									}
								}*/
								if(table.pi[si].s == 'playing'){
									upData['$inc'].playCount = -1;

								}
								var tempPlayerData = table.pi[si];
								tempPlayerData.s = 'standup';
								tempPlayerData.cash = uChips;
								tempPlayerData.wc = -cutChips;
								tempPlayerData.pts = pts;
								var ctth = '';
								if(table.pi[si].cards.length > 13){  //user has more than 13 cards means he has picked a card
									ctth = table.pi[si].cards.pop();
									upData['$push'] = {oDeck: ctth};
								}

								tempPlayerData.cards = table.pi[si].cards;
								// tempPlayerData.gCards = [table.pi[si].cards];
								tempPlayerData.gCards = {pure:[],seq:[],set:[],dwd:table.pi[si].cards};
								tempPlayerData.dCards = {pure:[],seq:[],set:[],dwd:table.pi[si].cards};
								// tempPlayerData.ps = config.MAX_DEADWOOD_PTS;
								// tempPlayerData.ps = cardsClass.cardsSum(table.pi[si].cards,table.wildCard);
								tempPlayerData.ps = pts;
								tempPlayerData.dps = pts;
								tempPlayerData.gedt = new Date();
								var players = playClass.getPlayingUserInRound(table.pi,true);
								if(players.length > 0){
								    upData['$addToSet'] = {hist:tempPlayerData,stdP: {uid:table.pi[si].uid,un:table.pi[si].un,si:si,theme:table.pi[si].theme/*dealerImg:table.pi[si].dealerImg,dealerId:table.pi[si].dealerId*/}};
								}
								else{
								    upData['$addToSet'] = {stdP: {uid:table.pi[si].uid,un:table.pi[si].un,si:si,theme:table.pi[si].theme/*dealerImg:table.pi[si].dealerImg,dealerId:table.pi[si].dealerId*/}};
								}

								db.collection('playing_table').findAndModify({_id:table._id,'pi.si':si},{},upData,{new:true},function(err,table1){
									if(!table1 || !table1.value){
										c('STNDUP------------------------->>>>>>Error:"table not found!!!!"');
										return false;
									}
									var game_id = table1.value.game_id;

									var reason = (data.flag && data.flag == 'auto')?'auto_standup':'standup';

									/*if(table.pi[si] && table.pi[si].gst && typeof table.pi[si].rndCount != 'undefined' && table.pi[si].rndCount != null){

										var gameDuration = 0;
										var tableDuration = 0;
										gameDuration = commonClass.GetTimeDifference(table.pi[si].gst,new Date());
										tableDuration = commonClass.GetTimeDifference(table.pi[si].jt,new Date());
										trackClass.TEA({table:'track_primary_data',category:'screen',label:table.gt,option:'game_end_summary',action:table.ap,name:(table.ap-table.uCount),detail1:game_id,detail3:table.pi[si].rndCount,description:gameDuration,value:tableDuration},{uid:table.pi[si].uid});
									}*/

									if(ctth != ''){

										commonClass.FireEventToTable(table1.value._id.toString(),{en:'DSCRD',data:{si:si,uid:table.pi[si].uid,card:ctth,bbv:table1.value.bbv,finish:false,cdd:true,isRaise:0}});
										playClass.DC({},{tbid : table1.value._id.toString()});
									}
									commonClass.FireEventToTable(table1.value._id.toString(),{en:'STNDUP',data:{id:client.id,si : si,uid:table.pi[si].uid,wc:cutChips,pts:pts,ap:table1.value.ap}});
									
									delete client.si; 
									
									playingTableClass.managePlayerOnLeave(table1.value._id.toString(),si,false,'standup');
									if(typeof callback == 'function'){
										return callback(true);
									}
								});
							});
					
						});
					}
				}
			}
			else{
				c('STNDUP:::::::::::::::::>>>>Error: "table not found!!!"');

			}
		});
	},
	JNBK:function(data,client){  //join back; data = {si}
		/* +-------------------------------------------------------------------+
            desc:event to join back the table 
            i/p: data = {si = seat index},client = socket object
        +-------------------------------------------------------------------+ */
		c('JNBK-------------->>>>>client.uid: '+client.uid+' client._ir: '+client._ir+' client.tbid: '+client.tbid+' data.si: '+data.si);
		if(data.si == -1){  //join back from outside the table; directly find empty seat and join
			cdClass.GetUserInfo(client.uid,{_id:1,rejoinID:1,rejoin:1},function(userInfo){

				if(userInfo){

					if(userInfo.rejoinID && userInfo.rejoinID != ''){
		                jtClass.cancelRejoinJobs(userInfo.rejoinID);
		                c('JNBK------------->>>>>Msg:"1 min rejoin timer canceled"');
		            }



					cdClass.UpdateUserData(client.uid,{$set:{rejoinID:'',rejoin:0}},function(upData){

						db.collection('playing_table').findOne({_id:MongoID(client.tbid),$or:[{'pi.uid':client.uid},{'stdP.uid':client.uid}]},function(err,table){
							if(table){


								//special logic to handle invalid join back event
								// for(var u in table.pi){
								// 	if(!_.isEmpty(table.pi[u]) && table.pi[u].uid && table.pi[u].uid == client.uid){
								// 		console.log('JNBK::::::::::'+client.tbid+':::::'+client.uid+'::::Error: "Invalid join back event" '+new Date());
								// 		return false;
								// 	}
								// }
								///////////////////////special logic ends here/////////////////////////

								// playClass.isFirstTimeUser(userInfo._id.toString(),function(isSpc,RobotCount,HumanCount){
			            			if(table.mode == 'practice'){
			            				var cond = (upData.Chips >= table.bv*config.MAX_DEADWOOD_PTS) ? true : false; 
			            			}
			            			else if(table.mode == 'cash'){
			            				var ef = table.bv*config.MAX_DEADWOOD_PTS;
										var cb = ef*config.CASH_BONUS/100;
			            				var cond = (userInfo.totalcash >= ef && (parseInt(userInfo.depositcash) + parseInt(userInfo.wincash) >= ef || (parseInt(userInfo.depositcash) + parseInt(userInfo.wincash) >= ef-parseInt(cb) && userInfo.bonuscash >= parseInt(cb)))) ? true : false;
			            			}
									
									// if(upData.Chips >= table.bv*config.MAX_DEADWOOD_PTS){
									if(cond){

										var seat = playingTableClass.findEmptySeat(table.pi);
										if(seat == -1 && client._ir == 0){  //seat not found
											cdClass.UpdateUserData(client.uid,{$set:{tbid:''}},function(){

												commonClass.SendData(client, 'PUP', {}, 'error:1024');  //seat is not Empty
											});
											c('JNBK------------'+table._id+'------------>>>>>>seat == -1');
											return false;   //if game stucks look here
										}
										

										/*var rCount = 0;

			                            for(k in table.pi){
			                                if(!_.isEmpty(table.pi[k]) && typeof table.pi[k]._ir != 'undefined' && table.pi[k]._ir == 1){
			                                    rCount++;
			                                }
			                            }*/


			                            /*var game_id = table.game_id;
			                            var sub_id = table.sub_id;

			                            if(_.contains(['','RoundTimerStarted','CollectingBootValue','StartDealingCard'],table.tst)){
			                                game_id = game_id+1;
			                                sub_id = sub_id+1;
			                            }
			                            
			                            if(table.gt == 'Deal' || table.gt == 'Pool'){ 


			                                if(table.round == 0){
			                                    game_id = game_id+'.1';
			                                    
			                                }
			                                else{
			                                    game_id = game_id+'.'+sub_id;

			                                }
			                                
			                            }*/


										var sts = '';
										console.log("table.gt:"+table.gt+" table.tst:"+table.tst+" table.round:"+table.round)
										if( (_.contains(['Classic','Bet'],table.gt) &&  !_.contains(["","RoundTimerStarted"],table.tst)) || (_.contains(['Deal','Pool'],table.gt) && ( !_.contains(["","RoundTimerStarted"],table.tst) || (!_.contains(['Classic','Bet'],table.gt) && table.round > 0) ))   ){
											sts = 'watch';
										}
										var di = "uploads/NewDealerImage/Dealer-1_1533300586.png"; 
										var id = "5b644f731bfdb4fe67fa3be7";

										var theme = 'cycn'
										for(var i in table.stdP){
											if(table.stdP[i].uid == client.uid){
												theme = table.stdP[i].theme;
											}
										}

										var updateInfo = {
											uid : upData._id.toString(),   		    		//	user id
											jt : new Date(),					    		//	join time
											gst : new Date(),								//  game start time
											gedt : new Date(),								//  game end time
											rndCount : 0,									//  round count
											si : seat,										//	seat index
											un : upData.un,						    		//	user name
											pp : upData.pp,						    		//	profile picture 
											Chips: upData.Chips,							// 	player chips
											totalCash: upData.totalcash,					//  player cash
											theme : theme,
											sort : false,
											secTime : config.SECONDARY_TIMER,				// 	secondary remaining time
											sct : false,									//	secondary timer flag
											tsd : new Date(),								// 	timer start time
											ted : new Date(),								//	timer end time
											_ir : upData.flags._ir,				    		//	is robot or not 
											rType : '',										// 	robot type not applicable for user
											s : sts,										//	status
											GiftId:'',										//  gift id
											GiftType:'',									//	gift type
											dealerImg:di,									//  dealer image
											dealerId:id,									//	dealer id
											play : 0,										//  is playing in current deal
											tCount : 0,										//	timeout count				
											ps : 0,											//	cards points (deadwood)
											dps: 0,											//  deal total points
											bet : table.bv,									//  bet set by players
											cards : [],										//	player cards
											gCards : {pure:[],seq:[],set:[],dwd:[]},		//  group cards formatted array
											dCards : {},									//  declared cards
											score : 0,										//	user score
											wc : 0,											//  win chips
											pts : 0,										//  points to be multiplied with bv
											pickCount: 0,									//  cards pick count
											_iw : 0,										//  is winner or not 
											// isSpc:isSpc,									//  is special user	
											thp : upData.counters.thp,						//  total hands played by user
											lpc : ''										//	last picked card
										}	
										
							
										var where = {_id:MongoID(table._id.toString())};
										where['pi.'+seat+'.si'] = {$exists:false};

										var newStdP = table.stdP.filter(function(stData){
											if(stData.uid != client.uid){
												return stData;
											}
										});

										playClass.getUserScore(upData._id.toString(),table.bv,table.gt,function(score){
											updateInfo.score = score;
											eval('var upData1 = {$set : {"pi.'+seat+'":updateInfo,stdP:newStdP,la :new Date()},$inc:{ap:1}}');

											/*if(isSpc){
												upData1.$set.spcSi = seat;
												upData1.$set.RobotCount = RobotCount;
												upData1.$set.HumanCount = HumanCount;
											}*/

											if(upData.flags._ir == 0){
												upData1.$inc.uCount = 1;
											}


											db.collection('playing_table').findAndModify(where,{},upData1,{new:true},function(err1,resp){
												resp = resp.value;

												if(!resp && client._ir == 0){
													cdClass.UpdateUserData(client.uid,{$set:{tbid:''}},function(){

														commonClass.SendData(client, 'PUP', {}, 'error:1024');  //seat is not Empty
													
													});
													
													return false;   ///if game stucks look here
													
												}

												c('JNBK----------'+resp._id+'---------->>>>>>client._ir: ',client._ir);
												if(client._ir == 0){
													var single = client.sck.replace(SERVER_ID+".","");
													c('JNBK--------->>>>>>single: ',single);
													// try{
													// 	c('JNBK----------->>>>>joinback with new method');
													// 	io.sockets.connected[single].si = seat;
													// }
													// catch(e){
													// 	c('JNBK------------->>>>>joinback with old method');
														client.tbid = resp._id.toString(); //adding tbid index to client
														client.si = seat; //adding seat index to client
														client.gt = resp.gt;
													// }
													if(io.sockets.connected[single]){
														c('JNBK--------->>>>>>>tbid: ',resp._id.toString());
														c('JNBK-----before----->>>>connected sockets: ',io.sockets.adapter.rooms[resp._id.toString()]);
														io.sockets.connected[single].join(resp._id.toString());
														c('JNBK-----after----->>>>connected sockets: ',io.sockets.adapter.rooms[resp._id.toString()]);

													}
													
												}
												c('JNBK-------if------>>>>>>client.tbid: ',client.tbid,' client.si: ',client.si);

												commonClass.SendData(client,'JNBK',{uid:client.uid});
												playingTableClass.GTI({"tbid": resp._id.toString(),_isHelp:0,"rejoin":0}, client,function(){

													commonClass.FireEventToTable(resp._id.toString(), { en : 'JT', data : {ap:resp.ap,si : seat,uid : upData._id.toString(),un : upData.un,pp : upData.pp,_ir : upData.flags._ir,secTime : resp.pi[seat].secTime,Chips : upData.Chips,totalCash : upData.totalcash,bet :resp.bv,s:sts}, flag : true },'JOIN_TABLE');
													
													playingTableClass.initializeGame(resp._id.toString());
												});
											});
										});
										// })
											
									}
									else{
										playClass.LT({flag:"noChips"},client,function(check){}); ///if no chips then direct remove from table
									}
		            			// });
								
							}
							else{
								cdClass.UpdateUserData(client.uid,{$set:{tbid:''}},function(){
									commonClass.SendData(client, 'PUP', {}, 'error:1023');  //table not found
								});
							}
						});
					});
				}
				else{
					c('JNBK------------------------->>>>"user not found"');
				}

			});
		}	
		else{  //join back with specific seat index given and user is standup 

			cdClass.GetTbInfo(client.tbid,{},function(table){
				if(table){
					if(_.isEmpty(table.pi[data.si]) && typeof table.pi[data.si] != 'undefined'){
						//join back logic here
						cdClass.GetUserInfo(client.uid,{_id:1,un:1,pp:1,'flags._ir':1,'flags._isSpc':1,Chips:1,totalcash:1,bonuscash:1,depositcash:1,wincash:1,wc:1,counters:1},function(userInfo){

							if(userInfo){
								// playClass.isFirstTimeUser(userInfo._id.toString(),function(isSpc,RobotCount,HumanCount){
									if(table.mode == 'practice'){
			            				var cond = (userInfo.Chips >= table.bv*config.MAX_DEADWOOD_PTS) ? true : false; 
			            			}
			            			else if(table.mode == 'cash'){
			            				var ef = table.bv*config.MAX_DEADWOOD_PTS;
										var cb = ef*config.CASH_BONUS/100;
			            				var cond = (userInfo.totalcash >= ef && (parseInt(userInfo.depositcash) + parseInt(userInfo.wincash) >= ef || (parseInt(userInfo.depositcash) + parseInt(userInfo.wincash) >= ef-parseInt(cb) && userInfo.bonuscash >= parseInt(cb)))) ? true : false;
			            			}

			            			if(cond){
									// if(userInfo.Chips >= table.bv*config.MAX_DEADWOOD_PTS){
										

										var sts = '';

										if( (_.contains(['Classic','Bet'],table.gt) &&  !_.contains(["","RoundTimerStarted"],table.tst)) || (_.contains(['Deal','Pool'],table.gt) && ( !_.contains(["","RoundTimerStarted"],table.tst) || (!_.contains(['Classic','Bet'],table.gt) && table.round > 0) ))   ){
											sts = 'watch';
										}

										var seat = data.si;
										var di = "uploads/NewDealerImage/Dealer-1_1533300586.png"; 
										var id = "5b644f731bfdb4fe67fa3be7";
							
										var theme = 'cycn'
										for(var i in table.stdP){
											if(table.stdP[i].uid == client.uid){
												theme = table.stdP[i].theme;
											}
										}

										var updateInfo = {
											uid : userInfo._id.toString(),   				//	user id
											jt : new Date(),					    		//	join time
											gst : new Date(),								//  game start time
											gedt : new Date(),								//  game end time
											rndCount : 0,									//  round count
											si : seat,										//	seat index
											un : userInfo.un,								//	user name
											pp : userInfo.pp,								//	profile picture 
											Chips: userInfo.Chips,							// 	player chips
											totalCash: userInfo.totalcash,							//  player cash
											theme : theme,									//	player selected table color
											sort : false,									//	display sort button
											secTime : config.SECONDARY_TIMER,				// 	secondary remaining time
											sct : false,									//	secondary timer flag
											tsd : new Date(),								// 	timer start time
											ted : new Date(),								//	timer end time
											_ir : userInfo.flags._ir,						//	is robot or not 
											rType : '',										// 	robot type not applicable for user
											s : sts,										//	status
											GiftId:'',										//  gift id
											GiftType:'',									//	gift Type
											dealerImg:di,									//  dealer image
											dealerId:id,									//	dealer id
											tCount : 0,										//	timeout count				
											ps : 0,											//	cards points (deadwood)
											dps: 0,											//  deal total points
											bet : table.bv,									//  bet set by players
											cards : [],										//	player cards
											gCards : {pure:[],seq:[],set:[],dwd:[]},		//  group cards formatted array
											dCards : {},									//  declared cards
											score : 0,										//	user score
											wc : 0,											//  win chips
											pts : 0,										//  points to be multiplied with bv
											pickCount: 0,									//  cards pick count
											_iw : 0,										//  is winner or not
											// isSpc:isSpc,									//  is special user	
											thp : userInfo.counters.thp					    //  total games played 	bu user	
										}


										var where = {_id:MongoID(table._id.toString())};
										where['pi.'+seat+'.si'] = {$exists:false};

										var newStdP = table.stdP.filter(function(stData){
											if(stData.uid != client.uid){
												return stData;
											}
										});
										c('JNBK---------'+table._id+'------------>>>>newStdP: ',newStdP);

										playClass.getUserScore(userInfo._id.toString(),table.bv,table.gt,function(score){
											updateInfo.score = score;
											eval('var upData = {$set : {la:new Date(),"pi.'+seat+'":updateInfo,stdP:newStdP},$inc:{ap:1}}');
											
											/*if(isSpc){
												upData.$set.spcSi = seat;
												upData.$set.nrg = 1;
												upData.$set.RobotCount = RobotCount;
												upData.$set.HumanCount = HumanCount;
											}*/
											if(userInfo.flags._ir == 0){
												upData.$inc.uCount = 1;
											}

											db.collection('playing_table').findAndModify(where,{},upData,{new:true},function(err1,resp){
												resp = resp.value;

												if(!resp && client._ir == 0){
													
													// c('JNBK---------'+resp._id+'---------->>>>>>MSG:"seat occupied"');
													commonClass.SendData(client, 'PUP', {}, 'error:1024');  //seat not empty
													return false;   ///if game stucks look here
													
												}

											
												if(client._ir == 0){
													var single = client.sck.replace(SERVER_ID+".","");
													c('JNBK--------->>>>>>single: ',single);
													
													client.si = seat; //adding seat index to client
												}
												commonClass.SendData(client,'JNBK',{uid:client.uid});
												playingTableClass.GTI({"tbid": resp._id.toString(),_isHelp:0,"rejoin":0}, client,function(){

													c('JNBK------else----->>>>>>>client.tbid: ',client.tbid,' client.si: ',client.si);
													commonClass.FireEventToTable(resp._id.toString(), { en : 'JT', data : {ap:resp.ap,si : seat,uid : userInfo._id.toString(),secTime : resp.pi[seat].secTime,un : userInfo.un,pp : userInfo.pp,_ir : userInfo.flags._ir,Chips : userInfo.Chips,totalCash : userInfo.totalcash,bet:resp.bv,s:sts}, flag : true },'JOIN_TABLE');
													
													playingTableClass.initializeGame(resp._id.toString());
												});
											});
										});
										// })
											
									}
									else{
										playClass.LT({flag:"noChips"},client,function(check){}); ///if no chips then direct remove from table
										// commonClass.SendData(client, 'PUP', {chips:table.bv*config.MAX_DEADWOOD_PTS,flag:'noChips'}, 'error:1020');  //don't have sufficient chips to play
									}
								// });
							}
							else{
								c('JNBK------------------------->>>>>"user data not found"');
							}
						});
					}
					else{
						commonClass.SendData(client, 'PUP', {}, 'error:1024');  //seat not empty
					}
				}
				else{
					commonClass.SendData(client, 'PUP', {}, 'error:1023');  //table not found
				}
			});
		}
	},
	LT: function(data,client,callback){  //leave table
		/* +-------------------------------------------------------------------+
            desc:event to leave table
            i/p: data = {flag = flag for table,onInvite = true/false leave from table invite or not},client = socket object,callback = callback function
        +-------------------------------------------------------------------+ */
		c('LT-------->>>>data: ',data,' client.tbid: '+client.tbid+' client.si: '+client.si+' client.id: '+client.id+' client._ir: '+client._ir);
		var freeSts = ["","RoundTimerStarted","winnerDeclared"/*,"roundWinnerDeclared","dealWinnerDeclared"*/];
		// cdClass.GetTbInfo(client.tbid,{},function(table){

		var leaveReason = 'back_to_lobby';

		if(data.flag){	
			switch(data.flag){
				case 'botc':leaveReason = 'ftu_bot_change';
							break;
				case 'lvlc':leaveReason = 'user_score_change';
							break;
				case 'noChips':leaveReason = 'out_of_chips';
							break;
				case 'auto': leaveReason = 'booted_out';
							break;
				case 'disc': leaveReason = 'user_disconnected';
							break;
				case 'lostPool':leaveReason = 'pool_elimination';
							break;
				default : leaveReason = 'exit';
			}
		}

		cdClass.UpdateTableData(client.tbid,{$set:{_isLeave:1}},function(table){
	
			if(table){
				var si = client.si;
				c('LT----'+table._id+'---->>>>>si: ',si);
				if(typeof si == 'undefined' || si == null || _.isEmpty(table.pi[si]) || table.pi[si].uid != client.uid){   //means player is in standup mode
					c('LT------if-'+table._id+'--->>>>table status: ',table.tst);
					

					cdClass.GetUserInfo(client.uid,{wc:1,flags:1,Chips:1,lasts:1,artifact:1},function(userInfo){
						var winc = (typeof userInfo == 'undefined' || userInfo == null || data.flag == 'noChips') ? 0 : userInfo.wc;
						var showRate = (userInfo.flags._isRated == 0 && typeof userInfo.lasts.lrpt != 'undefined' && commonClass.GetTimeDifference(userInfo.lasts.lrpt,new Date(),'day') >= 1) ? true : false; 
						c('LT------------>>>>>>>>winc: '+winc);
						if(client._ir == 1){
							cdClass.UpdateUserData(client.uid,{$set:{tbid:"",wc:0,s:"free",'counters.opc':0,sck:''}});
						}
						else{
							if(showRate || typeof userInfo.lasts.lrpt == 'undefined' || userInfo.lasts.lrpt == null){
								userInfo.lasts.lrpt = new Date();
							}
							var upData = {$set:{tbid:"",rejoinID:'',rejoin:0,'lasts.lrpt':userInfo.lasts.lrpt}};

							if(data.flag != 'switch'){

								upData.$set.wc = 0;
							}
							/*if(userInfo.artifact.qc == 1){
								upData.$set['artifact.qc'] = 0;
							}*/
							cdClass.UpdateUserData(client.uid,upData);	
						}
						var onInvite = (data.onInvite)?data.onInvite:false;
						if(data.flag){
							// eval('var dt = {leave:1,si:-1,winc:winc,uid:client.uid,id:client.id,tbid:table._id.toString(),'+data.flag+':1}')
							var dt = {ap:table.ap,pt:table.pt,leave:1,si : -1,gt:table.gt,winc:winc,showRate:showRate,uid:client.uid,id:client.id,tbid:table._id.toString(),flag:data.flag,onInvite:onInvite};
							if(data.flag == 'noChips'){
								dt.reqChips = (table.gt == 'Deal' || table.gt == 'Pool') ? table.bv:table.bv*config.MAX_DEADWOOD_PTS;
							}
						}
						else{
							var dt = {ap:table.ap,pt:table.pt,leave:1,si : -1,gt:table.gt,winc:winc,showRate:showRate,uid:client.uid,id:client.id,tbid:table._id.toString(),flag:'',onInvite:onInvite};
						}
						var newStdP = table.stdP.filter(function(stData){
							if(stData.uid != client.uid){
								return stData;
							}
						});
						c('LT-----'+table._id+'----->>>>>newStdP: ',newStdP);
						
						cdClass.UpdateTableData(client.tbid,{$set:{stdP:newStdP,_isLeave:0}},function(){

							c('LT-----------'+table._id+'---------->>>>>>client._ir: ',client._ir);
							if(client && typeof client._ir != 'undefined' && client._ir != null && client._ir == 0){
								c('LT--------if------>>>>>>');
								commonClass.SendDirect(client.uid, {en : "LT" , data :dt},true);	  //-1 to represent player as standup user

								delete client.tbid;
								delete client.si;
								delete client.gt; 
								
							}
							playingTableClass.managePlayerOnLeave(table._id.toString(),-1,true,leaveReason);
							if(typeof callback == 'function'){
								callback(1);
							}
							
						});
					});
				}
				else if(table.tst == "CollectingBootValue"){
					c('LT----'+table._id+'------>>>>>>Msg: "player cannot leave table on cards boot value collection phase"');
					cdClass.UpdateTableData(table._id.toString(),{$set:{_isLeave:0}},function(){

						commonClass.SendData(client, 'PUP', {}, 'error:1041');  //player can't leave table at cards dealing phase
						if(typeof callback == 'function'){
							callback(0);
						}
					});
				}
				else if(table.tst == "StartDealingCard" || table.tst == "CardsDealt"){
					c('LT----'+table._id+'------>>>>>>Msg: "player cannot leave table on cards dealing phase"');
					cdClass.UpdateTableData(table._id.toString(),{$set:{_isLeave:0}},function(){

						commonClass.SendData(client, 'PUP', {}, 'error:1033');  //player can't leave table at cards dealing phase
						if(typeof callback == 'function'){
							callback(0);
						}
					});
				}
				else if((table.tst == "roundWinnerDeclared" && table.gt == 'Deal') || (table.tst == 'roundWinnerDeclared' && table.gt == 'Pool' && data.flag != 'lostPool' ) || (table.tst == "" || table.tst == "RoundTimerStarted") &&  table.gt == "Deal" && table.round == 1 || (table.tst == "" || table.tst == "RoundTimerStarted") && table.gt == 'Pool' && table.round > 0){
					c('LT-----'+table._id+'-------->>>>>>Msg: "player cannot leave table on roundWinnerDeclared"');
					cdClass.UpdateTableData(table._id.toString(),{$set:{_isLeave:0}},function(){

						commonClass.SendData(client, 'LT', {ap:table.ap,pt:table.pt,si:si,leave:0,gt:table.gt,uid:client.uid,id:client.id,tbid:table._id.toString(),flag:''});  //player can't leave table at cards dealing phase
						commonClass.SendData(client, 'PUP', {}, 'error:1042');
						if(typeof callback == 'function'){
							callback(0);
						}
					});
				}
				else if(_.contains(freeSts,table.tst) || table.pi[si].s == '' || table.pi[si].s == 'watch' || (table.pi[si].s == 'drop' && (table.gt == 'Classic' || table.gt == 'Bet'))){  //simply remove player if player leaves after drop cards as chips already cut during drop cards process
					c('LT------'+table._id+'---->>>>table status: '+table.tst+' leaving user: '+table.pi[si].un);
					c('LT-------'+table._id+'------->>>on Free status or not playing');
					//simply remove player

					cdClass.GetUserInfo(table.pi[si].uid,{wc:1,flags:1,Chips:1,lasts:1,artifact:1},function(userInfo){
						var winc = (typeof userInfo == 'undefined' || userInfo == null || data.flag == 'noChips') ? 0 : userInfo.wc;
						var showRate = (userInfo.flags._isRated == 0 && typeof userInfo.lasts.lrpt != 'undefined' && commonClass.GetTimeDifference(userInfo.lasts.lrpt,new Date(),'day') >= 1) ? true : false; 
						c('LT--------------->>>>>>>winc: '+winc);
						var upData = {$set:{la:new Date(),'pi.$':{},_isLeave:0},$inc:{ap:-1}};



						if(table.pi[si]._ir == 1){
							cdClass.UpdateUserData(table.pi[si].uid,{$set:{tbid:"",wc:0,s:"free",'counters.opc':0,sck:''}});
						}
						else{

							if(showRate || typeof userInfo.lasts.lrpt == 'undefined' || userInfo.lasts.lrpt == null){
								userInfo.lasts.lrpt = new Date();
							}
							var upData1 = {$set:{tbid:"",wc:0,rejoinID:'',rejoin:0,'lasts.lrpt':userInfo.lasts.lrpt}};
							/*if(userInfo.artifact.qc == 1){
								upData1.$set['artifact.qc'] = 0;
							}*/
							cdClass.UpdateUserData(table.pi[si].uid,upData1);
							upData.$inc.uCount = -1;

							/*if(table.spcSi == si && si != -1){
								upData.$set.spcSi = -1;
								upData.$set.RobotCount = 0;
								upData.$set.HumanCount = 0;
							}*/


						}
						c('LT----->>>>table._id: ',table._id,' type of id: ',typeof table._id,' si: ',si);
						var onInvite = (data.onInvite)?data.onInvite:false;
						
						if(data.flag){
							// eval('var dt = {leave:1,si:client.si,winc:winc,uid:table.pi[si].uid,id:client.id,tbid:table._id.toString(),'+data.flag+':1}')
							var dt = {leave:1,si : si,gt:table.gt,pt:table.pt,winc:winc,showRate:showRate,uid:table.pi[si].uid,id:client.id,tbid:table._id.toString(),flag:data.flag,onInvite:onInvite};
							if(data.flag == 'noChips'){ //send out of chips with required chips
								dt.reqChips = (table.gt == 'Deal' || table.gt == 'Pool')?table.bv:table.bv*config.MAX_DEADWOOD_PTS;
							}
						}
						else{
							var dt = {leave:1,si : si,gt:table.gt,pt:table.pt,winc:winc,showRate:showRate,uid:table.pi[si].uid,id:client.id,tbid:table._id.toString(),flag:'',onInvite:onInvite};
						}
						
						c('LT--------->>>>>upData: ',upData,' table._id: '+table._id+' type table._id: '+typeof table._id+' si: '+si);
						db.collection('playing_table').findAndModify({_id:table._id,'pi.si':si},{},upData,{new:true},function(err,table1){
							if(table1 && table1.value){
								c('LT-------------->>>>>table1.value: ',table1.value);
								dt.ap = table1.value.ap;
								commonClass.FireEventToTable(table1.value._id.toString(),{en:'LT',data:dt});
								
								
								delete client.tbid;
								delete client.si; 
								delete client.gt;
								
								playingTableClass.managePlayerOnLeave(table1.value._id.toString(),si,true,leaveReason);
								if(typeof callback == 'function'){
									callback(1);
								}
							}
							else{
								console.log('LT:::free sts::::'+table._id+'::::si: '+si+'::::upData: ',upData,'::::\nerr: ',err,'::::Error: "table not found" '+new Date());
							}
						});
					});
				}
				else if(table.tst == "Finished"){
					cdClass.UpdateTableData(table._id.toString(),{$set:{_isLeave:0}},function(){
						if(data.flag == 'switch'){
							data.flag = data.flag;
						}
						else{
							data.flag = 'fns'
						}
						commonClass.SendDirect(client.uid, {en : "LT" , data :{ap:table.ap,pt:table.pt,leave:0,si : -1,gt:table.gt,winc:0,uid:client.uid,id:client.id,tbid:client.tbid,flag:data.flag}},true);
						commonClass.SendData(client, 'PUP', {}, 'error:1037');  //player can't leave table at cards declaration  phase
						if(typeof callback == 'function'){
							callback(0);
						}
					});
				}
				else if(table.gt == 'Deal'){
					c('LT-------'+table._id+'----Deal--->>>>table status: ',table.tst,' leaving user: ',table.pi[si].un);

					c('LT----------'+table._id+'------Deal------>>>>on running game');

					cdClass.GetUserInfo(table.pi[si].uid,{wc:1,flags:1,Chips:1,lasts:1,artifact:1},function(userInfo){
						var winc = (typeof userInfo == 'undefined' || userInfo == null || data.flag == 'noChips') ? 0 : userInfo.wc;
						var showRate = (userInfo.flags._isRated == 0 && typeof userInfo.lasts.lrpt != 'undefined' && commonClass.GetTimeDifference(userInfo.lasts.lrpt,new Date(),'day') >= 1) ? true : false; 
						c('LT----------->>>>winc: '+winc);

						cdClass.CountHands(table.pi[si].uid,'lost',table.gt,table.bv,false,function(thp,qstWin){
							var upData = {$set:{la:new Date(),'pi.$':{},_isLeave:0},$inc:{ap:-1}};

							if(table.pi[si]._ir == 1){
								cdClass.UpdateUserData(table.pi[si].uid,{$set:{tbid:"",wc:0,s:"free",'counters.opc':0,sck:''}});
							}
							else{
								if(showRate || typeof userInfo.lasts.lrpt == 'undefined' || userInfo.lasts.lrpt == null){
									userInfo.lasts.lrpt = new Date();
								}

								var upData1 = {$set:{tbid:"",wc:0,rejoinID:'',rejoin:0,'lasts.lrpt':userInfo.lasts.lrpt}};
								if(userInfo.artifact.qc == 1){
									upData1.$set['artifact.qc'] = 0;
								}
								cdClass.UpdateUserData(table.pi[si].uid,upData1);
								upData.$inc.uCount = -1;

								/*if(table.spcSi == si && si != -1){
									upData.$set.spcSi = -1;
									upData.$set.RobotCount = 0;
									upData.$set.HumanCount = 0;

									if(spc >= config.FIRST_TIME_GAME_LIMIT){
										db.collection('game_users').updateOne({_id:MongoID(table.pi[si].uid)},{$set:{'flags._isSpc':0}},function(errr,res){
											if(errr){
												c('LT------------>>>>>>errr: ',errr);
											}
											c('LT------------->>>>res: ',res);
										});
									}
								}*/
							}
							var onInvite = (data.onInvite)?data.onInvite:false;
							if(data.flag){
								// eval('var dt = {leave:1,si:si,winc:winc,uid:table.pi[si].uid,id:client.id,tbid:table._id.toString(),'+data.flag+':1}')
								var dt = {leave:1,si : si,gt:table.gt,pt:table.pt,winc:winc,showRate:showRate,uid:table.pi[si].uid,id:client.id,tbid:table._id.toString(),flag:data.flag,onInvite:onInvite};
								if(data.flag == 'noChips'){
									dt.reqChips = table.bv;
								}
							}
							else{
								var dt = {leave:1,si : si,gt:table.gt,pt:table.pt,winc:winc,showRate:showRate,uid:table.pi[si].uid,id:client.id,tbid:table._id.toString(),flag:'',onInvite:onInvite};
							}
							if(table.pi[si].s == 'playing'){
								upData['$inc'].playCount = -1;
							}

							var tempPlayerData = table.pi[si];
							tempPlayerData.s = 'left';
							var ctth = '';
							if(table.pi[si].cards.length > 13){  //user has more than 13 cards means he has picked a card
								ctth = table.pi[si].cards.pop();
								upData['$push'] = {oDeck: ctth};
							}
							tempPlayerData.cards = table.pi[si].cards;
							// tempPlayerData.gCards = [table.pi[si].cards];
							tempPlayerData.gCards = {pure:[],seq:[],set:[],dwd:table.pi[si].cards};
							tempPlayerData.dCards = {pure:[],seq:[],set:[],dwd:table.pi[si].cards};
							tempPlayerData.ps = config.MAX_DEADWOOD_PTS;
							tempPlayerData.dps = config.MAX_DEADWOOD_PTS*2;  //full two round points
							tempPlayerData._iw = 0;
							tempPlayerData.gedt = new Date();
							var players = playClass.getPlayingUserInRound(table.pi,true);
							c("LT---------------->>>>>>>>>>>>>>>players.length:",players.length);
							if(players.length > 0){
								upData['$addToSet'] = {hist:tempPlayerData};
							}
							else{
								c("LT---------------->>>>>>>>>>>>>>>do nothing")
							}

							db.collection('playing_table').findAndModify({_id:table._id,'pi.si':si},{},upData,{new:true},function(err,table1){
								if(err){
									console.log('LT::::si: '+si+':::::',table._id,':::::::upData: ',upData,':::err: ',err,':::>>>>>Error: "user not found"'+new Date());
								}

								if(!table1 || !table1.value){
									console.log('LT----si: '+si+'-----',table._id,'-------upData: ',upData,'------>>>>>Error: "user not found"'+new Date());
									return false;
								}

								/*var game_id = table1.value.game_id+'.'+table1.value.sub_id;
								var sts = '';
								if(onInvite){
									sts = 'invite';
								}
								else if(data.flag == 'auto'){
									sts = 'bootout';
								}
								else{
									sts = 'left';
								}*/

								/*if(table.pi[si] && table.pi[si].gst && typeof table.pi[si].rndCount != 'undefined' && table.pi[si].rndCount != null){

									var gameDuration = 0;
									var tableDuration = 0;
									gameDuration = commonClass.GetTimeDifference(table.pi[si].gst,new Date());
									tableDuration = commonClass.GetTimeDifference(table.pi[si].jt,new Date());
									trackClass.TEA({table:'track_primary_data',category:'screen',label:table.gt,option:'game_end_summary',action:table.ap,name:(table.ap-table.uCount),detail1:game_id,detail3:table.pi[si].rndCount,description:gameDuration,value:tableDuration},{uid:table.pi[si].uid});
								}*/
								// trackClass.TEA({table:'track_primary_data',category:'economy',label:table1.value.gt,option:'game_end',action:table.ap,name:0,value:0,detail1:game_id,detail3:tempPlayerData.dps,detail4:'chips',description:sts},{uid:client.uid});

								
								if(ctth != ''){

									commonClass.FireEventToTable(table1.value._id.toString(),{en:'DSCRD',data:{si:si,uid:table.pi[si].uid,time:table.pi[si].secTime,card:ctth,bbv:table1.value.bbv,finish:false,cdd:true,isRaise:0}});
									playClass.DC({},{tbid : table1.value._id.toString()});
								}
								dt.ap = table1.value.ap;
								commonClass.FireEventToTable(table1.value._id.toString(),{en:'LT',data:dt});
								
								delete client.tbid;
								delete client.si;
								delete client.gt; 
								
								if(data.flag != 'noChips'){

									playingTableClass.managePlayerOnLeave(table1.value._id.toString(),si,true,leaveReason);
								}
								if(typeof callback == 'function'){
									callback(1);
								}	
							});
						});
					});
				}
				else if(table.gt == 'Pool'){
					c('LT-------'+table._id+'----Pool--->>>>table status: ',table.tst,' leaving user: ',table.pi[si].un);

					c('LT----------'+table._id+'------Pool------>>>>on running game/end of game');


					cdClass.GetUserInfo(table.pi[si].uid,{wc:1,flags:1,Chips:1,lasts:1,artifact:1},function(userInfo){
						var winc = (typeof userInfo == 'undefined' || userInfo == null || data.flag == 'noChips') ? 0 : userInfo.wc;
						var showRate = (userInfo.flags._isRated == 0 && typeof userInfo.lasts.lrpt != 'undefined' && commonClass.GetTimeDifference(userInfo.lasts.lrpt,new Date(),'day') >= 1) ? true : false; 
						c('LT----------->>>>winc: '+winc);

						cdClass.CountHands(table.pi[si].uid,'lost',table.gt,table.bv,false,function(thp,qstWin){

							var upData = {$set:{la:new Date(),'pi.$':{},_isLeave:0},$inc:{ap:-1}};
							if(table.pi[si]._ir == 1){
								cdClass.UpdateUserData(table.pi[si].uid,{$set:{tbid:"",wc:0,s:"free",'counters.opc':0,sck:''}});
							}
							else{

								if(showRate || typeof userInfo.lasts.lrpt == 'undefined' || userInfo.lasts.lrpt == null){
									userInfo.lasts.lrpt = new Date();
								}

								var upData1 = {$set:{tbid:"",rejoinID:'',rejoin:0,'lasts.lrpt':userInfo.lasts.lrpt}};



								if(data.flag != 'switch'){
									upData1.$set.wc = 0;
								}
								
								/*if(userInfo.artifact.qc == 1){
									upData1.$set['artifact.qc'] = 0;
								}*/

								cdClass.UpdateUserData(table.pi[si].uid,upData1);
								upData.$inc.uCount = -1;

								/*if(table.spcSi == si && si != -1){
									upData.$set.spcSi = -1;
									upData.$set.RobotCount = 0;
									upData.$set.HumanCount = 0;
									if(spc >= config.FIRST_TIME_GAME_LIMIT){
										db.collection('game_users').updateOne({_id:MongoID(table.pi[si].uid)},{$set:{'flags._isSpc':0}},function(errr,res){
											if(errr){
												c('LT------------>>>>>>errr: ',errr);
											}
											c('LT------------->>>>res: ',res);
										});
									}
								}*/

							}
							var onInvite = (data.onInvite)?data.onInvite:false;
							if(data.flag){
								// eval('var dt = {leave:1,si:si,winc:winc,uid:table.pi[si].uid,id:client.id,tbid:table._id.toString(),'+data.flag+':1}')
								var dt = {leave:1,si : si,gt:table.gt,pt:table.pt,winc:winc,showRate:showRate,uid:table.pi[si].uid,id:client.id,tbid:table._id.toString(),flag:data.flag,onInvite:onInvite};
								if(data.flag == 'noChips'){
									dt.reqChips = table.bv;
								}
							}
							else{
								var dt = {leave:1,si : si,gt:table.gt,pt:table.pt,winc:winc,showRate:showRate,uid:table.pi[si].uid,id:client.id,tbid:table._id.toString(),flag:'',onInvite:onInvite};
							}
							if(table.pi[si].s == 'playing'){
								upData['$inc'].playCount = -1;
							}

							var tempPlayerData = table.pi[si];
							tempPlayerData.s = 'left';
							var ctth = '';
							if(table.pi[si].cards.length > 13){  //user has more than 13 cards means he has picked a card
								ctth = table.pi[si].cards.pop();
								upData['$push'] = {oDeck: ctth};
							}
							tempPlayerData.cards = table.pi[si].cards;
							// tempPlayerData.gCards = [table.pi[si].cards];
							tempPlayerData.gCards = {pure:[],seq:[],set:[],dwd:table.pi[si].cards};
							tempPlayerData.dCards = {pure:[],seq:[],set:[],dwd:table.pi[si].cards};
							tempPlayerData.ps = config.MAX_DEADWOOD_PTS;

							if(data.flag != 'lostPool'){  //if lostPool then no need direct show original dps
								
								tempPlayerData.dps = config.MAX_DEADWOOD_PTS;//table.pt;/*101*/  //full 101 points to show
							}
							tempPlayerData._iw = 0;
							tempPlayerData.gedt = new Date();
							upData['$addToSet'] = {hist:tempPlayerData};

							db.collection('playing_table').findAndModify({_id:table._id,'pi.si':si},{},upData,{new:true},function(err,table1){
								if(err){
									console.log('LT-------'+table._id+'---si: '+si+'----upData: ',upData,'------->>>>>Error: ',err,' '+new Date());
								}

								if(!table1 || !table1.value){
									console.log('LT-------'+table._id+'---si: '+si+'----upData: ',upData,'------->>>>>Error: "user not found"'+new Date());
									return false;
								}
								/*var game_id = table1.value.game_id+'.'+table1.value.sub_id;
								var sts = '';
								if(onInvite){
									sts = 'invite';
								}
								else if(data.flag == 'auto'){
									sts = 'bootout';
								}
								else if(data.flag == 'switch'){
									sts = 'switch';
								}
								else if(data.flag == 'lostPool'){
									sts = 'eliminate';
								}
								else{
									sts = 'left';
								}*/
								// trackClass.TEA({table:'track_primary_data',category:'economy',label:table1.value.gt,option:'game_end',action:game_id,name:table1.value.rSeq,value:0,detail1:table1.value.ap,detail2:0,detail3:tempPlayerData.dps,detail4:'chips',description:'loss'},{uid:client.uid});

								/*if(table.pi[si] && table.pi[si].gst && typeof table.pi[si].rndCount != 'undefined' && table.pi[si].rndCount != null){

									var gameDuration = 0;
									var tableDuration = 0;
									gameDuration = commonClass.GetTimeDifference(table.pi[si].gst,new Date());
									tableDuration = commonClass.GetTimeDifference(table.pi[si].jt,new Date());
									trackClass.TEA({table:'track_primary_data',category:'screen',label:table.gt,option:'game_end_summary',action:table.ap,name:(table.ap-table.uCount),detail1:game_id,detail3:table.pi[si].rndCount,description:gameDuration,value:tableDuration},{uid:table.pi[si].uid});
								}*/
								// trackClass.TEA({table:'track_primary_data',category:'economy',label:table1.value.gt,option:'game_end',action:table.ap,name:0,value:0,detail1:game_id,detail3:tempPlayerData.dps,detail4:'chips',description:sts},{uid:client.uid});

								if(ctth != ''){

									commonClass.FireEventToTable(table1.value._id.toString(),{en:'DSCRD',data:{si:si,uid:table.pi[si].uid,time:table.pi[si].secTime,card:ctth,bbv:table1.value.bbv,finish:false,cdd:true,isRaise:0}});
									playClass.DC({},{tbid : table1.value._id.toString()});
								}
								dt.ap = table1.value.ap;
								commonClass.FireEventToTable(table1.value._id.toString(),{en:'LT',data:dt});
								
								delete client.tbid;
								delete client.si; 
								delete client.gt;
								
								if( data.flag != 'lostPool' && data.flag != 'noChips'){

									playingTableClass.managePlayerOnLeave(table1.value._id.toString(),si,true,leaveReason);
								}
								else if(data.flag  == 'lostPool' && table1.value.tst == 'RoundStarted'){ //incase player left due to lost pool 
									playingTableClass.managePlayerOnLeave(table1.value._id.toString(),si,true,leaveReason);
								}
								else{
									c('LT::::::::::::::::"Anonymous case"');
								}
								if(typeof callback == 'function'){
									callback(1);
								}	
							});
						});
					});
				}
				else{
					//remove with full chips cut
					c('LT-------'+table._id+'------->>>>table status: ',table.tst,' leaving user: ',table.pi[si].un);

					c('LT----------'+table._id+'------------>>>>on running game');
					
					var cutChips = 0;   
					var pts = 0;

					if(table.gt == 'Bet'){

						if(table.pi[si].pickCount == 0){
							cutChips = config.MAX_DEADWOOD_PTS*table.pi[si].bet*config.FIRST_DROP;    //25% will be deducted if leave without picking any cards i.e First Leave
							pts = config.MAX_DEADWOOD_PTS*config.FIRST_DROP;
						}
						else{
							cutChips = config.MAX_DEADWOOD_PTS*table.pi[si].bet*config.MIDDLE_DROP;    //50% will be deducted if leave after picking any cards i.e Middle Leave
							pts = config.MAX_DEADWOOD_PTS*config.MIDDLE_DROP;
						}
					}
					else{
						if(table.pi[si].pickCount == 0){
							cutChips = config.MAX_DEADWOOD_PTS*table.bv*config.FIRST_DROP;    //25% will be deducted if leave without picking any cards i.e First Leave
							pts = config.MAX_DEADWOOD_PTS*config.FIRST_DROP;
						}
						else{
							cutChips = config.MAX_DEADWOOD_PTS*table.bv*config.MIDDLE_DROP;    //50% will be deducted if leave after picking any cards i.e Middle Leave
							pts = config.MAX_DEADWOOD_PTS*config.MIDDLE_DROP;
						}
					}
					c('LT--------'+table._id+'---------->>>cutChips: ',cutChips);
					
					if (table.mode == 'practice') {

						cdClass.UpdateUserChips(table.pi[si].uid,-cutChips,'Table Leave Deduction',function(uChips){

							cdClass.GetUserInfo(table.pi[si].uid,{wc:1,flags:1,Chips:1,lasts:1,artifact:1},function(userInfo){
								var winc = (typeof userInfo == 'undefined' || userInfo == null || data.flag == 'noChips') ? 0 : userInfo.wc;
								var showRate = (userInfo.flags._isRated == 0 && typeof userInfo.lasts.lrpt != 'undefined' && commonClass.GetTimeDifference(userInfo.lasts.lrpt,new Date(),'day') >= 1) ? true : false; 
								c('LT---------->>>>winc: '+winc);


								cdClass.CountHands(table.pi[si].uid,'lost',table.gt,table.bv,false,function(thp,qstWin){

									var upData = {$set:{la:new Date(),'pi.$':{},_isLeave:0},$inc:{pv:cutChips,ap:-1}};
									if(table.pi[si]._ir == 1){
										cdClass.UpdateUserData(table.pi[si].uid,{$set:{tbid:"",wc:0,s:"free",'counters.opc':0,sck:''}});
									}
									else{

										// if(showRate || typeof userInfo.lasts.lrpt == 'undefined' || userInfo.lasts.lrpt == null){
										// 	userInfo.lasts.lrpt = new Date();
										// }

										// var upData1 = {$set:{tbid:"",rejoinID:'',rejoin:0,'lasts.lrpt':userInfo.lasts.lrpt}};
										// if(data.flag != 'switch'){
										// 	upData1.$set.wc = 0;
										// }
										
										// if(userInfo.artifact.qc == 1){
										// 	upData1.$set['artifact.qc'] = 0;
										// }

										// cdClass.UpdateUserData(table.pi[si].uid,upData1);

										upData.$inc.uCount = -1;

										/*if(table.spcSi == si && si != -1){
											upData.$set.spcSi = -1;
											upData.$set.RobotCount = 0;
											upData.$set.HumanCount = 0;
											if(spc >= config.FIRST_TIME_GAME_LIMIT){
												db.collection('game_users').updateOne({_id:MongoID(table.pi[si].uid)},{$set:{'flags._isSpc':0}},function(errr,res){
													if(errr){
														c('LT------------>>>>>>errr: ',errr);
													}
													c('LT------------->>>>res: ',res);
												});
											}
										}*/
									}
									var onInvite = (data.onInvite)?data.onInvite:false;
									if(data.flag){
										// eval('var dt = {leave:1,si:si,winc:winc,uid:table.pi[si].uid,id:client.id,tbid:table._id.toString(),'+data.flag+':1}')
										var dt = {leave:1,si : si,gt:table.gt,pt:table.pt,winc:winc,showRate:showRate,uid:table.pi[si].uid,id:client.id,tbid:table._id.toString(),flag:data.flag,onInvite:onInvite};
										if(data.flag == 'noChips'){
											dt.reqChips =  table.bv*config.MAX_DEADWOOD_PTS;
										}
									}
									else{
										var dt = {leave:1,si : si,gt:table.gt,pt:table.pt,winc:winc,showRate:showRate,uid:table.pi[si].uid,id:client.id,tbid:table._id.toString(),flag:'',onInvite:onInvite};
									}

									if(table.pi[si].s == 'playing'){
										upData['$inc'].playCount = -1;

									}
									var tempPlayerData = table.pi[si];
									tempPlayerData.s = 'left';
									tempPlayerData.Chips = uChips;
									tempPlayerData.wc = -cutChips;
									tempPlayerData.pts = pts;
									var ctth = '';
									if(table.pi[si].cards.length > 13){  //user has more than 13 cards means he has picked a card
										ctth = table.pi[si].cards.pop();
										upData['$push'] = {oDeck: ctth};
									}
									
									tempPlayerData.cards = table.pi[si].cards;
									// tempPlayerData.gCards = [table.pi[si].cards];
									tempPlayerData.gCards = {pure:[],seq:[],set:[],dwd:table.pi[si].cards};
									tempPlayerData.dCards = {pure:[],seq:[],set:[],dwd:table.pi[si].cards};
									// tempPlayerData.ps = config.MAX_DEADWOOD_PTS;
									// tempPlayerData.ps = cardsClass.cardsSum(table.pi[si].cards,table.wildCard);
									tempPlayerData.ps = pts;
									tempPlayerData.dps = pts;
									tempPlayerData.gedt = new Date();

									var players = playClass.getPlayingUserInRound(table.pi,true);
									c("LT---------------->>>>>>>>>>>>>>>players.length:",players.length);
									if(players.length > 0){
										upData['$addToSet'] = {hist:tempPlayerData};
									}
									else{
										c("LT---------------->>>>>>>>>>>>>>>do nothing")
									}
									// upData['$addToSet'] = {hist:tempPlayerData};
									c('LT---------------->>>>>table._id: '+table._id+' si: '+si);
									db.collection('playing_table').findAndModify({_id:table._id,'pi.si':si},{},upData,{new:true},function(err,table1){
										if(err){
											console.log('LT:::::::'+table._id+':::::si: '+si+'::::::upData: ',upData,':::::::>>>>>Error: ',err,' '+new Date());
										}


										if(!table1 || !table1.value){
											console.log('LT------'+table._id+'---upData: ',upData,'---si: '+si+'--------->>>>"table not found"'+new Date());
											db.collection('playing_table').updateOne({_id:table._id},{$set:{la:new Date(),_isLeave:0}});
											return false;
										}

										if(showRate || typeof userInfo.lasts.lrpt == 'undefined' || userInfo.lasts.lrpt == null){
											userInfo.lasts.lrpt = new Date();
										}

										var upData1 = {$set:{tbid:"",rejoinID:'',rejoin:0,'lasts.lrpt':userInfo.lasts.lrpt}};
										if(data.flag != 'switch'){
											upData1.$set.wc = 0;
										}
										
										/*if(userInfo.artifact.qc == 1){
											upData1.$set['artifact.qc'] = 0;
										}*/

										cdClass.UpdateUserData(table.pi[si].uid,upData1);

										dt.wc = cutChips;
										dt.pts = pts;
										dt.ap = table1.value.ap;
										/*var game_id = table1.value.game_id;

										var sts = '';
										if(onInvite){
											sts = 'invite';
										}
										else if(data.flag == 'auto'){
											sts = 'bootout';
										}
										else if(data.flag == 'switch'){
											sts = 'switch';
										}
										else{
											sts = 'left';
										}*/



										/*if(table.pi[si] && table.pi[si].gst && typeof table.pi[si].rndCount != 'undefined' && table.pi[si].rndCount != null){

											var gameDuration = 0;
											var tableDuration = 0;
											gameDuration = commonClass.GetTimeDifference(table.pi[si].gst,new Date());
											tableDuration = commonClass.GetTimeDifference(table.pi[si].jt,new Date());
											trackClass.TEA({table:'track_primary_data',category:'screen',label:table.gt,option:'game_end_summary',action:table.ap,name:(table.ap-table.uCount),detail1:game_id,detail3:table.pi[si].rndCount,description:gameDuration,value:tableDuration},{uid:table.pi[si].uid});
										}*/


										if(ctth != ''){
											commonClass.FireEventToTable(table1.value._id.toString(),{en:'DSCRD',data:{si:si,uid:table.pi[si].uid,time:table1.value.pi[si].secTime,card:ctth,bbv:table1.value.bbv,finish:false,cdd:true,isRaise:0}});
											playClass.DC({},{tbid : table1.value._id.toString()});
										}
										commonClass.FireEventToTable(table1.value._id.toString(),{en:'LT',data:dt});
										
										delete client.tbid;
										delete client.si; 
										delete client.gt;
										
										playingTableClass.managePlayerOnLeave(table1.value._id.toString(),si,true,leaveReason);
										if(typeof callback == 'function'){
											callback(1);
										}	
									});
								});
							});
						});
					}
					else if (table.mode == 'cash') {

						var bc = cutChips*config.CASH_BONUS/100;
						cdClass.UpdateUserCashforgame(table.pi[si].uid,-cutChips,bc,'Table Leave Deduction',function(uChips){

							cdClass.GetUserInfo(table.pi[si].uid,{wc:1,flags:1,Chips:1,cash:1,lasts:1,artifact:1},function(userInfo){
								var winc = (typeof userInfo == 'undefined' || userInfo == null || data.flag == 'noChips') ? 0 : userInfo.wc;
								var showRate = (userInfo.flags._isRated == 0 && typeof userInfo.lasts.lrpt != 'undefined' && commonClass.GetTimeDifference(userInfo.lasts.lrpt,new Date(),'day') >= 1) ? true : false; 
								c('LT---------->>>>winc: '+winc);


								cdClass.CountHands(table.pi[si].uid,'lost',table.gt,table.bv,false,function(thp,qstWin){

									var upData = {$set:{la:new Date(),'pi.$':{},_isLeave:0},$inc:{pv:cutChips,ap:-1}};
									if(table.pi[si]._ir == 1){
										cdClass.UpdateUserData(table.pi[si].uid,{$set:{tbid:"",wc:0,s:"free",'counters.opc':0,sck:''}});
									}
									else{

										upData.$inc.uCount = -1;
									}
									var onInvite = (data.onInvite)?data.onInvite:false;
									if(data.flag){
										// eval('var dt = {leave:1,si:si,winc:winc,uid:table.pi[si].uid,id:client.id,tbid:table._id.toString(),'+data.flag+':1}')
										var dt = {leave:1,si : si,gt:table.gt,pt:table.pt,winc:winc,showRate:showRate,uid:table.pi[si].uid,id:client.id,tbid:table._id.toString(),flag:data.flag,onInvite:onInvite};
										if(data.flag == 'noChips'){
											dt.reqChips =  table.bv*config.MAX_DEADWOOD_PTS;
										}
									}
									else{
										var dt = {leave:1,si : si,gt:table.gt,pt:table.pt,winc:winc,showRate:showRate,uid:table.pi[si].uid,id:client.id,tbid:table._id.toString(),flag:'',onInvite:onInvite};
									}

									if(table.pi[si].s == 'playing'){
										upData['$inc'].playCount = -1;

									}
									var tempPlayerData = table.pi[si];
									tempPlayerData.s = 'left';
									tempPlayerData.cash = uChips;
									tempPlayerData.wc = -cutChips;
									tempPlayerData.pts = pts;
									var ctth = '';
									if(table.pi[si].cards.length > 13){  //user has more than 13 cards means he has picked a card
										ctth = table.pi[si].cards.pop();
										upData['$push'] = {oDeck: ctth};
									}
									
									tempPlayerData.cards = table.pi[si].cards;
									// tempPlayerData.gCards = [table.pi[si].cards];
									tempPlayerData.gCards = {pure:[],seq:[],set:[],dwd:table.pi[si].cards};
									tempPlayerData.dCards = {pure:[],seq:[],set:[],dwd:table.pi[si].cards};
									// tempPlayerData.ps = config.MAX_DEADWOOD_PTS;
									// tempPlayerData.ps = cardsClass.cardsSum(table.pi[si].cards,table.wildCard);
									tempPlayerData.ps = pts;
									tempPlayerData.dps = pts;
									tempPlayerData.gedt = new Date();
									var players = playClass.getPlayingUserInRound(table.pi,true);
									c("LT---------------->>>>>>>>>>>>>>>players.length:",players.length);
									if(players.length > 0){
										upData['$addToSet'] = {hist:tempPlayerData};
									}
									else{
										c("LT---------------->>>>>>>>>>>>>>>do nothing")
									}
									// upData['$addToSet'] = {hist:tempPlayerData};
									c('LT---------------->>>>>table._id: '+table._id+' si: '+si);
									db.collection('playing_table').findAndModify({_id:table._id,'pi.si':si},{},upData,{new:true},function(err,table1){
										if(err){
											console.log('LT:::::::'+table._id+':::::si: '+si+'::::::upData: ',upData,':::::::>>>>>Error: ',err,' '+new Date());
										}


										if(!table1 || !table1.value){
											console.log('LT------'+table._id+'---upData: ',upData,'---si: '+si+'--------->>>>"table not found"'+new Date());
											db.collection('playing_table').updateOne({_id:table._id},{$set:{la:new Date(),_isLeave:0}});
											return false;
										}

										if(showRate || typeof userInfo.lasts.lrpt == 'undefined' || userInfo.lasts.lrpt == null){
											userInfo.lasts.lrpt = new Date();
										}

										var upData1 = {$set:{tbid:"",rejoinID:'',rejoin:0,'lasts.lrpt':userInfo.lasts.lrpt}};
										if(data.flag != 'switch'){
											upData1.$set.wc = 0;
										}
										
										cdClass.UpdateUserData(table.pi[si].uid,upData1);

										dt.wc = cutChips;
										dt.pts = pts;
										dt.ap = table1.value.ap;

										if(ctth != ''){

											commonClass.FireEventToTable(table1.value._id.toString(),{en:'DSCRD',data:{si:si,uid:table.pi[si].uid,time:table1.value.pi[si].secTime,card:ctth,bbv:table1.value.bbv,finish:false,cdd:true,isRaise:0}});
											playClass.DC({},{tbid : table1.value._id.toString()});
										}
										commonClass.FireEventToTable(table1.value._id.toString(),{en:'LT',data:dt});
										
										delete client.tbid;
										delete client.si; 
										delete client.gt;
										
										playingTableClass.managePlayerOnLeave(table1.value._id.toString(),si,true,leaveReason);
										if(typeof callback == 'function'){
											callback(1);
										}	
									});
								});
							});
						});
					}
				}
			}
			else{
				c('LT::::::::::'+client.tbid+':::::::>>>>Error: "table not found!!!"');
				commonClass.SendDirect(client.uid, {en : "LT" , data :{ap:0,leave:1,si : -1,gt:client.gt,winc:0,uid:client.uid,id:client.id,tbid:client.tbid,flag:'tnf'}},true);
				
				if(typeof callback == 'function'){
					callback(1);
				}
			}
		});
	},
	SWTL :function(data,client){ // switch table; data = {}
		/* +-------------------------------------------------------------------+
            desc:event to switch table
            i/p: data = {},client = socket object
        +-------------------------------------------------------------------+ */
		c('SWTL----------->>>>>>client.uid: '+client.uid+' client.tbid: '+client.tbid+' client.si: '+client.si+' client.id: '+client.id+' client.gt: '+client.gt);
		var si = client.si;
		cdClass.GetUserInfo(client.uid,{},function(userInfo){
			if(!userInfo){
				c('SWTL::::::::::::::>>>>>>Error: "user not found!!!"');
				return false;
			}
			if(userInfo.rejoinID && userInfo.rejoinID != ''){
                jtClass.cancelRejoinJobs(userInfo.rejoinID);
                c('SWTL------------------>>>>>Msg: "4 min rejoin timer canceled"');
            }
			if(typeof userInfo.sck == 'string' && userInfo.sck != ''){

				var single = userInfo.sck.replace(/s\d*_\d*./i,'');
			}
			else{
				var single = '';	
			}
			cdClass.UpdateUserData(userInfo._id.toString(),{$set:{rejoinID:'',rejoin:0}},function(upData){

				var tbid = client.tbid;
				// playClass.LT({flag:"switch"},{id:single,uid:userInfo._id.toString(),_ir:userInfo.flags._ir,si : client.si,tbid:client.tbid},function(){
				cdClass.GetTbInfo(tbid,{},function(tbInfo){
					if(!tbInfo){
						c('SWTL::::::::::::::Error: "table not found!!!"');
						return false;
					}

					var gt = tbInfo.gt;
					c('SWTL------------------->>>>>client.tbid: '+client.tbid);

					var theme = '';
					for(var i in tbInfo.stdP){
						if(tbInfo.stdP[i].uid == client.uid){
							theme = tbInfo.stdP[i].theme;
						}
					}

					if(theme == '' && si != null && typeof si != 'undefined' && typeof tbInfo.pi[si].theme != 'undefined'){
						theme = tbInfo.pi[si].theme;
					}

					playClass.LT({flag:"switch",gt:gt},client,function(check){

						if(check == 1){

							c('SWTL---------->>>>>client: '+client.tbid+' client.uid: '+client.uid+' client.un: '+client.un+' check: '+check);
							cdClass.GetUserInfo(upData._id.toString(),{},function(userInfo1){

								if(userInfo1){
									c('SWTL---------->>>>>userInfo1.un: ',userInfo1.un,' userInfo1.tbid: ',userInfo1.tbid);

									if(typeof gt != 'undefined' && gt == 'Bet'){
										if(tbInfo.mode == 'practice'){

											db.collection('bet_category').find({from:{$lte:userInfo1.Chips},mode:'practice'}).sort({cpp:-1}).toArray(function(err,category){
												if(category.length > 0 && category[0].cpp*config.MAX_DEADWOOD_PTS <= userInfo1.Chips){
													var tData = {
														bv:category[0].cpp,
														lvc:userInfo1.counters.lvc,
														chips:userInfo1.Chips,
														mode:tbInfo.mode,
														pCount:tbInfo.ms,
														pt:tbInfo.pt,
														theme:theme,
														tbid:tbid,
														gt:'Bet'
													};
													playingTableClass.findTableAndJoin(tData,client,0); //player seats oon higher boot value
												}
												else{
													c('\nSWTL------bet----else------------------>>>>>');
													var reqChips = category[0].cpp*config.MAX_DEADWOOD_PTS;
													commonClass.SendDirect(client.uid, {en : "LT" , data :{minigames:[],leave:1,si : -1,winc:0,showRate:false,uid:client.uid,id:client.id,tbid:'',flag:'noChips',ap:0,reqChips:reqChips}},true);
													cdClass.UpdateUserData(client.uid,{$set:{wc:0}},function(){});
												}
											});
										}
										else{

											var cash = parseInt(userInfo.depositcash) + parseInt(userInfo.wincash);
											db.collection('bet_category').find({from:{$lte:cash},mode:'cash'}).sort({cpp:-1}).toArray(function(err,category){
												
												var ef = category[0].cpp*config.MAX_DEADWOOD_PTS;
												var cb = ef*config.CASH_BONUS/100;
												
												if (userInfo.totalcash >= ef && (parseInt(userInfo.depositcash) + parseInt(userInfo.wincash) >= ef || (parseInt(userInfo.depositcash) + parseInt(userInfo.wincash) >= ef-parseInt(cb) && userInfo.bonuscash >= parseInt(cb)))) {

													var tData = {
														bv:category[0].cpp,
														lvc:userInfo1.counters.lvc,
														chips:userInfo1.Chips,
														mode:tbInfo.mode,
														pCount:tbInfo.ms,
														pt:tbInfo.pt,
														theme:theme,
														tbid:tbid,
														gt:'Bet'
													};
													playingTableClass.findTableAndJoin(tData,client,0); //player seats oon higher boot value
												}
												else{
													c('\nSWTL------bet----else------------------>>>>>');
													var reqChips = category[0].cpp*config.MAX_DEADWOOD_PTS;
													commonClass.SendDirect(client.uid, {en : "LT" , data :{minigames:[],leave:1,si : -1,winc:0,showRate:false,uid:client.uid,id:client.id,tbid:'',flag:'noChips',ap:0,reqChips:reqChips}},true);
													cdClass.UpdateUserData(client.uid,{$set:{wc:0}},function(){});
												}
											});
										}
									}
									else{

										if(tbInfo.mode == 'practice'){

											if(config.PLAYING_CATEGORIES && upData && typeof upData.bv != 'undefined' && upData.bv != null && upData.bv > 0){
												if(upData.bv*config.MAX_DEADWOOD_PTS <= userInfo1.Chips){ 
													c('SWTL------------->>>>>>findTableAndJoin started!!!',tbInfo.pCount);
													var tData = {
														bv:upData.bv,
														lvc:userInfo1.counters.lvc,
														chips: userInfo1.Chips,
														tbid: tbid,
														mode:tbInfo.mode,
														pCount:tbInfo.ms,
														pt:tbInfo.pt,
														theme:theme,
														gt:tbInfo.gt
													}
													playingTableClass.findTableAndJoin(tData,client,0);  //player seats on higher boot value
												}
												else{
													c('\nSWTL--if--else----------->>>>>');
													// playClass.LT({flag:"noChips"},client,function(check){});
													var reqChips = upData.bv*config.MAX_DEADWOOD_PTS;
													commonClass.SendDirect(client.uid, {en : "LT" , data :{miniGames:[],leave:1,si : -1,winc:0,showRate:false,uid:client.uid,id:client.id,tbid:'',flag:'noChips',ap:0,reqChips:reqChips}},true);
													cdClass.UpdateUserData(client.uid,{$set:{wc:0}},function(){});
													// commonClass.SendData(client,'PUP', {flag:'noChips'},'error:1020');  //Don't have sufficient chips
												}
											}
											else{

												db.collection('playing_category').find({lBound:{$lte:userInfo1.Chips}}).sort({cpp:-1}).toArray(function(err,category){
													if(category.length > 0 && category[0].cpp*config.MAX_DEADWOOD_PTS <= userInfo1.Chips){ 
														c('SWTL------------->>>>>>findTableAndJoin started!!!');
														var tData = {
															bv:category[0].cpp,
															lvc:userInfo1.counters.lvc,
															chips: userInfo1.Chips,
															tbid: tbid,
															mode:tbInfo.mode,
															pCount:tbInfo.ms,
															pt:tbInfo.pt,
															theme:theme,
															gt:tbInfo.gt
														};
														playingTableClass.findTableAndJoin(tData,client,0);  //player seats on higher boot value
													}
													else{
														c('\nSWTL--else--else----------->>>>>');
														// playClass.LT({flag:"noChips"},client,function(check){});
														var reqChips = category[0].cpp*config.MAX_DEADWOOD_PTS;
														commonClass.SendDirect(client.uid, {en : "LT" , data :{miniGames:[],leave:1,si : -1,winc:0,showRate:false,uid:client.uid,id:client.id,tbid:'',flag:'noChips',ap:0,reqChips:reqChips}},true);
														cdClass.UpdateUserData(client.uid,{$set:{wc:0}},function(){});
														// commonClass.SendData(client,'PUP', {flag:'noChips'},'error:1020');  //Don't have sufficient chips
													}
												});
											}
										}
										else{

											if(config.PLAYING_CATEGORIES && upData && typeof upData.bv != 'undefined' && upData.bv != null && upData.bv > 0){
												
												var ef = upData.bv*config.MAX_DEADWOOD_PTS;
												var cb = ef*config.CASH_BONUS/100;
												if (userInfo.totalcash >= ef && (parseInt(userInfo.depositcash) + parseInt(userInfo.wincash) >= ef || (parseInt(userInfo.depositcash) + parseInt(userInfo.wincash) >= ef-parseInt(cb) && userInfo.bonuscash >= parseInt(cb)))) {

													c('SWTL------------->>>>>>findTableAndJoin started!!!');
													var tData = {
														bv:upData.bv,
														lvc:userInfo1.counters.lvc,
														chips: userInfo1.Chips,
														tbid: tbid,
														mode:tbInfo.mode,
														pCount:tbInfo.ms,
														pt:tbInfo.pt,
														theme:theme,
														gt:tbInfo.gt
													}
													playingTableClass.findTableAndJoin(tData,client,0);  //player seats on higher boot value
												}
												else{
													c('\nSWTL--if--else----------->>>>>');
													var reqChips = upData.bv*config.MAX_DEADWOOD_PTS;
													commonClass.SendDirect(client.uid, {en : "LT" , data :{leave:1,si : -1,winc:0,showRate:false,uid:client.uid,id:client.id,tbid:'',flag:'noChips',ap:0,reqChips:reqChips}},true);
													cdClass.UpdateUserData(client.uid,{$set:{wc:0}},function(){});
												}
											}
											else{

												var cash = parseInt(userInfo.depositcash) + parseInt(userInfo.wincash);
												db.collection('playing_category').find({lBound:{$lte:cash}}).sort({cpp:-1}).toArray(function(err,category){
													// if(category.length > 0 && category[0].cpp*config.MAX_DEADWOOD_PTS <= userInfo1.Chips){

													var ef = category[0].cpp*config.MAX_DEADWOOD_PTS;
													var cb = ef*config.CASH_BONUS/100; 
													if (userInfo.totalcash >= ef && (parseInt(userInfo.depositcash) + parseInt(userInfo.wincash) >= ef || (parseInt(userInfo.depositcash) + parseInt(userInfo.wincash) >= ef-parseInt(cb) && userInfo.bonuscash >= parseInt(cb)))) {
														
														c('SWTL------------->>>>>>findTableAndJoin started!!!');
														var tData = {
															bv:category[0].cpp,
															lvc:userInfo1.counters.lvc,
															chips: userInfo1.Chips,
															tbid: tbid,
															mode:tbInfo.mode,
															pCount:tbInfo.ms,
															pt:tbInfo.pt,
															theme:theme,
															gt:tbInfo.gt
														};
														playingTableClass.findTableAndJoin(tData,client,0);  //player seats on higher boot value
													}
													else{
														c('\nSWTL--else--else----------->>>>>');
														// playClass.LT({flag:"noChips"},client,function(check){});
														var reqChips = category[0].cpp*config.MAX_DEADWOOD_PTS;
														commonClass.SendDirect(client.uid, {en : "LT" , data :{miniGames:[],leave:1,si : -1,winc:0,showRate:false,uid:client.uid,id:client.id,tbid:'',flag:'noChips',ap:0,reqChips:reqChips}},true);
														cdClass.UpdateUserData(client.uid,{$set:{wc:0}},function(){});
														// commonClass.SendData(client,'PUP', {flag:'noChips'},'error:1020');  //Don't have sufficient chips
													}
												});
											}
										}
									}
								}
								else{
									c('SWTL:::::::::::::::::::::>>> Error : "user not found"');
									return false;
								}
							});
						}
					});
				});	
			});

		});
	},
	SWINF :function(data,client){ // switch information
		var si = data.si;
		// cdClass.GetTbInfo(data.tbid,{},function(table){
		// db.collection('playing_table').find({_id:MongoID(data.tbid.toString()),'pi.uid':client.uid}).toArray(function(err,table1){
		db.collection('playing_table').findOne({_id: MongoID(data.tbid.toString()),'pi.uid':client.uid},{},function(err, table) {
			if(table){
				
				var cutChips = 0;   
				var pts = 0;
				if(table.tst == 'RoundStarted'){

					if(table.gt == 'Bet'){

						if(table.pi[si].pickCount == 0){
							cutChips = config.MAX_DEADWOOD_PTS*table.pi[si].bet*config.FIRST_DROP;    //25% will be deducted if leave without picking any cards i.e First Leave
							pts = config.MAX_DEADWOOD_PTS*config.FIRST_DROP;
						}
						else{
							cutChips = config.MAX_DEADWOOD_PTS*table.pi[si].bet*config.MIDDLE_DROP;    //50% will be deducted if leave after picking any cards i.e Middle Leave
							pts = config.MAX_DEADWOOD_PTS*config.MIDDLE_DROP;
						}
					}
					else{
						if(table.pi[si].pickCount == 0 && table.pi[si].s == 'playing'){
							cutChips = config.MAX_DEADWOOD_PTS*table.bv*config.FIRST_DROP;    //25% will be deducted if leave without picking any cards i.e First Leave
							pts = config.MAX_DEADWOOD_PTS*config.FIRST_DROP;
						}
						else if(table.pi[si].s == 'playing'){
							cutChips = config.MAX_DEADWOOD_PTS*table.bv*config.MIDDLE_DROP;    //50% will be deducted if leave after picking any cards i.e Middle Leave
							pts = config.MAX_DEADWOOD_PTS*config.MIDDLE_DROP;
						}
						else{
							cutChips = 0;
							pts = 0;
						}
					}
				}
				else{
					cutChips = 0;
					pts = 0;
				}
			}
			else{
				cutChips = 0;
				pts = 0;
			}
			

			commonClass.SendData(client,'SWINF',{chips:cutChips});
			// commonClass.SendDirect(client.uid, {en : "SWINF" , data :{chips:cutChips}});
		});
	},
	DC:function(data,client){ //discarded card
		/* +-------------------------------------------------------------------+
            desc:event to see discarded cards
            i/p: data = {},client = socket object
            o/p: DC event: data = {dscd = array of discarded}
        +-------------------------------------------------------------------+ */
		c('DC---------->>>>>tbid: '+client.tbid);
		cdClass.GetTbInfo(client.tbid,{},function(table){
			if(table){
				// trackClass.TEA({table:'track_primary_data',category:'screen',label:table.gt,option:'discarded_cards',action:'click',name:table._id.toString(),detail1:table.rSeq,detail2:table.round},{uid:client.uid}); 
				// var game_id = table.game_id; 
				// if(table.gt == 'Deal' || table.gt == 'Pool'){
				// 	game_id = game_id+'.'+table.sub_id;
				// }

				// trackClass.TEA({table:'track_primary_data',category:'screen',label:table.gt,option:'discarded_cards',action:'click',name:table._id.toString(),detail1:game_id,detail3:table.rSeq},{uid:client.uid}); 

				var discarded = table.oDeck;
				var discardedrev = discarded.reverse(); 
				discardedrev.push(table.wildCard);

				if(_.contains(['','RoundTimerStarted','CollectingBootValue','StartDealingCard','CardsDealt'],table.tst)){
					discardedrev  = [];
				}

				// commonClass.SendData(client,'DC',{dscd:discardedrev});
				// commonClass.FireEventToTable(client.tbid,'DC',{dscd:discardedrev});
				commonClass.FireEventToTable(client.tbid,{en:'DC',data:{dscd:discardedrev}});
			}
		});
	},
	/*TUT: function(data,client){

		// var analysedUserCards = cardsClass.cardsAnalyser(data.cards,data.wildCard);
		var analysedUserCards = gbClass.GetSortedCard(data.cards,data.wildCard);

		commonClass.SendData(client,'TUT',analysedUserCards);

	},*/
	SORT:function(data,client){ //sort cards
		/* +-------------------------------------------------------------------+
            desc:event to set if the sort button has clicked or not
            i/p: data = {},client = socket object
            o/p: DC event: data = {dscd = array of discarded}
        +-------------------------------------------------------------------+ */

        if(client && client.tbid && client.tbid != ''){
        	
        	db.collection('playing_table').findAndModify({_id:MongoID(client.tbid),'pi.si': client.si},{},{$set:{la:new Date(),'pi.$.sort':false}},{new:true},function(err,table){
				
				if(table && table.value){
					c('SORT-------'+client.tbid+'-------->>>>>>Msg: "flag updated!!!"');
				}
				else{
					c('SORT------'+client.tbid+'------->>>>Msg:"flag not updated!!!"');
				}
			});
        }
        else{
        	c('SORT------------------->>>>"user not found"');
        }
	},
	isFirstTimeUser:function(uid,callback){
		cdClass.GetUserInfo(uid,{},function(userInfo){
			if(userInfo){
				c('isFirstTimeUser---------if-------->>>>');
				

				if(((userInfo.Chips <= config.FIRST_TIME_CHIPS_LIMIT && typeof userInfo.counters.spc != 'undefined' && typeof userInfo.flags._isSpc != 'undefined' && userInfo.counters.spc <= config.FIRST_TIME_GAME_LIMIT && userInfo.flags._isSpc == 1 && config.HAPPY_FLOW == true) || /*userInfo.counters.winct <= userInfo.winTrigger ||*/ (typeof userInfo.counters.loseStreak != 'undefined' && typeof userInfo.winTrigger != 'undefined' && userInfo.counters.loseStreak >= userInfo.winTrigger && config.HAPPY_FLOW == true)) && userInfo.flags._ir == 0){
					var HumanCount = 0;	
					var RobotCount = 0;
					var check = false;
					db.collection('first_time_journey').findOne({gameNo: userInfo.counters.spc+1},function(err,ftjData){
						if(ftjData){

							HumanCount = (ftjData.Human)?ftjData.Human:0;

							RobotCount += (ftjData.Newbie)?ftjData.Newbie:0;
							RobotCount += (ftjData.Amateur)?ftjData.Amateur:0;
							RobotCount += (ftjData.Pro)?ftjData.Pro:0;
							RobotCount += (ftjData.God)?ftjData.God:0;

							check = true;

							c("isFirstTimeUser-----------------------RobotCount:"+RobotCount);
							if(typeof callback == 'function'){

								return callback(check,RobotCount,HumanCount);
							}
						}
						else{
							db.collection('first_time_journey').findOne({type: 'wintrigger'},function(err,ftj){
								if(ftj){

									HumanCount = (ftj.Human)?ftj.Human:0;

									RobotCount += (ftj.Newbie)?ftj.Newbie:0;
									RobotCount += (ftj.Amateur)?ftj.Amateur:0;
									RobotCount += (ftj.Pro)?ftj.Pro:0;
									RobotCount += (ftj.God)?ftj.God:0;

									check = true;
									if(userInfo.counters.spc == config.FIRST_TIME_GAME_LIMIT){
										cdClass.updateWintrigger(userInfo._id.toString(),1);
									}
									c("isFirstTimeUser-----------------------RobotCount:"+RobotCount);
									if(typeof callback == 'function'){

										return callback(check,RobotCount,HumanCount);
									}
								}
							})
						}	
						
					});
				}
				else{
					c('isFirstTimeUser---------if--else----->>>>>>>>"user data not found"');
					if(typeof callback == 'function'){
						return callback(false,0,0);
					}
				}
			}
			else{
				c('isFirstTimeUser-------else------->>>>>>>>"user data not found"');
				if(typeof callback == 'function'){
					return callback(false,0,0);
				}
			}
		});
	},
	generateTable: function(data,callback){ //data = {bv,pCount,reke,gt,_ip} ; pCount,reke and gt iff gt == Deal or Pool
		/* +-------------------------------------------------------------------+
            desc:function to generate table for playing
            i/p: data = {bv = boot value,pCount = max player,reke = reke to cut,gt = game type,_ip:true/false}, callback = callback function
        +-------------------------------------------------------------------+ */
		c('generateTable------->>>>>data: ',data);
		var gt = 'Classic';
		var pi = [{},{},{},{},{},{}];
		var ms = data.pCount;
		var prize = 0;
		var reke = 0;
		var minS = 2;
		var pt = 101;
		data.mode = (typeof data.mode != 'undefined') ? data.mode : 'practice';
		if(data.gt && data.gt == 'Deal'){
			
			gt = 'Deal';
			ms = data.pCount;
			// prize = (typeof data.prize != 'undefined' && data.prize != null) ? data.prize : 0;
			reke = data.reke;
			prize = parseInt(data.bv*data.pCount*((100-reke)*0.01));  //table prize
			if(data.pCount == 2){  //no requirement for additional seats if there are only two players
				pi = [{},{}];  
			}
		}
		else if(data.gt && data.gt == 'Pool'){
			
			gt = 'Pool';
			ms = data.pCount;
			reke = data.reke;
			prize = parseInt(data.bv*data.pCount*((100-reke)*0.01));  //table prize reke = % deduct from prize money
			pt = (typeof data.pt != 'undefined') ? data.pt : 101;
			if(data.pCount == 2){
				pi = [{},{}];  //no requirement for additional seats if there are only three players
				minS = data.pCount;
			}
			else if (data.pCount == 4) {
				pi = [{},{},{},{}]
				minS = config.MIN_SEAT_TO_FILL_FOUR;
			}
			else if (data.pCount == 6) {
				pi = [{},{},{},{},{},{}];
				minS = config.MIN_SEAT_TO_FILL_SIX;
			}

		}
		else if(data.gt && data.gt == 'Bet'){
			
			gt = 'Bet';
			ms = data.pCount;
			if(data.pCount == 2){
				pi = [{},{}];
			}
			else if(data.pCount == 3){
				pi = [{},{},{}];
			}
			else if(data.pCount == 4){
				pi = [{},{},{},{}];
			}
			else{
				pi = [{},{},{},{},{}];
			}
			minS = data.pCount;
		}
		else{
			
			gt = 'Classic';
			ms = data.pCount;
			if(data.pCount == 2){
				pi = [{},{}];
				minS = data.pCount;
			}
			else if(data.pCount == 4){
				pi = [{},{},{},{}];
				minS = config.MIN_SEAT_TO_FILL_FOUR;
			}
			else{
				pi = [{},{},{},{},{},{}];
				minS = config.MIN_SEAT_TO_FILL_SIX;
			}
		}
		var di = "uploads/NewDealerImage/Dealer-1_1533300586.png"; 
		var id = "5b644f731bfdb4fe67fa3be7";
		var tjid = commonClass.GetRandomString(7);
 		var hint = (data.mode == 'cash') ? config.HINT_CASH : config.HINT_PRACTICE;
 		var tbJson = {
 			tjid : tjid,
 			cd: new Date(),						//	creation date
 			la: new Date(),  					//	last table active time
 			_ip:(data._ip)?1:0,					//  is private or not
 			ap : 0,   							//	active player
 			mode : data.mode,					// 	mode of table cash/chips
 			minS:minS,							//  minimum seats to fill
 			ms : ms,   							//	max seats on table
 			bv : data.bv, 						//	bootvalue
 			bbv : data.bv,						//  bet boot value
 			prize : prize,						//  prize for deal and pool
 			reke : reke,						//  reke to be deducted from prize
 			hint : hint,						//	show vard hint to user
 			lvc : data.lvc,						//	users level counter for find filter
 			pt : pt,							//	pool type 101/201
 			gt : gt,  							//	game type
 			tst: "",  							//	table status
 			pi: pi,  							//	player array
 			hist:[],							//  history of players per round to show players info at winner screen
 			stdP: [],							//  stand up players array (i.e not playing but still remains on table)
 			wildCard: '', 						//	wildCard card
 			cDeck: [],     						//	cards in cDeck
 			oDeck: [],   						//	thrown Cards
 			turn: -1,      						//	turn player index
 			dealer: -1,							//	round dealer index
 			dealerImg:di,						//  dealer image
 			dealerId:id,						//	dealer id	
 			declCount: 0,						//  declaration count
 			playCount : 0,						//	playing player count
 			fnsPlayer: -1,						// 	seat index of first finished  player
 			pv : 0,								//  pot value  
 			maxBet :0,							//  max bet value to be raised by players
 			// tScore:0,						//  table score
 			ctt: new Date(),					//  counter time
 			round: 0,							//  round count
 			game_id : 0,						//	game_id of table
 			sub_id : 0,							//	sub game_id for deak and pool
 			rSeq : 1,							//  round sequence
 			//spcSi : -1,						    //  seat index of special user
 			nrg : 0,
 			uCount : 0,						    //  number of human players
 			RobotCount : 0,						//  number of robots player to sit on special table
            HumanCount : 0,						//  number of human players to sit on special table
 			_isLeave: 0,						//  leave status, if 1 then someone left else left procedure completed(patiyu)
 			_isWinner:0,						//  if 1 then  winner handling start else winner handling complete
 			_artFlag : 0,						//	if artifact sent or not
 			_qstWin:0,							//  is anyone have win quest or not
 			initServer : SERVER_ID,				//  server id of initialization
 			ctrlServer : SERVER_ID				//	control server id
 		}

 		db.collection('playing_table').save(tbJson,function(err,resp){
 			callback(resp.ops[0]);
 		});
	},
	getPlayingUserInRound : function(p,play){  //gives the json of the each players on the table;  play = flag for getting actual playing user
		/* +-------------------------------------------------------------------+
            desc:return the details of player on table in current round if play = true then only returns currently playing players
            i/p: p = details of all players on table,play = true/false if true then only returns playing users
        +-------------------------------------------------------------------+ */
		var pl = [];
		if(!p){
		  return pl;
		}
		  

		for(var x = 0 ; x < p.length ; x ++){
			
			if(typeof p[x] == 'object' &&  p[x] && typeof p[x].s != 'undefined' && p[x].s != null  && p[x].s != 'left' && (!play || p[x].s == 'playing') ){  //special condition P'+T

				pl.push(p[x]);
			}	
		}
		return pl;
	},
	getPlayingUserInGame : function(p,play){  //gives the json of the each players on the table;  play = flag for getting actual playing user
		/* +-------------------------------------------------------------------+
            desc:return the details of player on table if play = true then only returns currently playing players
            i/p: p = details of all players on table,play = true/false if true then only returns playing users
        +-------------------------------------------------------------------+ */

		var pl = [];
		if(!p){
		  return pl;
		}
		  

		for(var x = 0 ; x < p.length ; x ++){
			
			if(typeof p[x] == 'object' &&  p[x] && typeof p[x].s != 'undefined' && p[x].s != null  && p[x].s != 'left' && (!play || p[x].play == 1) ){  //special condition P'+T

				pl.push(p[x]);
			}	
		}
		return pl;
	},
	chooseTurnUser : function(table){   //selects the turn among the players
		/* +-------------------------------------------------------------------+
            desc:return the details of player on table if play = true then only returns currently playing players
            i/p: p = details of all players on table,play = true/false if true then only returns playing users
        +-------------------------------------------------------------------+ */
		// var pi = playClass.getPlayingUserInRound(table.pi);
		var pi = playClass.getPlayingUserInRound(table.pi,true);
		c('chooseTurnUser---------------->>>>>>pi:',pi);
		var turn = -1;
		if(pi && pi.length > 1 && table.dealer == -1){ //if the game has just started then select random user
			turn = pi[Math.floor(Math.random()*pi.length)].si;
		}
		else if(pi && pi.length > 1 && table.dealer >= 0){ //dealer's next user will be new dealer

			var i = 0,k = table.dealer;
			while(i < table.ms){

				k = (k+1)%table.ms;
				if(!_.isEmpty(table.pi[k]) && table.pi[k].s == 'playing'){
					turn = k;
					break;
				}
				i++;
			}	
		}
		else{
			c('chooseTurnUser::::::::::::::::::::>>>>Error: "unable to find turn user"');
		}
		c('chooseTurnUser------------->>>>>>turn: ',turn);
		return turn;
	},
	getNextPlayer:function(table){ 	//get the index of next player on table
		/* +-------------------------------------------------------------------+
            desc:return the seat index of next playing user on table
            i/p: table = table details
            o/p: seat index of player
        +-------------------------------------------------------------------+ */
		c('getNextPlayer------->>>>>table.turn: ',table.turn,' table.ap: ',table.ap);
		if(table.ap > 1){

			var i = 0,k = table.turn,chRound = false,obj = {};
			while(i < table.ms){
				
				k = (k+1)%table.ms;

				if(k == table.dealer){
					chRound = true;
				}
				if(!_.isEmpty(table.pi[k]) && table.pi[k].s == 'playing'){
					obj = {
						nxt : k,
						chRound : chRound
					}
					return obj;
				}
				i++;
			}	
		}
	},
	getUserScore:function(uid,bv,gt,cb){
		/* +-------------------------------------------------------------------+
            desc:returns score of user
            i/p: uid = _id of user,bv = boot value of table,gt = game type of user,cb = callback function
            o/p: user score
        +-------------------------------------------------------------------+ */
		cdClass.GetUserInfo(uid,{'flags._ir':1,'counters.cw':1,'counters.cl':1,cd:1,Chips:1,'lasts.ll':1},function(userInfo){
			c('getUserScore---------->>>>userInfo: ',userInfo);
			if(userInfo && userInfo.flags._ir == 0){
				var cwin = userInfo.counters.cw;
				var closs = userInfo.counters.cl;
				var dsi = commonClass.GetTimeDifference(userInfo.cd,new Date(),'day');
				var cbal = userInfo.Chips;
				// if(bv > 0){
				// 	var cpp = Math.floor(userInfo.Chips/bv);
				// }
				// else{
				// 	var cpp = 0;
				// }
				var cpp = bv;
				var nduc = commonClass.GetTimeDifference(userInfo.lasts.ll,new Date(),'day');

				var totalScore = 0;
				c('getUserScore------>>>>>>cwin: ',cwin,' closs: ',closs,' dsi: ',dsi,' cbal: ',cbal,'cpp: ',cpp,' nduc: ',nduc);
				var i1,i2,i3,i4,i5,i6;
				for(i1 in CWIN){
					if(CWIN[i1].from <= cwin){
						c('getUserScore CWIN: ',CWIN[i1].score);
						totalScore+= CWIN[i1].score;
						break;
					}
				} 
				for(i2 in CLOSS){
					if(CLOSS[i2].from <= closs){
						c('getUserScore CLOSS: ',CLOSS[i2].score);
						totalScore+= CLOSS[i2].score;
						break;
					}
				}
				for(i3 in DSI){
					if(DSI[i3].from <= dsi){
						c('getUserScore DSI: ',DSI[i3].score);
						totalScore += DSI[i3].score;
						break;
					}
				}
				for(i4 in CBAL){
					if(CBAL[i4].from <= cbal){
						c('getUserScore CBAL: ',CBAL[i4].score);
						totalScore += CBAL[i4].score;
						break;
					}
				}
				if(gt != 'Deal'){
					
					for(i5 in CPP){
						if(CPP[i5].from <= cpp){
							c('getUserScore CPP: ',CPP[i5].score);
							totalScore += CPP[i5].score;
							break;
						}
					}
				}
				for(i6 in NDUC){
					if(NDUC[i6].from <= nduc){
						c('getUserScore NDUC: ',NDUC[i6].score);
						totalScore += NDUC[i6].score;
						break;
					}
				}

				c('getUserScore------->>>>totalScore: ',totalScore);
				totalScore = (totalScore > 0)? totalScore : 0;   //validation to prevent score < 0 
				cb(parseInt(totalScore));
				return;

			}
			else{
				c('getUserScore------------->>>>>>Msg:"user not found or player is robot"');
				cb(0);
				return;
			}
		});
	},
	getTableScore:function(tbId,callback){   //returns sum of all userScore
		/* +-------------------------------------------------------------------+
            desc:returns total score of table
            i/p: tbId = _id of table, callback = callback function
            o/p: return table score
        +-------------------------------------------------------------------+ */
		cdClass.GetTbInfo(tbId,{pi:1},function(tbInfo){
			// c('getTableScore------------>>>>tbInfo: ',tbInfo);
			if(tbInfo && tbInfo.pi && tbInfo.pi.length > 0){
				players = playClass.getPlayingUserInRound(tbInfo.pi);
				var tScore = [];
				var uCount = 0;
				if(players.length > 0){ 
					for(var i in players){
						if(players[i]._ir == 0){   //count only for user not robots
							
							uCount++;
							tScore.push(players[i].score);
						}
					}
					if(uCount == 1 ){
						callback(tScore[0]);
						return;
					}
					else if(uCount > 1){
						
						callback(commonClass.getMedian(tScore));
						return;
					}
					else{
						callback(0);
						return;
					}

				}
				else{
					callback(0);
					return;
				}
			}
			else{
				c('getTableScore------->>>>Error: "pi not found not found!"');
				callback(0);
				return;
			}
		});
	},
	removeOnLowChips:function(tbId,bv,gt,px,rType,tst,rSeq,game_id,rr,pt,iter){
		/* +-------------------------------------------------------------------+
            desc:this function removes the player who has not sufficient chips to play on table
            i/p: tbId = _id of table, bv = boot value of user,gt = game type of table,px = details of player,rType = robot type,tst = table status,iter = iterator 
        +-------------------------------------------------------------------+ */
		c('removeOnLowChips----------->>>>>>tbId',tbId,' px: ',px+' bv: '+bv+' iter: '+iter+' rType: '+rType+' pt: '+pt+' rr: '+rr+' gt: '+gt);
		if(iter < px.length){

		
			cdClass.GetUserInfo(px[iter].uid,{Chips:1,sck:1},function(playerInfo){

				if(playerInfo){

					c('removeOnLowChips---if--->>>>');
					var cond = false;
					var msg = 'noChips';
					
					if(px[iter]._ir == 1 && px[iter].rType != rType){

						if(rType == 'noBot'){
							msg = 'botc';
						}
						else{

							msg = 'lvlc';
						}

						cond = true;
					}

					/*if(px[iter]._ir == 1){
						if(rmrb && rr > 1){
							msg = 'botc';
							cond = true;
							rr = rr - 1;
						}
					}*/

					if(gt == 'Deal'){
						if( playerInfo.Chips < bv){
							msg = 'noChips';
							cond = true;
						}
					}
					else if(gt == 'Pool'){

						//low chips condition here
						if(tst == 'winnerDeclared' && playerInfo.Chips < bv){
							cond = true;
							msg = 'noChips';
						}


						c('removeOnLowChips-------->>>>>dps: '+px[iter].dps);
						if(px[iter].dps >= pt/*101*/){ //check if the player has total points greater than 100 then remove that player
							cond = true;
							msg = 'lostPool';
						}

					}
					else{
						if(playerInfo.Chips < bv * config.MAX_DEADWOOD_PTS){
							cond = true;
						}
					}
					// cond = (gt == 'Deal') ? playerInfo.Chips < bv : playerInfo.Chips < bv * config.MAX_DEADWOOD_PTS;
					
					if(cond){
						c('removeOnLowChips---if---if------>>>>');
						if(typeof playerInfo.sck == 'string' && playerInfo.sck != ''){

							var single = playerInfo.sck.replace(/s\d*_\d*./i,'');
						}
						else{
							var single = '';	
						}

						playClass.LT({flag:msg},{id:single,uid: px[iter].uid,_ir:px[iter]._ir,si:px[iter].si,tbid:tbId},function(check){
							c('removeOnLowChips----------->>>check: ',check);
							playClass.removeOnLowChips(tbId,bv,gt,px,rType,tst,rSeq,game_id,rr,pt,iter+1);
						});
					}
					else{
						c('removeOnLowChips---if--else------>>>>');
						playClass.removeOnLowChips(tbId,bv,gt,px,rType,tst,rSeq,game_id,rr,pt,iter+1);
					}
				}
				else{
					c('removeOnLowChips---else1--->>>>');
					playClass.removeOnLowChips(tbId,bv,gt,px,rType,tst,rSeq,game_id,rr,pt,iter+1);
				}
			});
			
		}
		else{
			cdClass.GetTbInfo(tbId,{},function(table1){
				if(table1){
					var players = playClass.getPlayingUserInRound(table1.pi);
					c('removeOnLowChips-- else-->>>>>>>players: ',players);
					if(players.length <= 0 && table1.stdP.length == 0 ){
						c('removeOnLowChips-------'+table1._id+'------>>>>"table deleted"');
						db.collection('last_deal').remove({tbid: table1._id.toString()},function(){});
						db.collection('playing_table').remove({_id: table1._id},function(){});
						db.collection('instant_table_invites').remove({tbid:table1._id.toString()},function(){});
						db.collection('table_invites').remove({tbid:table1._id.toString()},function(){});
						// db.collection('user_notification').remove({tbid:table1._id.toString()},function(){}); //remove all table invitation for this table
						// notiClass.deleteTableNoti(table1._id.toString());
					}
					else{
						/*var rcost = 0;
						db.collection('undo_data').findOne({turn:0},function(err,undoData){
							if(undoData && typeof undoData.coins != 'undefined'){
								rcost = undoData.coins;
							}*/

							c('removeOnLowChips-----else13131313----->>>>players: ',players);
							var pi = table1.pi;
							var ap = table1.ap;
							for(var x in pi){
								if(pi[x] && !_.isEmpty(pi[x]) && typeof pi[x].si != 'undefined'){

									if(pi[x].s == 'left'){			//remove left out player data from table
										pi[x] = {};
										ap--;
									}
									else{

										pi[x].s = '';
										pi[x].tCount = 0;
										pi[x].cards = [];
										// pi[x].dn = 0;
										pi[x]._iw = 0;
										pi[x].gCards = {};
										pi[x].dCards = {};
										pi[x].wc = 0;
										pi[x].pickCount = 0;
										pi[x].pts = 0;
										pi[x].ps = 0;
										pi[x].play = (table1.round < 2 && table1.gt == 'Deal' || table1.gt == 'Pool' && table1.tst == 'roundWinnerDeclared') ? pi[x].play : 0;
										pi[x].dps = (table1.round < 2 && table1.gt == 'Deal' || table1.gt == 'Pool' && table1.tst == 'roundWinnerDeclared') ? pi[x].dps : 0;  //only for deal and pool
										pi[x].bet = table1.bv;
										pi[x].isCollect = (table1.round < 2 && table1.gt == 'Deal' || table1.gt == 'Pool' && table1.tst == 'roundWinnerDeclared') ? pi[x].isCollect: 0; //isboot value collected or not
										pi[x].secTime = config.SECONDARY_TIMER;
										pi[x].sct = false;
										pi[x].tsd = new Date();
										pi[x].ted = new Date();
										pi[x].sort = true;
									}
								}
							}
							// var jobId = commonClass.GetRandomString(10);
							// var nxt = commonClass.AddTime(config.NXT);
							var round = (table1.round >= 2 && table1.gt == 'Deal' || table1.gt == 'Pool' && table1.tst == 'winnerDeclared') ? 0: table1.round; 
							// var game_id = (table1.round >= 2 && table1.gt == 'Deal' || table1.gt == 'Pool' && table1.tst == 'winnerDeclared') ? Math.floor(table1.game_id):table1.game_id;

							// var pv = (table1.round == 1 && table1.gt == 'Deal') ? table1.pv : 0;
							var pv = (round == 1 && table1.gt == 'Deal' || table1.gt == 'Pool' && round > 0) ? table1.pv : 0;

							var hist = [];
							if((table1.gt == 'Deal' || table1.gt == 'Pool') && round > 0){

								hist = table1.hist.filter(function(htData){
									if(htData.s == 'left'){
										return htData;
									}
								});
							}


							//var thp = (typeof table1.spcSi != 'undefined' && table1.spcSi != null && table1.spcSi != -1 && pi[table1.spcSi] && !_.isEmpty(pi[table1.spcSi]) && typeof pi[table1.spcSi].thp != 'undefined' && pi[table1.spcSi].thp != null) ? pi[table1.spcSi].thp : -1;
							// var spc = (typeof table1.spcSi != 'undefined' && table1.spcSi != null && table1.spcSi != -1 && pi[table1.spcSi] && !_.isEmpty(pi[table1.spcSi]) && typeof pi[table1.spcSi].spc != 'undefined' && pi[table1.spcSi].spc != null) ? pi[table1.spcSi].spc : -1;

							/*if(spc == config.FIRST_TIME_GAME_LIMIT){
								cdClass.updateWintrigger(pi[table1.spcSi].uid.toString(),1);
							}*/
							var RobotCount = table1.RobotCount;
							var HumanCount = table1.HumanCount;
							var minS = table1.minS;
							if(table1.gt == 'Deal'){
								minS = 2
							}
							else if(table1.gt == 'Pool'){
								minS = 3
							}
							else if(table1.gt == 'Bet'){
								minS = config.MIN_SEAT_TO_FILL_BET;
							}
							else{
								minS = config.MIN_SEAT_TO_FILL;
							}

							// console.log("removeOnLowChips-------------------------------thp"+spc); 
							// db.collection('first_time_journey').findOne({gameNo:spc+1},function(errr,ftjData){
							// 	if(ftjData){
							// 		RobotCount = 0;
							// 		HumanCount = 0;
									
							// 		HumanCount = (ftjData.Human)?ftjData.Human:0;

							// 		RobotCount += (ftjData.Newbie)?ftjData.Newbie:0;
							// 		RobotCount += (ftjData.Amateur)?ftjData.Amateur:0;
							// 		RobotCount += (ftjData.Pro)?ftjData.Pro:0;
							// 		RobotCount += (ftjData.God)?ftjData.God:0;

							// 		minS = RobotCount+1;
							// 	}
							// 	else{
									// if(spc != -1){
										var players = playClass.getPlayingUserInRound(table1.pi);
										var rCount = 0;
										for(var x in players){
											if(players[x]._ir == 1){
												rCount++;
											}
										}

										minS = rCount+1;
									// }
								// }
					
								console.log("removeOnLowChips-------------------------------minS"+minS); 
								/*var nrg = 0;
								if(table1.spcSi == -1){
									nrg = 0;
								}
								else{
									nrg = table1.nrg;
								}*/
								cdClass.UpdateTableData(table1._id.toString(),{$set:{rSeq:1,/*minS:minS,*/maxBet :0,bbv:table1.bv,_isWinner:0,_isLeave:0,tst:'',round:round/*,jid:jobId*/,ap:ap,pi:pi,pv:pv,wildCard: '',oDeck:[],declCount:0,playCount:0/*,dNum:0*/,cDeck: [],turn:-1,fnsPlayer:-1,ctt:new Date(),hist:hist,HumanCount:HumanCount,RobotCount:RobotCount}},function(table2){
									
									if(table2){
										c('removeOnLowChips-------111---->>>>>>"table data reset"',table2._id.toString());
										playingTableClass.initializeGame(table2._id.toString());
									}
									else{
										c('removeOnLowChips-------1---->>>>>>Error:"table not found"');
									}	
								});
							// });
						// });
					}
				}
				else{
					c('removeOnLowChips---------2----------Error:"Table not found"');
				}
			});
		}
	},
	removeOnLowCash:function(tbId,bv,gt,px,rType,tst,rSeq,game_id,rr,pt,iter){
		/* +-------------------------------------------------------------------+
            desc:this function removes the player who has not sufficient chips to play on table
            i/p: tbId = _id of table, bv = boot value of user,gt = game type of table,px = details of player,rType = robot type,tst = table status,iter = iterator 
        +-------------------------------------------------------------------+ */
		c('removeOnLowCash----------->>>>>>tbId',tbId,' px: ',px+' bv: '+bv+' iter: '+iter+' rType: '+rType+' rr: '+rr);
		if(iter < px.length){

		
			cdClass.GetUserInfo(px[iter].uid,{Chips:1,cash:1,sck:1},function(playerInfo){

				if(playerInfo){

					c('removeOnLowCash---if--->>>>');
					var cond = false;
					var msg = 'noChips';
					
					if(px[iter]._ir == 1 && px[iter].rType != rType){

						if(rType == 'noBot'){
							msg = 'botc';
						}
						else{

							msg = 'lvlc';
						}

						cond = true;
					}

					/*if(px[iter]._ir == 1){
						if(rmrb && rr > 1){
							msg = 'botc';
							cond = true;
							rr = rr - 1;
						}
					}*/
					
					if(gt == 'Deal'){
						if(playerInfo.cash < bv){
							msg = 'noChips';
							cond = true;
						}
					}
					else if(gt == 'Pool'){

						//low chips condition here
						if(tst == 'winnerDeclared' && playerInfo.cash < bv){
							cond = true;
							msg = 'noChips';
						}


						c('removeOnLowCash-------->>>>>dps: '+px[iter].dps);
						if(px[iter].dps >= pt/*101*/){ //check if the player has total points greater than 100 then remove that player
							cond = true;
							msg = 'lostPool';
						}

					}
					else{
						if(playerInfo.cash < bv * config.MAX_DEADWOOD_PTS){
							cond = true;
						}
					}
					// cond = (gt == 'Deal') ? playerInfo.Chips < bv : playerInfo.Chips < bv * config.MAX_DEADWOOD_PTS;
					

					
					if(cond){
						c('removeOnLowCash---if---if------>>>>');
						if(typeof playerInfo.sck == 'string' && playerInfo.sck != ''){

							var single = playerInfo.sck.replace(/s\d*_\d*./i,'');
						}
						else{
							var single = '';	
						}

						playClass.LT({flag:msg},{id:single,uid: px[iter].uid,_ir:px[iter]._ir,si:px[iter].si,tbid:tbId},function(check){
							c('removeOnLowCash----------->>>check: ',check);
							playClass.removeOnLowCash(tbId,bv,gt,px,rType,tst,rSeq,game_id,rr,pt,iter+1);
						});
					}
					else{
						c('removeOnLowCash---if--else------>>>>');
						playClass.removeOnLowCash(tbId,bv,gt,px,rType,tst,rSeq,game_id,rr,pt,iter+1);
					}
				}
				else{
					c('removeOnLowCash---else1--->>>>');
					playClass.removeOnLowCash(tbId,bv,gt,px,rType,tst,rSeq,game_id,rr,pt,iter+1);
				}
			});
			
		}
		else{
			cdClass.GetTbInfo(tbId,{},function(table1){
				if(table1){
					var players = playClass.getPlayingUserInRound(table1.pi);
					c('removeOnLowCash-- else-->>>>>>>players: ',players);
					if(players.length <= 0 && table1.stdP.length == 0 ){
						c('removeOnLowCash-------'+table1._id+'------>>>>"table deleted"');
						db.collection('playing_table').remove({_id: table1._id.toString()},function(){});
						db.collection('instant_table_invites').remove({tbid:table1._id.toString()},function(){});
						db.collection('table_invites').remove({tbid:table1._id.toString()},function(){});
						db.collection('last_deal').remove({tbid: table1._id},function(){});
						// db.collection('user_notification').remove({tbid:table1._id.toString()},function(){}); //remove all table invitation for this table
						// notiClass.deleteTableNoti(table1._id.toString());
					}
					else{
						/*var rcost = 0;
						db.collection('undo_data').findOne({turn:0},function(err,undoData){
							if(undoData && typeof undoData.coins != 'undefined'){
								rcost = undoData.coins;
							}*/

							c('removeOnLowCash-----else13131313----->>>>players: ',players);
							var pi = table1.pi;
							var ap = table1.ap;
							for(var x in pi){
								if(pi[x] && !_.isEmpty(pi[x]) && typeof pi[x].si != 'undefined'){

									if(pi[x].s == 'left'){			//remove left out player data from table
										pi[x] = {};
										ap--;
									}
									else{

										pi[x].s = '';
										pi[x].tCount = 0;
										pi[x].cards = [];
										// pi[x].dn = 0;
										pi[x]._iw = 0;
										pi[x].gCards = {};
										pi[x].dCards = {};
										pi[x].wc = 0;
										pi[x].pickCount = 0;
										pi[x].pts = 0;
										pi[x].ps = 0;
										pi[x].play = (table1.round < 2 && table1.gt == 'Deal' || table1.gt == 'Pool' && table1.tst == 'roundWinnerDeclared') ? pi[x].play : 0;
										pi[x].dps = (table1.round < 2 && table1.gt == 'Deal' || table1.gt == 'Pool' && table1.tst == 'roundWinnerDeclared') ? pi[x].dps : 0;  //only for deal and pool
										pi[x].bet = table1.bv;
										pi[x].isCollect = (table1.round < 2 && table1.gt == 'Deal' || table1.gt == 'Pool' && table1.tst == 'roundWinnerDeclared') ? pi[x].isCollect: 0; //isboot value collected or not
										pi[x].sort = true;
									}
								}
							}
							// var jobId = commonClass.GetRandomString(10);
							// var nxt = commonClass.AddTime(config.NXT);
							var round = (table1.round >= 2 && table1.gt == 'Deal' || table1.gt == 'Pool' && table1.tst == 'winnerDeclared') ? 0: table1.round; 
							// var game_id = (table1.round >= 2 && table1.gt == 'Deal' || table1.gt == 'Pool' && table1.tst == 'winnerDeclared') ? Math.floor(table1.game_id):table1.game_id;

							// var pv = (table1.round == 1 && table1.gt == 'Deal') ? table1.pv : 0;
							var pv = (round == 1 && table1.gt == 'Deal' || table1.gt == 'Pool' && round > 0) ? table1.pv : 0;

							var hist = [];
							if((table1.gt == 'Deal' || table1.gt == 'Pool') && round > 0){

								hist = table1.hist.filter(function(htData){
									if(htData.s == 'left'){
										return htData;
									}
								});
							}


							//var thp = (typeof table1.spcSi != 'undefined' && table1.spcSi != null && table1.spcSi != -1 && pi[table1.spcSi] && !_.isEmpty(pi[table1.spcSi]) && typeof pi[table1.spcSi].thp != 'undefined' && pi[table1.spcSi].thp != null) ? pi[table1.spcSi].thp : -1;
							// var spc = (typeof table1.spcSi != 'undefined' && table1.spcSi != null && table1.spcSi != -1 && pi[table1.spcSi] && !_.isEmpty(pi[table1.spcSi]) && typeof pi[table1.spcSi].spc != 'undefined' && pi[table1.spcSi].spc != null) ? pi[table1.spcSi].spc : -1;

							/*if(spc == config.FIRST_TIME_GAME_LIMIT){
								cdClass.updateWintrigger(pi[table1.spcSi].uid.toString(),1);
							}*/
							var RobotCount = table1.RobotCount;
							var HumanCount = table1.HumanCount;
							var minS = table1.minS;
							if(table1.gt == 'Deal'){
								minS = 2
							}
							else if(table1.gt == 'Pool'){
								minS = 3
							}
							else if(table1.gt == 'Bet'){
								minS = config.MIN_SEAT_TO_FILL_BET;
							}
							else{
								minS = config.MIN_SEAT_TO_FILL;
							}

							// console.log("removeOnLowCash-------------------------------thp"+spc); 
							// db.collection('first_time_journey').findOne({gameNo:spc+1},function(errr,ftjData){
							// 	if(ftjData){
							// 		RobotCount = 0;
							// 		HumanCount = 0;
									
							// 		HumanCount = (ftjData.Human)?ftjData.Human:0;

							// 		RobotCount += (ftjData.Newbie)?ftjData.Newbie:0;
							// 		RobotCount += (ftjData.Amateur)?ftjData.Amateur:0;
							// 		RobotCount += (ftjData.Pro)?ftjData.Pro:0;
							// 		RobotCount += (ftjData.God)?ftjData.God:0;

							// 		minS = RobotCount+1;
							// 	}
							// 	else{
									// if(spc != -1){
										var players = playClass.getPlayingUserInRound(table1.pi);
										var rCount = 0;
										for(var x in players){
											if(players[x]._ir == 1){
												rCount++;
											}
										}

										minS = rCount+1;
									// }
								// }
					
								console.log("removeOnLowCash-------------------------------minS"+minS); 
								/*var nrg = 0;
								if(table1.spcSi == -1){
									nrg = 0;
								}
								else{
									nrg = table1.nrg;
								}*/
								cdClass.UpdateTableData(table1._id.toString(),{$set:{rSeq:1,/*minS:minS,*/maxBet :0,bbv:table1.bv,_isWinner:0,_isLeave:0,tst:'',round:round/*,jid:jobId*/,ap:ap,pi:pi,pv:pv,wildCard: '',oDeck:[],declCount:0,playCount:0/*,dNum:0*/,cDeck: [],turn:-1,fnsPlayer:-1,ctt:new Date(),hist:hist,HumanCount:HumanCount,RobotCount:RobotCount}},function(table2){
									
									if(table2){

										playingTableClass.initializeGame(table2._id.toString());
									}
									else{
										c('removeOnLowCash-------1---->>>>>>Error:"table not found"');
									}	
								});
							// });
						// });
					}
				}
				else{
					c('removeOnLowCash---------2----------Error:"Table not found"');
				}
			});
		}
	}
}