module.exports = {
	FF:function (data,client){
		//invitable_friends 
		if(data.fid != '' && data.fid != null){
			var fData = new Object();
			FB.setAccessToken(data.fat);
			FB.api('/'+config.FB_API_V+'/me/invitable_friends', function (response) {
		  		if(!response || response.error){	
					response.lc = client.lc;
					commonClass.SendData(client,'FF',response,'error:1011');
				}
		  		else{
					var FriendArray = new Array();
					commonClass.SendData(client,'FF',response.data);
				}
			});
		}
		else{
			var response = {};
			response.lc = data.lc;
			commonClass.SendData(client,'FF',response,'error:1111');
		}
	},
	MSG : function(data,client){
		c('MSG---------------->>>"data: "',data);
	},
	sendTextMessage : function (sender, text) {
	    let messageData = { text:text }
	    
	    request({
	        url: 'https://graph.facebook.com/'+config.FB_INSTANT_API_V+'/me/messages',
	        qs: {access_token:config.FB_PAGE_ACCESS_TOKEN},
	        method: 'POST',
	        json: {
	            recipient: {id:sender},
	            message: messageData,
	        }
	    }, function(error, response, body) {
	        if (error) {
	            console.log('Error sending messages: ', error)
	        } else if (response.body.error) {
	            console.log('Error: ', response.body.error)
	        }else{
	            console.log('SuccessFully Send')
	        }
	    })
	},
	SaveFriendList:function (data){	
		/* +-------------------------------------------------------------------+
			desc:function to save fb friends
			i/p: data = {}, client = socket object
		+-------------------------------------------------------------------+ */
		//getting all facebook friends from user.
		c('SaveFriendList------------->>>>>>>data.un: '+data.un+' data.fid: '+data.fid+' data.fat: '+data.fat);
		FB.setAccessToken(data.fat);
		FB.api('/'+config.FB_API_V+'/me/friends', function (response) {
			c('SaveFriendList--------------->>>>>>>response: ',response);
			if(!response || response.error || typeof response == 'undefined' || typeof response.data == 'undefined'){
				c('SaveFriendList--------------->>>>>>>data.fat: '+data.fat);
				c('Save Friend List >> '+data.un +">>"+data.fid);
			}
			else{
			  
				var FriendArray = [];

				//preparing friends array who are playing with me
				for(var i in response.data){
					FriendArray.push(response.data[i].id);
				}
				
				c('SaveFriendList----------->>>>>>FriendArray: ',FriendArray);


				//first we have to find _id for registered users.
				
				db.collection("game_users").distinct("_id",{ fid : { $in : FriendArray }}, function(err, fndInfo){ 

					c('SaveFriendList------------->>>>>fndInfo: ',fndInfo);

					db.collection("user_friends").update({_id : data._id},{$set:{uid:data._id},$addToSet : {friends:{$each:fndInfo}}},{upsert:true,multi:true},function(){});
					db.collection("user_friends").update({ _id : { $in : fndInfo}}, { $addToSet : { friends : data._id }},{multi: true}, function(){ });

				});

				// adding current user to all of his friends list.
				// 	//add for remove buddy
				// 	db.collection("game_users").update({ _id : { $in : friends}}, { $addToSet : { Ffriends : data._id }},{multi: true}, function(){ });

				// 	//updating friends to user other information table
				// 	db.collection('game_users').findAndModify({_id: data._id},{},{ $addToSet: { friends: { $each : friends }} },{new : true},function(err, nObj) { 
				// 		//updating friends counter for current user.
				// 		db.collection("game_users").update({_id: data._id },{ $set : { "counters.fc" : nObj.friends.length , "counters.ffc":FriendArray.length }},function(){ });
				// 	});
				// });				  
			}
		});
	},
	saveGoogleFriends:function (data){
		var plus = google.plus('v1');
        var OAuth2 = google.auth.OAuth2;
        var oauth2Client = new OAuth2(config.GOOGLE_CLIENT_ID, config.GOOGLE_CLIENT_SECRET);
         
        // Retrieve tokens via token exchange explained above or set them: 
        oauth2Client.setCredentials({
            access_token: userData.oft,
            refresh_token: userData.oft
        });
         
        plus.people.list({ userId: 'me', auth: oauth2Client, 'collection' : 'visible' }, function(err, response) {
            if (err) {
                c("err", err);
            } else {
            	var FriendArray = [];
            	var googleFriends = response.items;
				//preparing friends array who are playing with me
				for(var i in googleFriends){
					FriendArray.push(googleFriends[i].id);
				}
				
				c('SaveFriendList----------->>>>>>FriendArray: ',FriendArray);


				//first we have to find _id for registered users.
				
				db.collection("game_users").distinct("_id",{ fid : { $in : FriendArray }}, function(err, fndInfo){ 

					c('SaveFriendList------------->>>>>fndInfo: ',fndInfo);

					db.collection("user_friends").update({_id : data._id},{$set:{uid:data._id},$addToSet : {friends:{$each:fndInfo}}},{upsert:true,multi:true},function(){});
					db.collection("user_friends").update({ _id : { $in : fndInfo}}, { $addToSet : { friends : data._id }},{multi: true}, function(){ });

				});
            }
        });
	},
	deletePendingRequest:function(reqid,tk){
		FB.setAccessToken(tk);
		FB.api('/'+config.FB_API_V+'/'+reqid,'delete',function(response) {  c(response); })
	}
}