module.exports = {
	FTAJC :function(data,client){  //find table and join; data = {bv}
		/* +-------------------------------------------------------------------+
            desc:event to find classic table and join 
            i/p: data = {bv = bot value},client = socket object
        +-------------------------------------------------------------------+ */
		c('FTAJC------>>>>client.uid: ',client.uid,' data: ',data);
		cdClass.GetUserInfo(client.uid,{cash:1},function(userInfo){
			if(userInfo){
				if(typeof data.bv != 'undefined' && data.bv != null && data.bv > 0){

					if(userInfo.cash >= data.bv*config.MAX_DEADWOOD_PTS){
						data.cash = userInfo.cash;
						data.bv = parseInt(data.bv);
						data.mode = 'cash';
						playingTableClass.findTableAndJoin(data,client,0);
					}
					else{
						var reqChips = data.bv*config.MAX_DEADWOOD_PTS;
						commonClass.SendData(client,'PUP', {chips:data.bv*config.MAX_DEADWOOD_PTS,flag:'noCash',reqChips:reqChips},'error:1020');  //Don't have sufficient chips
						// strClass.outOfChipsPop(client,{chips:data.bv*config.MAX_DEADWOOD_PTS,flag:'noChips',reqChips:reqChips});
					}
				}
				else{
					db.collection('playing_category').find({lBound:{$lte:userInfo.cash}}).sort({cpp:-1}).toArray(function(err,category){
						if(category.length > 0 && category[0].cpp*config.MAX_DEADWOOD_PTS <= userInfo.cash){
							playingTableClass.findTableAndJoin({bv:category[0].cpp,chips: userInfo.cash,mode: 'cash'},client,0);  //player seats on higher boot value
						}
						else{
							c('\nFTAJC----else----------->>>>>');

							db.collection('playing_category').find({}).sort({cpp:1}).toArray(function(err,category1){

								if(category1 && category1.length > 0){
									var reqChips = category1[0].lBound;
								}	
								else{
									var reqChips = 0;
								}
								commonClass.SendData(client,'PUP', {flag:'noChips',reqChips:reqChips},'error:1020');  //Don't have sufficient chips
								// strClass.outOfChipsPop(client,{flag:'noChips',reqChips:reqChips});
							});

						}
					});
				}
			} 
			else{
				c('FTAJ:::::::::::::::::::::::>>>>>>Error: "user not found!!!"');
			}
		});
	},
	findTableAndJoinCash : function (data, client, fCount) { // : data = {gt,pCount,reke,bv,chips} ; table finding function    //reke and pCount iff gt == Deal or Pool
		/* +-------------------------------------------------------------------+
            desc:generic function to find table for user 
            i/p: data = {gt = game type,pCount = max player count,reke = reke to cut if any,bv = boot value of table,chips = chips of user}
        +-------------------------------------------------------------------+ */
		playingTableClass.findTableExistence(client,false,function(check){

			c('findTableAndJoin--------------->>>>>>check: '+check);

			if(check == 1){


					if(data.gt && data.gt == 'Deal'){ //if user want to play deal rummy
						/*if(isSpc){
							c('\nfindTableAndJoin-------deal------>>>>"first timer user"');
							playClass.generateTable({bv:data.bv,repick:1,pCount:data.pCount,reke:data.reke,gt:'Deal'},function(tbInfo){
								//join table logic here 
								playingTableClass.joinSeat(tbInfo._id.toString(),client);
							});
						}*/
						// else{

							var where = {
								$and:[
									{
										_ip:{$ne:1},
										bv: data.bv,
										gt:'Deal',
										ap:{$lt:data.pCount},
										ms: data.pCount,
										'pi.uid':{$ne:client.uid},
										'stdP.uid':{$ne:client.uid},
										tst: {
											$in:["","RoundTimerStarted"]
										},
										round:0
									}/*,
									{
										$or:[
											{
												spcSi:{$ne:-1},
												$where : 'this.uCount < this.HumanCount+1'
											},
											{
												spcSi:-1
											}
										]
									}*/		
								]
							};
							db.collection('playing_table').find(where).limit(10).toArray(function(err,resp){
								if(resp.length > 0){  //user found appropriate table
									//join table logic here
									playingTableClass.joinSeat(resp[0]._id.toString(),client);
								}
								else{
									//table generate logic here


									playClass.generateTable({bv:data.bv,repick:1,pCount:data.pCount,reke:data.reke,gt:'Deal'},function(tbInfo){
										//join table logic here 
										playingTableClass.joinSeat(tbInfo._id.toString(),client);
									});
								}
							});
						// }
					}	
					else if(data.gt && data.gt == 'Pool'){//if user wants to play pool rummy

						/*if(isSpc){
							c('\nfindTableAndJoin------pool------->>>>>"first time user"');
							playClass.generateTable({bv:data.bv,repick:1,pCount:data.pCount,reke:data.reke,gt:'Pool'},function(tbInfo){
								///join table logic here 
								playingTableClass.joinSeat(tbInfo._id.toString(),client);
							});
						}*/
						// else{

							var where = {
								$and:[
									{
										_ip:{$ne:1},
										bv:data.bv,
										gt:'Pool',
										ap:{$lt:data.pCount},
										ms:data.pCount,
										'pi.uid':{$ne:client.uid},
										'stdP.uid':{$ne:client.uid},
										tst:{
											$in:["","RoundTimerStarted"]
										},
										round:0
									}/*,
									{
										$or:[
											{
												spcSi:{$ne:-1},
												$where : 'this.uCount < this.HumanCount+1'
											},
											{
												spcSi:-1
											}
										]
									}*/	
								]
							};
							db.collection('playing_table').find(where).limit(10).toArray(function(err,resp){
								if(resp.length > 0){ //user found appropriate table
									//join table logic here
									playingTableClass.joinSeat(resp[0]._id.toString(),client);
								}
								else{
									//table generate logic here

									playClass.generateTable({bv:data.bv,repick:1,pCount:data.pCount,reke:data.reke,gt:'Pool'},function(tbInfo){
										///join table logic here 
										playingTableClass.joinSeat(tbInfo._id.toString(),client);
									});
								}
							});
						// }
					}
					else if(data.gt && data.gt == 'Bet'){ //if user wants to play bet rummy

						/*if(isSpc){
							c('\nfindTableAndJoin-------bet------>>>>>"first time user"');
							playClass.generateTable({bv:data.bv,gt:'Bet'},function(tbInfo){
								c('\nfindTableAndJoin----else----------->>>>>>');
								playingTableClass.joinSeat(tbInfo._id.toString(),client);
							});
						}*/
						// else{

							if(data.tbid){
								var where = {
									$and:[
										{
											_ip:{$ne:1},
											bv:data.bv,
											gt:'Bet',
											_id:{$ne:MongoID(data.tbid)},
											ap:{$lt:5},
											'pi.uid':{$ne:client.uid},
											'stdP.uid':{$ne:client.uid},
											tst:{
												$in:["", "RoundTimerStarted"]
											}
										}/*,
										{
											$or:[
												{
													spcSi:{$ne:-1},
													$where : 'this.uCount < this.HumanCount+1'
												},
												{
													spcSi:-1
												}
											]
										}*/
									]
								};
							}
							else{
								var where = {
									$and:[
										{
											_ip:{$ne:1},
											bv:data.bv,
											gt:'Bet',
											ap:{$lt:5},
											'pi.uid':{$ne:client.uid},
											'stdP.uid':{$ne:client.uid}, 
											tst:{
												$in: ["", "RoundTimerStarted"]
											}
										}/*,
										{
											$or:[
												{
													spcSi:{$ne:-1},
													$where : 'this.uCount < this.HumanCount'
												},
												{
													spcSi:-1
												}
											]
										}*/
									]
								}
							}

							db.collection('playing_table').find(where).toArray(function(err,resp){
								if(resp.length > 0){ //user found appropriate
									c('\nfindTableAndJoin----if---->>>>>');
									playingTableClass.joinSeat(resp[0]._id.toString(),client);
								}
								else{
									//table generate logic here
									playClass.generateTable({bv:data.bv,gt:'Bet'},function(tbInfo){
										c('\nfindTableAndJoin----else----------->>>>>>');
										playingTableClass.joinSeat(tbInfo._id.toString(),client);
									});
								}
							});
						// }
					}
					else{
				
							if(data.tbid){

								var where = {
									$and:[
										{
											_ip:{$ne:1},
											mode:'cash',
											bv:data.bv,
											gt:'Classic',
											_id: {$ne:MongoID(data.tbid)}, 
											ap:{$lt:5},
											'pi.uid':{$ne:client.uid},
											'stdP.uid':{$ne:client.uid}, 
											tst:{
												$in: ["", "RoundTimerStarted"]
											}
										}
									]
								}
							}
							else{
								var where = {
									$and:[
										{
											_ip:{$ne:1},
											mode:'cash',
											bv:data.bv,
											gt:'Classic',
											ap:{$lt:5},
											'pi.uid':{$ne:client.uid},
											'stdP.uid':{$ne:client.uid}, 
											tst:{
												$in: ["", "RoundTimerStarted"]
											}
										}
									]
								};
							}
							c('\n findTableAndJoin------------------>>>>>>where: ',where);
							db.collection('playing_table').find(where).toArray(function(err,resp){
								if(resp && resp.length > 0 ){    //user found appropriate table to play
									c('\nfindTableAndJoin----if----->>>>>');
									playingTableClass.joinSeat(resp[0]._id.toString(),client);
								}
								else{ 
									//no table found
		                            c('\nfindTableAndJoin------------->>>>>>>>>"create a new table with the same specs"');

		                            
		                            if (config.PLAYING_CATEGORIES) {
		                                c('\nfindTableAndJoin------------->>>>>>"PLAYING_CATEGORIES is enabled"');
		                                playClass.generateTable({
		                                    bv: data.bv,
		                                    mode: 'cash'
		                                }, function(tbInfo) {
		                                    c('\nfindTableAndJoin----else----------->>>>>>');
		                                    playingTableClass.joinSeat(tbInfo._id.toString(), client);
		                                });
		                            }

		                            //so check the category one step down
		                            else if(typeof fCount != 'undefined' && fCount != null && fCount < config.FIND_TABLE_ATTEMPT){  //table find attempt remains
										db.collection('playing_category').find({cpp:{$lt:data.bv}}).sort({cpp:-1}).toArray(function(err,catData){
											if(catData.length > 0){   //if category left then find the table of that category
												playingTableClass.findTableAndJoin({bv:catData[0].cpp,chips:data.chips,tbid:data.tbid},client,fCount+1);
											}
											else{  //no category left so generate table as per the original chips per point
												c('findTableAndJoin---------->>>>>>data.chips: ',data.chips);
												db.collection('playing_category').find({lBound:{$lte:data.chips}}).sort({cpp:-1}).toArray(function(err1,catData1){
													c('findTableAndJoin------------>>>>catData1: ',catData1);
													if(catData1 && catData1.length > 0 && catData1[0].cpp*config.MAX_DEADWOOD_PTS <= data.chips){

														playClass.generateTable({bv:catData1[0].cpp,mode:'cash'},function(tbInfo){
															c('\nfindTableAndJoin----else----->>>>>');
															playingTableClass.joinSeat(tbInfo._id.toString(),client);
														});
													}
													else{
														c('\nfindTableAndJoin--------if------>>>>no sufficient chips');
														var reqChips = catData1[0].cpp*config.MAX_DEADWOOD_PTS ;
														commonClass.SendData(client,'PUP', {flag:'noChips',reqChips:reqChips},'error:1020');  //Don't have sufficient chips
														// strClass.outOfChipsPop(client,{flag:'noChips',reqChips:reqChips});
													}
												});
											}
										});
									}
									else{   //table attempt finish so generate table as per original chips per point

										db.collection('playing_category').find({lBound:{$lte:data.chips}}).sort({cpp:-1}).toArray(function(err1,catData1){
											c('findTableAndJoin---------->>>>>catData1: ',catData1);
											if(catData1 && catData1.length > 0 && catData1[0].cpp*config.MAX_DEADWOOD_PTS <= data.chips){

												playClass.generateTable({bv:catData1[0].cpp,mode:'cash'},function(tbInfo){
													c('\nfindTableAndJoin----else----->>>>>');
													playingTableClass.joinSeat(tbInfo._id.toString(),client);
												});
											}
											else{
												c('\nfindTableAndJoin----else------------->>>>>no chips');
												var reqChips = catData1[0].cpp*config.MAX_DEADWOOD_PTS;
												commonClass.SendData(client,'PUP', {flag:'noChips',reqChips:reqChips},'error:1020');  //Don't have sufficient chips
												// strClass.outOfChipsPop(client,{flag:'noChips',reqChips:reqChips});
											}
										});
									}
									
								}
							});
                        //}
					}
				//});
			}
			else{
				c('findTableAndJoin------------------>>>>>>table can\'t be join');
			}
		});
		// db.collection('playing_table').find({bv:data.bv,ap:{$lt:4},tst:{$in:['','RoundTimerStarted']}}).limit(5).toArray(function(err,resp){
	}	
}