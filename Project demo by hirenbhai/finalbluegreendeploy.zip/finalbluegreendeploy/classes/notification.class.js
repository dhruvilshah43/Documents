module.exports = {

	NRC : function(data){  //notification receiver counter; data = {uid}
		/* +-------------------------------------------------------------------+
			desc:event to send notification counter
			i/p: data = {uid = user id}
			o/p: NRC event : data = {count = notification counter unread notification}
		+-------------------------------------------------------------------+ */
		db.collection('user_notification').find({recvId:data.uid,isRead:0}).count(function(err,notiCount){
			commonClass.SendDirect(data.uid,{en:'NRC',data:{count:notiCount}}, true);
		});
	}
}