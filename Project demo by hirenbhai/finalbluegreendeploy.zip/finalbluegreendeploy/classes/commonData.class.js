module.exports = {
	PrepareDataCodes: function(cb) {
        /* +-------------------------------------------------------------------+
            desc: this function is use to refresh the datacode for popup.
        +-------------------------------------------------------------------+ */

        c('PrepareDataCodes---------------->>>>>>>');
        db.collection('data_codes').find().toArray(function(err, codes) {
            dataCodesArr = [];
            for (var e in codes){

                for (var f in codes[e]['Messages']){
                	
                    var obj = {Title: codes[e]['Messages'][f].Title, Message: codes[e]['Messages'][f].Message,Lc:codes[e]['Messages'][f].LanguageCode};
                    dataCodesArr[codes[e]['Messages'][f].LanguageCode + ":" + codes[e]['codeType'] + ":" + codes[e]['code']] = obj;
                }
                delete obj;
            }
            if(typeof cb == 'function'){

                cb();
            }

        });
    },
    PrepareScoreData:function(cb){
        /* +-------------------------------------------------------------------+
            desc: this function is use to initialize score data
        +-------------------------------------------------------------------+ */
        // c('PrepareScoreData-------------->>>>>>>>');
        db.collection('user_scores').find({}).project({_id:0}).sort({from:-1}).toArray(function(err,scores){
            CWIN = [];
            CLOSS = [];
            DSI = [];
            CBAL = [];
            CPP = [];
            NDUC = [];
            var i,cwin = [],closs = [],dsi = [],cbal = [],cpp = [],nduc = [];

            for(i in scores){
                switch(scores[i].type){
                    case 'CWIN': delete scores[i].type;
                                 cwin.push(scores[i]);
                                 break;
                    case 'CLOSS': delete scores[i].type;
                                 closs.push(scores[i]);
                                 break;
                    case 'DSI':  delete scores[i].type;
                                 dsi.push(scores[i]);
                                 break;
                    case 'CBAL': delete scores[i].type;
                                 cbal.push(scores[i]);
                                 break;
                    case 'CPP':  delete scores[i].type;
                                 cpp.push(scores[i]);
                                 break;
                    case 'NDUC': delete scores[i].type;
                                 nduc.push(scores[i]);
                                 break;                                                                                                   
                }
               
            }
            CWIN = cwin;
            CLOSS = closs;
            DSI = dsi;
            CBAL = cbal;
            CPP = cpp;
            NDUC = nduc;
            // c('CWIN: ',CWIN,' \nCLOSS: ',CLOSS,' \nDSI: ',DSI,' \nCBAL: ',CBAL,' \nCPP: ',CPP,' \nNDUC: ',NDUC);
            if(typeof cb == 'function'){

                cb();
            }
        });
    },
    PrepareFeatureData: function (cb) {
        /* +-------------------------------------------------------------------+
            desc:this function is use to on/off the dashboard button by refreshing button data.
        +-------------------------------------------------------------------+ */

        db.collection('feature_roll_feedback').find({}).toArray(function(err,action){
            CLASSIC_BTN = 0;
            DEAL_BTN = 0;
            POOL_BTN = 0;
            BET_BTN = 0;

            for(var i in action){

                eval(action[i].key+' = (action[i].action == 1)? 1:0');

            }
            c('PrepareFeatureData--------->>>>>>>>\nCLASSIC_BTN'+ CLASSIC_BTN+'\nDEAL_BTN: '+ DEAL_BTN + '\nPOOL_BTN: ' + POOL_BTN + '\nBET_BTN: '+BET_BTN);
            if(typeof cb == 'function'){
                cb();
            }
        });
    },
    PrepareRCData:function(cb){
        /* +-------------------------------------------------------------------+
            desc: this function is use to initialize robot card data
        +-------------------------------------------------------------------+ */
        db.collection('robot_cards').find({}).project({cType:0}).toArray(function(err,resp){
            if(resp.length > 0){

                var rCards = {
                    Newbie : {
                        PURE:{},
                        SEQS:{},
                        SETS:{},
                        JW:{},
                        CSEQS:{},
                        CSETS:{}
                    },
                    Amateur : {
                        PURE:{},
                        SEQS:{},
                        SETS:{},
                        JW:{},
                        CSEQS:{},
                        CSETS:{}
                    },
                    Pro : {
                        PURE:{},
                        SEQS:{},
                        SETS:{},
                        JW:{},
                        CSEQS:{},
                        CSETS:{}
                    },
                    God : {
                        PURE:{},
                        SEQS:{},
                        SETS:{},
                        JW:{},
                        CSEQS:{},
                        CSETS:{}
                    }

                };
               
                for(var i in resp){
                    
                    eval('rCards.'+resp[i].rType+'.'+resp[i].key+' = {nos0:resp[i].nos0,nos1:resp[i].nos1,nos2:resp[i].nos2,nos3:resp[i].nos3}');
                }
                RCARDS = rCards;
                // c('PrepareRCData------------->>>>>> RCARDS : ',RCARDS);
            }
            else{
                c('PrepareRCData::::::::::::::::>>>>>>Error:"data not found!!!"');
            }
            if(typeof cb == 'function'){
                cb();
            }
        });
    },
    PreparePlayData:function(cb){
        /* +-------------------------------------------------------------------+
            desc: this function is use to initialize robot playing data
        +-------------------------------------------------------------------+ */
        db.collection('robot_play').find({}).toArray(function(err,resp){
            if(resp.length > 0){

                var rPlay = {
                    PICK: {
                        Newbie : {},
                        Amateur :{},
                        Pro :{},
                        God :{}
                    },
                    DISCARD:{
                        Newbie : {},
                        Amateur :{},
                        Pro :{},
                        God :{} 
                    }
                };
                for(var i in resp){
                  
                    eval('rPlay.'+resp[i].action+'.'+resp[i].rType+' = {logic1:resp[i].logic1,logic2:resp[i].logic2,logic3:resp[i].logic3}');
                    
                }
                RPLAY = rPlay;
                // c('PreparePlayData-------------->>>>> RPLAY: ',RPLAY);
            }
            else{
                c('PreparePlayData::::::::::::::::::::::::>>>>>Error:"data not found!!!"');
            }
            if(typeof cb == 'function'){
                cb();
            }
        });
    },
    PrepareDropData:function(cb){
        /* +-------------------------------------------------------------------+
            desc: this function is use to initialize robot drop data
        +-------------------------------------------------------------------+ */ 
        db.collection('robot_drop').find({}).toArray(function(err,resp){
            if(resp.length > 0){
                var rDrop = {
                    first:{
                        Newbie : {},
                        Amateur :{},
                        Pro :{},
                        God :{},
                        logic1:{},
                        logic2:{}
                    },
                    middle:{
                        Newbie : {},
                        Amateur :{},
                        Pro :{},
                        God :{},
                        logic1:{},
                        logic2:{}
                    }
                }
                for(var i in resp){
                    var pts=(typeof resp[i].pts != 'undefined')? ',pts:resp[i].pts':'';

                    if(resp[i].dType == 'logic'){
                        eval('rDrop.'+resp[i].dropType+'.'+resp[i].rType+' = {logic1:resp[i].logic1,logic2:resp[i].logic2}');
                    }
                    else if(resp[i].dType == 'proc'){
                        if(resp[i].logicN == 1){
                            eval('rDrop.'+resp[i].dropType+'.logic1= {base:resp[i].base,pures:resp[i].pures,seqs:resp[i].seqs,sets:resp[i].sets}');
                        }
                        else{
                            eval('rDrop.'+resp[i].dropType+'.logic2 = {base:resp[i].base,pures:resp[i].pures,seqs:resp[i].seqs,sets:resp[i].sets,jw:resp[i].jw,cSeqs:resp[i].cSeqs,cSets:resp[i].cSets'+pts+'}');
                        }
                    }         
                }
                RDROP = rDrop;
                // c('PreparedropData-------------->>>>> RDROP: ',RDROP);
            }
            else{
                c('PrepareDropData::::::::::::::::::::::::>>>>>Error:"data not found!!!"')
            }
            if(typeof cb == 'function'){
                cb();
            }
        });
    },
    UpdateUserData: function (uid, uData, callback) {
        /* +-------------------------------------------------------------------+
            desc:this function use to update the user data.
            i/p:userid,fields to update
            o/p:updated value
        +-------------------------------------------------------------------+ */
        c('UpdateUserData---------->>>>uid: '+uid+' uData: ',uData);
        if(!uid || uid == ''){
            c('UpdateUserData:::::::::::::>>>>>>Error: "user data not found"');
            return false;
        }
        uid = uid.toString();
        
        if(uid.length < 24){
            c('UpdateUserData:::::::::::::>>>>Error: "string length less than 24"');
            return false;
        }
        //adding default time
        if (!uData){
            c('UpdateUserData:::::::::::::::>>>>upData data not found');
            return false;
        }

        db.collection('game_users').findAndModify({_id:MongoID(uid)},{},uData,{new:true} ,function (err,resp) {

            if(err){
                c('UpdateUserData::::::::::>>>>err: ',err);
            }
            if (typeof callback == 'function' && resp){
                return callback(resp.value);
            }
        });
    },
    GetUserInfo:  function(id, fields, callback) {
        /* +-------------------------------------------------------------------+
            desc:this function use to get the user data.
            i/p:userid,fields
            o/p:userdata
        +-------------------------------------------------------------------+ */
        c('GetUserInfo---------->>>id: ',id,' fields: ',fields);
        if (typeof fields == 'function'){

            callback = fields;
            fields = {};
        }
        if(!id){
            c('GetUserInfo::::::::fields: ',fields,':::::::::>>>>>>Error: "id not found!!!" '+new Date());
            
            return false;
        }
        id = id.toString();
		if(typeof id != 'string' || id.length < 24){
            c('GetUserInfo:::'+id+':::::fields: ',fields,':::::::::>>>>id not valid '+new Date());
			//callback();
            return;
		}
		
		
		db.collection('game_users').findOne({_id: MongoID(id)},{fields:fields},function(err, res) {
            // c('GetUserInfo---------->>>>>>res: ',res);
			if (!err && res){
				callback(res);
			}
			else{
                c('GetUserInfo-------'+id+'------fields: ',fields,' --->>>>>error: ',err,' '+new Date());
				//callback();
			}
			
			// res = null;	
		});
    },
    GetTbInfo: function(id, fields, callback) {
        /* +-------------------------------------------------------------------+
            desc:this function use to get table data.
            i/p:table id,fields 
            o/p:table data
        +-------------------------------------------------------------------+ */
        if(!id){
            console.log('GetTbInfo::::::::',fields,'::::::::>>>>Error: "id not found!!!" '+new Date());
            console.trace('GetTbInfo1');
            callback();
            return false;
        }
        if (typeof fields == 'function'){

            callback = fields;
            fields = {};
        }
		id = id.toString();
		if(typeof id != 'string' || id.length < 24){
            console.log('GetTbInfo::::'+id+':::::fields: ',fields,'::::::::>>>>Error: "id not valid!!!" '+new Date());
            console.trace('GetTbInfo2');
			callback();
		}
		
		db.collection('playing_table').findOne({_id: MongoID(id)},{fields:fields},function(err, res) {
            

            if(err){
                console.log('GetTbInfo::::'+id+':::::fields: ',fields,'::::::::>>>>Error: ',err,' '+new Date());
                callback();
            }
            else if(res){
                callback(res);
            }
			else{
                console.log('GetTbInfo::::'+id+':::::fields: ',fields,'::::::::>>>>Error: "data not found!!!" '+new Date());
				callback();
			}
		});
    },
    UpdateTableData: function(tbid, uData, callback) {
        /* +-------------------------------------------------------------------+
            desc:this function use to update the table data.
            i/p:table id,fields to update
            o/p:updated data
        +-------------------------------------------------------------------+ */
        if(!tbid){
            console.log('UpdateTableData-------uData: ',uData,'----->>>>>Error:"tbid not found" '+new Date());
            console.trace('UpdateTableData');
            if(typeof callback == 'function'){
                callback();
            }
            return false;
        }
        tbid = tbid.toString();

        //adding default time
		if(!uData.$set){
	        uData.$set = { la :  new Date(),ctrlServer:SERVER_ID };
		}
		else{
			uData.$set.la = new Date();
            uData.$set.ctrlServer = SERVER_ID;
		}
		where = {_id: MongoID(tbid)};	
        db.collection('playing_table').findAndModify(where,{}, uData,{new:true} ,function(err,resp) {
            if(err){
                console.log('UpdateTableData::::tbid: '+tbid+'::::::where: ',where,' ::::\nuData: ',uData,':::::::>>>Error: ',err,' '+new Date());
                return false;
            }
            // if(typeof resp == 'undefined' || resp == null || resp.value == null){
            //     c('UpdateTableData---------->>>>>Error:"table not found"');
            //     return false;
            // }
			if (typeof callback == 'function'){
                if(resp && resp.value){

                    callback(resp.value);
                }
                else{
                    callback();
                }
			}
				
        });
    },
    UpdateUserChips: function(id, Chips, t, callback) {
        /* +-------------------------------------------------------------------+
            desc:this function use to update the user chips.
            i/p:userid,chips,t:status
            o/p:updated user chips
        +-------------------------------------------------------------------+ */
		c('UpdateUserChips-->>>id: ',id,' chips: ',Chips,' t: ',t);
        if(!id){
            c('UpdateUserChips---------->>>>Error:"id not found!!!"');
            return false;
        }
        id = id.toString();
		
		
		cdClass.GetUserInfo(id, { Chips : 1,wc : 1 ,totalcash:1,"counters.hcl" : 1,"counters.mcw":1,  un : 1, sck : 1, "flags._ir" : 1 ,league:1,tbid:1}, function(userInfo){ 
			if( userInfo && userInfo._id){
                var playWinTxt = ['Won Mini Game','Card Drop Deduction','Table Leave Deduction','Collect Boot Value','Game Lost','Game Win','Game Draw','CB Game Win'];

                
                var fChips = ((Chips + userInfo.Chips) < 0) ? 0 : (Chips + userInfo.Chips); 
                var wChips = (_.contains(playWinTxt,t)) ? Chips + userInfo.wc: userInfo.wc;
                var mwChips = (Chips > userInfo.counters.mcw && _.contains(playWinTxt,t)) ? Chips: userInfo.counters.mcw; 
                
                if(userInfo.flags._ir == 0){

				    trackClass.Chips_Track(userInfo,Chips,t);
                }
                else{
                    //trackClass.Robot_Chips_Track(userInfo,Chips,t);
                }

                // c('UpdateUserChips---------->>>>fChips: ',fChips);
                var setInfo = {};
                setInfo.$set = {};
               
                
				if(userInfo.counters.hcl < fChips){
					setInfo.$set["counters.hcl"] =   fChips ;
                }
                 setInfo.$set["wc"] = wChips;
				 setInfo.$set["Chips"] = fChips;
                 setInfo.$set["counters.mcw"] = mwChips;

               


                 // c('UpdateUserChips------->>>setInfo: ',setInfo);
				
                 if(Chips > 0){
                    setInfo.$set['flags._freeSpinNoti'] = 0;
                 }

				db.collection('game_users').update({_id:MongoID(id)},setInfo, function(err,resp){

                    //c('sending data to '+userInfo.un);
                    if(userInfo.flags._ir == 0){

                        commonClass.SendDirect(userInfo._id, {en : "UC" , data :{ Chips :  fChips, totalCash : userInfo.totalcash , t:t}},true); //publishing to exchange
                    }
                    if(userInfo.tbid != ''){

                        db.collection('playing_table').update({_id:MongoID(userInfo.tbid),'pi.uid':userInfo._id.toString()},{$set:{'pi.$.Chips':fChips}});


                        //*****************table chips update code*************

                        db.collection('playing_table').findOne({_id:MongoID(userInfo.tbid),'pi.uid':userInfo._id.toString()},{fields:{'pi.$':1}},function(err1,resp1){
                            if(resp1){
                                c('UpdateUserChips------------------->>>>>resp1: ',resp1);

                                if(resp1.pi && resp1.pi.length > 0 && typeof resp1.pi[0].si != 'undefined'){
                                    commonClass.FireEventToTable(userInfo.tbid,{en:'UTC',data:{si:resp1.pi[0].si,chips:fChips,totalCash:userInfo.totalcash,reason:t}});
                                }
                            }
                        });

                        //******************code ends here********************
                    }   

    				if(typeof callback == 'function'){
    				 	callback(fChips);	
                    }
                });
                
			}
			else if(typeof callback == 'function'){
				callback(0);	
            }
		});
    },
    UpdateUserCash: function (id, chips, t, callback) {
        // var opoid=(typeof opid != 'undefined')?opid.toString():"";
        if(isNaN(chips)){
            if (typeof callback == 'function'){
                return callback(0);
            }else{
                return false;
            }
        }

        var wh = (typeof id == 'string') ? {
            _id: MongoID(id)
        } : {
            _id: id
        };

        chips = Math.floor(Number(chips));
        cdClass.GetUserInfo(wh._id.toString(), {
            "totalcash": 1,
            "bonuscash":1,
            "depositcash":1,
            "wincash":1,
            "un": 1,
            "sck": 1,
            "ue":1,
            "flags":1
        }, function (u) {
            if (typeof u._id != 'undefined') {

                var setInfo = {
                    $inc:{}
                };


                if(t == "Referral Bonus" || t == "Invite Friend Bonus")
                {   
                   setInfo["$inc"]["bonuscash"]=chips;
                   setInfo["$inc"]["totalcash"]=chips;

                   casetype = 1;
                }else if(t == "Withdraw Money" || t == "Withdraw Money Rejected"){

                    setInfo["$inc"]["wincash"]=chips; 
                    setInfo["$inc"]["totalcash"]=chips;
                    casetype = 2;
                    c("Withdraw Money Withdraw Money Withdraw Money")

                }else if(t == "Deposit Money"){

                    setInfo["$inc"]["depositcash"]=chips; 
                    setInfo["$inc"]["totalcash"]=chips;
                    casetype = 3;                    
                    c("depositcash depositcash depositcash")
                    
                }else if(t == "Extra Cash"){
                    
                    setInfo["$inc"]["depositcash"]=chips/2;
                    setInfo["$inc"]["wincash"]=chips/2;
                    setInfo["$inc"]["totalcash"]=chips;
                    casetype = 3;

                }else if(t == "Refund Money"){

                    setInfo["$inc"]["depositcash"]=chips; 
                    setInfo["$inc"]["totalcash"]=chips;
                    casetype = 3;                    
                    c("depositcash depositcash depositcash")
                    
                }else if(t == 'Game Win' || t == 'Game Draw'){
                    
                    setInfo["$inc"]["wincash"]=chips;
                    setInfo["$inc"]["totalcash"]=chips;
                    casetype = 2;
                    c("wincash wincash wincash")

                } else {
                    c("else else ")
                }
                /*var ftotalcash = ((chips + u.totalcash) < 0) ? 0 : chips + u.totalcash;
                var setInfo = {
                    $set: {
                        totalcash: ftotalcash
                    }
                };*/

                //wh.totalcash = u.totalcash;
                db.collection('game_users').findAndModify(wh,{}, setInfo, {new:true}, function (err,resp) {
                    if(!err && resp.value != null) {
                        if(u.flags._ir == 0){

                            var insertData = {
                                c: chips,
                                pc: u.totalcash,
                                bc: (casetype == 1)?chips:0,
                                dc:(casetype == 3)?chips:0,
                                wc:(casetype == 2)?chips:0,
                                tp: t,
                                pbc: u.bonuscash, //past supercash
                                pdc: u.depositcash, //past depoist case
                                pwc: u.wincash, //past win case
                                csc: resp.value.supercash, //cunrent supercash
                                cdc: resp.value.depositcash, //cunrent depoist case
                                cwc: resp.value.wincash, //cunrent win case
                                uid: MongoID(u._id.toString()),
                                un: u.un,
                                ue:u.ue
                            };

                            trackClass.Cash_Track(insertData);
                        }

                        var tcash = u.totalcash + chips;
                        c("UpdateUserCash--::::::::::::::::::>>>>>>>>>>")
                        commonClass.SendDirect(u.sck, {
                            en: "UC",
                            data: {
                                "cash":tcash,
                                "Chips":resp.value.Chips,
                                "bonuscash":resp.value.bonuscash,
                                "depositcash":resp.value.depositcash,
                                "wincash":resp.value.wincash,
                                "totalCash":tcash,
                                tp: t
                            }
                        }); //publishing to exchange
                        
                        if(resp.value.tbid != ''){

                            db.collection('playing_table').update({_id:MongoID(resp.value.tbid),'pi.uid':resp.value._id.toString()},{$set:{'pi.$.totalCash':tcash}});


                            //*****************table chips update code*************

                            db.collection('playing_table').findOne({_id:MongoID(resp.value.tbid),'pi.uid':resp.value._id.toString()},{fields:{'pi.$':1}},function(err1,resp1){
                                if(resp1){
                                    c('UpdateUserChips------------------->>>>>resp1: ',resp1);

                                    if(resp1.pi && resp1.pi.length > 0 && typeof resp1.pi[0].si != 'undefined'){
                                        commonClass.FireEventToTable(resp.value.tbid,{en:'UTC',data:{si:resp1.pi[0].si,chips:resp.value.Chips,totalCash:tcash,reason:t}});
                                    }
                                }
                            });

                            //******************code ends here********************
                        }

                        if (typeof callback == 'function'){
                            callback(tcash);
                            // return callback(1);
                        }
                                                            
                    } else {
                        if(typeof callback != 'undefined'){
                            cdClass.UpdateUserChips(id,"", chips, t, callback);
                        }
                        else{
                            cdClass.UpdateUserChips(id,"", chips, t, '');
                        }
                    }
                });
            } else if (typeof callback == 'function')
                callback(0);
        });
    },
    UpdateUserCashforgame: function(id, Chips, bc, t, callback) {
        /* +-------------------------------------------------------------------+
            desc:this function use to update the user chips.
            i/p:userid,chips,t:status
            o/p:updated user chips
        +-------------------------------------------------------------------+ */
        c('UpdateUserCash-->>>id: ',id,' chips: ',Chips,' t: ',t,' bc: ',bc);
        if(!id){
            c('UpdateUserCash---------->>>>Error:"id not found!!!"');
            return false;
        }
        id = id.toString();
        
        
        cdClass.GetUserInfo(id,{}, function(userInfo){ 
            if(userInfo){
                c("UpdateUserChipsForGame -----------------userInfo",userInfo);
                var playWinTxt = ['Card Drop Deduction','Table Leave Deduction','Collect Boot Value','Game Lost','Game Draw'];
                
                var fChips = ((Chips + userInfo.totalcash) < 0) ? 0 : (Chips + userInfo.totalcash); 
                var wChips = (_.contains(playWinTxt,t)) ? Chips + userInfo.wc: userInfo.wc;
                var mwChips = (Chips > userInfo.counters.mcw && _.contains(playWinTxt,t)) ? Chips: userInfo.counters.mcw; 
                
                if(userInfo.flags._ir == 0){

                    //trackClass.Chips_Track(userInfo,Chips,t);
                }
                else{
                    //trackClass.Robot_Chips_Track(userInfo,Chips,t);
                }

                // c('UpdateUserCash---------->>>>fChips: ',fChips);
                // var setInfo = {};
                // setInfo.$set = {};
                var setInfo = {
                    $inc: {}
                };
                
                /*if(userInfo.counters.hcl < fChips){
                    setInfo.$set["counters.hcl"] =   fChips ;
                }
                setInfo.$set["wc"] = wChips;
                setInfo.$set["cash"] = fChips;
                setInfo.$set["counters.mcw"] = mwChips;*/


                if(userInfo.depositcash + userInfo.bonuscash >= Math.abs(Chips) && userInfo.depositcash >= Math.abs(Chips)-bc){
                    //var supercashmin=(chips * per)/100;
                    c("UpdateUserChipsForGame -----------------depo super")
                    if(userInfo.bonuscash >= bc){
                        setInfo["$inc"]["bonuscash"]= -bc;
                        setInfo["$inc"]["depositcash"]= -(Math.abs(Chips) - bc);
                        var sc = bc;
                        var dc = Math.abs(Chips) - bc;
                    }else{
                        var sup = userInfo.bonuscash;
                        setInfo["$inc"]["bonuscash"]= -parseInt(sup);
                        setInfo["$inc"]["depositcash"]= -(Math.abs(Chips) - sup);
                        var sc = sup;
                        var dc = Math.abs(Chips) - sup;
                    }

                    setInfo["$inc"]["totalcash"]=Chips;
                   
                }else if(userInfo.wincash + userInfo.bonuscash >= Math.abs(Chips) && userInfo.wincash >= Math.abs(Chips)-bc){
                    c("UpdateUserChipsForGame -----------------win super")
                    if(userInfo.bonuscash >= bc){
                        setInfo["$inc"]["bonuscash"]= -bc;
                        setInfo["$inc"]["wincash"]= -(Math.abs(Chips) - bc);
                        var sc = bc;
                        var wc = Math.abs(Chips) - bc;
                    }else{
                        var sup = userInfo.bonuscash;
                        setInfo["$inc"]["bonuscash"]= -parseInt(sup);
                        setInfo["$inc"]["wincash"]= -(Math.abs(Chips) - sup);
                        var sc = sup;
                        var wc = Math.abs(Chips) - sup;
                    }
                   
                    setInfo["$inc"]["totalcash"]=Chips;
                   
                }else if(userInfo.bonuscash >= bc && userInfo.wincash + userInfo.depositcash >= Math.abs(Chips)-bc){
                    if(userInfo.depositcash >= Math.abs(Chips) - bc){
                        setInfo["$inc"]["bonuscash"]= -bc;
                        setInfo["$inc"]["depositcash"]= -(Math.abs(Chips) - bc);
                        var sc = bc;
                        var dc = Math.abs(Chips) - bc;
                    }else{
                        var chp = Math.abs(Chips) - bc;
                        var dop = userInfo.depositcash;
                        var depoc = chp - dop;
                        setInfo["$inc"]["bonuscash"]= -bc;
                        setInfo["$inc"]["depositcash"]= -dop;
                        setInfo["$inc"]["wincash"]= -depoc;
                        var sc = bc;
                        var dc = dop;
                        var wc = depoc;
                    }

                    setInfo["$inc"]["totalcash"]=Chips;
                }
                else if(userInfo.wincash + userInfo.depositcash >= Math.abs(Chips)){
                    c("UpdateUserChipsForGame -----------------depo win")
                    if(userInfo.depositcash >= Math.abs(Chips)){
                        setInfo["$inc"]["depositcash"] = Chips;
                    }
                    else{
                        var dop = userInfo.depositcash;
                        setInfo["$inc"]["depositcash"] = -parseInt(dop);
                        setInfo["$inc"]["wincash"]= -(Math.abs(Chips) - dop);
                        var dc = dop;
                        var wc = Math.abs(Chips) - dop;
                    }

                    setInfo["$inc"]["totalcash"]=Chips;

                }else if(userInfo.wincash + userInfo.depositcash + userInfo.bonuscash >= Math.abs(Chips)){
                    if(userInfo.bonuscash >= Math.abs(Chips)){
                        setInfo["$inc"]["bonuscash"] = Chips;
                    }
                    else{
                        setInfo["$inc"]["bonuscash"] = -userInfo.bonuscash;
                        var rm = Math.abs(Chips) - userInfo.bonuscash;
                        if(userInfo.depositcash >= rm){
                            setInfo["$inc"]["depositcash"] = -rm;
                        }
                        else{
                            setInfo["$inc"]["depositcash"] = -userInfo.depositcash;
                            var winn = rm - userInfo.depositcash;
                            setInfo["$inc"]["wincash"]= -winn;
                        }
                    }

                    setInfo["$inc"]["totalcash"]=Chips;
                }else{
                    c("return else");
                    return false
                }


                 // c('UpdateUserCash------->>>setInfo: ',setInfo);
                
                db.collection('game_users').findAndModify({_id:MongoID(id)},{},setInfo,{new:true}, function (err,resp) {
                    if(resp.value != null) {

                        //c('sending data to '+userInfo.un);
                        if(userInfo.flags._ir == 0){
                            
                            var inserData = {
                                c: Chips,
                                pc: userInfo.totalcash,
                                bc: Math.abs(sc),
                                dc: Math.abs(dc),
                                wc: Math.abs(wc),
                                tp: t,
                                pbc: userInfo.bonuscash, //past supercash
                                pdc: userInfo.depositcash, //past depoist case
                                pwc: userInfo.wincash, //past win case
                                cbc: resp.value.bonuscash, //cunrent supercash
                                cdc: resp.value.depositcash, //cunrent depoist case
                                cwc: resp.value.wincash, //cunrent win case
                                uid: MongoID(userInfo._id.toString()),
                                un: userInfo.un,
                                ue:userInfo.ue
                            };

                            trackClass.Cash_Track(inserData);
                        }

                        if(userInfo.flags._ir == 0){

                            commonClass.SendDirect(userInfo._id, {en : "UC" , data :{totalCash:fChips,Chips:userInfo.Chips,t:t}},true); //publishing to exchange
                        }
                        if(userInfo.tbid != ''){

                            db.collection('playing_table').update({_id:MongoID(userInfo.tbid),'pi.uid':userInfo._id.toString()},{$set:{'pi.$.totalCash':fChips}});


                            //*****************table chips update code*************

                            db.collection('playing_table').findOne({_id:MongoID(userInfo.tbid),'pi.uid':userInfo._id.toString()},{fields:{'pi.$':1}},function(err1,resp1){
                                if(resp1){
                                    c('UpdateUserCash------------------->>>>>resp1: ',resp1);

                                    if(resp1.pi && resp1.pi.length > 0 && typeof resp1.pi[0].si != 'undefined'){
                                        commonClass.FireEventToTable(userInfo.tbid,{en:'UTC',data:{si:resp1.pi[0].si,totalCash:fChips,chips:resp.value.Chips,reason:t}});
                                    }
                                }
                            });

                            //******************code ends here********************
                        }

                        if(typeof callback == 'function'){
                            callback(fChips);   
                        }
                    }    
                });
                
            }
            else if(typeof callback == 'function'){
                callback(0);    
            }
        });
    },
    UpdateUserCoins: function(id, Coins, t, callback) {
        /* +-------------------------------------------------------------------+
            desc:this function use to update the user coins.
            i/p:userid,coins,t:status
            o/p:updated coins
        +-------------------------------------------------------------------+ */
        c('UpdateUserCoins-->>>id: ',id,' coins: ',Coins,' t: ',t);
        if(!id){
            c('UpdateUserCoins---------->>>>Error:"id not found!!!"');
            return false;
        }
        id = id.toString();
        
        
        cdClass.GetUserInfo(id, { Coins : 1, un : 1, sck : 1, "flags._ir" : 1 }, function(userInfo){
            if( userInfo && userInfo._id){


                
                var fCoins = ((Coins + userInfo.Coins) < 0) ? 0 : (Coins + userInfo.Coins); 
                
                if(userInfo.flags._ir == 0){

                    //trackClass.Coins_Track(userInfo,Coins,t);
                }

                // c('UpdateUserCoins---------->>>>fCoins: ',fCoins);
                var setInfo = {};
                setInfo.$set = {};
               
                 setInfo.$set["Coins"] = fCoins;
                 // c('UpdateUserCoins------->>>setInfo: ',setInfo);
                    
                db.collection('game_users').update({_id:MongoID(id)},setInfo, function(err,resp){
                
                });
                
                //c('sending data to '+userInfo.un);
                if(userInfo.flags._ir == 0){

                    commonClass.SendDirect(userInfo._id, {en : "UCN" , data :{ Coins :  fCoins , t:t}},true); //publishing to exchange
                }
                
                if(typeof callback == 'function'){
                    callback(fCoins);   
                }
            }
            else if(typeof callback == 'function'){
                callback(0);    
            }
        });
    },
    CountHands : function(uid,flag,gt,bv,wholeWin,cb){   //count users hand i.e win count, lose count,play count ; flag = flag for is winner, loser or dropped
        /* +-------------------------------------------------------------------+
            desc: this function use to count the user's hand,user win count,user lose count,user play count.
            i/p:
                uid : user id
                flag : user status win/drop/lose
                gt : game type
                bv : boot value
                wholeWin : does user win whole game for deal/pool
                cb : callback function
        +-------------------------------------------------------------------+ */
        c('CountHands--------------------->>>>>>uid: '+uid+' flag: '+flag+' gt: '+gt+' bv: '+bv+' wholeWin: '+wholeWin);
        cdClass.GetUserInfo(uid,{},function(userInfo){
            if(!userInfo){
                console.log('CountHands::::::::::::::::>>>>>"user not found!!!"');
                return false;
            }
            var thp = 0;
            // var spc = 0;
            var upData = {$set:{},$inc:{}};
            if(flag == 'win'){
                upData = {$set:{'counters.cl':0,'counters.cdr':0/*,'counters.loseStreak':0*/},$inc:{'counters.thp':1,/*'counters.spc':1,*/'counters.hw':1,'wintrigger':1,'counters.cw':1}};
            }
            else if(flag == 'drop'){
                upData = {$set:{'counters.cw':0,'counters.cl':0},$inc:{'counters.thp':1,'counters.hd':1,'counters.cdr':1,'losscounter':1/*,'counters.loseStreak':1*/}};
            }
            else{
                upData = {$set:{'counters.cw':0,'counters.cdr':0},$inc:{'counters.thp':1,'counters.hl':1,'counters.cl':1,'losscounter':1/*,'counters.loseStreak':1*/}};
            }
            
            profileClass.ManageUserLevel('play',uid)    
            var qstWin = 0;

            c('CountHands---------------->>>>>>>upData: ',upData);
            cdClass.UpdateUserData(userInfo._id.toString(),upData,function(userInfo){
                
                thp = (userInfo && userInfo.counters.thp)? userInfo.counters.thp :0;
                // spc = (userInfo && userInfo.counters.spc)? userInfo.counters.spc :0;

                if(typeof cb == 'function'){
                    cb(thp,qstWin);
                }
            });

        });
    },
    updateWintrigger : function(uid,no){
        
        var number = (typeof no != 'undefined') ? no : -1;
        cdClass.GetUserInfo(uid,{},function(userInfo){
            if(!userInfo){
                console.log('updateWintrigger::::::::::::::::>>>>>"user not found!!!"');
                return false;
            }
            var winTrigger = 1;
            if(number != -1){
                winTrigger = number;
            }
            else{

                var no = [1,2,3];
                var index = no.indexOf(userInfo.winTrigger);
                if (index > -1) {
                   no.splice(index, 1);
                }
                var rInt = commonClass.GetRandomInt(0,1);
                winTrigger = no[rInt];
                if(typeof userInfo.counters.spc != 'undefined' && parseInt(userInfo.counters.spc)+1 <= config.FIRST_TIME_GAME_LIMIT){
                    winTrigger = 1;
                }
            }

            var upData = {$set:{}};
            upData = {$set:{'winTrigger':winTrigger}};
            cdClass.UpdateUserData(userInfo._id.toString(),upData,function(userInfo){});
        });
    }
}