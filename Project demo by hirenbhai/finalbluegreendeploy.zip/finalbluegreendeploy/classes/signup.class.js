module.exports = {
	SP:function (data, client) {  //Signup data = {}
		/* +-------------------------------------------------------------------+
			desc:main signup event
			i/p: data = {
							DeviceId = device id
							SerialNumber = serial number for push notification
							un = username
							det  = device type
							iv = ios version
							av = android version
							ipad = ip address
							osType = os type
							osVer = os version
							devBrn = device brand
							devMdl = device model
							giftCode = giftcode for user
							ult = user login type
						}
				client = socket object
		+-------------------------------------------------------------------+ */
        c('SP------>>> data: ',data);

		//we have to check type of registration. //setting offline user when sync
		if(data.uid && parseInt(data.sync) == 1){
			db.collection('game_users').update({_id : MongoID(data.uid)},{ $set : { "flags._io" : 0, sck : ""}},function(){});
		}
		
		if(typeof data.ip != 'undefined'){
			db.collection('blocks_ip').find({ip :data.ip}).toArray(function(err,ipdata){
		        if(!err && ipdata.length > 0){
		            //This IP is blocked by admin!
		            commonClass.SendData(client, 'PUP', { flag: 'SP', err: true }, 'error:1523');
		        }else{
					db.collection('blocks_device').find({did:data.DeviceId}).toArray(function(err,diddata){
		                if(!err && diddata.length > 0){
		                    //This device is blocked by admin!
		                    commonClass.SendData(client, 'PUP', { flag: 'SP', err: true }, 'error:1524');
		                }else{
		                	if(data.ult == 'FB'){ //if user is logged in using facebook profile
								c('SP------>>>FB---------->>>>sck: '+client.sck);
								this.FbLoginOrSignup(data, client);
							}
							else if (data.ult == 'google') {
								this.googleLoginOrSignup(data, client);
							}
							else if(data.ult == 'guest'){ //if user is trying yo login or signup using guest
								//if user is trying to play game as guest then we have handle it via guest registratio handler
								c('SP---------->>>>guest------>>>>>sck: '+client.sck);
								this.GuestSignup(data,client);
							}
		                }
	            	})
				}
			})
		}
		else{
			if(data.ult == 'FB'){ //if user is logged in using facebook profile
				c('SP------>>>FB---------->>>>sck: '+client.sck);
				this.FbLoginOrSignup(data, client);
			}
			else if (data.ult == 'google') {
				this.googleLoginOrSignup(data, client);
			}
			else if(data.ult == 'guest'){ //if user is trying yo login or signup using guest
				//if user is trying to play game as guest then we have handle it via guest registratio handler
				c('SP---------->>>>guest------>>>>>sck: '+client.sck);
				this.GuestSignup(data,client);
			}
		}
	},
	GGC : function(data, client){   //get game config
		/* +-------------------------------------------------------------------+
			desc:event to get game config
			i/p: data = {},client = socket object
		+-------------------------------------------------------------------+ */
		var cnf = commonClass.GetGameConfig();

		var dtdiff1 = commonClass.GetTimeDifference(new Date(), new Date(config.MMSD));
        var dtdiff2 = commonClass.GetTimeDifference(new Date(), new Date(config.MMED));
        
        
        dtdiff1=dtdiff1<0?0:dtdiff1;
        dtdiff2=dtdiff2<0?0:dtdiff2;
        if(commonClass.InMaintenanceMode()){
            
            config.MM=true;
            
        }
        else{
            config.MM=false;
           
        }
        if(config.MM == true && config.MMSFLAG == true && dtdiff2 > 0){
           
            cnf.StartAfter=0;
            cnf.RemoveAfter = dtdiff2;
            // cnf.m_mode = config.MM;     
        }
        else{
           
            cnf.StartAfter=dtdiff1;
            cnf.RemoveAfter = dtdiff2;
            // cnf.m_mode = false;
            // config.MM= cnf.m_mode;    
        }
        cnf.MM = config.MM;
        cnf.MMSFLAG = config.MMSFLAG;

		commonClass.SendDirect(client.sck, { en : 'GGC', data : cnf});
	},
	getUserDefaultFields: function(data, client,cb){ //generates the user default fields for the game
		/* +-------------------------------------------------------------------+
			desc:set the default fields for first timer user data
			i/p: data = {
					fid = facebook id
					un = user email
					ue = user email
					ult = user login type
					fat = facebook acces token
					det = device type
					DeviceId = device id
					SerialNumber = serial number
					nwt = network type
					lc = language code
					prms = array of fb permission
					osType = os type
					osVer = os version
					devBrnd = device brand
					devMdl = device model
				}
				client = socket object
				cb = callback function
		+-------------------------------------------------------------------+ */
		//defined ruby or diamond on type of signup.
		c('getUserDefaultFields------------->>>>data: ',data);
		db.collection('game_users').find({'flags._ir':0}).count(function(err,count){

			if(typeof count == 'undefined' || count == null){
				count = 0
			}

			var dids = [];
			var ldi = '';

			if(typeof data.DeviceId != 'undefined' && data.DeviceId != null && data.DeviceId != ''){
				dids.push(data.DeviceId);
				ldi = data.DeviceId;
			}

			if(ldi == '' && data.ult == 'guest'){
				c('getUserDefaultFields--------->>>>"device id not found"');
				return false;
			}

			var pp = '';

			var userId = commonClass.GetRandomInt(1, 99999999);

			var t = {

				un: (!data.un || data.un == "") ? 'MTR_' + userId : data.un.substr(0,15), //username
				unique_id: "MTR" + userId, //user uniqueID
	 			ue 	: (data.ue) ? data.ue : '',  //useremail
				phn : (data.MobileNumber) ? data.MobileNumber : '', //phone no.
	 			tId : (data.ID) ? data.ID : '',
				Password : (data.Password) ? data.Password : '',
				AuthExpire : (data.AuthExpire) ? data.AuthExpire : '',
				ExpireToken : (data.ExpireToken) ? data.ExpireToken : '',
 				ut : (data.UT) ? data.UT : '',
				fid : (data.fid) ? data.fid : '', //facebookid
				gid : (data.gid) ? data.gid : '',
 				ip : (data.ip) ? data.ip : '', //ip
				pp 	: pp,  //profile picture,
				ult	: data.ult,	//user login type
				cd 	: new Date(),  //create date
				fat : (data.fat) ? data.fat : '',  //facebook access token
				det	: data.det,  //device type
				dids: dids,//(!data.DeviceId || data.DeviceId == "") ? [] : [data.DeviceId],  //device ids
				sn 	: (data.SerialNumber) ? [data.SerialNumber] : [], //serial numbe(only for ios)	
				wc 	: 0, //chips for winner
				Chips: config.INITIAL_CHIPS, //user chips
				bonuscash:100000,
				wincash:200000,
				depositcash:100000,
				totalcash:400000,
				counters :{
					hw : 0, //hands win
					hl : 0, //hands lost
					hd : 0,	//Hands dropped
					cw : 0, //consecutive win
					cl : 0, //consecutive lose
					cdr : 0, //consecutive drop
					thp : 0, //Total Hands played
					hcl : config.INITIAL_CHIPS, //highest chip level
					mcw : 0, //Most Chips Won
					deal_c:0, //deal mode help session counter
					pool_c:0, //pool mode help session counter
					bet_c:0, //bet mode help session counter
					lvc:0, // level completed counter
					ppo:0, // current level point
					pper:0, //current level completed percentage
					opc:0, //operation counter
					dbc:0, //daily bonus counter for consecutive come
					invC:0,//invite counters
					spinDays:0 //
				},
				iv  : (data.det == 'ios') ? data.iv : 0, //ios app version
				ivc : (data.det == 'ios') ? data.verCode : 0, //ios app version code
				av  : (data.det == 'android') ? data.av : 0, //android app version
				avc : (data.det == 'android') ? data.verCode : 0, //android app version code
				nwt : (data.nwt) ? data.nwt : '', //network
				lc  : commonClass.GetLanguageCode(data.lc), //Language code
	            rfc : commonClass.GetRandomString(7), //referral code generated by system on signup
				flags : {
					_ir : 0, //is robot
					_fbLike:(data._fl) ? data._fl : 0, //facebook like
					_ftp : 1, //first Time playing
					_isup : 0, //is suspended
					_isbkip : 0, // block by ip
					_isbkdv : 0, // block by device
					_io : 1, //is Online
					_pyr:0, //is payer : 0 / 1
					_noti:0, //notification : 0 / 1
					_snd:1, // sounds : 0 / 1
					_vib:1, //vibration : 0 / 1
					_challenge:1, //challange : 0 / 1
					_tutf:1, //tutorial flag
					_payer:0, //is payer : 0 / 1
					_isSpc:1,  // is first time user
					_fPick :0,  //first pick 
					_fDiscard:0, //first discard 
					_fActions:0, //first actions(declare) 
					_fSort:0, //first sort
					_isRefered : 0, //is already refered user or not
					_isRated : 0
				},
				lasts : {
					pl : new Date(), //previous login
					ll : new Date(), //last login
					llgt : new Date(), // last logout 
					ldt : data.det, //last device type
					ldi : ldi, // last device id
					lsn : (data.SerialNumber) ? data.SerialNumber : null, // last serial number
					ldbt : commonClass.subTime(86400), //last daily bonus time
					lsct: commonClass.subTime(86400), //last spin collect time
					lort :"",  //last offer reject time
					lrtt : new Date(), // last retention time
					lltt: new  Date(), // last login track time
					lrpt: commonClass.subTime(86400),  //last rate popup showing time
				},
				club : 'Garnet',
				rand : Math.random(), //random numer for special purposes
				tbid : "", //table id
				rejoinID : "", //rejoinId
				rejoin : 0,  //rejoin flag
				cbtn : 1,  //in game notification
				ds : (data.ds) ? data.ds : '', //download source
			    ipad : (client.ipad) ? client.ipad : "", //ip address
			    country : 'India',  //country of player (default India)
			    cc : 'in', //country code
			    city : '', //city
			    bv : 50, // boot value of table that last played by user 
			    sck: (client.sck) ? client.sck : "", //socket id of user 
			    sessId:1, //Session Id
			    osType: (typeof data.osType != 'undefined') ? data.osType: "", //os of device
			    osVer : (typeof data.osVer != 'undefined') ? data.osVer : "", //os version
			    devBrnd : (typeof data.devBrnd != 'undefined') ? data.devBrnd : "", //device brand
			    devMdl : (typeof data.devMdl != 'undefined') ? data.devMdl : "", //device model 
			    offers:{
			    	ofId:'' //offer id
			    }, //offer to show on low chips 
			};
			if(typeof cb == 'function'){

				cb(t);
			}
		});
	},
	GuestSignup:function(data,client){  //handle signup operation of the guest player
		/* +-------------------------------------------------------------------+
			desc:function to handle guest signup
			i/p: data = {
					DeviceId = device id
					SerialNumber = serial number for push notification
					un = username
					det  = device type
					iv = ios version
					av = android version
					ipad = ip address
					osType = os type
					osVer = os version
					devBrn = device brand
					devMdl = device model
					giftCode = giftcode for user
				}
				client = socket object
		+-------------------------------------------------------------------+ */

		var wh = {$or : []};
		if(typeof data.DeviceId != 'undefined' && data.DeviceId != null && data.DeviceId != ''){
			wh['$or'].push({ dids:data.DeviceId});
		}
		if(typeof data.PhoneId != 'undefined' && data.PhoneId != null && data.PhoneId != ''){
			wh['$or'].push({ dids: data.PhoneId});
		}

	    c('GuestSignup--------->>>>>data.DeviceId: '+data.DeviceId+' data.PhoneId: '+data.PhoneId+' data.SerialNumber: '+data.SerialNumber);
		
			
		wh.ult = data.ult; //checking specific user account
		
		//guest signup with random username. on deviceId
		db.collection('game_users').findOne(wh,function(err,resp){ 
			
			//if user with this device key is already exist then we have return this user data.
			c("GuestSignup-----------resp:",resp);
			if(resp){
				
				var res = resp;
				

				client._isup = res.flags._isup;
				
				
				if(res.flags._isup == 1){
					

					commonClass.SendData(client,'PUP', data, 'error:1005');
					
					c('GuestSignup----->>>>user is suspended');
					return false;
				}
				
					
				var upWhere = { $set : { det : data.det, ult : data.ult,"lasts.pl":resp.lasts.ll,"lasts.lsn":data.SerialNumber, "lasts.ldt" : 
				data.det, "flags._io" : 1,'lasts.lsi':0 ,"lasts.lltt":new Date()}};
				upWhere.$set.nwt = (data.nwt) ? data.nwt:res.nwt;
				upWhere.$set.iv = (data.iv) ? data.iv : res.iv;
				upWhere.$set.av = (data.av) ? data.av : res.av;
				if(data.det == 'android'){
					if(typeof data.verCode != 'undefined' && data.verCode != null){
						upWhere.$set.avc = data.verCode;
					}
					else if(typeof res.avc != 'undefined' && res.avc != null){
						upWhere.$set.avc = res.avc;
					}
					else{
						upWhere.$set.avc = 0;	
					}
				}
				else if(data.det == 'ios'){
					if(typeof data.verCode != 'undefined' && data.verCode != null){
						
						upWhere.$set.ivc = data.verCode;
					}
					else if(typeof res.ivc != 'undefined' && res.ivc != null){
						upWhere.$set.ivc = res.ivc;
					}
					else{
						upWhere.$set.ivc = 0;
					}
				}
				


				var diff = 60;
				if(res.lasts.llgt){
					c('GuestSignup---------------->>>>>res.lasts.llgt: '+res.lasts.llgt);
					diff = commonClass.GetTimeDifference(res.lasts.llgt,new Date());
				}

				c('GuestSignup---------------->>>>>diff: '+diff);
				if(diff > 60 && resp.flags._io == 0){ //means time greater than 60 second = 1 min then update session
					upWhere.$set['lasts.ll'] = new Date();
					upWhere.$set['counters.opc'] = 0;
					upWhere.$inc = {sessId:1};
				}

				upWhere.$set.ipad = (client.ipad) ? client.ipad : "";
				upWhere.$set.osType = (typeof data.osType != 'undefined') ? data.osType : res.osType;
				upWhere.$set.osVer = (typeof data.osVer != 'undefined') ? data.osVer : res.osVer;
				upWhere.$set.devBrnd = (typeof data.devBrnd != 'undefined') ? data.devBrnd : res.devBrnd;
				upWhere.$set.devMdl = (typeof data.devMdl != 'undefined') ? data.devMdl : res.devMdl;


				c('GuestSignup------------>>>>data.device:',data.DeviceId,' ');
				if(data.DeviceId && data.DeviceId != ''){


					if(!commonClass.InArray(data.DeviceId, res.dids)){

						upWhere.$push =  { dids : data.DeviceId };
					}

					upWhere.$set['lasts.ldi'] = data.DeviceId;
				}
				
				if(data.SerialNumber && data.SerialNumber != '' &&  !commonClass.InArray(data.SerialNumber, res.sn)){
					upWhere.$push =  { sn : data.SerialNumber };
				}
								
				var dayDiff1 = Math.floor(commonClass.GetTimeDifference(res.cd, new Date())/86400);
				
				if(!res.unique_id){
					upWhere.$set.unique_id = "MTR" + commonClass.GetRandomInt(1, 99999999);
				}	
					
				c('GuestSignup------------------------->>>>>>>>>upWhere: ',upWhere);

				if(resp.tbid != ''){  //means user is reconnect after 1 min  so 

					//cdClass.GetTbInfo(resp.tbid,{},function(table){
					db.collection('playing_table').findOne({_id:MongoID(resp.tbid),$or:[{'pi.uid':resp._id.toString()},{'stdP.uid':resp._id.toString()}]},function(err,table){
						if(table){

							if(resp.rejoin == 0 ){  //special condition for rejoin before disconnect
								

								client.tbid = table._id.toString();
								client.gt = table.gt;
								
								upWhere.$set.rejoin = 1;  //means direct rejoin
							}
							else if(resp.rejoin == 2){
	

								client.tbid = table._id.toString();
								client.gt = table.gt;

								if(table.ap ==  table.ms){  //means table is full and user is not playing as rejoin = 2
									upWhere.$set.rejoin = 3;    ///rejoin = 3 means we have to show only switch table option
								}	
							}
						}
						else{
							upWhere.$set.tbid = '';
							upWhere.$set.rejoin = 0;
							upWhere.$set.rejoinID = '';
						}
		                
						
						cdClass.UpdateUserData(resp._id.toString(),upWhere,function(resp2){	
							if(resp2){

								if(data.giftCode != ''){   //gift code storing
									resp2.giftCode = data.giftCode;
								}
								
								c('GuestSignup---------->>>>>un: ',resp2.un);
								trackClass.TrackReferrer(data,resp2,false,function(userData1){
									
									dashboardClass.AUCI(resp2, client);
								});
							}
							else{
								c('GuestSignup::::::::::::::::::::::::::>>>>Error: "user not found"');
							}
						});
					});
				}
				else{  
					upWhere.$set.tbid = '';
					upWhere.$set.rejoin = 0;
					upWhere.$set.rejoinID = '';

					cdClass.UpdateUserData(resp._id.toString(),upWhere,function(resp2){	
						if(resp2){

							if(data.giftCode != ''){   //gift code storing
								resp2.giftCode = data.giftCode;
							}
							
							c('GuestSignup---------->>>>>un: ',resp2.un);
							trackClass.TrackReferrer(data,resp2,false,function(userData1){
									
								dashboardClass.AUCI(resp2, client);
							});
						}
						else{
							c('GuestSignup:::::::::::::::::>>>>Error: "user not found"');
						}
					});
				}
			}
			else{ //if no device id was there then we have create new user for this.
				
				
				client._isup = 0;
				//getting default avatar for guest
				signupClass.getUserDefaultFields(data, client,function(tData){

					if(tData){
						c("sp-----------------------------tData:",tData);
						// tData.ds = '';
						db.collection('game_users').save(tData , function(err, userData) {
							//c('SP-->>>>' ,JSON.stringify(userData));
							if(data.giftCode != ''){
								userData.ops[0].giftCode = data.giftCode;
							}
							// trackClass.TrackReferrer(data,userData.ops[0],true,function(userData1){

							trackClass.TrackReferrer(data,userData.ops[0],true,function(userData1){
									
								dashboardClass.AUCI(userData.ops[0], client);
							});
								
							// });	

						});
					}
					else{
						c('GuestSignup------------->>>>>"default field not found"');
					}
				});
			}
		});
	},
	FbLoginOrSignup:function(data,client){ ////handle signup operation of the google player
		/* +-------------------------------------------------------------------+
			desc:function to handle fb signup
			i/p: data = {
					DeviceId = device id
					SerialNumber = serial number for push notification
					un = username
					det  = device type
					iv = ios version
					av = android version
					ipad = ip address
					osType = os type
					osVer = os version
					devBrn = device brand
					devMdl = device model
					giftCode = giftcode for user
					fid = facebook id
				}
				client = socket object
		+-------------------------------------------------------------------+ */
		//first we have to find the user with email
		c('FbLoginOrSignup----> data: ',data);
		db.collection('game_users').findOne({ fid : data.fid},function(err,res){
			//if we found any previous account with facebook id then we have to load this account.
			if(res){
				//c('If record found >> '+data.un); 
				
				if(res.flags._isup == 1){
					commonClass.SendData(client,'PUP', data, 'error:1005');
					return false;
				}
				

				var upWhere = { $set : { det : data.det, fid : data.fid, fat : (data.fat)? data.fat:'', ult : data.ult,"lasts.pl":res.lasts.ll, 
								/*"lasts.ldi" : data.DeviceId,"lasts.lsn":data.SerialNumber,*/ "lasts.ldt" : data.det, "flags._io" : 1, prms : data.prms,'lasts.lsi':0 /*,'lasts.lbct':new Date()*/,'lasts.lltt':new Date()}};
				

				if(data.un){
					upWhere.$set.un = data.un.substr(0,15);
				}

				if(data.SerialNumber){
					upWhere.$set['lasts.lsn'] = data.SerialNumber;
				}
				upWhere.$set.nwt = (data.nwt) ? data.nwt: res.nwt;
				upWhere.$set.iv = (data.iv) ? data.iv : res.iv;
				upWhere.$set.av = (data.av) ? data.av : res.av;
				if(data.det == 'android'){

					
					if(typeof data.verCode != 'undefined' && data.verCode != null){
						upWhere.$set.avc = data.verCode;
					}
					else if(typeof res.avc != 'undefined' && res.avc != null){
						upWhere.$set.avc = res.avc;
					}
					else{
						upWhere.$set.avc = 0;	
					}
				}
				else if(data.det == 'ios'){
					
					if(typeof data.verCode != 'undefined' && data.verCode != null){
						upWhere.$set.ivc = data.verCode;
					}
					else if(typeof res.ivc != 'undefined' && res.ivc != null){
						upWhere.$set.ivc = res.ivc;
					}
					else{
						upWhere.$set.ivc = 0;	
					}
				}
				else if(data.det == 'html'){
					upWhere.$set.un = (data.un && data.un != '')?data.un:res.un;
					upWhere.$set.pp = (data.pp && data.pp != '')?data.pp:res.pp;
				}



				var diff = 60;
				if(res.lasts.llgt){
					diff = commonClass.GetTimeDifference(res.lasts.llgt,new Date());
				}


				if(diff > 60 && res.flags._io == 0|| data.det == 'flash' || data.det == 'html'){ //means time greater than 60 second = 1 min then update session
					upWhere.$set['lasts.ll'] = new Date();
					upWhere.$set['counters.opc'] = 0;
					upWhere.$inc = {sessId:1};
				}


				if(!res.ppId || res.ppId == ''){
					upWhere.$set.ppId = data.fid;
				}

				upWhere.$set.prms = (data.prms) ? data.prms : res.prms;
				upWhere.$set.ipad =(client.ipad) ? client.ipad:"";	
				upWhere.$set.osType = (typeof data.osType != 'undefined') ? data.osType : res.osType;
				upWhere.$set.osVer = (typeof data.osVer != 'undefined') ? data.osVer : res.osVer;
				upWhere.$set.devBrnd = (typeof data.devBrnd != 'undefined') ? data.devBrnd : res.devBrnd;
				upWhere.$set.devMdl = (typeof data.devMdl != 'undefined') ? data.devMdl : res.devMdl;				
				if(data.DeviceId && data.DeviceId != ''){
					if(!commonClass.InArray(data.DeviceId, res.dids)){

						upWhere.$push =  {dids : data.DeviceId };
					}
					upWhere.$set['lasts.ldi'] = data.DeviceId;
				}
				if(data.PhoneId && data.PhoneId != ''){
					if(!commonClass.InArray(data.PhoneId, res.dids)){

						upWhere.$push =  {dids : data.PhoneId };
					}
					upWhere.$set['lasts.ldi'] = data.PhoneId;
				}
				if(data.SerialNumber && data.SerialNumber != '' &&  !commonClass.InArray(data.SerialNumber, res.sn)){
					upWhere.$push =  { sn : data.SerialNumber };
				}
					
				if(!res.cbtn){
					upWhere.$set.cbtn = 1;
				}
				
				var dayDiff1 = Math.floor(commonClass.GetTimeDifference(res.cd, new Date())/86400);
				if (dayDiff1 >= 1){
					upWhere.$set.dbf = true;
				}
				else{
					upWhere.$set.dbf = false;
				}
				if(!res.unique_id){
					upWhere.$set.unique_id = "MTR" + commonClass.GetRandomInt(1, 99999999);
				}	

				var dayDiff = commonClass.GetTimeDifference(new Date(), res.cd,'day');
                if(dayDiff > config.TUTF){
                	
                    upWhere.$set['flags._tutf'] = 0;
                }
                
				if(res.tbid != ''){
					
					db.collection('playing_table').findOne({_id:MongoID(res.tbid),$or:[{'pi.uid':res._id.toString()},{'stdP.uid':res._id.toString()}]},function(err,table){
						if(table){

							if(res.rejoin == 0 ){  //special condition for rejoin before disconnect
								
								client.tbid = table._id.toString();
								client.gt = table.gt;
								upWhere.$set.rejoin = 1;  //means direct rejoin
								
							}
							else if(res.rejoin == 2){

								client.tbid = table._id.toString();
								client.gt = table.gt;
								if(table.ap ==  table.ms){  //means table is full and user is not playing as rejoin = 2
									upWhere.$set.rejoin = 3;    ///rejoin = 3 means we have to show only switch table option
								}	
							}
						}
						else{
							upWhere.$set.tbid = '';
							upWhere.$set.rejoin = 0;
							upWhere.$set.rejoinID = '';
						}

						
						cdClass.UpdateUserData(res._id.toString(),upWhere,function(resp){
							if(resp){

								resp.counters.rifc = res.counters.rifc; //setting how many users referred by the user.
								
								if(data.giftCode != ''){
									
									resp.giftCode = data.giftCode;
								}
								
								FBClass.SaveFriendList(resp);
								dashboardClass.AUCI(resp, client); //add server instance
							}
							else{
								console.log('FbLoginOrSignup:::::::::111::::::::>>>>"data not updated"  upWhere: ',upWhere,' res._id: '+res._id);
							}
						});
					});
				}
				else{

					upWhere.$set.tbid = '';
					upWhere.$set.rejoin = 0;
					upWhere.$set.rejoinID = '';
					
					cdClass.UpdateUserData(res._id.toString(),upWhere,function(resp){		
						if(resp){
							resp.counters.rifc = res.counters.rifc; //setting how many users referred by the user.
							
							if(data.giftCode != ''){
								
								resp.giftCode = data.giftCode;
							}
							
							
							FBClass.SaveFriendList(resp);
							dashboardClass.AUCI(resp, client); //add server instance
						}
						else{
							console.log('FbLoginOrSignup:::::::::::2222::::::::::>>>>>>>"data not updated"  upWhere: ',upWhere,' res._id: '+res._id);
						}
					});
				}
			}
			else{ //if user is registering first time with login credentials
				
				if( !data.fid || data.fid == '' || data.fid.trim() == ''){
					return false
				}


				var wh = {$or : [],ult:'guest'};
				if(typeof data.DeviceId != 'undefined' && data.DeviceId != null && data.DeviceId != ''){
					wh['$or'].push({ dids:data.DeviceId});
				}
				if(typeof data.PhoneId != 'undefined' && data.PhoneId != null && data.PhoneId != ''){
					wh['$or'].push({ dids: data.PhoneId});
				}	

				

				client._isup = 0;
				if(data.det == 'ios' || data.det == 'android'){
					
					db.collection('game_users').findOne(wh,function(err,userInfo){
						
						if(userInfo){
							
							var nwt = (data.nwt)?data.nwt:userInfo.nwt;
							var pp = (data.ult == 'FB') ? 'https://graph.facebook.com/'+data.fid+'/picture?height=200&width=200' : data.pp;
							var upWhere = {$set:{nwt:nwt,pp:pp,ppId:data.fid,ult:'FB',fid:data.fid,ue:data.ue,sck:client.sck,'lasts.pl':userInfo.lasts.ll,'lasts.lltt':new Date(),fat : (data.fat)? data.fat:''}};

							if(data.un){
								upWhere.$set.un = data.un.substr(0,15);
							}

							if(data.det == 'android'){

								
								if(typeof data.verCode != 'undefined' && data.verCode != null){
									upWhere.$set.avc = data.verCode;
								}
								else if(typeof userInfo.avc != 'undefined' && userInfo.avc != null){
									upWhere.$set.avc = userInfo.avc;
								}
								else{
									upWhere.$set.avc = 0;	
								}
							}
							else if(data.det == 'ios'){
								
								if(typeof data.verCode != 'undefined' && data.verCode != null){
									upWhere.$set.ivc = data.verCode;
								}
								else if(typeof userInfo.ivc != 'undefined' && userInfo.ivc != null){
									upWhere.$set.ivc = userInfo.ivc;
								}
								else{
									upWhere.$set.ivc = 0;	
								}
							}
							var diff = 60;
							if(userInfo.lasts.llgt){
								diff = commonClass.GetTimeDifference(userInfo.lasts.llgt,new Date());
							}

							if(diff > 60 && userInfo.flags._io == 0 || data.det == 'flash' || data.det == 'html'){ //means time greater than 60 second = 1 min then update session
								upWhere.$set['lasts.ll'] = new Date();
								upWhere.$set['counters.opc'] = 0;
								upWhere.$inc = {sessId:1};
							}

							if(data.DeviceId && data.DeviceId != ''){
								if(!commonClass.InArray(data.DeviceId, userInfo.dids)){

									upWhere.$push =  {dids : data.DeviceId };
								}
								upWhere.$set['lasts.ldi'] = data.DeviceId;

							}
							if(data.PhoneId && data.PhoneId != ''){
								if(!commonClass.InArray(data.PhoneId, userInfo.dids)){

									upWhere.$push =  {dids : data.PhoneId };
								}
								upWhere.$set['lasts.ldi'] = data.PhoneId;
							}
							if(data.SerialNumber && data.SerialNumber != '' &&  !commonClass.InArray(data.SerialNumber, userInfo.sn)){
								upWhere.$push =  { sn : data.SerialNumber };
							}
							cdClass.UpdateUserChips(userInfo._id.toString(),config.FB_CHIPS,'FB signup bonus',function(uChips){

								if(userInfo.tbid != ''){
									
									db.collection('playing_table').findOne({_id:MongoID(userInfo.tbid),$or:[{'pi.uid':userInfo._id.toString()},{'stdP.uid':userInfo._id.toString()}]},function(err,table){
										if(table){

											if(userInfo.rejoin == 0 ){  //special condition for rejoin before disconnect
												
												client.tbid = table._id.toString();
												client.gt = table.gt;
												upWhere.$set.rejoin = 1;  //means direct rejoin
												
											}
											else if(userInfo.rejoin == 2){

												client.tbid = table._id.toString();
												client.gt = table.gt;
												if(table.ap ==  table.ms){  //means table is full and user is not playing as rejoin = 2
													upWhere.$set.rejoin = 3;    ///rejoin = 3 means we have to show only switch table option
												}	
											}
										}
										else{
											upWhere.$set.tbid = '';
											upWhere.$set.rejoin = 0;
											upWhere.$set.rejoinID = '';
										}

										
										
										cdClass.UpdateUserData(userInfo._id.toString(),upWhere,function(upData){
											if(upData){
												
												if(data.giftCode != ''){
													upData.giftCode = data.giftCode;
												}

												trackClass.TrackReferrer(data,upData,false,function(userData1){

													FBClass.SaveFriendList(userData1);
													dashboardClass.AUCI(userData1, client);
												});
											}
											else{
												console.log('FbLoginOrSignup:::::::::3333:::::::: wh: ',wh,' upWhere: ',upWhere);
											}
										});	
									});
								}
								else{ //user is not playing in any table
									
									upWhere.$set.tbid = '';
									upWhere.$set.rejoin = 0;
									upWhere.$set.rejoinID = '';
									cdClass.UpdateUserData(userInfo._id.toString(),upWhere,function(upData){
										if(upData){

											if(data.giftCode != ''){
												upData.giftCode = data.giftCode;
											}
											trackClass.TrackReferrer(data,upData,false,function(userData1){

												FBClass.SaveFriendList(userData1);
												dashboardClass.AUCI(userData1, client);
											});
											// commonClass.SendData(client,'SP',upData.value);
										}
										else{
											console.log('FbLoginOrSignup::::::::444::::::::::: wh: ',wh,' upWhere: ',upWhere);
										}
									});		
								}
							});
						}
						else{
							signupClass.getUserDefaultFields(data, client,function(UserFields){
								if(UserFields){

									UserFields.Chips = UserFields.Chips + config.FB_CHIPS;
									UserFields.counters.hcl = UserFields.counters.hcl + config.FB_CHIPS;

									db.collection('game_users').save(UserFields , function(err, userData){
										
										if(data.giftCode != ''){
											userData.ops[0].giftCode = data.giftCode;
										}

										trackClass.TrackReferrer(data,userData.ops[0],true,function(userData1){

											FBClass.SaveFriendList(userData1);
											dashboardClass.AUCI(userData1, client);
											// commonClass.SendData(client,'SP',userData.ops[0]);
										})
										
									});
								}
								else{
									c('FbLoginOrSignup-------111-------->>>>>"user default fields not found"');
								}
							});
						}
					});
				}
				else if(data.det == 'html'){

					signupClass.getUserDefaultFields(data, client,function(UserFields){//generating all the common fields for userl
						if(UserFields){

							//use for get Download source
							// UserFields.ds = '';
							UserFields.Chips = UserFields.Chips + config.FB_CHIPS;
							UserFields.counters.hcl = UserFields.counters.hcl + config.FB_CHIPS;
							db.collection('game_users').save(UserFields , function(err, userData) {		
								
								if(data.giftCode != ''){
									userData.ops[0].giftCode = data.giftCode;
								}
									
								trackClass.TrackReferrer(data,userData.ops[0],true,function(userData1){

									FBClass.SaveFriendList(userData1);
									dashboardClass.AUCI(userData1, client);
								});

							});	
						}
						else{
							c('FbLoginOrSignup-------222-------->>>>>"user default fields not found"');
						}
					}); 
				}
				else{
					c('FbLoginOrSignup--------------->>>>"platform not found"');
				}
			}	
		});
	},
	googleLoginOrSignup:function(data,client){ //handle signup operation of the google player
		/* +-------------------------------------------------------------------+
			desc:function to handle fb signup
			i/p: data = {
					DeviceId = device id
					SerialNumber = serial number for push notification
					un = username
					det  = device type
					iv = ios version
					av = android version
					ipad = ip address
					osType = os type
					osVer = os version
					devBrn = device brand
					devMdl = device model
					giftCode = giftcode for user
					fid = google id
				}
				client = socket object
		+-------------------------------------------------------------------+ */
		c('googleLoginOrSignup----> data: ',data);
		db.collection('game_users').findOne({gid : data.gid},function(err,res){
			//if we found any previous account with google id then we have to load this account.
			if(res){

				if(res.flags._isup == 1){
					commonClass.SendData(client,'PUP', data, 'error:1005');
					return false;
				}

				var upWhere = { $set : { det : data.det, gid : data.gid, fat : (data.fat)? data.fat:'', ult : data.ult,"lasts.pl":res.lasts.ll, 
								/*"lasts.ldi" : data.DeviceId,"lasts.lsn":data.SerialNumber,*/ "lasts.ldt" : data.det, "flags._io" : 1, prms : data.prms,'lasts.lsi':0 /*,'lasts.lbct':new Date()*/,'lasts.lltt':new Date()}};
				

				if(data.un){
					upWhere.$set.un = data.un.substr(0,15);
				}

				if(data.SerialNumber){
					upWhere.$set['lasts.lsn'] = data.SerialNumber;
				}
				upWhere.$set.nwt = (data.nwt) ? data.nwt: res.nwt;
				upWhere.$set.iv = (data.iv) ? data.iv : res.iv;
				upWhere.$set.av = (data.av) ? data.av : res.av;
				if(data.det == 'android'){

					
					if(typeof data.verCode != 'undefined' && data.verCode != null){
						upWhere.$set.avc = data.verCode;
					}
					else if(typeof res.avc != 'undefined' && res.avc != null){
						upWhere.$set.avc = res.avc;
					}
					else{
						upWhere.$set.avc = 0;	
					}
				}
				else if(data.det == 'ios'){
					
					if(typeof data.verCode != 'undefined' && data.verCode != null){
						upWhere.$set.ivc = data.verCode;
					}
					else if(typeof res.ivc != 'undefined' && res.ivc != null){
						upWhere.$set.ivc = res.ivc;
					}
					else{
						upWhere.$set.ivc = 0;	
					}
				}
				else if(data.det == 'html'){
					upWhere.$set.un = (data.un && data.un != '')?data.un:res.un;
					upWhere.$set.pp = (data.pp && data.pp != '')?data.pp:res.pp;
				}



				var diff = 60;
				if(res.lasts.llgt){
					diff = commonClass.GetTimeDifference(res.lasts.llgt,new Date());
				}


				if(diff > 60 && res.flags._io == 0|| data.det == 'flash' || data.det == 'html'){ //means time greater than 60 second = 1 min then update session
					upWhere.$set['lasts.ll'] = new Date();
					upWhere.$set['counters.opc'] = 0;
					upWhere.$inc = {sessId:1};
				}


				if(!res.ppId || res.ppId == ''){
					upWhere.$set.ppId = data.gid;
				}

				upWhere.$set.prms = (data.prms) ? data.prms : res.prms;
				upWhere.$set.ipad =(client.ipad) ? client.ipad:"";	
				upWhere.$set.osType = (typeof data.osType != 'undefined') ? data.osType : res.osType;
				upWhere.$set.osVer = (typeof data.osVer != 'undefined') ? data.osVer : res.osVer;
				upWhere.$set.devBrnd = (typeof data.devBrnd != 'undefined') ? data.devBrnd : res.devBrnd;
				upWhere.$set.devMdl = (typeof data.devMdl != 'undefined') ? data.devMdl : res.devMdl;				
				if(data.DeviceId && data.DeviceId != ''){
					if(!commonClass.InArray(data.DeviceId, res.dids)){

						upWhere.$push =  {dids : data.DeviceId };
					}
					upWhere.$set['lasts.ldi'] = data.DeviceId;
				}
				if(data.PhoneId && data.PhoneId != ''){
					if(!commonClass.InArray(data.PhoneId, res.dids)){

						upWhere.$push =  {dids : data.PhoneId };
					}
					upWhere.$set['lasts.ldi'] = data.PhoneId;
				}
				if(data.SerialNumber && data.SerialNumber != '' &&  !commonClass.InArray(data.SerialNumber, res.sn)){
					upWhere.$push =  { sn : data.SerialNumber };
				}
					
				if(!res.cbtn){
					upWhere.$set.cbtn = 1;
				}
				
				var dayDiff1 = Math.floor(commonClass.GetTimeDifference(res.cd, new Date())/86400);
				if (dayDiff1 >= 1){
					upWhere.$set.dbf = true;
				}
				else{
					upWhere.$set.dbf = false;
				}
				if(!res.unique_id){
					upWhere.$set.unique_id = "MTR" + commonClass.GetRandomInt(1, 99999999);
				}	

				var dayDiff = commonClass.GetTimeDifference(new Date(), res.cd,'day');
                if(dayDiff > config.TUTF){
                	
                    upWhere.$set['flags._tutf'] = 0;
                }
                
				if(res.tbid != ''){
					
					db.collection('playing_table').findOne({_id:MongoID(res.tbid),$or:[{'pi.uid':res._id.toString()},{'stdP.uid':res._id.toString()}]},function(err,table){
						if(table){

							if(res.rejoin == 0 ){  //special condition for rejoin before disconnect
								
								client.tbid = table._id.toString();
								client.gt = table.gt;
								upWhere.$set.rejoin = 1;  //means direct rejoin
								
							}
							else if(res.rejoin == 2){

								client.tbid = table._id.toString();
								client.gt = table.gt;
								if(table.ap ==  table.ms){  //means table is full and user is not playing as rejoin = 2
									upWhere.$set.rejoin = 3;    ///rejoin = 3 means we have to show only switch table option
								}	
							}
						}
						else{
							upWhere.$set.tbid = '';
							upWhere.$set.rejoin = 0;
							upWhere.$set.rejoinID = '';
						}

						
						cdClass.UpdateUserData(res._id.toString(),upWhere,function(resp){
							if(resp){

								resp.counters.rifc = res.counters.rifc; //setting how many users referred by the user.
								
								if(data.giftCode != ''){
									
									resp.giftCode = data.giftCode;
								}
								
								FBClass.saveGoogleFriends(resp);
								dashboardClass.AUCI(resp, client); //add server instance
							}
							else{
								console.log('googleLoginOrSignup:::::::::111::::::::>>>>"data not updated"  upWhere: ',upWhere,' res._id: '+res._id);
							}
						});
					});
				}
				else{

					upWhere.$set.tbid = '';
					upWhere.$set.rejoin = 0;
					upWhere.$set.rejoinID = '';
					
					cdClass.UpdateUserData(res._id.toString(),upWhere,function(resp){		
						if(resp){
							resp.counters.rifc = res.counters.rifc; //setting how many users referred by the user.
							
							if(data.giftCode != ''){
								
								resp.giftCode = data.giftCode;
							}
							
							
							FBClass.saveGoogleFriends(resp);
							dashboardClass.AUCI(resp, client); //add server instance
						}
						else{
							console.log('googleLoginOrSignup:::::::::::2222::::::::::>>>>>>>"data not updated"  upWhere: ',upWhere,' res._id: '+res._id);
						}
					});
				}
			}
			else{

				if( !data.gid || data.gid == '' || data.gid.trim() == ''){
					return false
				}

				var wh = {$or : [],ult:'guest'};
				if(typeof data.DeviceId != 'undefined' && data.DeviceId != null && data.DeviceId != ''){
					wh['$or'].push({ dids:data.DeviceId});
				}
				if(typeof data.PhoneId != 'undefined' && data.PhoneId != null && data.PhoneId != ''){
					wh['$or'].push({ dids: data.PhoneId});
				}	

				client._isup = 0;
				if(data.det == 'ios' || data.det == 'android'){
					
					db.collection('game_users').findOne(wh,function(err,userInfo){
						
						if(userInfo){
							
							var nwt = (data.nwt)?data.nwt:userInfo.nwt;
							var pp = userInfo.pp;
							var upWhere = {$set:{nwt:nwt,pp:pp,ppId:data.gid,ult:'google',gid:data.fid,ue:data.ue,sck:client.sck,'lasts.pl':userInfo.lasts.ll,'lasts.lltt':new Date(),fat : (data.fat)? data.fat:''}};

							if(data.un){
								upWhere.$set.un = data.un.substr(0,15);
							}

							if(data.det == 'android'){

								
								if(typeof data.verCode != 'undefined' && data.verCode != null){
									upWhere.$set.avc = data.verCode;
								}
								else if(typeof userInfo.avc != 'undefined' && userInfo.avc != null){
									upWhere.$set.avc = userInfo.avc;
								}
								else{
									upWhere.$set.avc = 0;	
								}
							}
							else if(data.det == 'ios'){
								
								if(typeof data.verCode != 'undefined' && data.verCode != null){
									upWhere.$set.ivc = data.verCode;
								}
								else if(typeof userInfo.ivc != 'undefined' && userInfo.ivc != null){
									upWhere.$set.ivc = userInfo.ivc;
								}
								else{
									upWhere.$set.ivc = 0;	
								}
							}
							var diff = 60;
							if(userInfo.lasts.llgt){
								diff = commonClass.GetTimeDifference(userInfo.lasts.llgt,new Date());
							}

							if(diff > 60 && userInfo.flags._io == 0 || data.det == 'flash' || data.det == 'html'){ //means time greater than 60 second = 1 min then update session
								upWhere.$set['lasts.ll'] = new Date();
								upWhere.$set['counters.opc'] = 0;
								upWhere.$inc = {sessId:1};
							}

							if(data.DeviceId && data.DeviceId != ''){
								if(!commonClass.InArray(data.DeviceId, userInfo.dids)){

									upWhere.$push =  {dids : data.DeviceId };
								}
								upWhere.$set['lasts.ldi'] = data.DeviceId;

							}
							if(data.PhoneId && data.PhoneId != ''){
								if(!commonClass.InArray(data.PhoneId, userInfo.dids)){

									upWhere.$push =  {dids : data.PhoneId };
								}
								upWhere.$set['lasts.ldi'] = data.PhoneId;
							}
							if(data.SerialNumber && data.SerialNumber != '' &&  !commonClass.InArray(data.SerialNumber, userInfo.sn)){
								upWhere.$push =  { sn : data.SerialNumber };
							}
							cdClass.UpdateUserChips(userInfo._id.toString(),config.FB_CHIPS,'google signup bonus',function(uChips){

								if(userInfo.tbid != ''){
									
									db.collection('playing_table').findOne({_id:MongoID(userInfo.tbid),$or:[{'pi.uid':userInfo._id.toString()},{'stdP.uid':userInfo._id.toString()}]},function(err,table){
										if(table){

											if(userInfo.rejoin == 0 ){  //special condition for rejoin before disconnect
												
												client.tbid = table._id.toString();
												client.gt = table.gt;
												upWhere.$set.rejoin = 1;  //means direct rejoin
												
											}
											else if(userInfo.rejoin == 2){

												client.tbid = table._id.toString();
												client.gt = table.gt;
												if(table.ap ==  table.ms){  //means table is full and user is not playing as rejoin = 2
													upWhere.$set.rejoin = 3;    ///rejoin = 3 means we have to show only switch table option
												}	
											}
										}
										else{
											upWhere.$set.tbid = '';
											upWhere.$set.rejoin = 0;
											upWhere.$set.rejoinID = '';
										}

										
										
										cdClass.UpdateUserData(userInfo._id.toString(),upWhere,function(upData){
											if(upData){
												
												if(data.giftCode != ''){
													upData.giftCode = data.giftCode;
												}

												trackClass.TrackReferrer(data,upData,false,function(userData1){

													FBClass.saveGoogleFriends(userData1);
													dashboardClass.AUCI(userData1, client);
												});
											}
											else{
												console.log('googleLoginOrSignup:::::::::3333:::::::: wh: ',wh,' upWhere: ',upWhere);
											}
										});	
									});
								}
								else{ //user is not playing in any table
									
									upWhere.$set.tbid = '';
									upWhere.$set.rejoin = 0;
									upWhere.$set.rejoinID = '';
									cdClass.UpdateUserData(userInfo._id.toString(),upWhere,function(upData){
										if(upData){

											if(data.giftCode != ''){
												upData.giftCode = data.giftCode;
											}
											trackClass.TrackReferrer(data,upData,false,function(userData1){

												FBClass.saveGoogleFriends(userData1);
												dashboardClass.AUCI(userData1, client);
											});
											// commonClass.SendData(client,'SP',upData.value);
										}
										else{
											console.log('googleLoginOrSignup::::::::444::::::::::: wh: ',wh,' upWhere: ',upWhere);
										}
									});		
								}
							});
						}
						else{
							signupClass.getUserDefaultFields(data, client,function(UserFields){
								if(UserFields){

									UserFields.Chips = UserFields.Chips + config.FB_CHIPS;
									UserFields.counters.hcl = UserFields.counters.hcl + config.FB_CHIPS;

									db.collection('game_users').save(UserFields , function(err, userData){
										
										if(data.giftCode != ''){
											userData.ops[0].giftCode = data.giftCode;
										}

										trackClass.TrackReferrer(data,userData.ops[0],true,function(userData1){

											FBClass.saveGoogleFriends(userData1);
											dashboardClass.AUCI(userData1, client);
											// commonClass.SendData(client,'SP',userData.ops[0]);
										})
										
									});
								}
								else{
									c('googleLoginOrSignup-------111-------->>>>>"user default fields not found"');
								}
							});
						}
					});
				}
				else if(data.det == 'html'){

					signupClass.getUserDefaultFields(data, client,function(UserFields){//generating all the common fields for userl
						if(UserFields){

							//use for get Download source
							// UserFields.ds = '';
							UserFields.Chips = UserFields.Chips + config.FB_CHIPS;
							UserFields.counters.hcl = UserFields.counters.hcl + config.FB_CHIPS;
							db.collection('game_users').save(UserFields , function(err, userData) {		
								
								if(data.giftCode != ''){
									userData.ops[0].giftCode = data.giftCode;
								}
									
								trackClass.TrackReferrer(data,userData.ops[0],true,function(userData1){

									FBClass.saveGoogleFriends(userData1);
									dashboardClass.AUCI(userData1, client);
								});

							});	
						}
						else{
							c('googleLoginOrSignup-------222-------->>>>>"user default fields not found"');
						}
					}); 
				}
				else{
					c('googleLoginOrSignup--------------->>>>"platform not found"');
				}
			}
		})
	},
	AddUserOtherData: function(uId,callback){  //adds user extra fields
		db.collection('user_friends').insert({uid: uId, friends: []}, function() { callback(); });
	}
}