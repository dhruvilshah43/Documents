module.exports = {
    TEA:function(data,client){ //Track Event Analytics
    },
    Chips_Track : function(userInfo,chips,desc){ // function for chip history storing 
        /* +-------------------------------------------------------------------+
            desc:function for tracking user chips
            i/p: userInfo = user details,chips = chips of user, desc = description
        +-------------------------------------------------------------------+ */
        c('Chips_Track------->>>>chips: ',chips);
        if(!userInfo){
            return false;
        }
        
        var fChips = ((chips + userInfo.Chips) < 0) ? 0 : (chips + userInfo.Chips);
        var inserData = {
        	uid:userInfo._id.toString(),
        	pc:userInfo.Chips,
        	chips:chips,
        	balance:fChips,
        	description:desc,
        	cd : new Date()
        };
        db.collection('chips_track').insertOne(inserData); 
    },
    Cash_Track: function (obj) {
        if (typeof obj.uid == 'undefined')
            return false;

        obj.cd = new Date();
        obj.tc = obj.pc + obj.c;

        c("obj ::::::::",obj);

        db.collection('cash_track').insert(obj, function () { });
    },
    PlayTrack: function(tbid){
        
        cdClass.GetTbInfo(tbid, {}, function (table) {

            var data = {};
            data.cd = new Date();
            data.tbid = tbid.toString();
            data.tjid = table.tjid;
            data._ip = table._ip;
            data.ms = table.ms;
            data.ap = table.ap;
            data.bv = table.bv;
            data.gt = table.gt;
            data.mode = table.mode;
            data.lvc = table.lvc;
            data.win = '';
            data.pi = [];
            data.game_id = table.game_id;
            data.sub_id = table.sub_id;
            data.uCount = table.uCount;
            data.initServer = table.initServer;
            data.ctrlServer = table.ctrlServer;
            data.wildCard = table.wildCard;
            
            for(var i in table.pi){
                var insdata = {
                    uid : table.pi[i].uid,
                    un : table.pi[i].un,
                    si : table.pi[i].si,
                    thp : table.pi[i].thp,
                    _ir : table.pi[i]._ir
                };

                data.pi.push(insdata);
            }

            c("PlayTrack-------------->>>>>>>data to insert:",data);
            db.collection("play_track").save(data,function(err,td){})
        });
    },
    TrackReferrer: function (data, userData, isWholeNew,callback) {
        /* +-------------------------------------------------------------------+
            desc:function to handle user reference logic
            i/p: data = {
                        fid =  facebook id 
                        rfc = referral code 
                        request = request id       
                    }
                 userData = user details
                 callback = callback function
        +-------------------------------------------------------------------+ */
        var refCode = data.rfc;
        c("TrackReferrer-------------->>>refCode: " +refCode+' userData.flags._isRefered: '+userData.flags._isRefered);
        if(userData && userData.flags && userData.flags._isRefered != 1){

            if(typeof refCode != 'undefined' && refCode != null && refCode != '' && refCode.split('-').length == 2) {
                refCode = refCode.split('-');
                //first we need to check ip in request_track table
                       
                db.collection('game_users').findOne({rfc:refCode[0]},function(err1,result){
                    if(result){
                        c('TrackReferrer------------>>>>>"code has been refered"');
                        var check = false;
                        if(refCode[1] == 'WP'){
                            c('TrackReferrer------------>>>>>WP');

                            if(result.det == 'android' || result.det == 'ios'){
                                
                                cdClass.UpdateUserData(result._id.toString(),{$inc:{'counters.invC':1}});
                                cdClass.UpdateUserChips(result._id.toString(), config.IWR, "Whatsapp Invite Bonus");  
                                cdClass.UpdateUserData(userData._id.toString(),{$set:{'flags._isRefered':1}});
                            }
                            else{

                                db.collection('refer_track').insertOne({cd:new Date(),sendId:result._id,recvId:userData._id,type:'WP',pp:userData.pp,un:userData.un});
                            }
                        }
                        else if(refCode[1] == 'FB'){
                            c('TrackReferrer------------>>>>>FB');
                            if(result.det == 'android' || result.det == 'ios'){

                                cdClass.UpdateUserData(result._id.toString(),{$inc:{'counters.invC':1}});
                                cdClass.UpdateUserChips(result._id.toString(), config.IFR, "Facebook Invite Bonus");  
                                cdClass.UpdateUserData(userData._id.toString(),{$set:{'flags._isRefered':1}});
                            }
                            else{

                                db.collection('refer_track').insertOne({cd:new Date(),sendId:result._id,recvId:userData._id,type:'FB',pp:userData.pp,un:userData.un});
                            }
                        }
                        else{
                            c('TrackReferrer------------>>>>>referrer source not found');
                        }
                        
                    }
                    else{
                        c('TrackReferrer------------>>>"referrer user not found"');
                    }
                });
            } 
            else {
                
                c('TrackReferrer------------>>>>>data.fid: '+data.fid+' data.request: '+data.request);
                db.collection('invite_friends').find({to:data.fid}).sort({cd:1}).limit(1).toArray(function(err,resp){
                    if(resp && resp.length > 0){ //fb invite logic here
                        c('TrackReferrer-------------->>>>>>>resp: ',resp);
                        db.collection('invite_friends').update({to:data.fid},{$pull:{to:data.fid}},{multi:true},function(){
                            db.collection('invite_friends').remove({to:[]},function(){});
                        });
                        
                        cdClass.GetUserInfo(resp[0].uid,{det:1,avc:1,iv:1},function(result){
                            if(result.det == 'android' || result.det == 'ios'){

                                cdClass.UpdateUserData(resp[0].uid,{$inc:{'counters.invC':1}});
                                cdClass.UpdateUserChips(resp[0].uid, config.IFR, "Facebook Invite Bonus");  
                                cdClass.UpdateUserData(userData._id.toString(),{$set:{'flags._isRefered':1}});
                            }
                            else{

                                db.collection('refer_track').insertOne({cd:new Date(),sendId:MongoID(resp[0].uid),recvId:userData._id,type:'FB',pp:userData.pp,un:userData.un});
                            }
                        });
                    }
                    else{
                        if(userData.det == 'ios' || userData.det == 'android'){ //messenger invite here
                            db.collection('request_track').findOne({ip: userData.ipad}, function (err1,trackInfo) {
                                if(trackInfo && trackInfo.refCode && trackInfo.refCode.split('-').length == 2){
                                    
                                    c('TrackReferrer-------------->>>>trackInfo: ',trackInfo);
                                    refCode = trackInfo.refCode.split('-');
                                    db.collection('game_users').findOne({rfc:refCode[0]},function(err2,result){
                                        if(result){
                                            c('TrackReferrer------------>>>>>"code has been refered"');
                                            if(refCode[1] == 'WP'){
                                                c('TrackReferrer------------>>>>>WP');
                                                if(result.det == 'android' || result.det == 'ios'){

                                                    cdClass.UpdateUserData(result._id.toString(),{$inc:{'counters.invC':1}});
                                                    cdClass.UpdateUserChips(result._id.toString(), config.IWR, "Whatsapp Invite Bonus");  
                                                    cdClass.UpdateUserData(userData._id.toString(),{$set:{'flags._isRefered':1}});
                                                }
                                                else{

                                                    db.collection('refer_track').insertOne({cd:new Date(),sendId:result._id,recvId:userData._id,type:'WP',pp:userData.pp,un:userData.un});
                                                }
                                            }
                                            else if(refCode[1] == 'FB'){
                                                c('TrackReferrer------------>>>>>FB');
                                                if(result.det == 'android' || result.det == 'ios'){

                                                    cdClass.UpdateUserData(result._id.toString(),{$inc:{'counters.invC':1}});
                                                    cdClass.UpdateUserChips(result._id.toString(), config.IFR, "Facebook Invite Bonus");  
                                                    cdClass.UpdateUserData(userData._id.toString(),{$set:{'flags._isRefered':1}});
                                                }
                                                else{

                                                    db.collection('refer_track').insertOne({cd:new Date(),sendId:result._id,recvId:userData._id,type:'FB',pp:userData.pp,un:userData.un});
                                                }
                                            }
                                            else{
                                                c('TrackReferrer------------>>>>>referrer source not found');
                                            }
                                        }
                                        else{
                                            c('TrackReferrer------------>>>"referrer user not found"');
                                        }
                                    });
                                }
                            });
                        }

                        c('TrackReferrer------------>>>"not referred user"');
                    }
                });
            }
        }
        
        if(isWholeNew){
            
            rq.post('http://wthpl.in/createLink', {
                form: {
                    url: config.BU + 'referrer?t=' + commonClass.uenc(commonClass.Enc(userData.rfc+'-WP'))
                    
                }
            },function (error, response, body) {
                if (!error && response.statusCode == 200){
                    userData.rflWp = body;
                }
                else{
                    userData.rflWp = null;
                }

                rq.post('http://wthpl.in/createLink', {
                    form: {
                        url: config.BU + 'referrer?t=' + commonClass.uenc(commonClass.Enc(userData.rfc+'-FB'))
                        
                    }
                },function (error2, response2, body2) {
                    if (!error2 && response2.statusCode == 200){
                        userData.rflFb = body2;
                    }
                    else{
                        userData.rflFb = null;
                    }

                    db.collection('game_users').update({_id: userData._id}, {$set: {rflWp: body,/*rflMg: body1,*/rflFb: body2}}, function () {});
                    return callback(userData);
                });
            });
        }
        else{
            c('TrackReferrer---------------->>>>>>old user');
            return callback(userData);
        }
    },
    dauMau : function(uid, ldt){ //daily/monthly active user trackin
        /* +-------------------------------------------------------------------+
            desc:function to track daily active user and monthly active user
            i/p: uid = user id,ldt = last device type
        +-------------------------------------------------------------------+ */
        var det = ldt.toLowerCase();
        if(commonClass.InArray(det, ["android","ios","html"]))
        {
            var mString = new Date().getFullYear()+"-"+(new Date().getMonth()+1);
            var upData = { $addToSet : {}, $inc : {} };
            upData.$inc[det] = 1;
            upData.$addToSet["uid_"+det] = uid;
            var wh1 = { mString : mString, type : "month" };
            wh1['uid_'+det] = { $ne : uid };
            
            db.collection("track_au").update(wh1,upData, function(err){ });
            
            var dString = new Date().getFullYear()+"-"+(new Date().getMonth()+1)+"-"+new Date().getDate();
            var wh2 = { dString : dString, type : "day" };
            wh2['uid_'+det] = { $ne : uid };
            db.collection("track_au").update(wh2, upData, function(err,upd){ 
                if(upd){
                    cdClass.GetUserInfo(uid,{Chips:1},function(userInfo){
                       if(userInfo){

                           db.collection('dailyUserChips').save({uid:MongoID(uid),Chips:userInfo.Chips,dString:dString,cd:new Date()},function(){                            
                           });
                       }
                       else{
                         c('dauMau-------------->>>>"user not found"');
                       }
                    });
                }
            });
        }
    },
    monitorUsers: function () {
        rClient.get("onlinePlayers", function (err, counter) {
            if (!err && counter)
            {
                var today = commonClass.GetFormatedDate(new Date());
                //c("Players >>" + counter);//LOG
                db.collection('dhu').find({day: today}).limit(1).toArray(function (err, resp) {
                    if (resp && resp.length == 0){
                        db.collection('dhu').insert({day: today, players: parseInt(counter),currentPlayers: parseInt(counter), lowestPlayer:(parseInt(counter)*5),time: new Date(),ltime: new Date()}, function () {});
                    }
                    else
                    {
                        db.collection('dhu').update({day: today, players: {$lt: parseInt(counter)}}, {$set: {players: parseInt(counter),time: new Date()}}, function () {});
                        db.collection('dhu').update({day: today}, {$set: {currentPlayers: parseInt(counter)}}, function () {});
                        db.collection('dhu').update({day: today,lowestPlayer: {$gt: parseInt(counter)}}, {$set: { lowestPlayer: parseInt(counter),ltime: new Date()}}, function () {});
                    }

                });
            }
        });
    }
}