const PURE = 0, IMPURE = 1, SET = 2;

module.exports = {
	GetSortedCard: (cards, wildCard) => {
        /* +-------------------------------------------------------------------+
            desc: returns object with cards grouping
            i/p : cards = array of cards, wildCard = wildcard
            o/p : object = {
                    pure = 2D array of pure sequence
                    seq = 2D array of impure sequence
                    set = 2D array of sets
                    dwd = array of deadwood 
                    cardSum = valid cards points
                  }
           +-------------------------------------------------------------------+ */
        c('GetSortedCard------1----->>>>cards: ',cards);

		var userCard = _.clone(cards);
		var foundPureList = [];
		var foundImpureList = [];
		var foundSetList = [];

        var PURES = [];
        var SEQS = [];
        var SETS = [];
        var DWDS = [];

		//--------CHECK PURE COUNTINUSLY IF FOUND-----------------------------------------------------------------------------------
       
        for (let maxLoop = 0; maxLoop < 6; maxLoop++) {

			var pureList = gbClass.getPureSequence(userCard, wildCard); //got pure with 3 cards
            c('GetSortedCard----------->>>>pureList: ', pureList);
			if (pureList.length >= 3) {
				foundPureList.push(pureList);
				userCard = _.difference(userCard, pureList);
			} else {
				c('GetSortedCard ---------->>>>"No more pure list found..."');
                break; 
			}
		}
        c('GetSortedCard---------->>>foundPureList: ', foundPureList,' userCard: ',userCard);
		//--------------------------------------------------------------------------------------------------------------------------

		//--------CHECK ONE IMPURE 3 CARD LIST 1ST TIME-----------------------------------------------------------------------------
		var impureList = gbClass.getImpureSequence(userCard, wildCard); //got 3 cards impure
        c('GetSortedCard------>>>impureList: ', impureList);
		if (impureList.length >= 3) {
            foundImpureList.push(impureList);
            userCard = _.difference(userCard, impureList);
        } else {
            c('GetSortedCard---------->>>>"No more Impure List Found in first Impure Check..."');
        }  
        c('GetSortedCard---------->>>foundImpureList: ', foundImpureList,' userCard: ',userCard);
        //--------------------------------------------------------------------------------------------------------------------------


        //--------FIND BEST RESULT FROM IMPURE AND SET ONE TIME---------------------------------------------------------------------
       
        for (let maxLoop = 0; maxLoop < 6; maxLoop++) {

            var  bestList = gbClass.getBestFromThree(userCard, wildCard);
            c('GetSortedCard-----4546----->>>>>bestList: ',bestList);
            if (bestList == null) {
                
                break;
            } else if (bestList.groupType == IMPURE) {
                
                foundImpureList.push(bestList.cardObjectList);
                userCard = _.difference(userCard, bestList.cardObjectList);
            } else if (bestList.groupType == SET)  {
                
                foundSetList.push(bestList.cardObjectList);               
                userCard = _.difference(userCard, bestList.cardObjectList);
            }
        }
        ////--------------------------------------------------------------------------------------------------------------------------

        //------------ADD EXTRA IN PURE LIST----------------------------------------------------------------------------------------
        c('GetSortedCard------744----->>>>foundPureList: ',foundPureList,' foundImpureList: ',foundImpureList  ,' userCard: ',userCard);

        for (let i = 0; i < foundPureList.length; i++) {
            var len = foundPureList[i].length;
			foundPureList[i] = gbClass.addRemainingInPureList(foundPureList[i], userCard, wildCard);
            if (len != foundPureList[i].length) {
                i--;
            }
            userCard = _.difference(userCard, foundPureList[i]);
			c('GetSortedCard----54678----->>>>"Add Extra card in Pure list..." userCard: ',userCard);
        } 
        //--------------------------------------------------------------------------------------------------------------------------


        //------------ADD EXTRA IN IMPURE LIST--------------------------------------------------------------------------------------

        var getImPureWithExtraCard = [];
        var checkedImpure = [];
        var newImpure = [];

        c('GetSortedCard---11212----->>>>>foundImpureList: ',foundImpureList,' userCard: ',userCard);
        for (let i = 0; i < foundImpureList.length; i++) {
            
            var checkingList = foundImpureList[i];
            c('GetSortedCard--------->>>>>checkingList: ',checkingList,' userCard: ',userCard);
            getImPureWithExtraCard = gbClass.addRemainingInImpureList(checkingList, userCard, wildCard);
            c('GetSortedCard--------->>>>getImPureWithExtraCard: ',getImPureWithExtraCard,' userCard: ',userCard);
            checkedImpure.push(checkingList);
            newImpure.push(getImPureWithExtraCard.foundList);
            userCard = getImPureWithExtraCard.userRemainCard;
            userCard = _.difference(userCard, getImPureWithExtraCard.foundList);
        }

        c('GetSortedCard------3123---->>>>>newImpure: ',newImpure,' checkedImpure: ',checkedImpure,' foundImpureList: ',foundImpureList,' userCard: ',userCard);
        for (let i in checkedImpure) {

            foundImpureList = gbClass.removeArrayFrom2DArray(foundImpureList,checkedImpure[i]);
        }
        c('GetSortedCard----0000------->>>>foundImpureList: ',foundImpureList);
        foundImpureList =  foundImpureList.concat(newImpure);
        c('GetSortedCard----1111------->>>>foundImpureList: ',foundImpureList);
        //--------------------------------------------------------------------------------------------------------------------------


        //--------CHECK ONE SET 3 CARD LIST 1ST TIME-----------------------------------------------------------------------------
        c('GetSortedCard----12312---->>>userCard: ',userCard);
        for (let maxLoop = 0; maxLoop < 6; maxLoop++) {

            var setList = gbClass.getSet(userCard, wildCard);
            
            if (setList.length >= 3) {
                foundSetList.push(setList);
                userCard = _.difference(userCard, setList);
            } else {
                c('GetSortedCard------>>>>"No more Set Found in first Check..."');
                break;
            }
        }
        //--------------------------------------------------------------------------------------------------------------------------

         //-----------highest impure with 2 joker--------------------------------------------------------------------------------------
        var moreImpure = gbClass.makeImpureWithHighestCard(userCard, wildCard);
        c('GetSortedCard------>>>>>moreImpure: ',moreImpure,' userCard: ',userCard);
        for (let i = 0; i < moreImpure.length; i++) {
            foundImpureList.push(moreImpure[i]);
            userCard = _.difference(userCard, moreImpure[i]);
        }
        c('GetSortedCard--------->>>>>"GetSortedCardHigest Impure with 2 joker...  = "' + moreImpure.length+' userCard: ',userCard);
        c('GetSortedCard----2222----->>>foundImpureList: ',foundImpureList);
        ////-------------------------------------------------------------------------------------------------------------------------

        PURES = foundPureList;
        SEQS = foundImpureList;
        SETS = foundSetList;
        DWDS = userCard;
     	
        var group = {pure:PURES,seq:SEQS,set:SETS,dwd:DWDS};
        c('GetSortedCard--------->>>>>group: ',group);
        var obj = {pure: PURES,seq: SEQS, set: SETS, dwd: DWDS,cardSum: cardsClass.cardsValidPoints(group,wildCard)};

        
        
        return obj;
	},
	removeArrayFrom2DArray: (array2D, array1D) => {
    	/* +-------------------------------------------------------------------+
			desc: remove whole array from 2D array
			i/p: array2D = 2d array from which array is to be removed, array1D = 1D array
			o/p: returns formatted currency 
		+-------------------------------------------------------------------+ */

		for(var i = 0; i < array2D.length; i++){
			
			if(_.isEqual(array2D[i],array1D)){
				array2D.splice(i,1);
				break;
			}
		}
		return array2D;
    },
	getPureSequence: (cards,wildCard) => {
		/* +-------------------------------------------------------------------+
            desc: returns pure sequence
            i/p : cards = array of cards, wildCard = wildcard
            o/p : pure sequence array
           +-------------------------------------------------------------------+ */
        

        var Cardlist = cardsClass.sortCards(cards,false).reverse();

        c('getPureSequence---------->>>>Cardlist: ',Cardlist);
        var classify = cardsClass.classifyCards(Cardlist);
        c('getPureSequence---------->>>>classify: ',classify);
        
        var  HList =  gbClass.getThreeCardPure(classify.l);
        c('getPureSequence---------->>>>HList: ',HList);
        var  SList = gbClass.getThreeCardPure(classify.k);
        c('getPureSequence---------->>>>SList: ',SList);
        var  CList = gbClass.getThreeCardPure(classify.f);
        c('getPureSequence---------->>>>CList: ',CList);
        var DList = gbClass.getThreeCardPure(classify.c);
        c('getPureSequence---------->>>>DList: ',DList);
        //Sum of Pure Sequals all 4 colour
        let Ssum = cardsClass.cardsSum(SList,wildCard);
        let Hsum = cardsClass.cardsSum(HList,wildCard);
        let Dsum = cardsClass.cardsSum(DList,wildCard);
        let Csum = cardsClass.cardsSum(CList,wildCard);
        
        c('getPureSequence---------->>>HList: ',HList,' SList: ',SList,' CList: ',CList,' DList: ',DList);
        c('getPureSequence---------->>>>Ssum: '+Ssum+' Hsum: '+Hsum+' Dsum: '+Dsum+' Csum: '+Csum);
        //Sorting in Pure Sequals in highest in all 4 colour
        var  sortings = [];

        sortings.push({cardList: SList, sum: Ssum});
        sortings.push({cardList: HList, sum: Hsum});
        sortings.push({cardList: DList, sum: Dsum});
        sortings.push({cardList: CList, sum: Csum});

        c('getPureSequence---------->>>sortings: ',sortings);
        //return highest first sorting Sequence
        sortings.sort(function(a,b){
			return (b.sum - a.sum);
		});
       
        
        
        return sortings[0].cardList;
	},
	getImpureSequence: (cards,wildCard) => {
        /* +-------------------------------------------------------------------+
            desc: returns pure sequence
            i/p : cards = array of cards, wildCard = wildcard
            o/p : returns impure sequence
           +-------------------------------------------------------------------+ */
		//Short card decending order
        
        var sortedCards = cardsClass.sortCards(cards,false).reverse();

        c('getImpureSequence-------------->>>>"CardList sorted List"' ,sortedCards);      


        

        var H_color = [];
        var S_color = [];
        var C_color = [];
        var D_color = [];
        var Joker = [];


        //Short card Colorwise
        for (let i = 0; i < sortedCards.length; i++) {
            if (sortedCards[i].split('-')[0] == 'j' || parseInt(sortedCards[i].split('-')[1]) == parseInt(wildCard.split('-')[1])) {
                Joker.push(sortedCards[i]);
            } else if (sortedCards[i].split('-')[0] == 'l') {
                H_color.push(sortedCards[i]);
            } else if (sortedCards[i].split('-')[0] == 'c') {
                D_color.push(sortedCards[i]);
            } else if (sortedCards[i].split('-')[0] == 'k') {
                S_color.push(sortedCards[i]);
            } else if (sortedCards[i].split('-')[0] == 'f') {
                C_color.push(sortedCards[i]);
            }
        }


        c('getImpureSequence------------>>>>H_color: ',H_color,' S_color: ',S_color,'C_color: ',C_color,' D_color: ',D_color,' Joker: ',Joker);
        let gap = 1;
        var selectedItem = null;
        var  sortings = [];
        
        while (gap <= 3) {
            let HimpureList2 = gbClass.getTwoCardImpure(H_color, gap);
            
            let SimpureList2 = gbClass.getTwoCardImpure(S_color, gap);
            
            let CimpureList2 = gbClass.getTwoCardImpure(C_color, gap);
            
            let DimpureList2 = gbClass.getTwoCardImpure(D_color, gap);

            c('getImpureSequence----------->>>gap: ',gap,' HimpureList2: ',HimpureList2,' SimpureList2: ',SimpureList2,' CimpureList2: ',CimpureList2,' DimpureList2: ',DimpureList2);

            let Hsum2 = cardsClass.cardsSum(HimpureList2, wildCard);
            let Ssum2 = cardsClass.cardsSum(SimpureList2, wildCard);
            let Csum2 = cardsClass.cardsSum(CimpureList2, wildCard);
            let Dsum2 = cardsClass.cardsSum(DimpureList2, wildCard);


            let tmpGap = gap - 1;
            
            c('getImpureSequence----------->>>>tmpGap: '+tmpGap+' Hsum2: '+Hsum2+' Ssum2: '+Ssum2+' Csum2: '+Csum2+' Dsum2: '+Dsum2);


            if (HimpureList2.length >= 2) {
                sortings.push({cardList: HimpureList2, sum: Hsum2, gap: tmpGap});
                H_color = _.difference(H_color, HimpureList2);
            }

            if (SimpureList2.length >= 2) {
                sortings.push({cardList: SimpureList2, sum: Ssum2, gap: tmpGap});
                S_color = _.difference(S_color, SimpureList2);
            }

            if (CimpureList2.length >= 2) {
                sortings.push({cardList: CimpureList2, sum: Csum2, gap: tmpGap});
                C_color = _.difference(C_color, CimpureList2);            
            }

            if (DimpureList2.length >= 2) {
                sortings.push({cardList: DimpureList2, sum: Dsum2, gap: tmpGap});
                D_color = _.difference(D_color, DimpureList2);
            }

            gap++;

            let chk = gap <= 2 ? 1 : gap;
            if (chk > Joker.length) {
                break;
            }

            if (HimpureList2.length >= 2 || SimpureList2.length >= 2 || CimpureList2.length >= 2 || DimpureList2.length >= 2) {
                gap--;
            }

            c('getImpureSequence----------->>>>"2222 Gap count = " ' + gap);
        }

        sortings.sort(function(a,b){
			return (b.sum - a.sum);
		});


        
        if (sortings.length > 0 && sortings[0].cardList.length >= 2) {
            selectedItem = sortings[0];
        }

       

        //check Joker in the Joker array list
        if (selectedItem != null && selectedItem.cardList.length >= 2) {
            gap = selectedItem.gap;

            if (gap <= 0) {
                gap = 1;
            }

            c('getImpureSequence---------->>>>"GGGGGaaappp count = "' + gap);

            if (Joker.length >= gap) {
                for (let i = 0; i < gap; i++) {
                    selectedItem.cardList.push(Joker[i]);
                }

                selectedItem.cardList = cardsClass.sortCards(selectedItem.cardList,false);

                c('getImpureSequence------------>>>"Impure Only..."',selectedItem.cardList);
                
                
                return selectedItem.cardList;
            } else {
                
                
                return [];
            }
        } else {
            
            
           return [];
        }
	},
	getBestFromThree: (cards, wildCard) => {
        /* +-------------------------------------------------------------------+
            desc: returns object containg best among impure and set
            i/p : cards = array of cards, wildCard = wildcard
            o/p : obj = {
                cardObjectList = array of impure sequence or set,
                sum = sum of cards point,
                groupType =  code IMPURE/SET
            }
           +-------------------------------------------------------------------+ */
		//CHECK ONE IMPURE 3 CARD LIST
        
        var impureList = gbClass.getImpureSequence(cards, wildCard); //got highest seq 
        c('getBestFromThree---------->>>>impureList: ',impureList);
        //CHECK ONE SET 3 CARD LIST
        var setList = gbClass.getSet(cards, wildCard); //got highest set 
        c('getBestFromThree------------>>>>setList: ',setList);

        let impureSequenceSum = cardsClass.cardsSum(impureList, wildCard);
        let setSum = cardsClass.cardsSum(setList, wildCard);
        c('getBestFromThree------------->>>>impureSequenceSum: '+impureSequenceSum+' setSum: ',setSum);
        var sortingsPure = [];

      
        if (impureList.length >= 3) {
            var  impure1 = {cardObjectList: impureList, sum: impureSequenceSum, groupType: IMPURE};
            sortingsPure.push(impure1);
        }

        if (setList.length >= 3) {
            var set1 = {cardObjectList: setList,sum: setSum, groupType: SET};
            sortingsPure.push(set1);
        }

        if (sortingsPure.length >= 2) {
            c('getBestFromThree------------>>>>>sortingsPure: ',sortingsPure);
            sortingsPure.sort(function(a,b){
                return (b.sum - a.sum);
            });
        }

        var bestList = null;

        if (sortingsPure.length > 0) {
            bestList = sortingsPure[0];
        }
        c('getBestFromThree---------->>>>"find Best result from Set and Impure sequence...  "' , bestList);
        
        
        return bestList;
	},
	addRemainingInPureList: (targetPureList, cards, wildCard) => {
        /* +-------------------------------------------------------------------+
            desc: returns array of pure sequence
            i/p : targetPureList = array in which to add new card to form a pure ,cards = array of cards, wildCard = wildcard
            o/p : array of pure sequence
           +-------------------------------------------------------------------+ */
		var Joker = [];

        var  userCardListNew = _.clone(cards);


        for (let i = 0; i < userCardListNew.length; i++) {
            if (userCardListNew[i].split('-')[0] == 'j') {
                Joker.push(userCardListNew[i]);
                userCardListNew = _.without(userCardListNew, userCardListNew[i]);
                i--;
            }
        }
        
        
        targetPureList = cardsClass.sortCards(targetPureList, false).reverse();

        var firstCard = targetPureList[0];
        var lastCard = targetPureList[targetPureList.length-1];
        let firstAdded = false;
        let lastAdded = false;

        if (parseInt(firstCard.split('-')[1]) != 13) {
            let ind = gbClass.containsCardNoType(userCardListNew, parseInt(firstCard.split('-')[1]) + 1, firstCard.split('-')[0]);
            c('addRemainingInPureList------>>>>ind: '+ind+' firstCard: '+firstCard+' userCardListNew[ind]: '+userCardListNew[ind]);
            if (ind != -1 && firstCard.split('-')[0] == userCardListNew[ind].split('-')[0]) {
               
                targetPureList.push(userCardListNew[ind]);
                c('addRemainingInPureList--312313123--->>>>>targetPureList: ',targetPureList,' userCardListNew[ind]: ',userCardListNew[ind]);
                userCardListNew = _.without(userCardListNew, userCardListNew[ind]);
                cards = _.without(cards, cards[ind]);
                firstAdded = true;
            }
        } else {
            if (parseInt(lastCard.split('-')[1]) != 1) {
                let ind = gbClass.containsCardNoType(userCardListNew, 1, lastCard.split('-')[0]);
                if (ind != -1 && lastCard.split('-')[0] == userCardListNew[ind].split('-')[0]) {
                    targetPureList.push(userCardListNew[ind]);
                    userCardListNew = _.without(userCardListNew, userCardListNew[ind]);
                    cards = _.without(cards, cards[ind]);
                    firstAdded = true;
                }
            }
        }


        if (!firstAdded) {
            if (parseInt(lastCard.split('-')[1]) == 1 && parseInt(targetPureList[targetPureList.length - 2].split('-')[1]) != 2) {
                lastCard = targetPureList[targetPureList.length - 2];
            }

            let ind = gbClass.containsCardNoType(userCardListNew, parseInt(lastCard.split('-')[1]) - 1, lastCard.split('-')[0]);
            c('addRemainingInPureList----gdfgdg--->>>>ind: '+ind+' userCardListNew[ind]: '+userCardListNew[ind]+' lastCard: '+lastCard);
            if (ind != -1 && lastCard.split('-')[0] == userCardListNew[ind].split('-')[0]) {
                targetPureList.push(userCardListNew[ind]);
                userCardListNew = gbClass.removeArrayFrom2DArray(userCardListNew, userCardListNew[ind]);
                cards = _.without(cards,cards[ind]);
                lastAdded = true;
            }
        }
        c('addRemainingInPureList------->>>>targetPureList: ',targetPureList);
        
        
        return targetPureList;
	},
	addRemainingInImpureList: (targetImpure, userRemainCard, wildCard) => {
        /* +-------------------------------------------------------------------+
            desc: returns array of impure sequence
            i/p : targetPureList = array in which to add new card to form a pure ,userRemainCard = array of cards, wildCard = wildcard
            o/p : array of impure sequence
           +-------------------------------------------------------------------+ */
        var targetNormalList = [];
        var targetJokerList = [];

        var userNormalList = [];
        var userJokerList = [];


        for (let i = 0; i < targetImpure.length; i++) {
            if (targetImpure[i].split('-')[0] == 'j' || parseInt(targetImpure[i].split('-')[1]) == parseInt(wildCard.split('-')[1])) {
                targetJokerList.push(targetImpure[i]);
            } else {
                targetNormalList.push(targetImpure[i]);
            }
        }

        targetNormalList = cardsClass.sortCards(targetNormalList, false).reverse();
        c('addRemainingInImpureList------>>>>>targetNormalList: ',targetNormalList,' targetJokerList: ',targetJokerList);

        for (let i = 0; i < userRemainCard.length; i++) {
            if (userRemainCard[i].split('-')[0] == 'j' || parseInt(userRemainCard[i].split('-')[1]) == parseInt(wildCard.split('-')[1])) {
                userJokerList.push(userRemainCard[i]);
            } else {
                userNormalList.push(userRemainCard[i]);
            }
        }


        userJokerList = userJokerList.concat(targetJokerList);
        c('addRemainingInImpureList----->>>userJokerList: ',userJokerList,' targetJokerList: ',targetJokerList);


        var foundList = _.clone(targetNormalList);
        var tmpList = _.clone(targetNormalList); // only for gap calculation


        foundList = cardsClass.sortCards(foundList,false).reverse();
        tmpList = cardsClass.sortCards(tmpList,false).reverse();
        

        let ind1 = gbClass.containsCardNo(tmpList, 1);
        let ind2 = gbClass.containsCardNo(tmpList, 2);
        let ind3 = gbClass.containsCardNo(tmpList, 3);
        let ind4 = gbClass.containsCardNo(tmpList, 4);
        c('addRemainingInImpureList----->>>ind1: '+ind1+' ind2: '+ind2+' ind3: '+ind3+' ind4: '+ind4);
        if (ind1 != -1 && (ind2 == -1 && ind3 == -1 && ind4 == -1)) {
           
            var tempCard = tmpList[ind1];
            
            tmpList = _.without(tmpList, tmpList[ind1]);
            
            tmpList.splice(0,0,tempCard);
        }
        c('addRemainingInImpureList----->>>tmpList: ',tmpList);
        let gap = 1;
        let needToAddJoker = 0;
        for (let i = 0; i < tmpList.length - 1; i++) {
            let cc = parseInt(tmpList[i].split('-')[1]);
            cc = (i == 0 && cc == 1) ? 14 : cc;
            let a = cc - parseInt(tmpList[i + 1].split('-')[1]) - 1;

            if (a >= 1) {
                needToAddJoker += a;
            }
        }

        var needToBreak = false;
        if (targetNormalList.length >= 1) {
            while (true) {

                foundList = cardsClass.sortCards(foundList,false).reverse();
                c('addRemainingInImpureList------->>>foundList: ',foundList);
                var first = foundList[0];
                let req = parseInt(first.split('-')[1]) + (gap <= 0 ? 1 : gap);

                if (req == 14) {
                    req = 1;
                } else if (req > 14) {
                    break;
                }

                let index = gbClass.containsCardNoType(userNormalList, req, first.split('-')[0]);
                c('addRemainingInImpureList------->>>>index: ',index,' req: ',req);
                if (gbClass.containsCardNoType(foundList, req, first.split('-')[0]) == -1 && index != -1) {
                    foundList.push(userNormalList[index]);
                
                    userNormalList = _.without(userNormalList,userNormalList[index]);
                   
                    needToAddJoker += (gap == 2 ? 1 : (gap <= 1  ? 0 : gap));
                    gap = 1;
                    needToBreak = false;
                }
                else {
                    gap++;
                }

                let gapCheck = gap - 1;
                gapCheck = (gapCheck <= 2) ? 1 : gapCheck;
                
                if (needToBreak || needToAddJoker >= userJokerList.length || gapCheck > userJokerList.length) {
                    break;
                }

                needToBreak = gap >= 2;
            }


            gap = 1;
            needToBreak = false;
            c('addRemainingInImpureList------>>>needToAddJoker: '+needToAddJoker+' userJokerList: ',userJokerList);
            if (needToAddJoker < userJokerList.length) {
                while (true) {
                    foundList = cardsClass.sortCards(foundList, false).reverse();

                    var first = foundList[foundList.length - 1];
                    if (foundList.length >= 2 && parseInt(first.split('-')[1]) == 1 && gbClass.containsCardNoType(foundList, 2, first.split('-')[0]) == -1) {
                        first = foundList[foundList.length - 2];
                    }

                    let req = parseInt(first.split('-')[1]) - (gap <= 0 ? 1 : gap);

                    let index = gbClass.containsCardNoType(userNormalList, req, first.split('-')[0]);
                    c('addRemainingInImpureList---2222->>>req: '+req+' index: '+index);

                    if (gbClass.containsCardNoType(foundList, req, first.split('-')[0]) == -1 && index != -1) {
                        foundList.push(userNormalList[index]);

                        userNormalList = _.without(userNormalList, userNormalList[index]);
                        
                        needToAddJoker += (gap == 2 ? 1 : (gap <= 1 ? 0 : gap));
                        gap = 1;
                        needToBreak = false;
                    } else {
                        gap++;
                    }

                    let gapCheck = gap - 1;
                    gapCheck = gapCheck <= 2 ? 1 : gapCheck;
                    
                    if (needToBreak || needToAddJoker >= userJokerList.length || gapCheck > userJokerList.length) {
                        
                        break;
                    }
                    needToBreak = gap >= 2;
                }
            }

            
            for (let i = 0; i < needToAddJoker; i++) {
                foundList.push(userJokerList[i]);
            }

            
            userJokerList = _.difference(userJokerList, foundList);
            c('addRemainingInImpureList------------->>>userJokerList: ',userJokerList,' foundList: ',foundList,' targetImpure: ',targetImpure);
            userRemainCard = [];
            userRemainCard = userRemainCard.concat(userJokerList);
            userRemainCard = userRemainCard.concat(userNormalList);   
        }

        if (foundList.length >= 3) {
            
            
            return {foundList: foundList, userRemainCard: userRemainCard};
        }
        else{
            
            
            return {foundList: targetImpure, userRemainCard: userRemainCard};
        }
	},
	getSet: (cardList, wildCard) => {
		/* +-------------------------------------------------------------------+
            desc: returns array of set
            i/p : cardList = array of cards, wildCard = wildCard
            o/p : array set
           +-------------------------------------------------------------------+ */
        cardList = cardsClass.sortCards(cardList, false).reverse();
        
        var all_color = [];
        var Joker = [];

        //Short card Colorwise
        for (let i = 0; i < cardList.length; i++) {
            if (cardList[i].split('-')[0] == 'j' || parseInt(cardList[i].split('-')[1]) == wildCard.split('-')[1]) {
                Joker.push(cardList[i]);
            } else if (cardList[i].split('-')[0] != 'j' ) {
                all_color.push(cardList[i]);
            }
        }
        var all_Color4Set = gbClass.getSetCardList(all_color, 4);
        all_color = _.difference(all_color, all_Color4Set);
        var all_Color3Set = gbClass.getSetCardList(all_color, 3);
        all_color = _.difference(all_color, all_Color3Set);
        var all_Color2Set = gbClass.getSetCardList(all_color, 2);
        all_color = _.difference(all_color, all_Color2Set);



        let set4 = cardsClass.cardsSum(all_Color4Set, wildCard);
        let set3 = cardsClass.cardsSum(all_Color3Set, wildCard);
        let set2 = cardsClass.cardsSum(all_Color2Set, wildCard);


        var sortings = [];

        sortings.push({cardObjectList: all_Color4Set, sum: set4});
        sortings.push({cardObjectList: all_Color3Set, sum: set3});
        sortings.push({cardObjectList: all_Color2Set, sum: set2});

        
        sortings.sort(function(a,b){
            return (b.sum - a.sum);
        });
        
        var resultList = [];
        if (Joker.length <= 0) {
            for (let i = 0; i < sortings.length; i++) {
                if (sortings[i].cardObjectList.length >= 3) {
                    resultList = sortings[i].cardObjectList;
                    break;
                }
            }
        } else {
            if (sortings[0].cardObjectList.length == 2) {
                sortings[0].cardObjectList.push(Joker[0]);
            }
            resultList = sortings[0].cardObjectList;
        }

        return resultList;
	},
	makeImpureWithHighestCard: (userCardList, wildCard) => {
        /* +-------------------------------------------------------------------+
            desc: returns 2d array of impure sequence
            i/p : userCardList = array of cards, wildCard = wildCard
            o/p : 2d array of impure sequence
           +-------------------------------------------------------------------+ */
        var normalList = [];
        var jokerList = [];

        for (let i = 0; i < userCardList.length; i++) {
            if (userCardList[i].split('-')[0] == 'j' || parseInt(userCardList[i].split('-')[1]) == parseInt(wildCard.split('-')[1])) {
                jokerList.push(userCardList[i]);
            } else {
                normalList.push(userCardList[i]);
            }
        }

        normalList = cardsClass.sortCards(normalList, false).reverse();

        var impureList = [];
        while (normalList.length > 0 && jokerList.length >= 2) {
            var foundList = [];
            let ind = gbClass.containsCardNo(normalList, 1);
            if (ind != -1) {
                foundList.push(normalList[ind]);
                normalList = _.without(normalList, normalList[ind]);
            } else {
                foundList.push(normalList[0]);
                
                normalList = _.without(normalList, normalList[0]);
            }

            foundList.push(jokerList[0]);
            foundList.push(jokerList[1]);


            jokerList.splice(0,2);

            if(foundList.length >= 3) {
                impureList.push(foundList);
            }
        }
        return impureList;
	},
	getThreeCardPure: (cardList) => {
        /* +-------------------------------------------------------------------+
            desc: returns 2d array of impure sequence
            i/p : userCardList = array of cards, wildCard = wildCard
            o/p : 2d array of impure sequence
           +-------------------------------------------------------------------+ */
        c('getThreeCardPure---------->>>cardList: ',cardList);
        var foundList = [];
        for (var i = 0; i < cardList.length; i++) {
            let current = parseInt(cardList[i].split('-')[1]);
            let next = current + 1;
            let prev = current - 1;
            c('getThreeCardPure-------->>>>>current: '+current+' next: '+next+' prev: '+prev);
            if (next == 14) {
                next = 1;
            }
            let nIndex = gbClass.containsCardNo(cardList, next);
            let pIndex = gbClass.containsCardNo(cardList, prev);

            c('getThreeCardPure------>>>nIndex: '+nIndex+' pIndex: '+pIndex);

            if (nIndex != -1 && pIndex != -1) {
                foundList.push(cardList[pIndex]);
                foundList.push(cardList[i]);
                foundList.push(cardList[nIndex]);
                break;
            }
        }
        
        
        return foundList;
	},
	getTwoCardImpure: (cardList, gapCount) => {
        /* +-------------------------------------------------------------------+
            desc: returns array of impure sequence containing 2 cards
            i/p : cardList = array of cards, gapCount = gap count
            o/p :  array of impure sequence containing 2 cards
           +-------------------------------------------------------------------+ */
        cardList = cardsClass.sortCards(cardList, false).reverse();

        var foundList = [];
        for (let i = 0; i < cardList.length; i++) {
            let current = parseInt(cardList[i].split('-')[1]);
            let next = current + gapCount;
            let prev = current - gapCount;

            
            if (next == 14) {
                next = 1;
            }
            c('getTwoCardImpure------->>>>>next: '+next+' prev: '+prev+' gapCount: '+gapCount);
            let nIndex = gbClass.containsCardNo(cardList, next);
            let pIndex = gbClass.containsCardNo(cardList, prev);
            c('getTwoCardImpure------->>>>>nIndex: '+nIndex+' pIndex: '+pIndex);
            
            if (nIndex != -1) {
                foundList.push(cardList[i]);
                foundList.push(cardList[nIndex]);
                
                break;
            } else if (pIndex != -1) {
                foundList.push(cardList[pIndex]);
                foundList.push(cardList[i]);
                break;
            }
        }
        
        
        return foundList;
	},
    getSetCardList: (cardsList, cardCount) => {
        /* +-------------------------------------------------------------------+
            desc: returns array of set  cards
            i/p : cardList = array of cards, gapCount = gap count
            o/p :  array of set  cards
           +-------------------------------------------------------------------+ */
        var foundList = [];
        for (let i = 0; i < cardsList.length; i++) {
            foundList = [];
            var current = cardsList[i];
            
            foundList.push(current);
            for (let j = i; j < cardsList.length; j++) {
                if ((!(current.split('-')[0] == cardsList[j].split('-')[0])) && (parseInt(current.split('-')[1]) == parseInt(cardsList[j].split('-')[1]))) {
                    var needToAdd = cardsList[j];
                    var canAdd = true;
                    for (let k = 0; k < foundList.length; k++) {
                        if (needToAdd.split('-')[0] == foundList[k].split('-')[0] && parseInt(needToAdd.split('-')[1]) == parseInt(foundList[k].split('-')[1])) {
                            canAdd = false;
                        }
                    }

                    if (canAdd) {
                        foundList.push(cardsList[j]);
                        if (foundList.length >= 4 || foundList.length >= cardCount) {
                            break;
                        }
                    }
                }
            }

            if (foundList.length >= cardCount) {
                break;
            }
        }

        if (foundList.length <= 1) {
            foundList = [];
        }
        
        return foundList;
    },
    containsCardNo: (cards, number) => {
        /* +-------------------------------------------------------------------+
            desc: returns index of card containg given number
            i/p : cards = array of cards, number = card rank
            o/p : index of given card
           +-------------------------------------------------------------------+ */
        for (let i = 0; i < cards.length; i++) {
            if (parseInt(cards[i].split('-')[1]) == number) {
                return i;
            }
        }
        return -1;
    },
    containsCardNoType : (cards, number, type) => {
        /* +-------------------------------------------------------------------+
            desc: returns index of card containg given number and type 
            i/p : cards = array of cards, number = card rank, type = card suit
            o/p : index of given card
           +-------------------------------------------------------------------+ */
        for (let i = 0; i < cards.length; i++) {
            if (parseInt(cards[i].split('-')[1]) == number && cards[i].split('-')[0] == type)
            {
                return i;
            }
        }
        return -1;
    }
}